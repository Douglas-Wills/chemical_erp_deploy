"""Regression checks using the local Frappe context and read-only transactions."""
import importlib
import json
import logging
import sys
import unittest
from unittest.mock import patch

import frappe


class RuntimeRegressions(unittest.TestCase):
    def test_profile_cache_reused_and_invalidated(self):
        from chemical_erp.company import get_profile
        from chemical_erp.chemical_core.doctype.company_profile.company_profile import CompanyProfile
        frappe.local._chem_profiles = {}
        first = get_profile()
        self.assertIs(first, get_profile())
        CompanyProfile({"doctype": "Company Profile"}).on_update()
        self.assertEqual(frappe.local._chem_profiles, {})
        self.assertIsNot(first, get_profile())

    def test_certificate_company_placeholder(self):
        from chemical_erp.company import fill
        with patch("chemical_erp.company.company_name", return_value="EXAMPLE CHEMICALS"):
            self.assertEqual(fill("Issued by {company}.", frappe._dict(company="Example")), "Issued by Example Chemicals.")
            self.assertEqual(fill(None), "")

    def test_tender_keyword_cache_and_categories(self):
        from chemical_erp.tenders_desk.scanner import _settings
        settings = frappe._dict(scope_keywords=[frappe._dict(keyword=" Chlorine ", kind="Include", weight=3, category="Chemicals")], country_terms="Uganda")
        with patch.object(frappe, "get_cached_doc", return_value=settings):
            actual, keywords, terms = _settings()
        self.assertIs(actual, settings)
        self.assertEqual(frappe.local._tender_kw_category, {"chlorine": "Chemicals"})
        self.assertEqual(keywords[0][2], 3)
        self.assertEqual(terms, ["Uganda"])

    def test_return_to_service_controller_name(self):
        module = importlib.import_module("chemical_erp.plant_maintenance.doctype.return_to_service.return_to_service")
        self.assertTrue(callable(getattr(module, "Return to Service".replace(" ", ""))))

    def test_fully_discounted_invoice_line_stays_zero(self):
        from chemical_erp.integrations.efris import build_invoice_content
        inv = frappe.get_doc({"doctype": "Sales Invoice", "name": "AUDIT-INVOICE", "customer": "Audit Customer", "company": "Audit Company", "currency": "UGX", "posting_date": "2026-10-10", "net_total": 100, "total_taxes_and_charges": 18, "grand_total": 118,
                              "items": [{"name": "free", "item_code": "ITEM", "item_name": "Item", "qty": 1, "amount": 100, "net_amount": 0, "uom": "Kg"},
                                        {"name": "paid", "item_code": "ITEM", "item_name": "Item", "qty": 1, "amount": 100, "net_amount": 100, "uom": "Kg"}],
                              "taxes": [{"item_wise_tax_detail": json.dumps({"ITEM": [18, 18]})}]})
        settings = frappe._dict(efris_tin="audit", efris_device_no="audit")
        with patch.object(frappe, "get_cached_doc", return_value=frappe._dict(customer_name="Audit Customer")), \
             patch.object(frappe, "get_cached_value", side_effect=lambda dt, name, field: "123" if field == "efris_commodity_code" else "Kg"):
            payload = build_invoice_content(inv, settings)
        goods = payload["goodsDetails"]
        self.assertEqual(float(goods[0]["total"]), 0)
        self.assertEqual(float(goods[0]["tax"]), 0)
        self.assertEqual(float(goods[1]["tax"]), 18)
        self.assertEqual(sum(float(g["total"]) for g in goods), float(payload["summary"]["netAmount"]))

    def test_field_lab_denies_guest_and_unrelated_roles(self):
        from chemical_erp.field_laboratory.offline import _check_access
        user = frappe.session.user
        try:
            frappe.set_user("Guest")
            with self.assertRaises(frappe.PermissionError):
                _check_access()
            frappe.set_user("Administrator")
            with patch.object(frappe, "get_roles", return_value=["Sales User"]):
                with self.assertRaises(frappe.PermissionError):
                    _check_access()
            with patch.object(frappe, "get_roles", return_value=["Field Technician"]):
                _check_access()
        finally:
            frappe.set_user(user)

    def test_confidential_records_denied_to_non_owners(self):
        from chemical_erp.controls.confidentiality import has_permission
        with patch("chemical_erp.controls.confidentiality.is_formula_owner", return_value=False):
            self.assertFalse(has_permission(frappe._dict(is_confidential=1), user="test@example.invalid"))
            self.assertIsNone(has_permission(frappe._dict(is_confidential=0), user="test@example.invalid"))

    def test_bulk_refresh_preserves_savepoints_and_continues(self):
        from chemical_erp.controls import approvals
        meta = frappe._dict(has_field=lambda field: field == "approval_level")
        docs = {name: frappe._dict(doctype="Purchase Order", name=name, meta=meta, docstatus=0, approval_level="None") for name in ("audit-1", "audit-2")}
        seen = []
        def transition(doc, action):
            seen.append(doc.name)
            if doc.name == "audit-1":
                raise frappe.ValidationError("Expected test rejection")
        def refresh(doc):
            doc.approval_level = "MD"
        # Real MariaDB savepoints catch accidental commits during refresh;
        # the only potential business write and workflow execution are mocked.
        with patch.object(frappe, "get_doc", side_effect=lambda dt, name: docs[name]), \
             patch.object(frappe, "get_meta", return_value=meta), \
             patch.object(frappe.db, "set_value") as write, \
             patch.object(frappe.db, "commit", wraps=frappe.db.commit) as commit, \
             patch.object(approvals, "set_approval_level", side_effect=refresh), \
             patch("frappe.model.workflow.apply_workflow", side_effect=transition), \
             patch.object(frappe, "msgprint") as message:
            approvals._bulk(list(docs), "Purchase Order", "Approve")
            self.assertEqual(write.call_count, 2)
            self.assertEqual(commit.call_count, 1)
            self.assertEqual(seen, ["audit-1", "audit-2"])
            self.assertIn("Expected test rejection", message.call_args.args[0])
            self.assertNotIn(approvals.PENDING, frappe.flags)


if __name__ == "__main__":
    frappe.logger = lambda *args, **kwargs: logging.getLogger("regression_audit")
    frappe.init(site="chemical.local", sites_path="/Users/mugenyidarglous/frappe-bench/sites")
    frappe.connect()
    frappe.set_user("Administrator")
    frappe.db.sql("SET SESSION TRANSACTION READ ONLY")
    try:
        outcome = unittest.main(exit=False, verbosity=2)
    finally:
        frappe.db.rollback()
        frappe.destroy()
    sys.exit(not outcome.result.wasSuccessful())
