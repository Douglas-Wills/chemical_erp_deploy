"""Repeatable static and read-only runtime checks for the extracted local app.

Run with the Frappe bench Python. Runtime checks require access to the local DB/Redis.
No business documents are saved, submitted, cancelled or sent by this script.
"""
import argparse
import ast
import importlib
import json
import logging
import pathlib
import re
import subprocess
import traceback
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

ROOT = pathlib.Path(__file__).resolve().parents[1]
APP = ROOT / "chemical_erp"
results = {"passed": Counter(), "failures": [], "notes": []}


def check(group, name, fn):
    try:
        fn()
        results["passed"][group] += 1
    except Exception as exc:
        results["failures"].append({"group": group, "name": str(name), "error": str(exc),
                                    "traceback": traceback.format_exc(limit=6)})


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def module_name(path):
    return ".".join(path.relative_to(ROOT).with_suffix("").parts)


def static():
    for path in APP.rglob("*.py"):
        check("python_syntax", path.relative_to(ROOT), lambda p=path: ast.parse(p.read_text(), str(p)))
    def js(path):
        proc = subprocess.run(["node", "--check", str(path)], capture_output=True, text=True)
        return path, proc
    with ThreadPoolExecutor(max_workers=6) as pool:
        for path, proc in pool.map(js, APP.rglob("*.js")):
            check("javascript_syntax", path.relative_to(ROOT), lambda p=proc: require(p.returncode == 0, p.stderr))
    def pairs(items):
        keys = [k for k, v in items]
        require(len(keys) == len(set(keys)), "Duplicate JSON object keys")
        return dict(items)
    for path in APP.rglob("*.json"):
        check("json", path.relative_to(ROOT), lambda p=path: json.loads(p.read_text(), object_pairs_hook=pairs))
        doc = json.loads(path.read_text())
        if not isinstance(doc, dict) or doc.get("doctype") != "DocType":
            continue
        def definition(doc=doc):
            fields = [f["fieldname"] for f in doc.get("fields", [])]
            require(len(fields) == len(set(fields)), "Duplicate fieldnames")
            require(set(doc.get("field_order", [])) == set(fields), "field_order differs from fields")
        check("doctype_definition", doc["name"], definition)


def runtime():
    import frappe
    from frappe.model import no_value_fields
    from frappe.model.base_document import get_controller
    frappe.logger = lambda *args, **kwargs: logging.getLogger("project_audit")
    frappe.init(site="chemical.local", sites_path="/Users/mugenyidarglous/frappe-bench/sites")
    frappe.connect()
    frappe.set_user("Administrator")
    frappe.db.sql("SET SESSION TRANSACTION READ ONLY")
    # Surface swallowed exceptions without inserting Error Log records.
    frappe.log_error = lambda *args, **kwargs: results["notes"].append({"caught_error": kwargs.get("title", str(args[:1])), "message": kwargs.get("message", "")})
    try:
        import chemical_erp
        require(pathlib.Path(chemical_erp.__file__).resolve().is_relative_to(ROOT), "Wrong app copy imported")
        results["version"] = chemical_erp.__version__
        results["source"] = str(ROOT)
        for path in APP.rglob("*.py"):
            check("module_import", module_name(path), lambda p=path: importlib.import_module(module_name(p)))
        from chemical_erp import hooks
        def strings(value):
            if isinstance(value, str):
                yield value
            elif isinstance(value, dict):
                for sub in value.values():
                    yield from strings(sub)
            elif isinstance(value, (list, tuple)):
                for sub in value:
                    yield from strings(sub)
        names = ["doc_events", "scheduler_events", "permission_query_conditions", "has_permission", "override_whitelisted_methods", "jinja", "page_renderer", "after_install", "after_migrate", "boot_session", "on_login"]
        refs = {v for n in names for v in strings(getattr(hooks, n, {})) if v.startswith("chemical_erp.")}
        for ref in sorted(refs):
            check("hook_target", ref, lambda r=ref: require(callable(frappe.get_attr(r)), "Target is not callable"))
        for path in APP.rglob("*.json"):
            doc = json.loads(path.read_text())
            if not isinstance(doc, dict) or doc.get("doctype") != "DocType":
                continue
            name = doc["name"]
            def schema(doc=doc, name=name):
                require(frappe.db.exists("DocType", name), "DocType not installed")
                if not doc.get("issingle"):
                    cols = set(frappe.db.get_table_columns(name))
                    missing = [f["fieldname"] for f in doc.get("fields", []) if f["fieldtype"] not in no_value_fields and f["fieldname"] not in cols]
                    require(not missing, f"Missing columns: {missing}")
                for field in doc.get("fields", []):
                    if field["fieldtype"] in ("Link", "Table", "Table MultiSelect"):
                        target = field.get("options")
                        require(frappe.db.exists("DocType", target), f"Missing link/table target {target}")
                        if field["fieldtype"] != "Link":
                            require(frappe.get_meta(target).istable, f"{target} is not a child table")
            check("installed_schema", name, schema)
            check("doctype_controller", name, lambda n=name: get_controller(n))
        from chemical_erp.setup.install import custom_fields
        for dt, fields in custom_fields().items():
            for field in fields:
                check("custom_field", f"{dt}.{field['fieldname']}", lambda dt=dt, f=field: require(frappe.get_meta(dt).has_field(f["fieldname"]), "Custom field missing"))
        for path in APP.glob("*/report/*/*.py"):
            if path.name == "__init__.py":
                continue
            mod = importlib.import_module(module_name(path))
            if hasattr(mod, "execute"):
                check("report_empty_filters", module_name(path), lambda m=mod: m.execute(frappe._dict()))
        calls = [
            ("chemical_erp.dashboard.data.get_dashboard", ()),
            ("chemical_erp.dashboard.calendar.agenda", ()),
            ("chemical_erp.field_laboratory.offline.bootstrap", ()),
            ("chemical_erp.help.search.search", ("batch",)),
            ("chemical_erp.help.search.contents", ()),
            ("chemical_erp.controls.limits.suggest", ()),
            ("chemical_erp.tenders_desk.scanner._settings", ()),
            ("chemical_erp.www.quick_order.get_context", (frappe._dict(),)),
            ("chemical_erp.www.my_documents.get_context", (frappe._dict(),)),
            ("chemical_erp.www.approvals.get_context", (frappe._dict(),)),
            ("chemical_erp.www.driver.get_context", (frappe._dict(),)),
            ("chemical_erp.chemical_core.quick_orders.page_data", ()),
            ("chemical_erp.company.get_profile", ()),
        ]
        for ref, args in calls:
            check("read_only_smoke", ref, lambda r=ref, a=args: frappe.get_attr(r)(*a))
        from chemical_erp.chemical_core.doctype.company_profile.company_profile import CompanyProfile
        check("profile_callback", "CompanyProfile.on_update", lambda: CompanyProfile({"doctype": "Company Profile"}).on_update())
        from frappe.utils.jinja import get_jenv
        env = get_jenv()
        for path in APP.rglob("*"):
            source = None
            if path.suffix == ".html":
                source = path.read_text()
            elif path.suffix == ".json":
                doc = json.loads(path.read_text())
                if isinstance(doc, dict) and doc.get("doctype") == "Print Format":
                    source = doc.get("html")
            if source:
                check("jinja_syntax", path.relative_to(ROOT), lambda s=source: env.parse(s))
        refs = set()
        for path in APP.rglob("*.js"):
            refs.update(re.findall(r'''["'](chemical_erp\.[a-zA-Z0-9_.]+)["']''', path.read_text()))
        for ref in sorted(refs):
            if ref.endswith("."):
                results["notes"].append({"dynamic_js_prefix_skipped": ref})
                continue
            def endpoint(ref=ref):
                fn = frappe.get_attr(ref)
                require(callable(fn), "Not callable")
                require(fn in frappe.whitelisted, "Not whitelisted")
            check("js_api_target", ref, endpoint)
        results["setup_problems"] = frappe.cache().get_value("chem_setup_problems")
    finally:
        frappe.db.rollback()
        frappe.destroy()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["static", "runtime"])
    parser.add_argument("--output", type=pathlib.Path, required=True)
    args = parser.parse_args()
    try:
        globals()[args.mode]()
    finally:
        args.output.write_text(json.dumps(results, indent=2, default=str))
        print(json.dumps({"passed": results["passed"], "failures": [{k: v for k, v in f.items() if k != "traceback"} for f in results["failures"]], "notes": results["notes"]}, indent=2, default=str))
