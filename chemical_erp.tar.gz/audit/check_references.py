"""Read-only verification of literal field references and installed workflows."""
import ast
import json
import logging
import pathlib
import re

import frappe

root = pathlib.Path(__file__).resolve().parents[1]
result = {"field_references_checked": 0, "field_issues": [], "workflows_checked": 0, "workflow_issues": []}


def literal(node):
    try:
        return ast.literal_eval(node)
    except (ValueError, TypeError):
        return None


def field_check(doctype, field, location):
    if not isinstance(field, str) or not re.fullmatch(r"[a-zA-Z_]\w*", field):
        return
    # Singles is a storage table, not a DocType.
    if doctype == "Singles":
        return
    meta = frappe.get_meta(doctype)
    columns = set(meta.get_valid_columns()) | {f.fieldname for f in meta.fields}
    result["field_references_checked"] += 1
    if field not in columns:
        result["field_issues"].append({"at": location, "doctype": doctype, "field": field})


frappe.logger = lambda *args, **kwargs: logging.getLogger("reference_audit")
frappe.init(site="chemical.local", sites_path="/Users/mugenyidarglous/frappe-bench/sites")
frappe.connect()
frappe.set_user("Administrator")
frappe.db.sql("SET SESSION TRANSACTION READ ONLY")
try:
    for path in (root / "chemical_erp").rglob("*.py"):
        for node in ast.walk(ast.parse(path.read_text())):
            if not isinstance(node, ast.Call) or not node.args:
                continue
            name = ast.unparse(node.func)
            if name not in {"frappe.db.get_value", "frappe.db.get_single_value", "frappe.db.set_value", "frappe.db.set_single_value", "frappe.get_cached_value", "frappe.get_all", "frappe.get_list", "frappe.db.exists", "frappe.db.count"}:
                continue
            dt = literal(node.args[0])
            if not isinstance(dt, str) or not frappe.db.exists("DocType", dt):
                continue
            location = f"{path.relative_to(root)}:{node.lineno}"
            kws = {kw.arg: literal(kw.value) for kw in node.keywords}
            fields = None
            if name.endswith(("get_single_value", "set_single_value")) and len(node.args) > 1:
                fields = literal(node.args[1])
            elif name.endswith(("get_value", "get_cached_value", "set_value")) and len(node.args) > 2:
                fields = literal(node.args[2])
            else:
                fields = kws.get("fields") or kws.get("fieldname") or kws.get("pluck")
            if isinstance(fields, dict):
                fields = list(fields)
            for field in fields if isinstance(fields, (list, tuple)) else [fields]:
                field_check(dt, field, location)
            filters = kws.get("filters")
            if filters is None and len(node.args) > 1 and not name.endswith(("get_single_value", "set_single_value")):
                filters = literal(node.args[1])
            if isinstance(filters, dict):
                for field in filters:
                    field_check(dt, field, location)
    for name in frappe.get_all("Workflow", filters={"is_active": 1}, pluck="name"):
        wf = frappe.get_doc("Workflow", name)
        result["workflows_checked"] += 1
        try:
            wf.validate_docstatus()
            meta = frappe.get_meta(wf.document_type)
            assert meta.has_field(wf.workflow_state_field), "Missing workflow_state field"
            for state in wf.states:
                assert frappe.db.exists("Role", state.allow_edit), f"Missing role {state.allow_edit}"
                if state.update_field:
                    assert meta.has_field(state.update_field), f"Missing state update field {state.update_field}"
            for transition in wf.transitions:
                assert frappe.db.exists("Role", transition.allowed), f"Missing transition role {transition.allowed}"
                if transition.condition:
                    compile(transition.condition, name, "eval")
                    for node in ast.walk(ast.parse(transition.condition, mode="eval")):
                        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "doc":
                            field_check(wf.document_type, node.attr, f"Workflow {name}")
        except Exception as exc:
            result["workflow_issues"].append({"workflow": name, "error": str(exc)})
finally:
    frappe.db.rollback()
    frappe.destroy()
    (root / "audit/references.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
