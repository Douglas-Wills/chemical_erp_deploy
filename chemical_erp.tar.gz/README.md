# Chemical ERP (`chemical_erp`)

One Frappe app that turns ERPNext v15 into Brave Chemicals' manufacturing and distribution system, built to the System Design Specification. ERPNext and Frappe HR are extended, never modified.

| Module | What it does |
| --- | --- |
| Chemical Core | Batch QC status and QC zones; two-signature release; delivery hard stops; approval routing with segregation of duties (the Managing Director signs last); confidential formulas with time-limited delegation; potency, substitutes, co-products; waste and Disposal Orders with accrual accounting; batch genealogy and recall trace; Estimate Requests; Credit Limit Requests; EFRIS |
| Regulatory Compliance | Substance Register, English SDS files with MD approval, Deviations and CAPA linked to the IMS procedure breached, training requirements, staff certifications, product labels |
| Management Systems | IMS Document register (85 documents), Legal Requirement register (31 entries) with permit expiry and operational gates, Compliance Watch Items (6), review reminders and the weekly HSE digest |
| Plant Maintenance (sidebar: Maintenance) | Equipment register, calibration with failed-calibration impact review, PM schedules, breakdowns, Return to Service |
| Tenders Desk | Tender tracking, bid prep, costing, bid security, Claude notice reading (ported unchanged) |
| Learning | Training needs raised automatically from HR and compliance records, training programs with self-paced material, online training sessions in a video room inside ERPNext, attendance logging, and certificates issued on passing |
| People Management (sidebar: HR Management) | Brave HR merged with Frappe HR: staff details, contracts, insurance, Uganda payroll (PAYE, NSSF, LST), reading Frappe HR attendance and unpaid leave |
| Documents (sidebar: Documents) | Centralized document repository, uploads, multi-format preview and storage, secure WhatsApp/Email/Link sharing with SuperAdmin-controlled access durations, expiration countdowns, passcode protection, and access audit logs |

**How the modules connect:**
- **Lapsed permits gate operations.** A Legal Requirement with an expiry date and *Checked On* set (Disposal, Delivery or Production) either warns or blocks that operation once the permit lapses. Permits nearing expiry are flagged daily to the HSE Officer and MD.
- **Deviations name the procedure breached.** Each Deviation links to the IMS Document it relates to.
- **Tenders reuse the registers.** Tender readiness checks permits and documents against the Legal Requirement and IMS Document records, so nothing is held twice.

## Version 1.0.7: laboratory roles

Laboratory staff no longer get ERPNext's "Quality Manager" role (which can also delete and cancel inspections and read assets, cost centres and accounts, and was easy to confuse with Chemical ERP's QC Manager). Instead:
- **QC Analyst** (post): roles QC Analyst + Laboratory Technician: enters and signs inspection results.
- **Laboratory Assistant** (access profile): role **Laboratory Technician**: creates inspections and enters readings, cannot sign.
- **QC Manager**: the quality approver once quality is switched to the QC Manager in Chemical ERP Settings.
Inspection drafts are edited by Laboratory Technicians (before, only QC Analysts could, so lab assistants could not enter readings). A migration patch moves existing posts, profiles and grants across. "Quality Manager" on certificates is only the printed job title.

## Version 1.0.6: consistency review

A full review of the app against itself, its Help and README, and Frappe/ERPNext/HRMS v15. Fixed:

**Approvals (the most important).** Frappe v15 has no `before_transition` document event, so the approval checks were never running: no self-approval check, no delegation limits, no expense routing, no OOS rule, and no Approval Log (so Certificates of Analysis would always print NOT VALID). The checks now run on every workflow action (desk, bulk approval, `/approvals`, or any other path) from `validate` / `before_cancel` / `before_update_after_submit`, with `apply_workflow` and `bulk_workflow_approval` overridden to pass along the action chosen. Also:
- the approval route is re-checked against the approval level worked out at that moment (limits changed, or the 48-hour MD hold after a payee's bank details change), and the level is refreshed before actions are offered;
- workflow cancel roles (e.g. only the MD cancels an approved PO) are enforced, also for cancels made through the API;
- the MD's delegate can give final approval on expense claims; the delegate role cannot be passed on to anyone;
- the payment limit applies to payments out only (customer receipts no longer wait for the MD);
- "Submit Report" counts as the author's own step (internal audits).

**Approvals lists.** Frappe v15 records pending approvals by role, not user, so `/approvals`, the dashboard list, the weekly reminder and the Approval Aging report were always empty. Fixed; colleagues' unsent drafts are not shown as waiting for you.

**Deleting.** The audit trail (Deleted Document, Version, Activity Log, Access Log) can no longer be deleted from the screens or API; system records (User Permission, File, Share…) follow Frappe's own permissions instead of being open to everyone; the MD can delete in every Chemical ERP document type; the v2 API is covered.

**Money and records.**
- Commission paid through payroll is recorded from the submitted payslips, and a run will not submit if commission was added after its payslips were calculated.
- A sale keeps the commission agreement it was booked under: ending an agreement no longer reverses up to 60 days of commission.
- EFRIS: each line's VAT comes from the invoice's own tax breakdown (zero-rated items were sent at 18%), lines add up to the totals after discount, and a fiscalised invoice cannot be cancelled (issue a credit note).
- Document exceptions cannot be widened after the MD decides; the 14 days count from the decision.
- Cancelling a batch inspection (quality approver or MD only) puts the batch back in Quarantine.

**One rule, one place.** Waste thresholds are shared by production and the variance report; items counted in pieces use ERPNext's Weight Per Unit (no longer 1 kg each); the SDS review period comes from Chemical ERP Settings everywhere; recall closing and product classification follow the quality approver setting; Missing Attachments uses the Document Profile rules (the old "every chemical needs a CoA and SDS" check was removed); the excess-waste button shows to the Plant Manager and the MD, matching the server.

**Help and README.** Corrected 30+ statements (menus, buttons, days, who signs), added the missing **Make Landed Cost Voucher** button on Import Shipment, fixed Help "Open …" buttons that pointed at non-existent screens, added Expense Pattern Review to HR Management > Expenses, and unified names (Client Water Systems; Documents to Be Supplied With the Goods).

Checked afterwards: every field name in the Python code (about 670 calls) and the screens (158 references) exists on its document; every settings field read exists; every server call from the screens exists and is whitelisted; every role used exists or is created by setup.

## Version 1.0.4: house-style PDFs (earlier preview style)

Prints in the earlier system style: no signature block, QR centred under the document. Fiscalised invoices and credit notes show only URA's EFRIS QR (Brave's verification QR is left off them, so there is one QR per document).

## Version 1.0.3: house-style PDFs

Quotations, sales orders, delivery notes, invoices and credit notes, purchase orders, requests for quotation, receipts and payment vouchers are produced as PDFs in the house style of Brave's existing documents (QUO-000367-26, INV-000283-26).
- **One shared layout** (`templates/print/house_style.html`) for all of them: logo and title, company and customer blocks, grey item table, totals, amount in words, notes and the verification QR centred below. Change it once, every document follows.
- **Saved automatically** on each document when it is approved (submitted), named like `QUO-000367-26_MERU_QUOTATION.pdf`; invoices once EFRIS returns the fiscal number; re-saved marked CANCELLED on cancel. **⬇ PDF** on the form downloads it any time. E-mails attach the same PDF.
- **Credit notes / goods returns** print with positive figures under their own titles.
- The logo is embedded in the PDF, so they never go missing when the server cannot fetch its own URL.

## Version 1.0.2: repetition removed

**Do not install the old separate apps alongside this one.** `brave_hr`, `brave_tenders` and `hr_management` were earlier versions; their contents now live inside Chemical ERP, so installing them as well shows every HR and Tenders module twice (and `hr_management` adds a second, older payroll). If any is on the bench: `bench --site <site> uninstall-app <app>`, then `bench remove-app <app>`.

Within Chemical ERP:
- **Sidebar:** each item now has one home. Removed the Management Systems card repeated inside Regulatory Compliance, the Competence card (training lives in Learning, staff in HR Management), and six items listed twice in the same workspace (Work Order, Batch Margin, Chemical ERP Settings, Go-Live Readiness, Company Position, Tender). Vehicles live in Maintenance; Business Diagnostics in Management Systems (and on the MD's dashboard). Kept on purpose in two places: My Dashboard, and Equipment, Calibration Record and Reagent Solution (used by both the plant laboratory and the field laboratory).
- **Tender Scan Settings** is now the *Tender Scanning* section of **Tender Settings** (one settings page for the Tenders Desk); values and scope keywords move across automatically.
- **Missing Current SDS** report removed: **Document Gaps** covers it and more.
- Calendar events use ERPNext's own *Location* field instead of a second one.
- Code: one shared copy of helpers that had been copied between modules.

**Standard modules we replace are hidden** (not deleted): ERPNext *Quality* and HRMS *Payroll*, *Salary Payout*, *Tax & Benefits*. Chemical ERP Settings > Standard Modules > untick *Hide Standard Modules We Replace* to show them again.

## Version 1.0.1: install fixes (read this if 1.0.0 did not install)

1.0.0 stopped part-way through installing, so none of its modules appeared. The causes, now fixed:

- **Two custom fields used names ERPNext already has**: Batch `parent_batch` (now `waste_from_batch`) and Purchase Receipt `supplier_delivery_note` (now `supplier_delivery_note_file`). Frappe refuses a duplicate field name, the setup step failed, and the whole install was rolled back.
- **Two modules shared names with other apps**: our "HR" (Frappe HR's module) and "Maintenance" (ERPNext's). They are now **People Management** and **Plant Maintenance**. The sidebar workspaces keep their names (HR Management, Maintenance).
- **Setup now runs step by step.** If one step fails, the others still run and the app still installs. At the end bench prints "Chemical ERP: N of N setup steps completed" and lists any step that needs attention; details are in Error Log (search "Chemical ERP setup").

Checked against the real Frappe, ERPNext and HRMS v15 sources: no clashing names among the DocTypes, reports, print formats and workspaces; all custom fields and 21 workflows pass Frappe's own validation rules; every table is within MariaDB's row-size limit.

### Re-installing over the failed attempt
```bash
cd ~/frappe-bench
# replace the old copy with this version (keep the folder name chemical_erp)
rm -rf apps/chemical_erp && cp -r /path/to/chemical_erp apps/chemical_erp
./env/bin/pip install -e apps/chemical_erp          # registers the Python package
grep -qx chemical_erp sites/apps.txt || echo chemical_erp >> sites/apps.txt
bench --site <site> list-apps                        # is chemical_erp listed?
bench --site <site> install-app chemical_erp         # if not listed
bench --site <site> migrate                          # if it was listed
bench build --app chemical_erp && bench restart
```

## Install

```bash
cd ~/frappe-bench
bench get-app erpnext --branch version-15     # if not already present
bench get-app hrms --branch version-15
bench get-app /path/to/chemical_erp
bench --site staging.local install-app hrms
bench --site staging.local install-app chemical_erp
bench --site staging.local migrate
bench restart
```

**Install on a staging copy first.** The app was built and checked without a live ERPNext site:
- All JSON, Python and JavaScript have been checked to load and parse.
- Field names have been cross-checked against the DocTypes.
- The approval routing and validation rules have been tested in isolation.
- It has not yet run on a bench. Expect a round of fixes on the first `bench migrate` and first transactions, and send any error back for correction.

**If the separate `brave_ims`, `brave_tenders` or `brave_hr` apps are already installed on a site,** their DocTypes now live in this app. Before installing `chemical_erp`:

1. Export any data you have entered (Data Export, or a full site backup).
2. Uninstall the old app.
3. Install `chemical_erp`.

On a fresh site, the Management Systems seed data (85 documents, 31 legal requirements, 6 watch items) loads automatically into the empty tables.

## Positions and vacancy cover

Brave's posts are kept in **Company Position** (HR Management workspace). Each post lists the system roles it carries. Installation creates these posts:

- Plant Manager
- QC Manager
- QC Analyst
- HSE Officer
- Production Supervisor
- Production Assistant
- Stores Officer
- Procurement Officer
- Accounts Officer
- Technical Sales Officer
- Sales Representative
- HR Officer

**Until a post is filled, the Managing Director holds its roles.** When you recruit:

1. Open the post.
2. Add the new person as holder.
3. Save. The roles move to them and the MD's cover is withdrawn.

If the holder later leaves, remove them from the post and the MD covers it again. The system only ever removes roles it granted itself. Roles you gave someone by hand stay. Set a leaver's Employee status to Left with the relieving date: the account is then disabled automatically from that day.

**Two-person checks while the MD covers a post.** Some controls need two different people: QC Analyst then Plant Manager on batch release, Accounts Officer then MD on purchase orders, HSE Officer then the quality approver (Plant Manager) on overrides. While the MD covers the first post, the MD may sign both stages. Each signature given only because a post is vacant is logged as **"Acting for vacant position: …"**. Once the post is filled, the MD can no longer sign that stage and the normal two-person rule applies again automatically.

The Go-Live Readiness report lists every post the MD is covering.

## Approval positions: Plant Manager and QC Manager

Production and quality documents are approved by a **position**, not a named person. While those posts are unfilled, the Managing Director holds them: installation gives the MD the **Plant Manager** role.

| Plant Manager approves | Quality approver (Plant Manager today) approves |
| --- | --- |
| Work orders that differ from the sales order; waste above the formula quantity; stock reconciliations (after the HSE Officer); returns to service (after the supervisor or QC Analyst); plant equipment calibrations | Batch release and rejection (after the QC Analyst signs results); batch status overrides (after the HSE Officer); deviation closure |

**When Brave appoints a Plant Manager:** add them as holder of the Plant Manager post (see Positions and vacancy cover).

Approvals, notifications and printed titles move to them at once. Nothing is reinstalled or redeveloped, and the role is never automatically given back to the MD once someone else holds it.

**When Brave appoints a QC Manager:**
1. Add them as holder of the QC Manager post.
2. In Chemical ERP Settings, set *Quality Documents Approved By* to **QC Manager**. Saving moves the quality workflows over immediately.

Titles printed on documents come from the same settings section.

**These stay with the Managing Director personally:**
- Formula approval, because formulas are confidential to the MD and the formula delegate.
- The MD's direct approval of documents the MD raises.
- Purchase receipts, SDS files, disposal orders and other non-production approvals.

The Go-Live Readiness report checks that someone holds each position, and that the QC Analyst never also holds the quality approval role.

## The Managing Director's own documents

The Managing Director is the final authority, so anything the MD raises needs no further approval. This covers purchase orders, receipts, payments, quotations, sales orders, work orders, expense claims, disposal orders, credit limits, SDS files, stock reconciliations and status overrides. The MD chooses **Approve as MD** and the document goes straight to its approved state. Each such approval is logged as raised and approved by the Managing Director.

Two things are deliberately unchanged:
- **Batch release** still needs the QC Analyst's signed results before the MD countersigns.
- **The hard stops apply to everyone, the MD included.** No one can deliver an unreleased, expired or waste batch, deliver without a current SDS, or print an unfiscalised tax invoice.

## System permissions

**Staff accounts.** Only the **system administrator** (System Manager), the **Managing Director** and the **HR Manager** can create an employee's system account. On the Employee form, **Create System Account** creates the login, links it to the employee, gives them the roles of any post they hold, and optionally emails them to set a password. The rule is enforced on the account itself, so anyone else is refused however they try: the Users list, ERPNext's own Create User button, or turning a customer portal login into a staff account. Customer portal logins (website accounts) are not affected.

Each person's access comes from three places, all visible in the **User Access Review** report:

1. **Their post** (Company Position). Holders get the post's roles, and the MD covers vacant posts.
2. **Access Grants**, for extra work scope.
3. **Roles given by hand** by the system administrator. These are flagged for review.

**Access Grants.** Give an employee an **Access Profile** (a bundle of roles for a scope of work) or a single role.
- **Limits:** a grant can be limited to particular departments, warehouses, cost centres or companies, so the person only sees those records.
- **Temporary access:** with an end date, for example while covering someone's leave, access ends by itself. It also ends if the employee leaves.
- **Revoking:** cancelling a grant ends it at once.

Eight starting profiles are created: Stores Assistant, Sales Support, Accounts Assistant, Production Assistant, Maintenance Support, HR Assistant, Procurement Support and Laboratory Assistant. Add more for Brave's own scopes of work.

**Who may grant:**
- **Line managers** grant access to the people who report to them (set *Reports To* on each employee), directly or further down. They can only give roles they hold themselves.
- **The Managing Director** grants anything to anyone.
- **Sensitive roles are the MD's alone to give:** Managing Director, Plant Manager, QC Manager, and the manager roles (Accounts, HR, Purchase, Stock, Manufacturing, Sales, Tender), plus Expense Approver.
- **Never granted here:** System Manager (the administrator's) and Formula Owner (only through Formula Delegation).
- **Nobody grants access to themselves.**

**Roles are never removed by mistake.** A role still provided by a post, by another active grant, or given by hand stays when a grant ends.

**Permitted items make up the dashboard.** My Dashboard shows a section only to people with its roles, shows a card only if they may open that record type, and counts only the records their limits allow. When access is granted, the matching cards appear; when it ends or is revoked, they disappear.
- **Line managers** also see **My Team**: team size, active and ending access, open training needs, expense claims waiting for them, and team members without a login.
- **The MD and HR Manager** see **People and Access**: active, ending and pending grants, staff without a login, and posts the MD is covering.

## My Dashboard and calendar

Every user has **My Dashboard** (`/app/my-dashboard`, also on the apps screen and as the first shortcut on every workspace). It shows:

- **📅 My Calendar.** A month view with an agenda for the next two weeks, combining:
  - their own meetings, appointments and field visits
  - training sessions they attend or run
  - audits they lead
  - maintenance jobs assigned to them
  - expected import arrivals, for Purchasing and Stores

  New Meeting, New Appointment and New Field Visit are one click away. Attendees are invited automatically. Field visits record who was visited, where, the outcome and a follow-up date, and the visitor is reminded to write the report.
- **Waiting for my approval.** The documents waiting for this person's signature.
- **Sections for their own work.** Each card opens the list it counts:

  | Section | Shown to |
  | --- | --- |
  | My Work | Everyone: tasks, own training needs, expense claims, expiring certificates |
  | Sales and Customers | Sales staff |
  | Quality | QC Analyst, quality approver |
  | Production and Maintenance | Production and the Plant Manager |
  | Stores and Dispatch | Stores |
  | Procurement and Imports | Procurement |
  | Health, Safety, Environment and Compliance | HSE Officer |
  | Accounts | Accounts |
  | People | HR |
  | Tenders | Tender staff |

**The Managing Director sees every section**, plus a Management section: sales this month, overdue receivables, cash and bank, stock value, products selling below cost, objectives off target, complaints, incidents, high risks and the posts the MD is covering. Counts respect each user's permissions, so confidential formulas stay hidden from anyone not entitled to them.

## Customer complaints and returns

A **Customer Complaint** links to the delivery, product and batch, and draws in the batch's retained sample for testing. A major or critical quality or safety complaint opens a Deviation. Goods sent back come in on a return delivery note into a Quarantine or Rejected warehouse, never straight into released stock, and nothing in those warehouses can be delivered. Only the quality approver can close a complaint, and only once it has:
- a justified or not-justified decision
- a root cause and disposition, if justified (credit note, replacement or rework)
- the return delivery note, if goods were sent back
- the response to the customer
- every corrective action completed

Unacknowledged complaints (2 days) and long-open ones (30 days) are chased.

## Health, safety and environment

An **HSE Incident** covers injuries, near misses, spills, fires, property damage, environmental events and occupational illness. It records the people involved, any substance released, the investigation and corrective actions, and any report made to the authorities. Lost-time injuries are flagged automatically, and the dashboard counts the days since the last one. Any employee can report an incident. The HSE Officer investigates and the Plant Manager closes it. **Emergency Drills** are recorded with their results, and the next drill is scheduled (every 6 months by default).

## Imports

An **Import Shipment** follows a foreign order from proforma to receipt: payment method (including LC number and expiry), shipping, ETA, clearing agent, customs entry, and a document checklist. The checklist covers proforma, invoice, packing list, bill of lading or airway bill, certificate of origin, supplier COA and SDS, UNBS certificate of conformity, customs entry and tax assessment.

Import costs can be in any currency and are converted to UGX: freight, insurance, duty, import VAT, withholding tax, IDF, infrastructure levy, clearing, port charges, transport and UNBS fees. Import VAT and withholding tax default to *recoverable*, so they're claimed rather than added to stock. **Make Landed Cost Voucher** adds every other cost to the received stock's value, so product costing sees the true import cost. Purchasing is reminded three days before arrival, and 14 days before an LC expires.

## Retained samples and stability

Every released finished batch automatically gets a **Retained Sample**, kept until expiry plus 12 months; you can choose to keep raw-material samples too. QC is told when a sample can be disposed of. A **Stability Study** tracks one batch over time, by default at months 0, 1, 3, 6, 9, 12, 18 and 24. It reports the shelf life the results actually support, which is the evidence behind the expiry date on the COA.

## Supplier evaluation

Each approved supplier is evaluated every 12 months. A draft is created automatically when one is due.
- **Measured by the system:** on-time delivery against the order's required date (30%), and the share of batches QC accepted (40%).
- **Assessed by Procurement:** COA and SDS accuracy, responsiveness and price (30%).

A score of 80% or more rates A (Approved), 60–79% B (Conditional), and below 60% C (Not Approved). The MD approves the evaluation. A C rating removes approved status, and **chemicals can only be ordered from approved suppliers**.

## Returnable containers (optional)

Only used where wanted:
- Mark container items as returnable, optionally with a deposit.
- Tick *Returns Containers* on customers who send them back. Their deliveries then default to *Containers to Be Returned*, which can be changed on any delivery.
- Those deliveries record the containers sent out. Returns and write-offs are recorded as Container Movements.

The **Container Balance** report shows what each customer still holds and for how long. Customers and deliveries not ticked are left alone.

## Withholding tax certificates (a provision, never a gate)

Customers who withhold tax often pay it to URA late, and send their certificates around the end of the calendar year. The system therefore tracks certificates without ever holding anything up.

- **Every transaction is covered.** Tick *Deducts Withholding Tax* on customers such as government bodies and designated withholding agents. Each of their sales invoices then carries a Withholding Tax section: WHT expected (6% of the value excluding VAT, editable), status, certificate number, and a place to **attach the certificate whenever it arrives**. Any other invoice can be ticked individually too.
- **An expected certificate is opened per invoice.** When the certificate is attached, on the invoice or on the WHT Certificate, the status becomes Certificate Received. A customer payment with a deduction to the WHT receivable account confirms the WHT and links the payment.
- **One certificate can cover many invoices.** Add the invoices to one WHT Certificate, and their separate expected records are absorbed into it.
- **Follow-up is gentle, then firmer.** Accounts gets a monthly summary of certificates still owed, by customer and amount. From *Weekly WHT Follow-up From* (November by default) to year end it becomes weekly. Nothing is ever blocked, and an unattached certificate simply stays outstanding until it arrives.
- **For the tax return**, the **WHT Reconciliation** report lists every invoice for a calendar year with WHT withheld, certificates received and still outstanding. It shows totals of WHT withheld, backed by certificates, and outstanding. Record the return each certificate was claimed in.
- **Cancelling an invoice** removes its expected certificate. A received certificate is kept on record.

## Product certification (attention, never a gate)

A **Product Certification** per product records whether it falls within UNBS (or other) certification scope. Where it does, record the certificate number, dates and copy. Status is Valid, Expiring (60 days), Expired, Certificate Missing, Not in Scope or To Be Confirmed. Quotations, sales orders and delivery notes show an orange notice when a product needs attention, and **are never blocked**. HSE and Sales are reminded of expiring certificates.

## Dispatch safety

A delivery carrying hazardous goods needs a passed **Dispatch Safety Check** before it is submitted (a setting, on by default). The check covers:
- the driver's licence and hazardous-goods training
- placards, fire extinguisher, spill kit and PPE
- the load secured and incompatible chemicals segregated
- containers sealed and every package labelled
- the emergency card and SDS copies handed over

The **Transport Emergency Card** print format on the delivery note gives the driver each hazardous product's UN number, class, hazards and emergency actions, with Brave's 24-hour number.

## Laboratory

**Reagent Solutions** are recorded with preparation and expiry dates and an optional standardisation factor. An expired reagent can't be used for a reading. A failed reading opens an **OOS Investigation** automatically. A batch can only be rejected once that investigation is closed as *Confirmed Out of Specification*, after the Phase 1 checks: calculations, instrument, reagents, sample and method. If it was a laboratory error, the batch is retested instead.

## Management review, risks and objectives

- **Management Review** (every 6 months by default). **Compile Inputs from the System** gathers earlier actions, audit results, complaints, HSE performance, objectives, supplier ratings, process results, high risks and compliance gaps. The MD approves the decisions and actions, and Management Review Minutes print at 11pt with 1.15 spacing.
- **IMS Risk** scores risks and opportunities by likelihood and impact, before and after treatment, with owners, treatment actions and review dates.
- **Quality Objectives** set targets for quality, environment and safety. Built-in measures record themselves monthly: complaints, lost-time injuries, incidents, audit score, batch rejection rate, on-time delivery, supplier score and open findings. Others are entered by hand.

## Customer document portal

Customers with a website login linked to their customer record can open **/my-documents**. There they download the COA for every batch delivered to them in the last two years, and the current SDS for every product they buy. Access is checked against their own deliveries.

## ERPNext features to switch on

These are already in ERPNext and only need setting up. The Go-Live Readiness report checks each one:
- **Budgets** per cost centre for the financial year.
- **Bank reconciliation** monthly.
- **Collection reminders** (Dunning Types).
- **Asset categories** with depreciation accounts.
- **Production planning (MRP)** from sales orders.
- **Projects** for site jobs.

## Currencies

The company currency is **UGX**. Payroll, approval limits, stock values, costing and the ledger are all in UGX. Foreign currencies (USD for imports, exports and joint-venture tenders, and any other) are used on documents and converted with the exchange rate of the day.

**Set up once:**
1. Set the Company's default currency to UGX.
2. Enable USD (and any other currency used) under Currency.
3. Give every price list its currency.
4. In Accounts Settings, turn off *Allow Stale Exchange Rates*.

**Every week:** enter exchange rates under **Currency Exchange**, for example the Bank of Uganda rate. ERPNext's automatic rate service does not cover the Uganda shilling, so rates must be entered by hand. Each week the system reminds Accounts which currencies in use have no rate from the last 7 days. Any document that needs a missing rate stops and says so, rather than using a wrong one.

**How each area handles currency:**

| Area | Currency handling |
| --- | --- |
| Approval limits | Checked on company-currency amounts for purchase orders, payments, expense claims and estimate requests. An estimate in USD is converted before the limit check |
| Price floor | Compared per kg in UGX, whatever unit the line is sold in (drum, jerrycan) |
| Product costing | Foreign buying and selling price lists are converted to UGX, and selling prices to a per-kg basis, before margins are worked out |
| Disposal | Vendors may quote in any currency. Expected cost and the accrual are posted in UGX |
| Tenders | Priced in the tender's currency, with an exchange rate on the tender. Supplier costs from quotations are converted into the bid currency, and the bid value is also shown in UGX |
| EFRIS | Invoices are sent in their own currency. Before invoicing in a foreign currency through the offline enabler, confirm the currency and exchange-rate fields with URA's specification |

The Go-Live Readiness report checks all of the above.

## Product costing

**Cost Elements** list every cost besides materials. Each has a category, a basis and a default rate:

| Basis | How it is charged |
| --- | --- |
| Per kg of output | rate × batch size |
| Per batch | rate, once per batch |
| Per pack | rate × number of packs (batch size ÷ pack size) |
| Per labour hour | rate × hours per batch |
| % of material cost | percentage of the raw material cost |
| Per month (spread over volume) | monthly amount × batch size ÷ expected monthly output |

Installation creates eight starting elements with rates at zero: direct labour, production overheads, electricity and water, container, labels and caps, QC testing, delivery and administration overhead. The MD or Accounts sets the rates. Any element can be added, changed or retired at any time without development. A packaging element can follow a packaging item's stock value, so its rate updates as you buy.

**Product Costing tab on the formula.** Every BOM has a **Product Costing** tab:
- **Materials** come from the formula itself, with packaging items in it shown separately.
- **Cost items:** a new formula gets every active cost element (direct labour, electricity, water, containers, labels and caps, production overheads, QC testing, delivery, administration). Change any rate there, or add rows for further cost items. Rates can be changed even after the formula is approved.
- **Waste and co-products:** disposal cost is added and co-products are credited.
- **Results:** total per batch, per kg and per pack, and a suggested price at the target margin. **Make Standard Cost Sheet** turns the tab into the product's standard cost. Product Costing is also on ERPNext's own Manufacturing workspace.

**Product Cost Sheet** costs one product:
- **Materials** come from its approved formula at the chosen prices: valuation rate, last purchase rate or a buying price list. A premix or other sub-formula is costed as one line at its own formula's cost, so the confidential recipe is never shown.
- **Other costs.** All active elements are added with their default rates. Change any rate, quantity or batch size on the sheet to test a scenario.
- **Waste and co-products.** Waste disposal cost from the formula is added, and co-products are credited.
- **Results:** cost per batch, per kg and per pack; the current selling price and margin; and a suggested price for the target margin (margin on selling price).
- **Refresh Prices** reloads today's material prices and element rates.

**Make Standard Cost** (MD or Accounts Manager) marks a sheet as the product's current standard and supersedes the previous one. **Set Price Floor to Cost** (MD only) sets the product's price floor to its cost per kg, so quotes and orders below cost go to the Sales Manager for approval.

**Into stock value.** Elements ticked *Add to Stock Value on Manufacture*, with an absorbed cost account, are added to every manufacture entry from the standard cost, scaled to the quantity made. Finished stock then carries labour and overheads, not just materials. Costs already entered on the manufacture entry are never replaced.

**Reports:**
- **Product Cost Summary** lists every product's cost against its price, flagging selling below cost, missing prices and margins below target.
- **Batch Margin** now compares each batch's actual cost with its standard cost.

## Document QR codes

Quotations (**Quotation (House Style)**), tax invoices (**Tax Invoice (EFRIS)**) and purchase orders (**Purchase Order (House Style)**) print with a QR code centred at the end of the document. Installation makes them the default print formats.

**Scanning always returns the document itself**, as a PDF and with no login. A status stamp in the upper corner says what state it is in:

| Stamp | Meaning |
| --- | --- |
| **FINAL COPY** | Issued and unchanged since this copy was printed (with the time it was verified) |
| **ALTERED** | Changed since this copy was printed. The current version is shown, so the reader can compare it with their paper copy |
| **DRAFT** | Not yet issued |
| **CANCELLED** | No longer valid, with the replacement named if the document was amended |

**How ALTERED is detected.** Each code carries a fingerprint of what was printed: the party, date, currency, every line's item, quantity and price, and the total. A scan compares it with the document today. Administrative updates that don't change the printed content (EFRIS number, WHT certificate, attachments) don't count as alterations. Codes printed before this feature open as usual, without the alteration check.

**Tampered codes.** Each code is signed with the site's own key. A code that has itself been tampered with, such as a changed document number, gets "not recognised" and no document. Document numbers run in sequence, so returning whatever a forged code names would let anyone browse every customer's documents.

**Scan log.** Every scan is recorded in **Document Scan**: document, stamp (Final Copy, Altered, Draft, Cancelled or Not recognised), time and device. Repeated rapid scanning is rate-limited.

**On printed copies.** Draft and cancelled documents show the same corner stamp when printed normally.

**EFRIS on the tax invoice.** URA's EFRIS code prints as a scannable QR image beside the fiscal document number. Once an invoice is fiscalised, only URA's QR is printed (Brave's verification QR is left off), so there is one QR per document.

**Receipts.** Customer payments print as a **RECEIPT** (*Receipt (House Style)*, the default for payment entries), in the same layout as the quotation and invoice. It shows:
- the RCT number and "Received From:" with the customer's address and VAT number
- the receipt date, payment method, bank or cheque reference, and who received it
- the invoices settled (with the customer's PO), plus any advance
- any withholding tax the customer deducted, with a note that the certificate is awaited
- the amount received, the amount in words, and the verification QR code

Supplier payments use the same template as a **PAYMENT VOUCHER** with "Paid To:".

**The templates** follow Brave's existing quotation and invoice layout:
- the Brave Chemicals logo at top left, and the title (ESTIMATE, INVOICE or PURCHASE ORDER) at top right, with the number and the status under it (DRAFT, UNPAID, PAID and so on). The scan stamp appears there too.
- Brave's company block on the left, and the customer ("To" / "Bill To:") or supplier on the right with their VAT number or TIN, followed by the dates and the sale agent.
- a grey-banded item table (#, Item with its description, Qty such as "40 bags", Rate, Amount in the form UGX750,000), and totals on the right with Total and Amount Due in grey bands.
- the amount in words ("With words: … UGX"), and the QR code centred at the end.

The invoice adds Brave's bank details as a note, the customer's PO number, and the URA EFRIS fiscal number, verification code and EFRIS QR once fiscalised. Until then it is marked "NOT A TAX INVOICE". The LPO marks hazardous lines and states the order's conditions (COA and English SDS with every chemical; goods received into quarantine). No signature block is printed.

The logo, company block, bank details and quotation title (ESTIMATE by default) are set in the **Company Profile** (Branding, Bank Accounts, Documents).

The QR images are drawn with `pyqrcode`, which ships with Frappe.

**Where QR codes point.** Chemical ERP Settings → *QR Link Address*. Brave's is `https://bravechemicals.com/system`, so a code opens `https://bravechemicals.com/system/api/method/chemical_erp.doc_qr.v?c=…`. Only QR codes use this address; email and other links keep the site's own address. If the address is ever changed, keep the old one working too, since codes already printed carry it.

ERPNext can't run inside a folder of another website, so the web server at bravechemicals.com must pass `/system/` through to the ERP server, removing the `/system` prefix. For nginx:

```nginx
location /system/ {
    proxy_pass https://ERP-SERVER-ADDRESS/;      # the trailing slash removes /system
    proxy_set_header Host ERP-SITE-NAME;          # the Frappe site name, e.g. erp.bravechemicals.com
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto https;
}
```

Scans return the document as a PDF, which works fully through this path. The short "not recognised" message page is still readable, but without the site's styling. If bravechemicals.com is on shared hosting that can't forward requests, use a subdomain instead (e.g. `https://system.bravechemicals.com`, pointed at the ERP server) and enter that as the QR Link Address.

## Required attachments

| Record | Attachment | When |
| --- | --- | --- |
| Sales Order | The **customer's purchase order** (number and copy) | Before the order goes forward. It is carried to the delivery note and invoice automatically |
| Sales Invoice | The customer's purchase order (from the sales order, or attached on the invoice) | Before the invoice is submitted: the PO is the basis for invoicing. Customers with *Sends a Purchase Order* unticked (cash, walk-in) are exempt |
| Purchase Receipt | As the product's Document Profile requires (see Product documents): an SDS when none is on file for a hazardous product; the supplier's CoA, or our own inspection becomes the certificate | Checked on receipt (warnings); documents are copied onto the batch |
| Purchase Order | **Supplier's receipt**, attached by the person who raised the purchase | After the purchase. When the goods are received, that person is asked for it (and reminded). Suppliers may be paid at any time, including in full before delivery, but **the purchase order cannot close until the receipt is attached**: the Close button refuses, and the supplier's invoice (which would complete the order) cannot be posted. **Where the supplier's invoice doubles as the receipt**, attach it as the receipt on the order, or attach it on the purchase invoice and tick *This Invoice Is Also the Receipt*; posting the invoice then files it as the order's receipt |
| Expense Claim, each line | **Receipt**, attached by the person who made the request | After approval. The approval asks for receipts (and reminds); the reimbursement is not paid until every line has one |
| Disposal Order | Certificate of disposal, manifest signatures and the **hazardous waste disposal acknowledgement** from the receiving facility | Before the order can be closed, completing the waste cycle |
| Calibration Record | Calibration certificate | Before review |
| Employment Contract | Signed copy | When marked signed |
| Employee | National ID copy (whenever a NIN is entered), signed appointment letter, certificate copies | On saving |

The *Signed and Stamped LPO* field on a purchase order is optional, for a supplier's acknowledgement.

*Reimburse Expenses Only Once Receipts Are Attached* (Chemical ERP Settings, on by default) holds expense reimbursements until the employee's receipts are attached. Supplier payments are never held.

**72 hours to attach receipts.** The clock starts when an expense claim is approved, or when a purchase's goods are received. It is shown on the document as *Receipt Due By*.
- **24 hours before the deadline:** the originator is warned.
- **At the deadline:**
  - the originator is told they are blocked, copied to their line manager
  - **an employee with overdue expense receipts can't start another expense claim**, and nobody can raise one for them
  - **whoever raised a purchase with an overdue supplier receipt can't raise another purchase request or purchase order**
- **Lifting the block:** attaching the receipt lifts it immediately. A supplier's invoice serving as the receipt counts.

Overdue receipts show at the top of the person's dashboard.

**Repeated small expense claims.** Each expense claim is checked against the employee's recent claims, and two patterns are flagged:
- **frequent small claims:** more than 3 claims under UGX 100,000 within 7 days
- **possible splitting:** small claims within 48 hours that together pass the *Expense Claim: MD above* limit, so splitting would have avoided the MD's approval (not checked while that limit is 0, since every claim then goes to the MD anyway)

A flag never stops the claimant. The claim shows a red banner with the reason and the related claims, and the line manager and Accounts are alerted once. **Approval needs *Pattern Reviewed* ticked with a note** on what was checked; the claimant can't tick it. Flags and reviews stay on the claim.

The **Expense Pattern Review** report shows each employee's claims per month: count, small claims, totals, flagged and not-yet-reviewed. The dashboard shows flagged claims to Accounts and the MD. Thresholds are settings: *Small Expense: Below*, *Small Claims Allowed per Window*, *Window (days)* and *Splitting Window (hours)*. The number of hours is a setting: *Hours Allowed to Attach Receipts*.

**Privacy.** National ID copies, appointment letters, CVs, certificates, signed contracts and expense receipts are stored privately.

## How the system links together

Every record's **Connections** panel lists what relates to it:

| Record | Shows |
| --- | --- |
| Batch | Retained samples, stability studies, deviations, status overrides, OOS investigations, customer complaints, disposal orders, genealogy |
| Item | Cost sheets, certification, SDS files, stability studies, complaints |
| Customer | Complaints, estimate requests, WHT certificates, container movements |
| Supplier | Evaluations, import shipments, disposal orders and prices |
| Employee | Access grants, training needs, contracts, payslips |
| BOM | Cost sheets |
| Delivery note | Dispatch checks, containers, complaints |
| Equipment | Calibration records, maintenance jobs, PM schedules, returns to service |

Purchase orders and receipts show their import shipments, and payment entries their WHT certificates.

**The main chains:**
- **Sales:** customer PO → sales order → delivery note (dispatch check, SDS, containers) → tax invoice (EFRIS, WHT) → payment → WHT certificate
- **Purchasing:** request → purchase order → payment (often in advance) → import shipment → receipt (COA, SDS) → inspection and release → supplier's receipt on the order → purchase invoice → order closes
- **Production:** formula (BOM, with its Product Costing tab) → cost sheet → work order → job card (training, equipment) → manufacture (stock value includes absorbed costs) → final inspection → release → delivery
- **Waste:** manufacture → waste batch → disposal order → manifest, certificate and acknowledgement → disposal accrual
- **Quality:** inspection → OOS investigation → deviation → complaint → retained sample → management review

My Dashboard brings each person's open items from all of these chains into one place.

## Internal audit (quarterly)

Internal audits follow procedure **BC/IMS/020** and run every three months. The quarters follow the financial year: July–September, October–December, January–March and April–June. You can change the start month in Chemical ERP Settings.

**Planning (automatic).** At the start of each quarter, an Internal Audit is created for the HSE Officer as lead auditor and scheduled 21 days before quarter end. Its checklist is built from the live registers:
- every active procedure, policy, plan, manual and register in the IMS document register, grouped by owning area
- every applicable legal requirement
- every open compliance watch item

System notes flag what is already known, such as a document overdue for review or an expired permit. Open findings from earlier audits are carried forward for follow-up. If the scheduled date passes, the lead auditor is reminded.

**Auditing.** For each checklist item, record the evidence seen and the result: Conforms, Observation, Opportunity for Improvement, Minor Nonconformity, Major Nonconformity or Not Audited.
- **Findings and score.** Anything other than Conforms becomes a numbered finding, and the compliance score updates as results are entered.
- **Independence.** No one may audit their own area: an auditor who holds a post is refused on items for that post's area.

**Issuing.** The lead auditor submits the report, then the Managing Director approves it. It can't be issued until every nonconformity has a corrective action, owner and due date, and the conclusion is written. On issue, each action owner is notified.

**Follow-up.** Corrective actions stay editable after issue. A finding can only be closed once someone records who verified it. The audit shows "Closed" when every finding is closed.

**Word report.** **Download Word Report** produces form **BC/HSE/006** as a .docx file in Arial, 11pt, 1.15 line spacing, with the Brave header and page numbers. It contains:
- audit details
- objective and scope
- executive summary with score
- follow-up of earlier findings
- results by area
- findings and corrective actions
- conclusion
- approval and distribution

It can be downloaded at any stage; until the MD approves it, it carries a DRAFT banner.

The report is built with python-docx, which `bench get-app` installs automatically.

## Expense claims

| Claim | Signs first | Signs last |
| --- | --- | --- |
| At or below the expense limit | The claimant's own Expense Approver (department manager) | — |
| Above the limit | The claimant's own Expense Approver | Managing Director |
| Claimant's manager is the MD, or no approver is set | Fallback Expense Approver (Accounts Officer) | Managing Director, if above the limit |
| The Managing Director's own claim | No approval needed: the MD approves it directly | — |

Only the named first approver can sign the first stage. Anyone else holding the Expense Approver role is refused, and a claimant can never approve their own claim. The claimant is notified of the outcome.

**Set up:**
1. Enter each employee's Expense Approver.
2. Set the **Fallback Expense Approver** in Chemical ERP Settings, and give that person the Expense Approver role.

Until the MD sets an expense limit, every claim also goes to the MD.

## Learning and the training room

The Learning module builds on Frappe HR's own Training Program, Training Event and Training Result records, so training is recorded once.

**Where training needs come from (automatic, daily):**
- A certificate on an employee's record is within 60 days of expiry: Certification Renewal.
- An employee's role (designation) requires training they don't hold, per Training Requirement: Missing Required Training.
- A new joiner hasn't done the induction program: Induction.
- A Job Card is refused because the operator's training has lapsed. The need is raised at the moment of refusal.
- Managers can also raise needs by hand from an Employee or an Appraisal (**Raise Training Need**), including development needs from appraisals.

**How a need is met:**
1. The need shows the recommended program and its learning material: videos, documents and links, with a duration for each.
2. HR schedules a Training Event. Choosing the program offers to add everyone with an open need.
3. On submit, each invitee is emailed the date, venue and the join link for online sessions.
4. Online sessions open in the **Training Room**, a video meeting inside ERPNext. Cameras start off and video is capped at 360p to save data. Join and leave times are logged automatically and copied onto the Training Result.
5. When the trainer submits the Training Result, every employee marked **Passed** gets the certificate on their record, with an expiry date from the program's validity. Their needs close, and any Job Card block lifts at once.

**Training room platform** (Learning Settings):

| Option | Cost | Set-up |
| --- | --- | --- |
| JaaS (8x8 Jitsi as a Service), the default | Free for unlimited minutes for up to 25 users a month | Create a JaaS account and enter the App ID and API Key ID. Store the private key in site config: `bench --site <site> set-config jaas_private_key "$(cat key.pem)"` |
| Self-hosted Jitsi | Free; runs on your own server | Enter the server domain. If token authentication is on, add the App ID and store the secret as `jitsi_jwt_secret` in site config |
| External link (Zoom, Google Meet, Teams) | Per that platform | Paste each session's link on the Training Event |

The public meet.jit.si service is not offered, because it now cuts off embedded meetings after 5 minutes. Employees need an ERPNext login to join online sessions; anyone without one can still attend in person.

The **Training Matrix** report shows, for every employee, each required training and its status: Current, Expiring, Expired, Missing or Scheduled.

## Company font and text size

Two rules apply to every printed document:

- **Font:** Arial everywhere.
- **Lengthy documents:** contracts, reports, and any document with running paragraphs use **11pt text with 1.15 line spacing**. The Employment Contract and Deviation Report print formats follow this. Installation also adds a **Brave** print style, so long text in any ERPNext document (terms and conditions, contract clauses, descriptions) prints the same way.
- **Compact forms keep their tighter layouts** so they stay on one page: the certificate, invoice, manifest, label, sticker and payslip.


Every document the system prints uses **Arial**, Brave's company font. That covers this app's print formats (Certificate of Analysis, Tax Invoice, Waste Manifest, Product Label, Calibration Sticker and Payslip). Installation also sets Print Settings to Arial, so ERPNext's standard documents follow suit.

PDFs are rendered on the server, so Arial must be installed there:

```bash
sudo apt install ttf-mscorefonts-installer && fc-cache -f
```

Without it, PDFs fall back to Liberation Sans, which has identical spacing, so layouts don't shift. The Go-Live Readiness report checks for this.

## Material availability for manufacturing orders

Every manufacturing order (Work Order) checks its materials when it is saved and submitted, and again daily while not started. **Materials → Check Materials** runs the check at any time.

For each material the order shows:
- **still needed**
- **released stock:** only released warehouses count, since quarantined stock hasn't passed QC
- **committed** to other open manufacturing orders
- **in quarantine**
- **on order:** open purchase orders, with the earliest arrival

Each material gets one of these verdicts:
- **Available**
- **Short: Awaiting QC Release:** enough stock is in quarantine
- **Short: On Order in Time**
- **Short: On Order but Late:** arrives after the planned start
- **Order Now**

The order's *Materials* field shows the worst verdict: All Available, Shortages Covered, Late Supplies or Order Needed.

For **Order Now** the check suggests:
- **quantity**, rounded up to whole purchase packs (e.g. 25 kg bags) and the minimum order quantity
- **supplier**: the default or last supplier, but only an approved one for hazardous chemicals
- **cost**, from the last purchase price
- **arrival**, from the item's lead time, with a warning when even an order placed today would arrive after the planned start

**Materials → Create Purchase Orders** raises draft purchase orders, one per supplier, into the quarantine receiving warehouse, linked to the manufacturing order. They go through the normal approvals, approved-supplier rule and 72-hour receipt rule.

Procurement and the production manager are alerted when an order needs materials ordered or a supply will be late. The dashboard shows *Manufacturing orders short of materials* and *Materials to order for manufacturing*. For accurate suggestions, set each material's purchase unit, minimum order quantity, lead time and default supplier on the Item.

## Field Laboratory

Water testing at customers' boilers, cooling towers and chillers, from field visit to signed report and invoice.

**Set-up.**
- **Water Test Parameters:** each test carries its method, method reference, measuring range, alternative method and sample-handling notes, taken from HACH and HANNA documentation:

  | Test | Method | Range |
  | --- | --- | --- |
  | Iron | HACH 8008, FerroVer | 0.02–3.00 mg/L |
  | Phosphates | HACH 8114, molybdovanadate (8048, PhosVer 3, for low range) | 0.3–45.0 mg/L |
  | Total hardness | HACH 8030, Calmagite (EDTA titration, HACH 8213, above 4 ppm) | 0.05–4.00 mg/L |
  | Sulphites | HACH 8216, iodate-iodide titration (not a DR900 test); test at once on site | 4–400 mg/L |
  | Dissolved oxygen | HACH 8166, HRDO; low range HACH 8316, indigo carmine | 0.3–15.0 mg/L; 10–1000 µg/L on the DR900 |
  | Silica | HACH 8185 (8186 for low range) | 1–100 mg/L |
  | Free / total chlorine | HACH 8021 / 8167, DPD | 0.02–2.00 mg/L |
  | Sulphate | HACH 8051 | 2–70 mg/L |
  | Manganese | HACH 8149 | 0.006–0.7 mg/L |
  | pH, temperature, conductivity, TDS | HANNA HI98130 | conductivity 0–20,000 µS/cm; TDS 0–10,000 ppm, conversion factor 0.5 |

  A reading above a method's range is flagged *dilute and retest* (record the dilution used). Results below detection can be entered as e.g. `<0.010`. When a specification is tighter than the method can detect, the report says compliance can't be proven with that method. Brave's feed-water dissolved oxygen limit (<0.007 mg/L) is below the DR900's 0.010 mg/L. pH, temperature, TDS and conductivity use the **HANNA meter**; colorimetric tests (phosphates, chlorine, iron, silica, sulphate, nitrate, nitrite, ammonia, manganese, colour) use the **HACH DR900**.
- **Instruments:** both are registered as laboratory equipment needing calibration. Enter a first Calibration Record for each before use. Results can't use an instrument that is out of calibration, or an expired reagent.
- **Water Standards:** the specifications.
  - **Boiler Water** and **Boiler Feed Water** carry the specifications on Brave's boiler reports, plus **iron** (guide limits <1.0 and <0.1 mg/L, to confirm).
  - **Cooling tower and chiller** ranges are guides marked *confirm before use*.
  - **Drinking water (US EAS 12) and NEMA effluent** list their parameters, with limits to be entered from the official text.
  - A nil limit (e.g. feed-water hardness) is entered as *Nil*.
  - **Industry versions.** **Make Industry Version** copies a standard for one industry (e.g. *Boiler Water - Pharmaceuticals*), tagged with the industry and an application such as "clean steam" or "low pressure", so its limits can be tightened or relaxed for that industry's demands. New equipment for a customer picks up the version matching the customer's industry, otherwise the general standard. Statutory standards carry a reminder that industry versions may tighten their limits but should not relax them.
- **Specification adjustments (per equipment).** On each Client Water System, a parameter's window (minimum, maximum or Nil) can be changed, or a parameter added, for one sample point or all of them, with a reason such as the client's specification or an industry demand. Anyone may propose an adjustment, but it applies only once the quality approver or the MD approves it. Editing an approved window sends it back for approval. Adjusted specifications are marked * on the report and field sheet, with the reason, and the report names the standard each sample point was judged against.
- **Client Water Systems:** each customer's boiler, cooling tower or chiller, with location, capacity (l/hr), operating hours, key contact, how often it is sampled, and the responsible technician. Each has its **sample points**, each with its own specification:
  - **Boiler:** Boiler Water and Feed Water
  - **Cooling tower:** Tower Water and Make-up Water
  - **Chiller:** Chilled Water Loop

**In the field.** Samples are drawn and tested on the client's site, so there is no transport or laboratory hand-over to track.

A **Water Sample** is one site visit and can cover several pieces of equipment.
- **Choose what to sample:** **Sample Points → Add Equipment** picks one of the client's boilers, cooling towers or chillers and ticks which of its points to sample. **Add All Client Equipment** loads everything.
- **One row per bottle:** each row gets a bottle code (e.g. WS-26-00014-1) and records the time drawn, temperature and appearance.
- **Adjustable tests:** each row's **tests** are filled from that point's specification, including approved adjustments. Remove any not needed this visit, or add extra test names.
- **Extra points:** a point not listed on the equipment uses the equipment's default specification.
- **Status:** *Open* → *Analysed* (results being entered) → *Reported* (every analysis issued), or *Cancelled* with a reason.

**Print Field Sheet** prints the **Field Sampling Sheet**, a professional form in the house style:
- **Header:** logo, company block and the visit number, date and client.
- **1. Visit:** technician (the person logged in when the visit was created), visit date, arrival and departure times, client contact, *testing on site*.
- **2. Samples Taken:** every bottle, with its code, equipment, point, time, temperature and appearance.
- **3. Field Tests:** one block per piece of equipment, showing type, capacity and operating hours. Each sample point lists its tests with **method reference** (e.g. HACH Method 8008), **specification** (* where adjusted), and blank columns for result, dilution and comment. Tests to be done immediately are marked. Each block ends with a *Chemicals on site* table: stock, daily use, and whether the dosing pump is working.
- **4. Observations** box.
- **5. Sign-off:** names only, no signatures. It lists the technician, the client's representative (from the visit's *Client Representative* field, filled automatically from the equipment's key contact and editable) and the date, taken automatically from the visit date, confirming the samples were drawn and tested on site.
- **Footer:** "Page x of y" on every page.

**Enter Results** creates one Water Analysis per piece of equipment, containing only the points and tests taken, ready for the results read on site.

**Analysis and report.**
1. The **Water Analysis** lists every test for every sample point. Enter results as read, leaving a blank for anything not tested.
2. Each result is judged against its specification: within, above, below, not met, or not tested.
3. Add comments, observations, recommendations, dosing advice, and the **Chemical Use Estimation** (daily kg; monthly is worked out at 30 days).
4. Results outside specification need a comment or recommendation before signing.
5. The analyst (or field technician) signs, and the quality approver issues the report.

The **Water Analysis Report** follows Brave's existing layout:
- A. Water Treatment
- B. Client Information
- C. Test Parameters, by sample point, with out-of-specification results in red, bold and underlined
- D. Chemical Use Estimation
- E. Observations and Recommendations, when there are any
- Assessed by (name, email, office and mobile)

It adds the report number, the reviewer, and the QR verification code.

**Technical analysis (page two of the report).** Worked out from the results each time the analysis is saved:
- a **compliance score** (percentage of tests within specification) and how far each failing result is outside it
- **boiler calculations:**
  - cycles of concentration from boiler and feed TDS (or conductivity), against the maximum the specification allows
  - estimated blowdown now and needed, in l/hr, from the boiler's capacity
  - oxygen-scavenger demand from feed-water oxygen and the sulphite reserve, in kg/day as sodium sulphite
- **cooling tower calculations:** cycles of concentration, and the **Langelier** and **Ryznar** indices (scaling or corrosive tendency) when pH, temperature, TDS, calcium hardness and alkalinity are tested
- a **measurement check:** TDS should be 0.5 to 0.7 times conductivity
- **risk ratings:** scale, corrosion, carryover and microbiological risk (cooling towers, from bacteria count and free chlorine), each Low, Medium, High or Not Assessed
- **findings ranked by severity,** each with a recommended action, kept on the analysis and editable; **Draft Interpretation** writes suggested observations and recommendations for the analyst to edit
- **trends:** each result compared with the previous visit (change and earlier value), with a trend line from up to five earlier reports

The page shows the compliance gauge, the risk tiles, the key figures with a plain-language reading, a bar for every result showing where it sits against its specification band, the change since the last visit, trend lines, and the findings and actions. A note states the calculation basis: these are engineering estimates from a single sample, to be confirmed on site. Issuing a report updates the equipment's next sampling date. A non-compliant report alerts the Sales Manager to follow up, and **Make Invoice** raises a draft invoice for the analysis using the service item set in Chemical ERP Settings.

**Following up.**
- The **Water Trend** report charts one parameter over time for a piece of equipment.
- Technicians are reminded three days before equipment is due for sampling.
- The dashboard's **Field Laboratory** section shows equipment due, samples waiting, analyses to sign, reports awaiting approval, non-compliant reports and reports not yet invoiced.
- Each customer's record links to their equipment, samples and reports.

## Document numbering

Reference numbers are set in the Company Profile under **Document Numbering**: one row per document, with its pattern and next number, and a live example of what the next document will be called. **Setup → Apply Numbering** applies them. Documents already issued keep their numbers.

**Pattern parts**, separated by dots:
- the prefix, e.g. `QUO-`
- `#` for each digit of the number, e.g. `######` for six digits
- dates: `YY` (two-digit year), `YYYY` (four-digit year), `MM` (month), `DD` (day)

| Pattern | Next number | Gives |
| --- | --- | --- |
| `QUO-.######.-.YY` | 368 | QUO-000368-26 |
| `INV-.######.-.YY` | 284 | INV-000284-26 |
| `QUO-.YY.-.######` | 1 | QUO-26-000001 |
| `EXP-.YYYY.-.MM.-.####` | 15 | EXP-2026-10-0015 |

**Where the date goes matters.** A date placed **after** the number keeps one running count across years (QUO-000368-26, then QUO-000369-27). A date placed **before** it restarts the count each year (QUO-26-000001, then QUO-27-000001).

**Starting numbers.** Enter the next number once, when switching over from another system, and leave it blank afterwards. A starting number that would reuse numbers already issued is refused.

**Which documents.** Rows can be added for quotations, sales orders, invoices, delivery notes, purchase orders, purchase invoices, expense claims, disposal orders, stock entries, material requests and journal entries.

**Receipts have their own references:**
- **Customer receipts** (money received) count as RCT-…
- **Supplier payments** (money paid) count as PAY-…
- **Goods received notes** count as GRN-…

ERPNext records money in and money out as one type of document (a payment entry). The system picks the receipt or payment series automatically from the direction of the money, so the two keep separate counts. Transfers between Brave's own accounts keep ERPNext's standard numbering.

**Waste manifests** get their own number, given when the disposal order is approved and printed on the manifest. The Disposal Order keeps its own number as well.

Brave's profile starts with patterns in its current style: QUO-, INV-, DN-, RCT-, PAY-, GRN-, EXP-, DO- and WM-, each with six digits and the year. Profiles created earlier get the new receipt rows on the next migrate. Enter the next number for quotations and invoices (the next after your last issued QUO- and INV- numbers) before applying.

## Tender scanning (Tenders Desk)

The **Tender Scanner** reads tender sources automatically, scores every notice against the company's scope, and records relevant ones as **Tender Leads** for review.

| Source | How it is read |
| --- | --- |
| **PPDA e-GP portal** (egpuganda.go.ug) | Public bid notices, a few pages every 6 hours. Titles the portal cuts short are opened in full before scoring |
| **World Bank** | Official public procurement-notices data (search.worldbank.org), filtered to Uganda, every 12 hours |
| **UN Global Marketplace (UNGM)** | UNGM offers no free feed. Its **Tender Alert Service** (paid, about USD 20 a month, several recipients) emails new UN notices; send them to the tender inbox |
| **LinkedIn** | LinkedIn's terms forbid automated reading. Follow procuring entities and switch on email notifications to the tender inbox |
| **Newspapers** (New Vision, Daily Monitor) | Their tender adverts sit in the paid e-paper. Subscribe to their tender alerts, or forward adverts, to the tender inbox |
| **Other websites** (utilities, ministries, NGOs, embassies) | Copy the *Client and Agency Websites* template for each page, then enter its address and the CSS selectors that pick each notice |
| **RSS / Atom feeds** | Any tender feed, by address |

**Tender inbox.** Set up an incoming Email Account (e.g. tenders@yourcompany.com) and choose it in **Tender Settings > Tender Scanning**. Every email arriving there is read as a notice, credited to the source whose sender matches (ungm.org, linkedin.com, newvision…), otherwise to *Other Tender Emails*.

**Generic until the company is set up.** The Tenders Desk ships neutral. Its tender categories are PPDA procurement types (supplies, works, non-consultancy services, consultancy, framework agreements), and no company scope is loaded. Scanning stays **off** until:
1. the **Company Profile** is filled in,
2. the **company scope** is entered: at least one Include keyword in Tender Settings > Tender Scanning, and
3. **Scan Automatically** is ticked. It can't be ticked before steps 1 and 2.

Until then nothing is scanned, *Scan Now* says what's missing, and the dashboard and Go-Live Readiness report flag it.

**Company scope.** Tender Settings > Tender Scanning lists the words that make a notice relevant, each with points, and words that rule a notice out, with points removed. Enter the company's own, or use **Load Example Scope** to start from an example and edit it. For Brave, load **Brave Chemicals (website 27 Sep 2026, plus fertilisers)**: Brave's scope as published on its website, plus polyelectrolyte (with flocculants and coagulants) and fertilisers (DAP, urea), which Brave keeps in its scope. These come with a *Fertilisers and Agro-inputs* tender category. It covers the six service lines (generic and specialty chemicals with water treatment; industrial chemicals cleaning; industrial equipment supply and servicing; chemical laboratory supplies; PPE; chemicals and safety consultancy), distributed gases and solvents, and the Brave Home cleaning range. It adds those as tender categories and writes the scope and sectors onto the Company Profile's *Scope of Work*. Its exclusions are narrow (e.g. "fuel supply", "consultancy for design", "office cleaning services"), so Brave's own consultancy, industrial cleaning and propane business still get through. The other examples are:
- *Chemicals and water treatment:* a narrower chemicals-only set.
- *Civil works and design.*
- *General supplies (starting point).*

The World Bank search uses the scope's strongest words, so it suits any company.
- Plurals match ("coagulant" finds "coagulants"), and each phrase counts once, for the longest keyword that covers it.
- A notice needs a score of 3 to become a lead. At 6, the Tender Manager is alerted immediately.
- International notices are kept only if they mention Uganda (or a town on the Uganda terms list).
- Duplicates and notices already closed are skipped.

**Reviewing leads.** Each lead shows its source, score, matched words, closing date, procuring entity, link and summary.
- **Convert to Tender** opens a full Tender with the details filled in, ready for the go/no-go review.
- **Not Relevant** dismisses it.
- Leads past their closing date are marked Expired automatically.
- A **daily digest email** lists the past day's new leads, if digest recipients are set.
- The dashboard's Tenders section shows *New tender leads to review* and *Shortlisted leads*. **Scan Now** on any source scans it at once.

Watch the first weeks' leads and adjust the scope words and points: add words for products you sell, and exclusions for recurring noise.

## Bid document (Word)

On a Tender, **Generate Bid Document (Word)** drafts the bid for the Bid Manager. The draft is saved on the tender as a private attachment (*Bid Document Draft*) and opened for download. Generate it again after changes: each draft is kept, dated.

The draft is filled from the system:

| Section | Filled from |
| --- | --- |
| Cover | Tender title, procurement reference, procuring entity, method, deadline, bidding as (sole or joint venture), company contacts; marked DRAFT with the Bid Manager's name |
| Contents | Word builds it when the file is opened |
| 1. Bid Submission Sheet | The usual PPDA declarations, with the bid total in figures and words, bid validity, and any addenda from the clarifications |
| 2. Company Profile | Company Profile: legal and trading name, address, phone, email, website, TIN, VAT, URSB, National Supplier Database number, scope of work, sectors; ISO-aligned IMS statement and the policy list from the IMS register |
| 3. Eligibility and Administrative Documents | The tender's requirements with their credentials: in hand, expired or to obtain, validity and certificate numbers, plus readiness |
| 4. Technical Proposal | Understanding (from the advert, or Claude's summary of it); a compliance table from the price lines, with "Manufactured by Brave" for Brave's own products; methodology (QC release, COA, SDS, dispatch safety, and site and water-testing work where the category calls for it); QHSE; experience from tenders won; key people from the company's posts; delivery schedule |
| 5. Financial Proposal | Price schedule from the price lines, sub-total, VAT and total, amount in words, validity, and the bid security (form, amount, issuer, validity) |
| 6–8. Clarifications, Declarations, Annexes | Clarifications and addenda; anti-bribery (citing the policy number), conflict of interest, code of ethical conduct; the annex list with what is attached and what is still to attach |

Anything the system can't know is left as a **[yellow-highlighted placeholder]**: signatory, discounts, delivery periods, makes and origins, past contract values, and so on. The draft is Arial 11pt with 1.15 line spacing. Use the procuring entity's own forms wherever they differ from the draft: the cover note says so.

## Bid Library (learning from sample bids)

The bid draft learns the company's own wording from its past bids.

1. **Add a sample bid**, Word (.docx) or PDF:
   - from **Bid Sample** (Tenders Desk workspace), or
   - from a tender: **Add Submitted Bid to Library**.

   Record whether the bid was won, lost, not known, or is a template.
2. **The system learns:** it splits the bid at its headings (Word heading styles, bold or numbered headings, all-capitals titles) and recognises each section: understanding of the requirement, company profile, methodology and delivery, quality and HSE, relevant experience, key personnel, delivery schedule, warranty and after-sales, declarations, the bid submission sheet, or other. Tables are kept, duplicates skipped, and fragments too short to reuse ignored.
3. **Review and approve:** the learned sections arrive as **Bid Library Blocks** for review. Edit out anything specific to the old tender (names, quantities, dates), then tick **Approved**. Only a Tender Manager or the MD can approve, and only approved sections are ever used.
4. **New drafts use the approved wording** in place of the standard text: company profile ("About us"), methodology, quality and HSE, experience, key personnel and declarations. A **Warranty and after-sales** section is added when the library has one. For each section the system prefers wording from bids in the same tender category, then winning bids, then the most recent. Each reused passage is followed by a note naming its source bid and a **[Review]** marker, and the system counts how often each block is used.

**Samples are optional.** **Generate Bid Document (Word)** always drafts straight away. Without approved library wording it uses the standard wording, and afterwards shows a brief tip about teaching it with a sample. Samples only make later drafts better.
- **Bid Library → Teach with a Sample Bid** is available on every tender at any time.
- Once a tender is submitted, under evaluation, won or lost, the tender suggests **Add Submitted Bid to Library**.
- The dashboard shows *Bid library sections to review*.

## Module names

The tender module is **Tenders Desk** (formerly Brave Tenders) and the integrated management system module is **Management Systems** (formerly Brave IMS). On a site that had the old names, the next `bench migrate` moves everything to the new modules and workspaces and removes the old menu entries. No records change. The names of the old standalone apps mentioned under Install (`brave_ims`, `brave_tenders`) are unchanged, since those are separate packages.

## Brave Chemicals as the default company

When the default company is Brave Chemicals, the app sets Brave up from its website (27 September 2026), plus polyelectrolyte and fertilisers, which Brave keeps in scope. This runs on install and every migrate, and from **Company Profile → Setup → Apply Brave Chemicals Defaults**. It only creates what's missing and only fills empty fields: nothing already entered is overwritten.

| What | From the website | Links to |
| --- | --- | --- |
| **Company Profile** | Trading name, tagline "Reliable Chemical Solutions", website, scope of work (six service lines, Brave Home, polyelectrolyte and fertilisers), sectors served | Every document header, the portal, the tender scan |
| **Item groups** (15) | Brave Chemicals Range → Generic and Specialty Chemicals (Disinfection, Cleaning and Descaling, Boilers and Steam, Cooling Water, Water Treatment Chemicals, Process Chemicals, Laboratory Chemicals), Fertilisers and Agro-inputs, Chemical Laboratory Supplies, PPE, Industrial Equipment, Brave Home, Brave Services | Items, tender categories |
| **Substances** (12) | CAS number (check digits verified), UN number, shipping name and hazard class for hypochlorite, caustic, hydrochloric and sulphuric acid, acetone, ethanol, methanol, CO2, oxygen, propane, urea, DAP | Items, SDS files, transport emergency cards |
| **Items** (45) | 14 Brave-made products (BR-Hypo 10/12/35/56, BR-SAV, BR-Sav 1201/1202, ACIDEX, ACIDEX 1202, COTOCIDE 1402/1403, SCAV 1204, AQUATREAT 9510, BR-OXO+); 11 distributed (sulphuric acid, acetone, ethanol, methanol, CO2, oxygen, propane, surfactants, polyelectrolyte, DAP, urea); the 13 Brave Home products; 7 service items (water treatment programme, water analysis, industrial cleaning, spill response, equipment servicing, safety audit, safety consultancy) | Batches and QC release, SDS (hazardous items need a current SDS before delivery), costing, certification, quotations and invoices, field laboratory, tenders |
| **Customer groups** (9) | Major Projects and Remote Sites, Manufacturing, Water and Utilities, Healthcare and Laboratories, Government and NGOs; Brave Home retailers, distributors, institutions and households | Customers, sales analysis |
| **Tenders Desk** | The Brave scope loaded, with each keyword tied to its tender category; categories tied to the item group they sell from; scanning switched on | Leads arrive categorised, and the category carries to the Tender |
| **Field Laboratory** | Water Analysis service item set as the analysis fee. New boilers start with SCAV 1204 and AQUATREAT 9510 as treatment products; cooling towers with COTOCIDE 1402/1403 and BR-Hypo 12; chillers with AQUATREAT 9510 | Field sheets, analysis reports, invoices |
| **Product certification** | The 13 Brave Home products and BR-Hypo 10/12 marked *To Be Confirmed* for UNBS scope (the website awaits mark and permit numbers) | Attention notices on quotations, orders and deliveries |
| **IMS register** | *Standard Terms and Conditions of Sale* added as a draft (the website lists it without a number) | Management Systems |

**Placeholders still on the website, to enter as they are confirmed:**
- *Company details:* the 24-hour emergency number (Company Profile, as "Emergency (24 hours)"), National Supplier Database number, URSB registration number, NEMA licence, PDPO registration and insurance.
- *Product details:* the chemistry and application of products marked [Confirm] (on each Item and its SDS), pack sizes, and ISO certification status.
- *Policy title:* the website calls BC/HR/004 "Code of Conduct and Anti-Bribery Policy", while the IMS register says "Anti-Bribery Policy". Align the two.

## Setting up for a company

The system isn't tied to Brave Chemicals: any company, or several on one site, can use it. Everything that identifies a company is kept in its **Company Profile** (Chemical Operations workspace, *Company Setup*), one per ERPNext Company.

| Section | What it holds |
| --- | --- |
| Identity | Legal name as printed, trading name (used in messages), tagline, registration number, TIN, VAT number |
| Branding | Wide logo for quotations, invoices and orders; square logo for certificates and letters; brand colour for headings |
| Address and contacts | Address lines; telephone numbers (office, mobile, WhatsApp, fax, 24-hour emergency, other), each ticked for sales documents, letterheads, or both; email addresses; website |
| Bank accounts | Bank, branch, account name, number, currency and SWIFT, each ticked to print on invoices, plus an optional invoice note |
| Documents | Quotation title (QUOTATION, ESTIMATE or PROFORMA) and an optional footer |
| Organisation | Departments (with parent department and head) and posts (with department, the post each reports to, and starting access) |

Every document reads from the profile of its own company. That covers the quotation, tax invoice, purchase order, certificate of analysis, employment contract, deviation report, transport emergency card, management review minutes and the Word internal audit report. The QR scan page, customer portal and system messages also name the company from its profile. Certificate notes may contain `{company}`, which prints the company's name.

**Organisation.**
1. List the departments and posts in the profile.
2. Click **Apply Organisation**. This creates the ERPNext Departments and the company's posts with their reporting lines, giving each post the roles of its starting access profile.
3. Add the people holding each post on the post itself.

The **Company Organisation** report shows the chart: each post under the one it reports to, with its department and holder, or *vacant, covered by the MD*.

**Starting fresh for another company.**
1. Create the ERPNext Company.
2. Fill in its Company Profile and apply the organisation.
3. Run the Go-Live Readiness report.

Brave's own reference data is loaded only for Brave: its 85-document IMS register, legal register, IMS document number series and the BR HYPO 10 COA template. Another company starts with clean registers, and can load the IMS register as a starting template from the profile (**Setup → Load Reference IMS Register**). Print formats and the print style have neutral names: *Quotation (House Style)*, *Purchase Order (House Style)*, *House Style*.

**For Brave**, the details that used to sit in Chemical ERP Settings move into Brave's Company Profile automatically on the next migrate: company block, office and mobile numbers, email, TIN, Equity Bank accounts, logos and the ESTIMATE title. Brave's documents print exactly as before.

## First-time setup

1. **Roles.** Staff get their roles from their **post** (Company Position): create the Employee, then **Create System Account**, and add them to the post. For reference, the main roles are:

   | Person | Roles |
   | --- | --- |
   | Managing Director | Managing Director, Plant Manager (until one is appointed), Formula Owner, Sales Manager, Stock Manager, Manufacturing Manager, Accounts Manager, HR Manager |
   | QC Analyst | QC Analyst, Laboratory Technician |
   | Laboratory Assistant | Laboratory Technician (enters readings, cannot sign) |
   | HSE Officer | HSE Officer |
   | Production Supervisor | Manufacturing Manager, Manufacturing User, Waste Officer |
   | Production Assistants | Manufacturing User, Maintenance Technician |
   | Stores Officer | Stock User |
   | Procurement Officer | Purchase User |
   | Accounts Officer | Accounts User, Expense Approver (as Fallback Expense Approver) |
   | Sales Representative, Technical Sales Officer | Sales User (TSO also Sales Manager) |
   | HR Officer | HR User |
   | External administrator | System Manager only, with no approval role |

   Never give one person both QC Analyst and Managing Director: the release would then need the same person twice, and the system will refuse it.

2. **Warehouses.** On each warehouse, set its **QC Zone**: Quarantine, Released, WIP, Transit, Rejected, Waste Hold, Receiving, or Neutral (Spares Store). Create a Premix Kitchen warehouse (zone WIP) and give Production and Stores no user permission on it.

3. **Chemical ERP Settings** (Managing Director only).
   - Pick the quarantine, release, rejected, Waste Hold and spares warehouses.
   - Pick the disposal expense, disposal accrual and maintenance expense accounts.
   - Leave **approval limits at 0** until you decide them; every document then routes for approval.
   - EFRIS starts in **Manual (URA Desktop App)** mode.

4. **Items.** For every chemical:
   - Tick **Has Batch No** and set a batch series with **Automatically Create New Batch**.
   - Set the shelf life, Substance, Hazardous flag and EFRIS commodity code.
   - **Untick "Inspection Required before Purchase"**. The receipt must post into Quarantine first; the inspection then gates release.
   - Mark waste items **Waste Item** and list their allowed disposal methods.

5. **SDS files.** The HSE Officer uploads one English PDF per saleable item, and the MD approves it. Items without one cannot be delivered.

6. **Formulas.** The MD (or a delegate the MD creates under Formula Delegation) enters each master premix BOM with Formula Level = Master premix, plus a production-recipe BOM showing only premix and bulk. The MD approves both.

7. **Equipment.** Register every instrument and critical plant item, tick **Requires Calibration** where needed, and enter the first Calibration Record. Every numeric QC reading must name a calibrated instrument.

8. **Legal register.** For each licence or permit in Legal Requirement, enter its expiry date. Where an operation must not run on a lapsed permit, set *Checked On* and *When Lapsed* (for example, the NEMA waste licence: Disposal, Block).

9. **Run the Go-Live Readiness report** (Chemical Operations workspace). It checks:
   - settings, warehouses and accounts
   - who holds each role, and that QC Analyst and Managing Director are different people
   - item set-up, SDS coverage and EFRIS codes
   - formula approval
   - equipment calibration
   - expired permits and overdue IMS documents
   - EFRIS and payroll set-up

   Fix every **Fail** before going live.

10. **HR and Tenders.** Follow the HR and Tenders Desk sections of their own settings pages (PAYE bands, LST, tender reminders, Claude key).

## How the main flows work

- **Receiving:** Stores drafts a Purchase Receipt, the MD approves it, and stock posts to Quarantine. A Quality Inspection opens automatically.
- **Release:** the QC Analyst enters readings and chooses Sign Results; the quality approver (the Plant Manager, or a QC Manager once appointed) chooses Approve Release (or Approve Rejection). On release the system moves the stock into Released and copies the assay to the Batch. On rejection it moves to Rejected and a Deviation opens.
- **Production:** a Work Order can only use an approved formula. Material issue applies potency scaling automatically for potency-managed items. The Manufacture entry sends output to Quarantine and waste to Waste Hold at zero value, and excess waste needs the Plant Manager's (or the MD's) approval. A final inspection then opens.
- **Selling:** a Delivery Note is refused for any batch that is not Released, is expired or due for retest, is waste, or has no current English SDS. The SDS used is stored on the delivery.
- **EFRIS:** each submitted Sales Invoice is logged.
  - Manual mode: Accounts keys in the fiscal number from the Desktop App.
  - Enabler mode: the invoice is sent automatically and retried.
  - Either way, the Tax Invoice (EFRIS) print shows "NOT A TAX INVOICE" until the number exists.
- **Waste:** the Waste Officer drafts a Disposal Order; the HSE Officer signs first and the MD signs last above the cost limit. Close with Certificate issues the batch from Waste Hold and posts the expense against the accrual. Waste held for more than 30 days is flagged daily.
- **Maintenance:** calibration lapses automatically on its due date. A failed "as found" calibration lists every inspection the instrument was used for, opens a Deviation and blocks affected Quarantine batches. Breakdowns take equipment out of service until a signed Return to Service.

## Implementation status

| Area | Status |
| --- | --- |
| QC zones, release, rejection, delivery hard stops, SDS stamping | Built |
| Approval routing, workflows for 21 documents, segregation of duties, approval log | Built |
| Formula confidentiality, delegation and expiry | Built. Known limits: the Administrator account bypasses permission checks, and some standard stock reports read the ledger directly; restrict those reports by role and Premix Kitchen user permission |
| Potency, substitutes, co-products | Built. Co-products are BOM scrap rows marked Co-product, priced from their allocation %, so ERPNext deducts their value from the main product's cost |
| Waste, Disposal Orders, manifest, accrual accounting | Built |
| Batch genealogy and Batch Trace report | Built |
| Maintenance: equipment, calibration, impact review, PM, breakdowns, Return to Service | Built |
| EFRIS manual mode | Built; ready for go-live |
| EFRIS enabler mode | Built to the published envelope. **Verify every payload field against URA's interface specification and test in URA's sandbox before switching it on** |
| Tenders Desk, HR | Ported from the tested-in-isolation apps; shift records now use Frappe HR |
| Management Systems | Folded in as its own module, with seed data, permit gates, Deviation and Tender links, dashboard cards |
| Go-Live Readiness report | Built |
| Learning: training needs, programs and material, online training room (JaaS, self-hosted Jitsi or external link), attendance, certificate issue | Built. The room needs a JaaS account or Jitsi server before first use |

## Testing

Run the acceptance tests from the SRS and the System Design Specification on staging, phase by phase, with real users in each role. Pay particular attention to these three:
- A QC Analyst cannot countersign their own results.
- A Production user cannot find a premix BOM, Work Order or Stock Entry anywhere: in lists, search, reports or by URL.
- A delivery of a Quarantine batch is refused even for the Managing Director.

## October 2026 additions

**Approvals without the MD bottleneck**
- *Approval Delegation*: the MD names a delegate for set dates (at most 30 days by default), optionally for selected documents only and with a per-document cap. The delegate gets the "MD Delegate" role only while it runs, signs at every MD step except formulas and cancellations, and each signature is logged against the delegation. The MD gets a daily email of what was signed.
- *Suggest Limits* (Chemical ERP Settings): proposes approval limits from the last six months of documents and shows how many approvals each would remove from the MD's desk. Nothing is saved until the MD saves.
- */approvals*: a phone page listing everything waiting on you, with Approve/Reject and comments. Same rules as the desk.

**Field Laboratory on site**
- */field-lab*: a phone or tablet screen that works with no signal once opened. Readings are flagged against the specification as they are typed, kept on the device, and sent with Sync. Sync creates the Water Sample and draft Water Analyses.
- A draft analysis keeps the readings even if an instrument has no calibration on record; signing is still blocked until it does.
- On-site pH 7.01 buffer check per visit (tolerance in Settings), shown in the report's measurement checks.
- *Prepare First Calibrations* (Water Sample form) opens draft Calibration Records for the HANNA HI98130 and HACH DR900 with their check points listed.

**Commercial**
- *Quick Order*: Brave Home orders by phone, WhatsApp or the public */quick-order* page. Paste a WhatsApp message and use *Read Message*; *Create Sales Order* creates the customer if needed. Optional WhatsApp Business webhook: `/api/method/chemical_erp.chemical_core.quick_orders.whatsapp_webhook`.
- A price list for each customer group (Utilities, Manufacturers, Projects, Brave Home channels…), *Fill From Another List* on any Price List (percentage, rounding, never below the price floor), and the *Price List Comparison* report.
- *Cash Flow Forecast* (13 weeks): bank and cash today, customer invoices moved by each customer's usual delay, sales orders, supplier orders paid in advance, supplier invoices, expense claims, payroll and PAYE/NSSF, plus *Planned Cash Items* (rent, loans, taxes). Weeks below the minimum balance are flagged and appear on the dashboard.

**Deleting documents:** the Managing Director can delete any document. A line manager can delete documents raised by (or for) the people in their team, using *Menu > Delete (as line manager)*; nobody deletes their own. Every deletion is reported to the MD, and a full copy is kept under *Deleted Document* for restoring. Others use *Menu > Request Deletion*, which goes to their line manager, or to the MD when there is no line manager. Personal to-dos, calendar entries, comments and attachments are not covered; commission lines are never deleted.

**Security:** password policy (strength 3 of 4), lock-out for 15 minutes after 5 failed sign-ins, 12-hour idle sign-out, password change every 90 days (applied once; editable in System Settings). Two-factor sign-in (authenticator app) for MD, admin, accounts, HR and formula roles, switched on from *Chemical ERP Settings > Security > Turn On Two-Factor Sign-in* once outgoing email works. The MD is alerted to repeated failed sign-ins, privileged users signing in from a new network address, privileged roles being given, and bank-detail changes (payments to that party then need the MD for 48 hours). Leavers' accounts are disabled automatically; accounts unused for 60 days are flagged and disabled at 90. Only managers may export sensitive lists. Changes to customers, suppliers, staff, prices and bank accounts are tracked. The MD is alerted if no backup has been taken in 26 hours. *Security Check* shows what needs attention.

**Product documents (SDS, CoA):** every item has a *Document Profile* (Hazardous - Made by Us, Hazardous - Bought In, Non-hazardous Industrial, Consumer (Brave Home), Service / Equipment / PPE), set automatically on update and editable. Hazardous products cannot be delivered without a current SDS; non-hazardous products only warn; services never need one. Customers marked *Requires a Certificate* or *Requires an SDS* get hard stops for every product. Receipts ask for the supplier's SDS only when none is on file, turn it into a draft SDS File for HSE, and certify batches received without a supplier CoA as a *Certificate of Testing* (or *Certificate of Conformity* where the item says so); the printed certificate carries the right title and statement. Purchase orders print the documents the supplier must send. The MD can approve a one-off *Document Exception* for a single delivery (14 days at most). *Document Gaps* lists what is missing, ranked by stock and sales.

**Production waste:** Waste = (1 − Yield %) × Total Batch Size. The total batch size is everything charged into the batch, in kg (litres through each item's density); the yield is entered on the formula (blank: product out ÷ materials in, and a warning when the entered yield disagrees with the quantities by more than 1 point). The formula's waste item is set to that waste, so production entries are pre-filled with it and disposal is costed on it. Each production run works out its own expected waste from what was actually charged, its actual yield, and any loss not recorded as waste (batch in − product out − waste). More than 10% above the expected waste needs the Plant Manager's approval; less than 50% of it needs a reason (both in Settings). Waste must be ticked as weighed; an approval covers only the quantities approved. *Production Waste Variance* shows every run.

**Business Diagnostics:** the MD's dashboard has a *🩺 Business Diagnostics* button (also in the Management Systems workspace). It runs 34 checks across sales, finance and cash, stock, production and quality, purchasing, compliance and HSE, people and control, the field laboratory, tenders and security; grades each Good / Watch / Act Now against good practice; and gives a recommendation, the role that should act and a link to the evidence. Each run is kept with an overall and per-area score and the change since the last run; it also runs on the 1st of every month and notifies the MD. Checks with no data yet say so.

## ❓ Help (the user manual, searched by keyword)

- **❓ Help** sits in the top bar on every page (also on My Dashboard, and **Ctrl+Shift+H**). It asks "What do you need help with?" and searches as you type.
- Everyday words work: LPO → purchase order, GRN → purchase receipt, MSDS → SDS, BOM → formula, salary/PAYE → payroll, "MD is away" → delegation, forgot password → signing in. Matches are highlighted; ↑/↓ and Enter pick a result.
- Opened on a document (e.g. a Purchase Order), it starts with **Help for this page**. Each topic has buttons to open the documents it talks about. **Whole Manual** shows every section as a table of contents.
- The manual is stored as **Help Topics** (one per sub-heading), loaded on install/migrate from `help/manual_topics.json`. The MD or a System Manager can edit a topic in the system or add new ones; edited topics are marked *Edited Here* and are never overwritten by later manual updates.
- Searches that find nothing are counted: **Help Topic list > Searches With No Answer** shows what people looked for, so the next topics can be written where people get stuck.
