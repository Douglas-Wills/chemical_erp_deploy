"""Formulas, potency, substitutes, co-products, waste and Job Card blocks."""

import frappe
from frappe import _
from frappe.utils import flt, getdate, today
from chemical_erp.utils import USABLE_EQUIPMENT, approver_role, get_settings, has_role, is_formula_owner, MD_ROLE, position_title


# ------------------------------------------------------------------ BOM (formula)
def bom_validate(doc, method=None):
	if doc.get("formula_level") == "Master premix":
		doc.is_confidential = 1
	if doc.get("is_confidential") and not is_formula_owner():
		frappe.throw(_("Only the Managing Director or the formula delegate can edit this formula."), frappe.PermissionError)
	if doc.docstatus == 0:
		doc.formula_status = "Draft"
	changed = formula_waste(doc)
	expected_disposal = 0.0
	base_cost = flt(doc.raw_material_cost) + flt(doc.operating_cost)
	for row in doc.get("scrap_items") or []:
		if frappe.get_cached_value("Item", row.item_code, "is_waste_item"):
			if flt(row.rate):
				row.rate = 0
				changed = True
			expected_disposal += to_kg(row.item_code, row.stock_qty) * _disposal_rate(row.item_code)  # rates are per kg
		elif row.get("is_co_product") and flt(row.stock_qty):
			row.rate = flt(base_cost * flt(row.allocation_percent) / 100 / flt(row.stock_qty), 4)
			changed = True
	if sum(flt(r.get("allocation_percent")) for r in doc.get("scrap_items") or []) >= 100:
		frappe.throw(_("Co-product allocations must total less than 100%; the rest stays on the main product."))
	doc.expected_disposal_cost = expected_disposal
	if changed and hasattr(doc, "calculate_cost"):
		doc.calculate_cost()
	from chemical_erp.chemical_core.costing import bom_costing

	bom_costing(doc)


KG = {"kg": 1, "kgs": 1, "kilogram": 1, "kilograms": 1, "g": 0.001, "gram": 0.001, "grams": 0.001, "tonne": 1000, "tonnes": 1000,
      "ton": 1000, "metric ton": 1000, "mt": 1000}
LITRE = {"l": 1, "litre": 1, "litres": 1, "liter": 1, "liters": 1, "ltr": 1, "ml": 0.001, "millilitre": 0.001, "m3": 1000, "cubic meter": 1000}


def to_kg(item_code, qty):
	"""Quantity in the item's stock unit, in kg: litres through the item's density (1 kg/L when none is set); items
	counted in pieces (Nos, jerrycan, drum, bar) through ERPNext's Weight Per Unit. A piece with no weight set counts
	as no mass (not 1 kg each); formulas warn about such items (see unweighed)."""
	uom = (frappe.get_cached_value("Item", item_code, "stock_uom") or "").strip().lower()
	if uom in KG:
		return flt(qty) * KG[uom]
	if uom in LITRE:
		return flt(qty) * LITRE[uom] * (flt(frappe.get_cached_value("Item", item_code, "density_kg_per_l")) or 1.0)
	per_piece = flt(frappe.get_cached_value("Item", item_code, "weight_per_unit"))
	if per_piece:
		w_uom = (frappe.get_cached_value("Item", item_code, "weight_uom") or "kg").strip().lower()
		return flt(qty) * per_piece * KG.get(w_uom, 1)
	return 0.0


def unweighed(item_codes):
	"""Items counted in pieces with no Weight Per Unit: their mass cannot enter the batch size."""
	out = []
	for code in dict.fromkeys(item_codes):
		uom = (frappe.get_cached_value("Item", code, "stock_uom") or "").strip().lower()
		if uom not in KG and uom not in LITRE and not flt(frappe.get_cached_value("Item", code, "weight_per_unit")):
			out.append(code)
	return out


def waste_thresholds():
	"""(tolerance %, low %) from Chemical ERP Settings; blank means the defaults 10 and 50, while 0 is honoured."""
	s = get_settings()
	over = flt(s.get("waste_tolerance_percent")) if s.get("waste_tolerance_percent") not in (None, "") else 10.0
	under = flt(s.get("waste_low_percent")) if s.get("waste_low_percent") not in (None, "") else 50.0
	return over, under


def from_kg(item_code, kg):
	"""kg back to the item's stock unit."""
	per_unit = to_kg(item_code, 1) or 1.0
	return flt(kg) / per_unit


def formula_waste(doc):
	"""Waste = (1 − Yield %) × Total Batch Size.
	Total batch size: everything charged into the batch, in kg. Yield: entered on the formula; when blank it is worked out
	as product out ÷ materials in. The waste item rows are then set to that waste (shared in their current proportions),
	so production entries are pre-filled with the right estimate and disposal is costed on it."""
	batch_kg = sum(to_kg(r.item_code, r.stock_qty) for r in doc.get("items") or [])
	missing = unweighed([r.item_code for r in doc.get("items") or []] + [doc.item])
	if missing:
		frappe.msgprint(_("These items are counted in pieces and have no Weight Per Unit, so they add nothing to the batch size: {0}. "
		                  "Set Weight Per Unit on the item if it is part of the batch (packaging can be left).").format(", ".join(missing)),
		                indicator="orange", alert=True)
	out_kg = to_kg(doc.item, _bom_doc_qty_in_stock_uom(doc))
	out_kg += sum(to_kg(r.item_code, r.stock_qty) for r in doc.get("scrap_items") or []
	              if not frappe.get_cached_value("Item", r.item_code, "is_waste_item"))  # co-products are output too
	if doc.meta.has_field("total_batch_kg"):
		doc.total_batch_kg = round(batch_kg, 3)
	implied = round(min(out_kg / batch_kg * 100, 100), 2) if batch_kg else 100.0
	if not flt(doc.get("expected_yield_percent")) and batch_kg:
		doc.expected_yield_percent = implied
	elif batch_kg and abs(flt(doc.expected_yield_percent) - implied) > 1:
		frappe.msgprint(_("The formula's quantities give a yield of {0}% ({1:.1f} kg out of {2:.1f} kg charged), but {3}% is entered. "
		                  "Check the batch quantities, the product's density, or the yield.").format(
			implied, out_kg, batch_kg, flt(doc.expected_yield_percent)), indicator="orange", alert=True)
	y = min(max(flt(doc.get("expected_yield_percent")), 0), 100)
	waste_kg = (1 - y / 100) * batch_kg
	if doc.meta.has_field("expected_waste_kg"):
		doc.expected_waste_kg = round(waste_kg, 3)
	rows = [r for r in doc.get("scrap_items") or [] if frappe.get_cached_value("Item", r.item_code, "is_waste_item")]
	if waste_kg > 0.0005 and not rows:
		frappe.msgprint(_("This formula expects {0:.2f} kg of waste (yield {1}%), but has no waste item. Add the waste item under Scrap "
		                  "Items so it can be recorded, held and costed for disposal.").format(waste_kg, y), indicator="orange", alert=True)
		return False
	current = sum(to_kg(r.item_code, r.stock_qty) for r in rows)
	changed = False
	for r in rows:
		share = (to_kg(r.item_code, r.stock_qty) / current) if current else 1.0 / len(rows)
		target = round(from_kg(r.item_code, waste_kg * share), 4)
		if abs(flt(r.stock_qty) - target) > 1e-4:
			r.stock_qty, r.qty = target, target / (flt(r.get("conversion_factor")) or 1)
			changed = True
	return changed


def _bom_doc_qty_in_stock_uom(doc):
	stock_uom = frappe.get_cached_value("Item", doc.item, "stock_uom")
	if not doc.get("uom") or doc.uom == stock_uom:
		return flt(doc.quantity) or 1.0
	factor = flt(frappe.db.get_value("UOM Conversion Detail", {"parent": doc.item, "uom": doc.uom}, "conversion_factor")) or 1.0
	return (flt(doc.quantity) or 1.0) * factor


def bom_quantity_in_stock_uom(bom_no):
	"""A formula written per tonne or per drum, converted to the product's stock unit (what fg_completed_qty counts)."""
	bom = frappe.db.get_value("BOM", bom_no, ["quantity", "uom", "item"], as_dict=True)
	if not bom:
		return 1.0
	stock_uom = frappe.get_cached_value("Item", bom.item, "stock_uom")
	if not bom.uom or bom.uom == stock_uom:
		return flt(bom.quantity) or 1.0
	factor = flt(frappe.db.get_value("UOM Conversion Detail", {"parent": bom.item, "uom": bom.uom}, "conversion_factor"))
	if not factor:
		from erpnext.stock.get_item_details import get_conversion_factor

		factor = flt((get_conversion_factor(bom.item, bom.uom) or {}).get("conversion_factor")) or 1.0
	return (flt(bom.quantity) or 1.0) * factor


def formula_yield(bom_no):
	"""Expected yield % of a formula (entered, or product out ÷ materials in)."""
	y = flt(frappe.db.get_value("BOM", bom_no, "expected_yield_percent")) if frappe.get_meta("BOM").has_field("expected_yield_percent") else 0
	if y:
		return min(y, 100)
	items = frappe.get_all("BOM Item", filters={"parent": bom_no}, fields=["item_code", "stock_qty"])
	batch = sum(to_kg(r.item_code, r.stock_qty) for r in items)
	out = to_kg(frappe.db.get_value("BOM", bom_no, "item"), bom_quantity_in_stock_uom(bom_no))
	return min(out / batch * 100, 100) if batch else 100.0


def run_balance(doc):
	"""For a production entry: total batch size (kg charged), product out (kg), waste recorded (kg), expected waste
	= (1 − formula yield) × total batch size, actual yield, and the loss not accounted for by recorded waste."""
	bom_item = frappe.db.get_value("BOM", doc.bom_no, "item") if doc.get("bom_no") else None
	batch = out = recorded = 0.0
	for row in doc.items:
		waste = frappe.get_cached_value("Item", row.item_code, "is_waste_item")
		qty = flt(row.get("transfer_qty") or row.qty)
		if row.s_warehouse and not row.t_warehouse and not waste:
			batch += to_kg(row.item_code, qty)
		elif row.t_warehouse and waste:
			recorded += to_kg(row.item_code, qty)
		elif row.t_warehouse and (row.get("is_finished_item") or row.get("is_scrap_item") or row.item_code == bom_item):
			out += to_kg(row.item_code, qty)
	if not batch and doc.get("bom_no"):  # nothing consumed listed: the formula's batch, scaled
		scale = flt(doc.fg_completed_qty) / bom_quantity_in_stock_uom(doc.bom_no)
		batch = sum(to_kg(r.item_code, r.stock_qty) for r in frappe.get_all("BOM Item", filters={"parent": doc.bom_no},
		                                                                     fields=["item_code", "stock_qty"])) * scale
	y = formula_yield(doc.bom_no) if doc.get("bom_no") else 100.0
	expected = (1 - y / 100) * batch
	return frappe._dict(batch_kg=batch, output_kg=out, recorded_kg=recorded, yield_expected=y, expected_kg=expected,
	                    yield_actual=(out / batch * 100) if batch else 0.0, unaccounted_kg=max(batch - out - recorded, 0.0))


def expected_waste(bom_no, qty_made):
	"""{waste item: expected quantity (its stock unit)} for qty_made of the product: (1 − yield) × batch, shared over the
	formula's waste items."""
	scale = flt(qty_made) / bom_quantity_in_stock_uom(bom_no)
	batch = sum(to_kg(r.item_code, r.stock_qty) for r in frappe.get_all("BOM Item", filters={"parent": bom_no},
	                                                                     fields=["item_code", "stock_qty"])) * scale
	waste_kg = (1 - formula_yield(bom_no) / 100) * batch
	rows = [r for r in frappe.get_all("BOM Scrap Item", filters={"parent": bom_no}, fields=["item_code", "stock_qty"])
	        if frappe.get_cached_value("Item", r.item_code, "is_waste_item")]
	total = sum(to_kg(r.item_code, r.stock_qty) for r in rows)
	out = {}
	for r in rows:
		share = to_kg(r.item_code, r.stock_qty) / total if total else 1.0 / len(rows)
		out[r.item_code] = out.get(r.item_code, 0) + from_kg(r.item_code, waste_kg * share)
	return out


def _disposal_rate(waste_item):
	"""Cheapest current disposal rate per kg, in company currency."""
	from chemical_erp.utils import exchange_rate

	rows = frappe.get_all("Disposal Vendor Price", filters={"waste_item": waste_item, "valid_from": ["<=", today()]},
	                      or_filters=[["valid_to", "is", "not set"], ["valid_to", ">=", today()]],
	                      fields=["rate_per_kg", "currency"])
	rates = [flt(r.rate_per_kg) * exchange_rate(r.currency) for r in rows]
	return min(rates) if rates else 0.0


def bom_on_submit(doc, method=None):
	doc.db_set("formula_status", "Approved")


# ------------------------------------------------------------------ Work Order
def work_order_validate(doc, method=None):
	bom = frappe.db.get_value("BOM", doc.bom_no, ["docstatus", "formula_status", "is_active", "is_confidential"], as_dict=True)
	if not bom or bom.docstatus != 1 or bom.formula_status != "Approved" or not bom.is_active:
		frappe.throw(_("BOM {0} is not an approved, active formula.").format(doc.bom_no), title=_("Formula not approved"))
	doc.is_confidential = bom.is_confidential
	if doc.is_confidential and not is_formula_owner():
		frappe.throw(_("Only the Managing Director or the formula delegate can work with a premix order."), frappe.PermissionError)
	differs = 0
	if doc.get("sales_order"):
		so_qty = frappe.db.get_value("Sales Order Item", {"parent": doc.sales_order, "item_code": doc.production_item}, "sum(stock_qty)")
		default_bom = frappe.db.get_value("Item", doc.production_item, "default_bom")
		differs = int(flt(so_qty) != flt(doc.qty) or (default_bom and default_bom != doc.bom_no))
	doc.differs_from_sales_order = differs


# ------------------------------------------------------------------ Stock Entry
def stock_entry_validate(doc, method=None):
	conf = 0
	if doc.get("work_order"):
		conf = frappe.db.get_value("Work Order", doc.work_order, "is_confidential") or 0
	elif doc.get("bom_no"):
		conf = frappe.db.get_value("BOM", doc.bom_no, "is_confidential") or 0
	doc.is_confidential = conf
	if conf and not is_formula_owner() and not doc.flags.get("system_release"):
		frappe.throw(_("Premix stock entries are restricted to the Managing Director and the formula delegate."), frappe.PermissionError)
	if doc.purpose in ("Material Transfer for Manufacture", "Manufacture"):
		_apply_potency(doc)
		_check_substitutes(doc)
	if doc.purpose == "Manufacture":
		_waste_rules(doc)
		_absorb_standard_costs(doc)


def _apply_potency(doc):
	for row in doc.items:
		if not row.s_warehouse or not row.get("batch_no") or flt(row.get("potency_factor")):
			continue
		item = frappe.get_cached_value("Item", row.item_code, ["is_potency_managed", "target_assay"], as_dict=True)
		if not item or not item.is_potency_managed or not flt(item.target_assay):
			continue
		assay = flt(frappe.db.get_value("Batch", row.batch_no, "assay"))
		if not assay:
			frappe.throw(_("Row {0}: batch {1} has no assay, so potency cannot be applied.").format(row.idx, row.batch_no))
		factor = flt(item.target_assay) / assay
		row.qty = flt(row.qty * factor, 3)
		row.potency_factor = flt(factor, 4)


def _check_substitutes(doc):
	bom_no = doc.get("bom_no") or (doc.work_order and frappe.db.get_value("Work Order", doc.work_order, "bom_no"))
	if not bom_no:
		return
	subs = {s.substitute_item: s for s in frappe.get_all("BOM Substitute", filters={"parent": bom_no},
	                                                   fields=["substitute_item", "min_assay"])}
	for row in doc.items:
		s = subs.get(row.item_code)
		if s and flt(s.min_assay) and row.get("batch_no"):
			assay = flt(frappe.db.get_value("Batch", row.batch_no, "assay"))
			if assay < flt(s.min_assay):
				frappe.throw(_("Row {0}: substitute batch {1} assays {2}%, below the minimum {3}%.").format(
					row.idx, row.batch_no, assay, s.min_assay))


def _waste_rules(doc):
	"""Recorded waste against the formula's estimate.
	- above the estimate by more than the tolerance (Settings, default 10%): the Plant Manager approves;
	- below the low limit (default 50% of the estimate, including none): a reason is required, because waste that is
	  not recorded is waste that is not accounted for;
	- waste quantities must be confirmed as weighed: ERPNext fills in the formula's figure, which proves nothing;
	- an approval covers the quantities approved; changing them afterwards needs a new approval."""
	bom_no = doc.get("bom_no")
	if not bom_no:
		return
	s = get_settings()
	over, under = waste_thresholds()
	bal = run_balance(doc)
	for field, value in (("total_batch_kg", bal.batch_kg), ("expected_yield_percent", bal.yield_expected), ("actual_yield_percent", bal.yield_actual),
	                     ("waste_unaccounted_kg", bal.unaccounted_kg)):
		if doc.meta.has_field(field):
			doc.set(field, round(value, 3))
	actual = {}
	for row in doc.items:
		if row.t_warehouse and frappe.get_cached_value("Item", row.item_code, "is_waste_item"):
			row.basic_rate = 0
			row.set_basic_rate_manually = 1
			row.allow_zero_valuation_rate = 1
			actual[row.item_code] = actual.get(row.item_code, 0) + flt(row.transfer_qty or row.qty)
	doc.waste_expected_kg = round(bal.expected_kg, 3) if doc.meta.has_field("waste_expected_kg") else None
	doc.waste_recorded_kg = round(bal.recorded_kg, 3) if doc.meta.has_field("waste_recorded_kg") else None
	rec = bal.recorded_kg
	label = _("waste ({0:.2f} kg recorded; expected (1 − {1:.1f}%) × {2:.1f} kg = {3:.2f} kg)").format(rec, bal.yield_expected, bal.batch_kg, bal.expected_kg)
	low = [label] if bal.expected_kg > 0.0005 and rec < bal.expected_kg * under / 100 else []
	if low and s.require_zero_waste_reason and not (doc.get("waste_reason") or "").strip():
		frappe.throw(_("Recorded waste is well below the estimate: {0}, less than {1}% of it. Weigh it again, or give the reason "
		               "(e.g. waste recovered into the next batch).").format(low[0], int(under)), title=_("Waste lower than expected"))
	if actual and doc.docstatus == 1 and doc.meta.has_field("waste_weighed") and not doc.get("waste_weighed"):
		frappe.throw(_("Confirm the waste quantities were weighed (tick 'Waste Weighed'). The formula's figure is filled in for you and "
		               "must be replaced by the weighed quantity."), title=_("Waste not weighed"))
	excess = [label] if rec > bal.expected_kg * (1 + over / 100) + 1e-6 else []
	import json

	snapshot = json.dumps({i: round(q, 3) for i, q in sorted(actual.items())})
	if doc.get("excess_waste_approved_by") and doc.meta.has_field("excess_waste_approved_qty") and doc.get("excess_waste_approved_qty") != snapshot:
		doc.excess_waste_approved_by = None  # the quantities changed after approval
		doc.excess_waste_approved_qty = None
	if excess and not doc.get("excess_waste_approved_by"):
		msg = _("Waste above the estimate needs the {1}'s approval: {0}.").format(excess[0], position_title())
		if doc.docstatus == 1:
			frappe.throw(msg, title=_("Excess waste"))
		frappe.msgprint(msg + " " + _("The entry is saved as a draft and the {0} has been asked to approve.").format(position_title()),
		                indicator="orange", alert=True)
		doc.flags.notify_excess_waste = excess


def notify_excess_waste(doc, method=None):
	"""After a draft manufacture entry with excess waste is saved, ask the Plant Manager to approve it."""
	if doc.flags.get("notify_excess_waste") and doc.name:
		from chemical_erp.utils import notify, users_with_role

		notify(users_with_role(approver_role()), "Stock Entry", doc.name,
		       _("Excess waste to approve on {0}: {1}").format(doc.name, ", ".join(doc.flags.notify_excess_waste)), priority="High")


def _absorb_standard_costs(doc):
	"""Add labour and overheads marked 'Add to Stock Value' from the product's standard cost sheet,
	scaled to the quantity made, so finished stock is valued at full cost. Entered costs are never replaced."""
	if doc.get("additional_costs") or doc.flags.get("no_cost_absorption"):
		return
	item = (frappe.db.get_value("Work Order", doc.work_order, "production_item") if doc.get("work_order")
	        else frappe.db.get_value("BOM", doc.get("bom_no"), "item"))
	sheet = frappe.db.get_value("Product Cost Sheet", {"item_code": item, "status": "Current"}, ["name", "batch_size"], as_dict=True) if item else None
	if not sheet or not flt(sheet.batch_size) or not flt(doc.fg_completed_qty):
		return
	scale = flt(doc.fg_completed_qty) / flt(sheet.batch_size)
	added = False
	for line in frappe.get_all("Cost Sheet Line", filters={"parent": sheet.name}, fields=["cost_element", "amount"]):
		e = frappe.get_cached_value("Cost Element", line.cost_element, ["absorb_into_stock", "absorbed_account"], as_dict=True)
		if e and e.absorb_into_stock and e.absorbed_account and flt(line.amount):
			amount = flt(line.amount * scale, 2)
			doc.append("additional_costs", {"expense_account": e.absorbed_account, "description": _("{0} (standard cost, {1})").format(line.cost_element, sheet.name),
			                                 "amount": amount, "base_amount": amount, "exchange_rate": 1})
			added = True
	if added and hasattr(doc, "calculate_rate_and_amount"):
		doc.calculate_rate_and_amount()


@frappe.whitelist()
def approve_excess_waste(stock_entry):
	if not (has_role(approver_role()) or has_role(MD_ROLE)):
		frappe.throw(_("Only the {0} or the Managing Director can approve excess waste.").format(position_title()), frappe.PermissionError)
	doc = frappe.get_doc("Stock Entry", stock_entry)
	if doc.owner == frappe.session.user:
		frappe.throw(_("You created this entry, so you cannot approve its waste."))
	import json

	actual = {}
	for row in doc.items:
		if row.t_warehouse and frappe.get_cached_value("Item", row.item_code, "is_waste_item"):
			actual[row.item_code] = actual.get(row.item_code, 0) + flt(row.transfer_qty or row.qty)
	values = {"excess_waste_approved_by": frappe.session.user}
	if doc.meta.has_field("excess_waste_approved_qty"):
		values["excess_waste_approved_qty"] = json.dumps({i: round(q, 3) for i, q in sorted(actual.items())})
	doc.db_set(values)
	return True


# ------------------------------------------------------------------ Job Card
def job_card_validate(doc, method=None):
	from chemical_erp.management_systems.gates import check as permit_gate

	permit_gate("Production")
	s = get_settings()
	if s.block_job_card_equipment and doc.get("workstation"):
		critical = ["A - Quality or safety", "B - Stops production"]
		for eq in frappe.get_all("Equipment", filters={"workstation": doc.workstation, "criticality": ["in", critical]},
		                         fields=["name", "status"]):
			if eq.status not in ("In Service", "Calibration Due"):
				frappe.throw(_("Equipment {0} on this workstation is {1}.").format(eq.name, eq.status), title=_("Equipment not usable"))
			overdue = frappe.db.exists("Maintenance Job", {"equipment": eq.name, "job_type": "Preventive",
			                                               "status": ["!=", "Done"], "due_date": ["<", today()]})
			if overdue:
				frappe.throw(_("Equipment {0} has overdue preventive maintenance ({1}).").format(eq.name, overdue),
				             title=_("Maintenance overdue"))
	if s.block_job_card_training and doc.get("workstation"):
		required = frappe.get_all("Training Requirement", filters={"workstation": doc.workstation, "active": 1}, pluck="required_record")
		employees = {r.employee for r in (doc.get("time_logs") or []) if r.get("employee")}
		employees |= {r.employee for r in (doc.get("employee") or []) if hasattr(r, "employee") and r.employee}
		for emp in employees:
			for req in required:
				ok = frappe.db.exists("Staff Certification", {"parent": emp, "parenttype": "Employee", "title": req,
				                                              "expires_on": [">=", today()]}) or \
				     frappe.db.exists("Staff Certification", {"parent": emp, "parenttype": "Employee", "title": req,
				                                              "expires_on": ["is", "not set"]})
				if not ok:
					from chemical_erp.learning.needs import on_job_card_blocked

					on_job_card_blocked(emp, req, doc.name if not doc.is_new() else None)
					frappe.throw(_("{0} has no current '{1}', required on {2}. A training need has been raised.").format(emp, req, doc.workstation),
					             title=_("Training required"))
