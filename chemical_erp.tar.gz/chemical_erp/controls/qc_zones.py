"""Batch status vs warehouse QC zone, on every stock movement."""

import frappe
from frappe import _

from chemical_erp.utils import batch_info, row_batches, warehouse_zone

ALLOWED = {
	"Quarantine": {"Quarantine", "Receiving"},
	"Released": {"Released", "WIP", "Transit", "Neutral"},
	"Retest Due": set(),
	"Rejected": {"Rejected"},
	"Expired": {"Rejected"},
}


def _item_flags(item_code):
	return frappe.get_cached_value("Item", item_code, ["is_waste_item", "has_batch_no"], as_dict=True) or frappe._dict()


def validate_zone(doc, method=None):
	system = doc.flags.get("system_release") or doc.flags.get("system_move")
	for row in doc.get("items") or []:
		item = _item_flags(row.item_code)
		if not item.get("has_batch_no"):
			continue
		target = row.get("t_warehouse") if doc.doctype == "Stock Entry" else row.get("warehouse")
		source = row.get("s_warehouse") if doc.doctype == "Stock Entry" else None
		tz = warehouse_zone(target)

		if doc.doctype == "Purchase Receipt":
			if tz not in ("Quarantine", "Receiving"):
				frappe.throw(_("Row {0}: received goods must go to a Quarantine warehouse, not {1}.").format(row.idx, target))
			continue

		# New output of a manufacture or repack: no batch yet
		if doc.doctype == "Stock Entry" and target and not source and doc.purpose in ("Manufacture", "Repack"):
			if item.get("is_waste_item"):
				if tz != "Waste Hold":
					frappe.throw(_("Row {0}: waste must go to the Waste Hold warehouse.").format(row.idx))
			elif tz != "Quarantine":
				frappe.throw(_("Row {0}: production output must go to a Quarantine warehouse until released.").format(row.idx))
			continue

		for batch_no, _qty in row_batches(row):
			b = batch_info(batch_no)
			if not b:
				continue
			status = b.qc_status or "Quarantine"
			if b.is_waste_batch:
				ok = (not target and doc.flags.get("disposal_issue")) or tz == "Waste Hold" or (
					doc.doctype == "Stock Entry" and doc.purpose == "Material Transfer for Manufacture")
				if not ok:
					frappe.throw(_("Batch {0} is waste. It can only stay in Waste Hold, return to process, or leave through a Disposal Order.").format(batch_no))
				continue
			if target:
				if system:
					continue
				if tz not in ALLOWED.get(status, set()):
					frappe.throw(_("Batch {0} is {1} and cannot go to {2} ({3} zone).").format(batch_no, status, target, tz),
					             title=_("QC zone rule"))
			elif source:
				# Issue with no target: only Released stock, a QC sample, or a system move
				if status != "Released" and not system and doc.get("stock_entry_type") != "QC Sample":
					frappe.throw(_("Batch {0} is {1} and cannot be issued.").format(batch_no, status), title=_("QC zone rule"))
