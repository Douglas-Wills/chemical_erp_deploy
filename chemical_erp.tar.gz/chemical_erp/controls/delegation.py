"""Approval delegation: while the Managing Director is away, a named person signs in the MD's place.

How it works
- Every workflow step that waits on the MD has a twin step for the role "MD Delegate" (added in setup/workflows.py).
- Nobody holds "MD Delegate" except during an active Approval Delegation; the role is given and taken back here.
- When the delegate signs, before_transition (controls/approvals.py) calls `check`, which confirms the delegation is
  active today, covers this document type and is within its per-document cap. The approval log records the delegation.
- Formulas (BOMs) and cancellations are never delegated.
"""

import frappe
from frappe import _
from frappe.utils import cint, date_diff, flt, getdate, now_datetime, today

from chemical_erp.utils import MD_ROLE, get_settings, has_role

DELEGATE_ROLE = "MD Delegate"
NO_DELEGATION_WORKFLOWS = {"Chem Formula"}
NOT_DELEGATED_ACTIONS = {"Cancel", "Approve as MD", "Make Obsolete"}

# The value the per-document cap is compared with (company currency).
AMOUNT_FIELDS = {
	"Purchase Order": ("base_grand_total",),
	"Purchase Receipt": ("base_grand_total",),
	"Payment Entry": ("base_paid_amount",),
	"Expense Claim": ("base_total_sanctioned_amount", "total_sanctioned_amount", "total_claimed_amount"),
	"Disposal Order": ("expected_cost",),
	"Credit Limit Request": ("requested_limit",),
	"Quotation": ("base_grand_total",),
	"Sales Order": ("base_grand_total",),
}


def delegate_transitions(workflow_name, transitions):
	"""Twin steps for the delegate: same from/to/condition as the MD's own step."""
	if workflow_name in NO_DELEGATION_WORKFLOWS:
		return []
	return [(f, a, n, DELEGATE_ROLE, c) for f, a, n, r, c in transitions if r == MD_ROLE and a not in NOT_DELEGATED_ACTIONS]


def amount_of(doc):
	for field in AMOUNT_FIELDS.get(doc.doctype, ()):
		if doc.get(field) is not None and flt(doc.get(field)):
			return flt(doc.get(field))
	return 0.0


def active_for(user, on=None):
	"""The delegation the user is signing under today, or None."""
	on = getdate(on or today())
	for d in frappe.get_all("Approval Delegation", filters={"delegate": user, "status": ["in", ["Active", "Scheduled"]]},
	                        fields=["name", "valid_from", "valid_to"], order_by="valid_from asc"):
		if getdate(d.valid_from) <= on <= getdate(d.valid_to):
			return frappe.get_doc("Approval Delegation", d.name)
	return None


def covers(delegation, doc):
	"""(True, None) or (False, reason)."""
	if not cint(delegation.all_documents):
		allowed = {r.document_type for r in delegation.document_types}
		if doc.doctype not in allowed:
			return False, _("Delegation {0} does not cover {1}. It waits for the Managing Director.").format(delegation.name, _(doc.doctype))
	cap = flt(delegation.max_amount)
	if cap and amount_of(doc) > cap:
		return False, _("{0} {1} is above the delegate's cap of {2}. It waits for the Managing Director.").format(
			_(doc.doctype), doc.name, frappe.format_value(cap, {"fieldtype": "Currency"}))
	return True, None


def check(doc, user, allowed_role):
	"""Called from before_transition. Returns the delegation name when the user is signing as the MD's delegate."""
	if allowed_role != DELEGATE_ROLE or has_role(MD_ROLE, user):
		return None
	d = active_for(user)
	if not d:
		frappe.throw(_("You have no active approval delegation from the Managing Director today."), title=_("Not delegated"))
	ok, reason = covers(d, doc)
	if not ok:
		frappe.throw(reason, title=_("Outside the delegation"))
	return d.name


def record(delegation_name):
	frappe.db.set_value("Approval Delegation", delegation_name, "signed_count",
	                    cint(frappe.db.get_value("Approval Delegation", delegation_name, "signed_count")) + 1, update_modified=False)


# ---------------------------------------------------------------- role sync and the daily run
def status_on(d, on=None):
	on = getdate(on or today())
	if d.status == "Revoked":
		return "Revoked"
	if on < getdate(d.valid_from):
		return "Scheduled"
	if on > getdate(d.valid_to):
		return "Expired"
	return "Active"


def sync_role(user):
	"""The delegate holds the role exactly while one of their delegations is active."""
	if not user or not frappe.db.exists("User", user):
		return
	want = bool(active_for(user)) and frappe.db.get_value("User", user, "enabled")
	roles = frappe.get_roles(user)
	if want and DELEGATE_ROLE not in roles:
		frappe.get_doc("User", user).add_roles(DELEGATE_ROLE)
	elif not want and DELEGATE_ROLE in roles:
		frappe.get_doc("User", user).remove_roles(DELEGATE_ROLE)


def daily():
	"""Start and end delegations on their dates; tell the MD what the delegate signed yesterday."""
	users = set()
	for d in frappe.get_all("Approval Delegation", filters={"status": ["in", ["Scheduled", "Active"]]},
	                        fields=["name", "status", "valid_from", "valid_to", "delegate"]):
		new = status_on(d)
		if new != d.status:
			frappe.db.set_value("Approval Delegation", d.name, "status", new, update_modified=False)
			if new == "Active":
				from chemical_erp.utils import notify

				notify(d.delegate, "Approval Delegation", d.name,
				       _("From today you sign for the Managing Director until {0}. Open /approvals to see what is waiting.").format(d.valid_to),
				       priority="High")
		users.add(d.delegate)
	for user in frappe.get_all("Has Role", filters={"role": DELEGATE_ROLE, "parenttype": "User"}, pluck="parent"):
		users.add(user)
	for user in users:
		sync_role(user)
	report_to_md()


def signed_yesterday(delegation_name):
	day = frappe.utils.add_days(today(), -1)
	return frappe.get_all("Approval Log", filters={"delegation": delegation_name, "on": ["between", [f"{day} 00:00:00", f"{day} 23:59:59"]]},
	                      fields=["parenttype", "parent", "action", "state", "user", "on"], order_by="`on` asc")


def report_to_md():
	from chemical_erp.people_management.positions import md_users

	if not frappe.get_meta("Approval Log").has_field("delegation"):
		return
	for d in frappe.get_all("Approval Delegation", filters={"status": ["in", ["Active", "Expired"]], "daily_report": 1,
	                                                         "valid_to": [">=", frappe.utils.add_days(today(), -1)]},
	                        fields=["name", "delegate"]):
		rows = signed_yesterday(d.name)
		if not rows:
			continue
		lines = "".join(f"<li>{frappe.utils.escape_html(r.parenttype)} <a href='{frappe.utils.get_url_to_form(r.parenttype, r.parent)}'>"
		                f"{frappe.utils.escape_html(r.parent)}</a>: {frappe.utils.escape_html(r.action)} → {frappe.utils.escape_html(r.state)}</li>"
		                for r in rows)
		frappe.sendmail(recipients=md_users(), subject=_("Signed for you yesterday under {0}: {1} document(s)").format(d.name, len(rows)),
		                message=f"<p>{frappe.utils.escape_html(frappe.utils.get_fullname(d.delegate))} signed:</p><ul>{lines}</ul>",
		                reference_doctype="Approval Delegation", reference_name=d.name)


def ensure_role_and_permissions():
	"""The delegate role exists and can open, save and submit what it may sign. Runs on install and migrate."""
	from frappe.permissions import add_permission, update_permission_property

	from chemical_erp.setup.workflows import WORKFLOWS

	if not frappe.db.exists("Role", DELEGATE_ROLE):
		frappe.get_doc({"doctype": "Role", "role_name": DELEGATE_ROLE, "desk_access": 1}).insert(ignore_permissions=True)
	for name, (doctype, _states, transitions) in WORKFLOWS.items():
		if not delegate_transitions(name, transitions) or not frappe.db.exists("DocType", doctype):
			continue
		if not frappe.db.exists("Custom DocPerm", {"parent": doctype, "role": DELEGATE_ROLE, "permlevel": 0}):
			add_permission(doctype, DELEGATE_ROLE, 0)
		ptypes = ["read", "write", "print", "report"]
		if frappe.get_meta(doctype).is_submittable:
			ptypes.append("submit")
		for ptype in ptypes:
			update_permission_property(doctype, DELEGATE_ROLE, 0, ptype, 1, validate=False)


def validate_delegation(doc):
	if not has_role(MD_ROLE) and frappe.session.user != "Administrator":
		frappe.throw(_("Only the Managing Director can delegate approvals."), frappe.PermissionError)
	if has_role(MD_ROLE, doc.delegate):
		frappe.throw(_("The delegate cannot be a Managing Director."))
	if not frappe.db.get_value("User", doc.delegate, "enabled"):
		frappe.throw(_("{0} is disabled.").format(doc.delegate))
	if getdate(doc.valid_to) < getdate(doc.valid_from):
		frappe.throw(_("'To' is before 'From'."))
	limit = cint(get_settings().get("max_approval_delegation_days")) or 30
	if date_diff(doc.valid_to, doc.valid_from) + 1 > limit:
		frappe.throw(_("A delegation can last at most {0} days. Make a new one when it ends.").format(limit))
	if not cint(doc.all_documents) and not doc.document_types:
		frappe.throw(_("List the documents the delegate may sign, or tick 'All MD approvals'."))
	for r in doc.document_types or []:
		if r.document_type == "BOM":
			frappe.throw(_("Formulas (BOMs) stay with the Managing Director and cannot be delegated."))
	if doc.status != "Revoked":
		clash = frappe.get_all("Approval Delegation", filters={"name": ["!=", doc.name or ""], "status": ["in", ["Scheduled", "Active"]],
		                                                        "valid_from": ["<=", doc.valid_to], "valid_to": [">=", doc.valid_from]},
		                       fields=["name", "delegate"])
		if clash:
			frappe.throw(_("{0} ({1}) already covers some of these dates. One delegate at a time keeps it clear who signs.").format(
				clash[0].name, clash[0].delegate))
		doc.status = status_on(doc)
