"""Expense Claim approval routing.

First signature: the claimant's own expense approver (their department manager). If that person is the
Managing Director, the claimant themself, or not set, the Fallback Expense Approver in Chemical ERP Settings
(the Accounts Officer) signs first instead, so the MD can still sign last.
Last signature: the MD above the expense limit. The MD's own claims need no approval: the MD approves them directly.
"""

import frappe
from frappe import _

from chemical_erp.utils import MD_ROLE, get_settings, has_role, notify, users_with_role



def _claimant_user(doc):
	return frappe.db.get_value("Employee", doc.employee, "user_id") if doc.get("employee") else None


def set_routing(doc, method=None):
	claimant = _claimant_user(doc)
	doc.claimant_is_md = 1 if claimant and has_role(MD_ROLE, claimant) else 0
	doc.raised_by_md = doc.claimant_is_md
	first = doc.get("expense_approver")
	if not first or first == claimant or has_role(MD_ROLE, first):
		from chemical_erp.people_management.positions import holder_of

		# The Accounts Officer signs first; while that post is vacant the MD covers it.
		first = get_settings().expense_fallback_approver or holder_of("Accounts Officer")
	doc.first_approver = first


def check_transition(doc, action, state):
	"""Called from approvals.before_transition for Expense Claim."""
	user = frappe.session.user
	if user == "Administrator":
		return
	if action == "Submit for Approval":
		if not doc.first_approver:
			frappe.throw(_("No first approver: set the employee's Expense Approver, or the Fallback Expense Approver in Chemical ERP Settings."),
			             title=_("Approver missing"))
		if not has_role("Expense Approver", doc.first_approver):
			frappe.throw(_("{0} needs the Expense Approver role to approve this claim.").format(doc.first_approver))
		return
	if state == "Manager Review" and action in ("Approve", "Review", "Reject"):
		if user != doc.first_approver:
			frappe.throw(_("This claim is waiting for {0} to sign first.").format(frappe.utils.get_fullname(doc.first_approver)),
			             title=_("Not your approval"))
	if state == "MD Review" and action in ("Approve", "Reject"):
		from chemical_erp.controls.delegation import DELEGATE_ROLE

		# the MD's delegate is allowed here: delegation.check has already confirmed the delegation covers this claim
		if not (has_role(MD_ROLE) or has_role(DELEGATE_ROLE)):
			frappe.throw(_("Only the Managing Director (or the MD's delegate) can give the final approval."), title=_("Not your approval"))


def notify_next(doc, method=None):
	before = doc.get_doc_before_save()
	state = doc.get("workflow_state")
	if not before or before.get("workflow_state") == state:
		return
	amount = frappe.utils.fmt_money(doc.get("total_sanctioned_amount") or doc.get("total_claimed_amount"), currency=doc.get("currency"))
	if state == "Manager Review" and doc.first_approver:
		notify(doc.first_approver, doc.doctype, doc.name, _("Expense claim to approve: {0}, {1}").format(doc.employee_name, amount))
	elif state == "MD Review":
		who = users_with_role(MD_ROLE)
		notify(who, doc.doctype, doc.name, _("Expense claim for final approval: {0}, {1}").format(doc.employee_name, amount))
	elif state in ("Approved", "Rejected"):
		claimant = _claimant_user(doc)
		if claimant:
			notify(claimant, doc.doctype, doc.name, _("Your expense claim {0} was {1}").format(doc.name, state.lower()))
