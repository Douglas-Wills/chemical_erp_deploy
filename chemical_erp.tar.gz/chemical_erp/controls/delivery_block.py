"""Hard stops on Delivery Note and Sales Invoice. No role, setting or approval can bypass these."""

import frappe
from frappe import _
from frappe.utils import flt, getdate, today

from chemical_erp.utils import batch_info, current_sds, get_settings, row_batches, warehouse_zone


def _needs_sds(item_code, customer=None):
	"""By the item's Document Profile (regulatory_compliance/documents.py)."""
	from chemical_erp.regulatory_compliance.documents import sds_required

	return sds_required(item_code, customer)


def check(doc, method=None):
	if doc.doctype == "Sales Invoice" and not doc.get("update_stock"):
		return  # stock left on the Delivery Note, which is checked there
	if doc.get("is_return"):
		return
	from chemical_erp.management_systems.gates import check as permit_gate

	permit_gate("Delivery")
	from chemical_erp.regulatory_compliance.documents import delivery_problems

	problems, warnings = delivery_problems(doc)  # SDS and certificates, by product type and customer
	from chemical_erp.regulatory_compliance.controlled import problems as controlled_problems

	problems += controlled_problems(doc)  # controlled chemicals: declaration, licence, annual limit
	now = getdate(today())
	for row in doc.items:
		for batch_no, _q in row_batches(row):
			b = batch_info(batch_no)
			if not b:
				continue
			zone = warehouse_zone(row.warehouse)
			if b.is_waste_batch or zone == "Waste Hold":
				problems.append(_("Row {0}: batch {1} is waste and can never be delivered").format(row.idx, batch_no))
			elif zone in ("Quarantine", "Rejected"):
				problems.append(_("Row {0}: {1} is a {2} warehouse; stock there cannot be delivered").format(row.idx, row.warehouse, zone))
			elif b.qc_status != "Released":
				problems.append(_("Row {0}: batch {1} is {2}, not Released").format(row.idx, batch_no, b.qc_status or "Quarantine"))
			if b.expiry_date and getdate(b.expiry_date) < now:
				problems.append(_("Row {0}: batch {1} expired on {2}").format(row.idx, batch_no, b.expiry_date))
			if b.retest_date and getdate(b.retest_date) < now:
				problems.append(_("Row {0}: batch {1} passed its retest date {2}").format(row.idx, batch_no, b.retest_date))
			if get_settings().check_customer_spec:
				problems += _spec_problems(doc, row, batch_no)
	if problems:
		frappe.throw("<br>".join(problems), title=_("Delivery blocked"))
	if warnings and doc.docstatus == 0:
		frappe.msgprint("<br>".join(dict.fromkeys(warnings)), title=_("Product documents"), indicator="orange")


def _spec_problems(doc, row, batch_no):
	out = []
	specs = frappe.get_all("Customer Spec Line", filters={"parent": doc.customer, "parenttype": "Customer", "item_code": row.item_code},
	                       fields=["parameter", "min_value", "max_value"])
	if not specs:
		return out
	qi = frappe.db.get_value("Batch", batch_no, "accepted_inspection")
	readings = {r.specification.lower(): flt(r.reading_value or r.reading_1) for r in
	            frappe.get_all("Quality Inspection Reading", filters={"parent": qi}, fields=["specification", "reading_value", "reading_1"])} if qi else {}
	for s in specs:
		val = readings.get((s.parameter or "").lower())
		if val is None:
			out.append(_("Row {0}: batch {1} has no result for {2}, which the customer specifies").format(row.idx, batch_no, s.parameter))
		elif (s.min_value and val < s.min_value) or (s.max_value and val > s.max_value):
			out.append(_("Row {0}: batch {1} {2} = {3} is outside the customer's limits").format(row.idx, batch_no, s.parameter, val))
	return out


def returns_to_quarantine(doc, method=None):
	"""Goods coming back from a customer are received into Quarantine or Rejected, never straight into released stock."""
	if not doc.get("is_return"):
		return
	for row in doc.items:
		if row.get("batch_no") or row.get("serial_and_batch_bundle"):
			if warehouse_zone(row.warehouse) not in ("Quarantine", "Rejected"):
				frappe.throw(_("Row {0}: returned goods must be received into a Quarantine or Rejected warehouse, not {1}.").format(
					row.idx, row.warehouse), title=_("Returned goods"))


def stamp_sds(doc, method=None):
	"""Store the SDS file actually used on each row, so a reprint uses the same file."""
	if doc.get("is_return"):
		return
	for row in doc.items:
		if row.meta.has_field("sds_file") and _needs_sds(row.item_code, doc.get("customer")):
			row.sds_file = current_sds(row.item_code)
