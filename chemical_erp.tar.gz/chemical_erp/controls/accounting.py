import frappe
from frappe import _

from chemical_erp.utils import get_settings


def period_closing_validate(doc, method=None):
	if not get_settings().block_period_close:
		return
	end = doc.get("period_end_date") or doc.get("posting_date")
	pending = frappe.db.sql(
		"""select count(*) from `tabBatch` where qc_status='Quarantine' and reference_doctype='Stock Entry'
		and ifnull(is_waste_batch,0)=0 and creation <= %s""", (str(end) + " 23:59:59",))[0][0]
	if pending:
		frappe.throw(_("{0} production batch(es) from this period are still in Quarantine. Release or reject them before closing.").format(pending),
		             title=_("Period close blocked"))
