"""Receipt into Quarantine, inspection, release and rejection."""

import frappe
from frappe import _
from frappe.utils import flt, getdate, now_datetime, today

from chemical_erp.utils import (USABLE_EQUIPMENT, batch_balances, get_settings, make_stock_entry, notify,
                                row_batches, users_with_role, warehouse_zone)


# ------------------------------------------------------------------ receipt and manufacture outputs
def purchase_receipt_on_submit(doc, method=None):
	for row in doc.items:
		for batch_no, _q in row_batches(row):
			values = {"qc_status": "Quarantine"}
			if row.get("supplier_batch_no"):
				values["supplier_batch"] = row.supplier_batch_no
			for f in ("supplier_coa", "supplier_sds"):
				if row.get(f):
					values[f] = row.get(f)
			frappe.db.set_value("Batch", batch_no, values, update_modified=False)
			open_inspection(row.item_code, batch_no, "Incoming", "Purchase Receipt", doc.name)


def manufacture_on_submit(doc, method=None):
	if doc.purpose not in ("Manufacture", "Repack"):
		return
	finished = []
	for row in doc.items:
		if not row.t_warehouse or row.s_warehouse:
			continue
		is_waste = frappe.get_cached_value("Item", row.item_code, "is_waste_item")
		for batch_no, _q in row_batches(row):
			values = {"source_work_order": doc.work_order, "qc_status": "Quarantine"}
			if is_waste:
				values["is_waste_batch"] = 1
			else:
				finished.append((row.item_code, batch_no))
			frappe.db.set_value("Batch", batch_no, values, update_modified=False)
	main = finished[0][1] if finished else None
	for row in doc.items:
		if row.t_warehouse and frappe.get_cached_value("Item", row.item_code, "is_waste_item"):
			for batch_no, _q in row_batches(row):
				frappe.db.set_value("Batch", batch_no, "waste_from_batch", main, update_modified=False)
	for item_code, batch_no in finished:
		open_inspection(item_code, batch_no, "Outgoing", "Stock Entry", doc.name)


def open_inspection(item_code, batch_no, inspection_type, ref_type, ref_name):
	if frappe.db.exists("Quality Inspection", {"batch_no": batch_no, "docstatus": 0, "reference_name": ref_name}):
		return
	qi = frappe.new_doc("Quality Inspection")
	qi.update({"inspection_type": inspection_type, "reference_type": ref_type, "reference_name": ref_name,
	           "item_code": item_code, "batch_no": batch_no, "sample_size": 1, "report_date": today(),
	           "inspected_by": frappe.session.user,
	           "quality_inspection_template": frappe.get_cached_value("Item", item_code, "quality_inspection_template")})
	if qi.quality_inspection_template and hasattr(qi, "get_item_specification_details"):
		qi.get_item_specification_details()
	copy_coa_fields(qi)
	qi.flags.ignore_mandatory = True
	qi.flags.ignore_permissions = True
	qi.insert()
	notify(users_with_role("QC Analyst"), "Quality Inspection", qi.name,
	       _("Inspection needed: {0} batch {1}").format(item_code, batch_no))


def copy_coa_fields(qi):
	"""ERPNext copies only the standard template columns into readings; add the COA method and printed specification."""
	if not qi.get("quality_inspection_template"):
		return
	tpl = {r.specification: r for r in frappe.get_all(
		"Item Quality Inspection Parameter", filters={"parent": qi.quality_inspection_template},
		fields=["specification", "test_method", "specification_text"])}
	for r in qi.get("readings") or []:
		t = tpl.get(r.specification)
		if t:
			if not r.get("test_method"):
				r.test_method = t.test_method
			if not r.get("specification_text"):
				r.specification_text = t.specification_text


# ------------------------------------------------------------------ inspection rules
def inspection_validate(doc, method=None):
	copy_coa_fields(doc)
	for r in doc.get("readings") or []:
		if not r.meta.has_field("instrument"):
			break
		if r.get("numeric") and not r.get("instrument"):
			frappe.throw(_("Reading {0} ({1}): name the instrument used.").format(r.idx, r.specification), title=_("Instrument required"))
		if r.get("reagent"):
			rs = frappe.db.get_value("Reagent Solution", r.reagent, ["status", "expires_on"], as_dict=True)
			if not rs or rs.status != "Valid" or getdate(rs.expires_on) < getdate(today()):
				frappe.throw(_("Reading {0}: reagent {1} is expired or discarded and cannot be used.").format(r.idx, r.reagent),
				             title=_("Reagent not usable"))
		if r.get("instrument"):
			status = frappe.db.get_value("Equipment", r.instrument, "status")
			if status not in USABLE_EQUIPMENT:
				frappe.throw(_("Reading {0}: instrument {1} is {2} and cannot be used.").format(r.idx, r.instrument, status),
				             title=_("Instrument not usable"))


def blocking_deviation(batch_no):
	return frappe.db.get_value("Deviation", {"batch": batch_no, "status": ["!=", "Closed"], "batch_blocked": 1}, "name")


def inspection_on_submit(doc, method=None):
	if not doc.batch_no:
		return
	if doc.status == "Accepted":
		release_batch(doc.batch_no, doc)
		keep_retained_sample(doc)
	elif doc.status == "Rejected":
		reject_batch(doc.batch_no, doc)


def inspection_before_cancel(doc, method=None):
	"""Cancelling a signed inspection undoes a release or rejection: only the quality approver or the MD may."""
	from chemical_erp.utils import MD_ROLE, approver_role, has_role

	if frappe.session.user != "Administrator" and not (has_role(MD_ROLE) or has_role(approver_role("quality"))):
		frappe.throw(_("Only the {0} or the Managing Director can cancel a batch inspection.").format(approver_role("quality")),
		             frappe.PermissionError, title=_("Not allowed"))


def inspection_on_cancel(doc, method=None):
	"""The batch goes back on hold: its release (or rejection) no longer stands until it is inspected again."""
	if not doc.batch_no:
		return
	b = frappe.db.get_value("Batch", doc.batch_no, ["accepted_inspection", "qc_status"], as_dict=True) or {}
	values = {}
	if b.get("accepted_inspection") == doc.name:
		values["accepted_inspection"] = None
	if b.get("qc_status") in ("Released", "Rejected"):
		values["qc_status"] = "Quarantine"
	if values:
		frappe.db.set_value("Batch", doc.batch_no, values)
		frappe.msgprint(_("Batch {0} is on hold again (Quarantine) until a new inspection releases it.").format(doc.batch_no),
		                indicator="orange", alert=True)


def keep_retained_sample(qi):
	"""Keep a sample of every released finished batch (and raw materials if set) for complaint investigations."""
	s = get_settings()
	is_finished = frappe.db.get_value("Batch", qi.batch_no, "reference_doctype") == "Stock Entry"
	if not (is_finished or s.get("retain_raw_material_samples")) or frappe.db.exists("Retained Sample", {"batch": qi.batch_no}):
		return
	frappe.get_doc({"doctype": "Retained Sample", "batch": qi.batch_no, "sample_qty": s.get("retained_sample_qty") or 0.5,
	                "uom": frappe.get_cached_value("Item", qi.item_code, "stock_uom"),
	                "storage_location": s.get("retained_sample_location") or "Retained sample store"}).insert(ignore_permissions=True)


def _assay_from(qi):
	for r in qi.get("readings") or []:
		if "assay" in (r.specification or "").lower():
			return flt(r.get("reading_value") or r.get("reading_1"))
	return None


def release_batch(batch_no, qi=None, via=None):
	dev = blocking_deviation(batch_no)
	if dev:
		frappe.throw(_("Batch {0} cannot be released while Deviation {1} is open.").format(batch_no, dev), title=_("Release blocked"))
	s = get_settings()
	b = frappe.get_doc("Batch", batch_no)
	values = {"qc_status": "Released"}
	if qi:
		values["accepted_inspection"] = qi.name
		assay = _assay_from(qi)
		if assay:
			values["assay"] = assay
	frappe.db.set_value("Batch", batch_no, values)
	target = s.released_finished_warehouse if b.reference_doctype == "Stock Entry" else s.released_raw_warehouse
	_move(b, target, "Quarantine", via or (qi and qi.name))


def reject_batch(batch_no, qi=None, via=None):
	s = get_settings()
	b = frappe.get_doc("Batch", batch_no)
	frappe.db.set_value("Batch", batch_no, "qc_status", "Rejected")
	_move(b, s.rejected_warehouse, None, via or (qi and qi.name))
	if qi:
		dev = frappe.get_doc({"doctype": "Deviation", "title": _("Batch {0} rejected").format(batch_no),
		                      "source_type": "Quality Inspection", "source_name": qi.name, "batch": batch_no,
		                      "description": _("Opened automatically when inspection {0} rejected the batch.").format(qi.name)})
		dev.insert(ignore_permissions=True)


def _move(batch, target, only_zone, reference):
	"""System transfer of every balance of a batch into `target` (from `only_zone` warehouses if given)."""
	if not target:
		frappe.throw(_("Set the release and rejected warehouses in Chemical ERP Settings."))
	rows = []
	for wh, qty in batch_balances(batch.name):
		if wh == target or (only_zone and warehouse_zone(wh) != only_zone):
			continue
		rows.append({"item_code": batch.item, "qty": qty, "s_warehouse": wh, "t_warehouse": target, "batch_no": batch.name})
	if rows:
		company = frappe.get_cached_value("Warehouse", target, "company")
		make_stock_entry(company, "Material Transfer", rows, flags={"system_release": True},
		                 is_release_transfer=1, release_reference=reference,
		                 remarks=_("System transfer for batch {0} ({1})").format(batch.name, reference))
