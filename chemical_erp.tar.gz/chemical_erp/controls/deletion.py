"""Who may delete a document, and what happens when one is deleted.

- The Managing Director may delete any document.
- A line manager may delete documents created by (or for) the people who report to them, directly or further down.
  Nobody deletes their own documents: their line manager does, and where there is no line manager the MD does.
- Every deletion by a person (form, list or API) is reported to the MD, and Frappe keeps a full copy under
  'Deleted Document', from which it can be restored.
- Everyone else uses Menu > Request Deletion, which goes to their line manager (the MD if they have none).
The system's own clean-ups (e.g. recalculating draft payslips) are not affected.
"""

import frappe
from frappe import _

from chemical_erp.utils import MD_ROLE

# Not business documents: personal notes, logs, attachments and system records. Deleting these follows Frappe's
# own permissions (e.g. only a System Manager removes a User Permission); the line-manager rule does not apply.
EXEMPT = {"ToDo", "Event", "Comment", "Communication", "File", "Notification Log", "Error Log", "Route History", "Email Queue",
          "Scheduled Job Log", "Prepared Report", "Session Default", "User Permission", "DocShare", "Tag Link", "Kanban Board",
          "Dashboard Settings", "List View Settings", "Report", "Workflow Action", "Energy Point Log", "Integration Request",
          "Webhook Request Log", "Submission Queue", "Unhandled Email", "Document Scan"}
# The audit trail: the kept copies of deleted documents and the change and access history. Never deleted from the
# screens or the API (only by the Administrator), so a deletion can always be traced and undone.
AUDIT = {"Deleted Document", "Version", "Activity Log", "Access Log"}
NEVER = {"Commission Entry"}  # ledgers: corrected by new lines, never deleted
APPS = ("erpnext", "hrms", "chemical_erp")


def is_md(user=None):
	user = user or frappe.session.user
	return user == "Administrator" or MD_ROLE in frappe.get_roles(user)


def people_on(doc):
	"""Employees a document belongs to: whoever created it, and the employee it is for (claims, leave, payslips…)."""
	people = set()
	emp = frappe.db.get_value("Employee", {"user_id": doc.owner}, "name") if doc.get("owner") else None
	if emp:
		people.add(emp)
	if doc.meta.has_field("employee") and doc.get("employee"):
		people.add(doc.employee)
	return people


def line_manager_of(employee):
	"""The line manager's login, or None (then the MD acts as line manager)."""
	manager = frappe.db.get_value("Employee", employee, "reports_to") if employee else None
	if not manager or frappe.db.get_value("Employee", manager, "status") != "Active":
		return None
	user = frappe.db.get_value("Employee", manager, "user_id")
	return user if user and frappe.db.get_value("User", user, "enabled") else None


def manages(user, doc):
	from chemical_erp.people_management.access import employee_of, team_of

	me = employee_of(user)
	if not me:
		return False
	people = people_on(doc)
	return bool(people) and me not in people and people <= team_of(me)


def may_delete(doc, user=None):
	user = user or frappe.session.user
	if doc.doctype in NEVER:
		return False
	if doc.doctype in AUDIT:
		return user == "Administrator"
	return doc.doctype in EXEMPT or is_md(user) or manages(user, doc)


def check(doc):
	if may_delete(doc):
		return
	if doc.doctype in NEVER:
		frappe.throw(_("{0} lines are never deleted; corrections are made as new lines.").format(_(doc.doctype)), frappe.PermissionError)
	if doc.doctype in AUDIT:
		frappe.throw(_("{0} is part of the audit trail and is not deleted.").format(_(doc.doctype)), frappe.PermissionError)
	frappe.throw(_("Only the line manager of the person who raised this {0}, or the Managing Director, can delete it. "
	               "Cancel it, or use Menu > Request Deletion.").format(_(doc.doctype)), frappe.PermissionError, title=_("Not allowed"))


def _delete(doctype, name):
	doc = frappe.get_doc(doctype, name)
	check(doc)
	owner, title = doc.owner, doc.get_title() if hasattr(doc, "get_title") else name
	# System records follow Frappe's own permissions. Business documents: check() has already allowed this user (the
	# MD, or the line manager, who has no 'Delete' role right), so Frappe's role check is not repeated.
	frappe.delete_doc(doctype, name, ignore_permissions=doctype not in EXEMPT)
	report_to_md(doctype, name, owner, title)


def report_to_md(doctype, name, owner, title=None):
	"""Tell the MD who deleted what; the copy is kept under Deleted Document."""
	if doctype in EXEMPT or is_md():
		return
	from chemical_erp.people_management.positions import md_users
	from chemical_erp.utils import notify

	copy = frappe.db.get_value("Deleted Document", {"deleted_doctype": doctype, "deleted_name": name}, "name", order_by="creation desc")
	notify(md_users(), "Deleted Document" if copy else doctype, copy or name,
	       _("{0} deleted {1} {2}{3} (raised by {4}). A copy is kept and can be restored.").format(
		       frappe.utils.get_fullname(), _(doctype), name, f" ({title})" if title and title != name else "",
		       frappe.utils.get_fullname(owner)))


# --- the delete routes -------------------------------------------------------------------------------
@frappe.whitelist(methods=["POST", "DELETE"])
def client_delete(doctype, name):
	"""Replaces frappe.client.delete (the form's Delete)."""
	_delete(doctype, name)


@frappe.whitelist(methods=["POST", "DELETE"])
def delete_items():
	"""Replaces frappe.desk.reportview.delete_items (list view bulk delete): each document checked on its own."""
	import json

	doctype = frappe.form_dict.get("doctype")
	items = frappe.form_dict.get("items")
	names = json.loads(items) if isinstance(items, str) else (items or [])
	refused = []
	for name in names:
		try:
			_delete(doctype, name)
			frappe.db.commit()
		except Exception:
			frappe.db.rollback()
			frappe.clear_messages()
			refused.append(name)
	if refused:
		frappe.msgprint(_("Not deleted (not yours to delete, or linked to other documents): {0}").format(", ".join(refused[:20])),
		                indicator="orange")


@frappe.whitelist()
def can_delete(doctype, name):
	"""For the form menu: may this user delete this document although they hold no 'Delete' right?"""
	doc = frappe.get_doc(doctype, name)
	doc.check_permission("read")
	return {"line_manager": not is_md() and manages(frappe.session.user, doc)}


@frappe.whitelist()
def manager_delete(doctype, name):
	_delete(doctype, name)
	return True


def on_trash(doc, method=None):
	"""REST API: DELETE /api/resource/<doctype>/<name>. (Code-driven clean-ups do not come through a DELETE request.)"""
	req = getattr(frappe.local, "request", None)
	if req is not None and req.method == "DELETE" and (req.path or "").startswith(("/api/resource", "/api/v2/document")):
		check(doc)
		# after the delete commits, so the kept copy (Deleted Document) can be linked
		frappe.db.after_commit.add(lambda: report_to_md(doc.doctype, doc.name, doc.owner))


# --- asking for a deletion ---------------------------------------------------------------------------
@frappe.whitelist()
def request_deletion(doctype, name, reason):
	"""Goes to the requester's line manager; the MD when there is none."""
	doc = frappe.get_doc(doctype, name)
	doc.check_permission("read")
	reason = (reason or "").strip()
	if len(reason) < 5:
		frappe.throw(_("Say why it should be deleted."))
	from chemical_erp.people_management.access import employee_of
	from chemical_erp.people_management.positions import md_users
	from chemical_erp.utils import notify

	manager = line_manager_of(employee_of(frappe.session.user))
	to = [manager] if manager else md_users()
	notify(to, doctype, name, _("Deletion requested by {0}: {1}").format(frappe.utils.get_fullname(), reason[:200]), priority="High")
	doc.add_comment("Comment", _("Deletion requested from {0}: {1}").format(
		frappe.utils.get_fullname(to[0]) if to else _("the Managing Director"), reason[:500]))
	return frappe.utils.get_fullname(to[0]) if to else _("the Managing Director")


def boot_session(bootinfo):
	"""The form shows 'Delete (as line manager)' only to people who manage someone."""
	from chemical_erp.people_management.access import employee_of

	me = employee_of(frappe.session.user)
	bootinfo.chem_manages_staff = bool(me and frappe.db.exists("Employee", {"reports_to": me, "status": "Active"}))


# --- permissions (install / migrate) -----------------------------------------------------------------
def business_doctypes():
	modules = frappe.get_all("Module Def", filters={"app_name": ["in", APPS]}, pluck="name")
	return [d for d in frappe.get_all("DocType", filters={"module": ["in", modules], "istable": 0, "issingle": 0, "is_virtual": 0},
	                                  pluck="name") if d not in EXEMPT and d not in AUDIT]


def ensure_md_only_delete():
	"""The 'Delete' right stays with the MD only; line managers delete through the checked route above."""
	from frappe.permissions import update_permission_property

	if not frappe.db.exists("Role", MD_ROLE):
		return
	for dt in business_doctypes():
		try:
			perms = frappe.get_all("Custom DocPerm", filters={"parent": dt}, fields=["role", "permlevel", "delete"]) or \
				frappe.get_all("DocPerm", filters={"parent": dt}, fields=["role", "permlevel", "delete"])
			for p in perms:
				if (p.role != MD_ROLE or dt in NEVER) and p.delete:
					update_permission_property(dt, p.role, p.permlevel, "delete", 0, validate=False)
			md = [p for p in perms if p.role == MD_ROLE and p.permlevel == 0]
			if dt in NEVER:
				continue
			if not md:  # the MD may delete anything: give the MD a row where the doctype has none (so Delete shows)
				from frappe.permissions import add_permission

				add_permission(dt, MD_ROLE, 0)
			if not md or not md[0].delete:
				update_permission_property(dt, MD_ROLE, 0, "delete", 1, validate=False)
		except Exception:
			frappe.log_error(title=f"Delete rights: could not update {dt}", message=frappe.get_traceback())
