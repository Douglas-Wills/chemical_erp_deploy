"""Suggested approval limits, worked out from the company's own documents.

Limits default to 0, so until they are set every purchase, payment and expense waits for the Managing Director.
This looks at the last six months and proposes limits that leave the MD the larger documents only, and shows how
many approvals each limit would have taken off the MD's desk. Nothing is saved: the MD reviews and saves.
"""

import math

import frappe
from frappe import _
from frappe.utils import add_months, flt, today

from chemical_erp.utils import MD_ROLE, get_settings, has_role

# Used when there is too little history (fewer than MIN_HISTORY documents). Uganda shillings.
STARTER = {"po_limit": 1_000_000, "po_md_limit": 5_000_000, "expense_limit": 300_000, "payment_limit": 5_000_000,
           "disposal_limit": 2_000_000, "estimate_limit": 20_000_000, "sales_discount_limit": 5}
MIN_HISTORY = 10

# field: (label, doctype, amount expression, extra filters, percentile, who decides below the limit)
SOURCES = {
	"po_limit": (_("Purchase Order: first approver above"), "Purchase Order", "base_grand_total", {}, 0.50,
	             _("Below it, Procurement submits without an approver")),
	"po_md_limit": (_("Purchase Order: MD above"), "Purchase Order", "base_grand_total", {}, 0.85,
	                _("Below it, Accounts approves")),
	"expense_limit": (_("Expense Claim: MD above"), "Expense Claim", "total_sanctioned_amount", {}, 0.80,
	                  _("Below it, the line manager approves")),
	"payment_limit": (_("Payment: MD above"), "Payment Entry", "base_paid_amount", {"payment_type": "Pay"}, 0.85,
	                  _("Below it, Accounts submits")),
	"disposal_limit": (_("Disposal Order: MD above"), "Disposal Order", "expected_cost", {}, 0.80,
	                   _("Below it, HSE approves")),
	"estimate_limit": (_("Estimate Request value"), "Estimate Request", "estimated_value", {}, 0.75,
	                   _("Below it, Sales confirms without the Sales Manager")),
}


def nice(x):
	"""Round up to 1, 2, 2.5 or 5 times a power of ten: limits people remember."""
	x = flt(x)
	if x <= 0:
		return 0
	power = 10 ** math.floor(math.log10(x))
	for step in (1, 2, 2.5, 5, 10):
		if x <= step * power:
			return int(step * power)
	return int(10 * power)


def percentile(values, q):
	values = sorted(values)
	if not values:
		return 0
	k = (len(values) - 1) * q
	lo, hi = math.floor(k), math.ceil(k)
	return values[lo] + (values[hi] - values[lo]) * (k - lo)


def history(doctype, field, filters):
	if not frappe.db.exists("DocType", doctype) or not frappe.get_meta(doctype).has_field(field):
		return []
	f = {"docstatus": ["<", 2], "creation": [">=", add_months(today(), -6)]}
	f.update(filters)
	return [flt(v) for v in frappe.get_all(doctype, filters=f, pluck=field) if flt(v) > 0]


@frappe.whitelist()
def suggest():
	if not (has_role(MD_ROLE) or has_role("System Manager")):
		frappe.throw(_("Only the Managing Director sets approval limits."), frappe.PermissionError)
	s = get_settings()
	rows = []
	for field, (label, doctype, amount, filters, q, below) in SOURCES.items():
		values = history(doctype, amount, filters)
		current = flt(s.get(field))
		if len(values) >= MIN_HISTORY:
			proposed = nice(percentile(values, q))
			basis = _("{0} {1}s in 6 months; {2}% of them are at or below this").format(len(values), _(doctype), int(q * 100))
		else:
			proposed = STARTER[field]
			basis = _("Starter value: only {0} {1}s on record").format(len(values), _(doctype))
		rows.append({"field": field, "label": label, "current": current, "proposed": proposed, "basis": basis, "below": below,
		             "over_now": sum(1 for v in values if v > current), "over_proposed": sum(1 for v in values if v > proposed),
		             "count": len(values)})
	# the MD threshold for purchase orders must sit above the first-approver threshold
	by = {r["field"]: r for r in rows}
	if by["po_md_limit"]["proposed"] <= by["po_limit"]["proposed"]:
		by["po_md_limit"]["proposed"] = nice(by["po_limit"]["proposed"] * 2.5)
	rows.append({"field": "sales_discount_limit", "label": _("Sales discount %"), "current": flt(s.sales_discount_limit),
	             "proposed": flt(s.sales_discount_limit) or STARTER["sales_discount_limit"],
	             "basis": _("Discounts above this go to the Sales Manager"), "below": "", "over_now": None, "over_proposed": None,
	             "count": None})
	return rows
