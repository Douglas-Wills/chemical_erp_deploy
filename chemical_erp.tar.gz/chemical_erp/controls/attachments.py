"""Required attachments. Drafts may be saved without them; the document cannot move forward
(sent for approval, reviewed or submitted) until the papers are attached."""

import frappe
from frappe import _
from frappe.utils import cint


def _moving_forward(doc):
	state = doc.get("workflow_state")
	return doc.docstatus == 1 or bool(state and state not in ("Draft", "Rejected"))


def _is_chemical(item_code):
	v = frappe.get_cached_value("Item", item_code, ["substance", "is_hazardous"], as_dict=True) or {}
	return bool(v.get("substance") or v.get("is_hazardous"))


def _stop(missing, title):
	if missing:
		frappe.throw(_("Attach these before continuing:") + "<br>• " + "<br>• ".join(missing), title=title)


# Purchase Receipt documents: see regulatory_compliance.documents.receipt_check (Document Profile rules).


def expense_claim(doc, method=None):
	"""Receipts are not needed to ask for approval: they are called for once the expense is approved."""
	return


# ------------------------------------------------------------------ receipts after approval / purchase
def _missing_receipts(doc):
	return [r for r in doc.get("expenses") or [] if not r.get("receipt")]


def expense_receipts(doc, method=None):
	"""On approval (submit) and whenever receipts are attached afterwards."""
	if doc.docstatus != 1:
		return
	status = "Awaiting Receipts" if _missing_receipts(doc) else "Receipts Attached"
	before = doc.get_doc_before_save() if method == "on_update_after_submit" else None
	if doc.get("receipts_status") != status:
		doc.db_set("receipts_status", status, update_modified=False)
	from chemical_erp.utils import notify, users_with_role

	claimant = frappe.db.get_value("Employee", doc.employee, "user_id") if doc.get("employee") else doc.owner
	if status == "Awaiting Receipts" and method == "on_submit":
		start_receipt_clock(doc)
		notify(claimant or doc.owner, doc.doctype, doc.name,
		       _("Your expense claim {0} is approved. Attach the receipt for each expense line to be reimbursed.").format(doc.name), priority="High")
	if status == "Receipts Attached" and (method == "on_submit" or (before and before.get("receipts_status") != status)):
		notify(users_with_role("Accounts User"), doc.doctype, doc.name, _("Receipts attached for {0}: ready to reimburse").format(doc.name))


def purchase_originator(po):
	"""The person who raised the purchase: the material request's requester, else the purchase order's author."""
	for row in po.items:
		if row.get("material_request"):
			return frappe.db.get_value("Material Request", row.material_request, "owner")
	return po.owner


def goods_received(doc, method=None):
	"""Purchase Receipt submitted: the purchase has happened, so ask whoever raised it for the supplier's receipt."""
	from chemical_erp.utils import notify

	for po_name in sorted({r.purchase_order for r in doc.items if r.get("purchase_order")}):
		po = frappe.get_doc("Purchase Order", po_name)
		if po.get("supplier_receipt"):
			continue
		originator = purchase_originator(po)
		po.db_set({"purchase_originator": originator, "supplier_receipt_status": "Awaiting Supplier Receipt"}, update_modified=False)
		if not po.get("receipt_requested_on"):
			start_receipt_clock(po)
		notify(originator, "Purchase Order", po_name,
		       _("Goods from {0} have been received. Attach the supplier's receipt to purchase order {1}; it cannot close without it.").format(
			       po.supplier, po_name), priority="High")


def po_receipt_status(doc, method=None):
	"""Purchase Order updated after submission: record when the receipt is attached."""
	if doc.docstatus != 1:
		return
	if doc.get("supplier_receipt") and doc.get("supplier_receipt_status") != "Attached":
		doc.db_set("supplier_receipt_status", "Attached", update_modified=False)


def _po_missing_receipt(po_names):
	return [po for po in sorted(set(po_names)) if po and not frappe.db.get_value("Purchase Order", po, "supplier_receipt")]


def _invoice_serves_as_receipt(doc):
	return bool(doc.get("invoice_is_receipt") and doc.get("supplier_invoice_file"))


def invoice_needs_po_receipt(doc, method=None):
	"""Posting the supplier's invoice would complete the order, so the order needs its receipt first, unless this
	invoice is itself the receipt (common: the supplier's invoice doubles as the receipt)."""
	if _invoice_serves_as_receipt(doc):
		return
	missing = _po_missing_receipt(r.purchase_order for r in doc.items if r.get("purchase_order"))
	if missing:
		hint = _("If the supplier's invoice doubles as the receipt, attach it here and tick 'This Invoice Is Also the Receipt'.")
		_stop([_("the supplier's receipt on purchase order {0} (the order cannot close without it)").format(m) for m in missing] + [hint],
		      _("Supplier's receipt needed"))


def invoice_as_receipt(doc, method=None):
	"""On submit: file the supplier's invoice as the receipt on each purchase order it covers that has none yet."""
	if not _invoice_serves_as_receipt(doc):
		return
	for po in _po_missing_receipt(r.purchase_order for r in doc.items if r.get("purchase_order")):
		frappe.db.set_value("Purchase Order", po, {"supplier_receipt": doc.supplier_invoice_file, "supplier_receipt_status": "Attached"},
		                    update_modified=False)
		frappe.get_doc("Purchase Order", po).add_comment("Info", _("Supplier's invoice {0} ({1}) filed as the receipt").format(
			doc.bill_no or doc.name, doc.name))


def guard_po_close(names, status):
	if status not in ("Closed", "Completed"):
		return
	missing = _po_missing_receipt(names)
	if missing:
		frappe.throw(_("Attach the supplier's receipt before closing: {0}").format(", ".join(missing)), title=_("Supplier's receipt needed"))


@frappe.whitelist()
def update_po_status(status, name):
	"""Replaces ERPNext's Close button on a purchase order: closing needs the supplier's receipt."""
	guard_po_close([name], status)
	from erpnext.buying.doctype.purchase_order.purchase_order import update_status

	return update_status(status, name)


@frappe.whitelist()
def close_or_unclose_pos(names, status):
	"""Replaces ERPNext's bulk Close from the purchase order list."""
	import json

	guard_po_close(json.loads(names) if isinstance(names, str) else names, status)
	from erpnext.buying.doctype.purchase_order.purchase_order import close_or_unclose_purchase_orders

	return close_or_unclose_purchase_orders(names, status)


def payment_needs_receipts(doc, method=None):
	"""Expense reimbursements wait for the employee's receipts (setting, on by default). Suppliers are paid freely,
	often in full before delivery; their receipt is required before the purchase order can close instead."""
	from chemical_erp.utils import get_settings

	if not get_settings().get("block_payment_without_receipts") or doc.docstatus == 2:
		return
	missing = []
	for r in doc.get("references") or []:
		if r.reference_doctype == "Expense Claim" and frappe.db.get_value("Expense Claim", r.reference_name, "receipts_status") == "Awaiting Receipts":
			missing.append(_("expense claim {0}: receipts not yet attached").format(r.reference_name))
	if missing and doc.docstatus == 1 or (missing and doc.get("workflow_state") not in (None, "", "Draft", "Rejected")):
		_stop(missing, _("Receipts needed before payment"))
	elif missing:
		frappe.msgprint(_("This payment cannot be submitted until: ") + "; ".join(missing), indicator="orange", alert=True)


# ------------------------------------------------------------------ customer purchase orders: the basis for invoicing
def _po_required(customer):
	v = frappe.db.get_value("Customer", customer, "po_required")
	return v is None or bool(v)


def sales_order_po(doc, method=None):
	if not _moving_forward(doc) or not _po_required(doc.customer):
		return
	missing = []
	if not doc.get("po_no"):
		missing.append(_("the customer's purchase order number"))
	if not doc.get("customer_po_file"):
		missing.append(_("a copy of the customer's purchase order"))
	_stop(missing, _("Customer purchase order missing"))


def carry_customer_po(doc, method=None):
	"""Delivery notes and invoices carry the customer's PO from the sales order."""
	if doc.get("is_return"):
		return
	so = next((r.get("against_sales_order") or r.get("sales_order") for r in doc.items if r.get("against_sales_order") or r.get("sales_order")), None)
	if so:
		po = frappe.db.get_value("Sales Order", so, ["po_no", "po_date", "customer_po_file"], as_dict=True)
		if po:
			doc.po_no = doc.get("po_no") or po.po_no
			doc.po_date = doc.get("po_date") or po.po_date
			if doc.meta.has_field("customer_po_file") and not doc.get("customer_po_file"):
				doc.customer_po_file = po.customer_po_file


def invoice_po(doc, method=None):
	if doc.get("is_return") or not _po_required(doc.customer):
		return
	missing = []
	if not doc.get("po_no"):
		missing.append(_("the customer's purchase order number (from the sales order, or entered here)"))
	if not doc.get("customer_po_file"):
		missing.append(_("a copy of the customer's purchase order"))
	_stop(missing, _("No customer purchase order: the invoice has no basis"))


def calibration_record(doc, method=None):
	if _moving_forward(doc) and not doc.get("certificate"):
		_stop([_("the calibration certificate")], _("Calibration certificate missing"))


def employment_contract(doc, method=None):
	if cint(doc.get("is_signed")) and not doc.get("signed_copy"):
		_stop([_("the signed contract / appointment letter, since the contract is marked signed")], _("Signed copy missing"))


def employee(doc, method=None):
	missing = []
	if doc.get("nin") and doc.meta.has_field("nin_card_copy") and not doc.get("nin_card_copy"):
		missing.append(_("a copy of the National ID for NIN {0}").format(doc.nin))
	for q in doc.get("staff_qualifications") or []:
		if not q.get("certificate"):
			missing.append(_("Qualification row {0} ({1}): certificate copy").format(q.idx, q.qualification))
	for c in doc.get("staff_certifications") or []:
		if c.record_type in ("Training", "Certification", "Medical") and not c.get("attachment") and not c.get("awaiting_certificate"):
			missing.append(_("{0} row {1} ({2}): certificate copy").format(c.record_type, c.idx, c.title))
	if doc.meta.has_field("appointment_letter") and doc.status == "Active" and not doc.get("appointment_letter"):
		if doc.is_new():
			missing.append(_("the signed appointment letter"))
		else:
			frappe.msgprint(_("{0} has no signed appointment letter on file. Please attach it.").format(doc.employee_name),
			                indicator="orange", alert=True)
	for c in doc.get("staff_certifications") or []:
		if c.get("attachment") and c.get("awaiting_certificate"):
			c.awaiting_certificate = 0
	_stop(missing, _("Employee documents missing"))


# ------------------------------------------------------------------ privacy
def make_private(doc, fieldnames):
	"""Move personal documents to private storage so only users with access to the record can open them."""
	for fieldname in fieldnames:
		url = doc.get(fieldname)
		if not url or url.startswith("/private/") or not url.startswith("/files/"):
			continue
		name = frappe.db.get_value("File", {"file_url": url}, "name")
		if not name:
			continue
		f = frappe.get_doc("File", name)
		f.is_private = 1
		f.flags.ignore_permissions = True
		f.save()
		doc.set(fieldname, f.file_url)


def employee_privacy(doc, method=None):
	make_private(doc, ("nin_card_copy", "appointment_letter", "cv_attachment"))
	for q in doc.get("staff_qualifications") or []:
		make_private(q, ("certificate",))
	for c in doc.get("staff_certifications") or []:
		make_private(c, ("attachment",))


def contract_privacy(doc, method=None):
	make_private(doc, ("signed_copy",))


def expense_privacy(doc, method=None):
	for r in doc.get("expenses") or []:
		make_private(r, ("receipt",))


def approved_supplier(doc, method=None):
	"""Chemicals may only be ordered from an approved supplier (set by Supplier Evaluation)."""
	if not _moving_forward(doc):
		return
	chemicals = sorted({r.item_code for r in doc.items if _is_chemical(r.item_code)})
	if chemicals and not frappe.db.get_value("Supplier", doc.supplier, "is_approved_vendor"):
		frappe.throw(_("{0} is not an approved supplier, so it cannot supply chemicals ({1}). Evaluate and approve it first.").format(
			doc.supplier, ", ".join(chemicals)), title=_("Supplier not approved"))



# ------------------------------------------------------------------ 72 hours to attach receipts
def deadline_hours():
	from chemical_erp.utils import get_settings

	return int(get_settings().get("receipt_deadline_hours") or 72)


def start_receipt_clock(doc):
	from frappe.utils import add_to_date, now_datetime

	now = now_datetime()
	doc.db_set({"receipt_requested_on": now, "receipt_due_by": add_to_date(now, hours=deadline_hours())}, update_modified=False)


def _employee_user(employee):
	return frappe.db.get_value("Employee", employee, "user_id") if employee else None


def overdue_receipts(user=None, employee=None, kind=None):
	"""Receipts past their deadline. kind: 'expense' (by employee) or 'purchase' (by originator)."""
	from frappe.utils import now_datetime

	now = now_datetime()
	out = []
	if kind in (None, "expense") and employee:
		out += [("Expense Claim", n) for n in frappe.get_all("Expense Claim", filters={
			"employee": employee, "docstatus": 1, "receipts_status": "Awaiting Receipts", "receipt_due_by": ["<", now]}, pluck="name")]
	if kind in (None, "purchase") and user:
		out += [("Purchase Order", n) for n in frappe.get_all("Purchase Order", filters={
			"purchase_originator": user, "docstatus": 1, "supplier_receipt_status": "Awaiting Supplier Receipt",
			"receipt_due_by": ["<", now], "status": ["not in", ["Closed", "Cancelled"]]}, pluck="name")]
	return out


def _refuse(overdue, what):
	items = "; ".join(f"{_(dt)} {n}" for dt, n in overdue)
	frappe.throw(_("Receipts are more than {0} hours overdue on: {1}. Attach them before starting another {2}.").format(
		deadline_hours(), items, what), title=_("Overdue receipts"))


def block_new_expense(doc, method=None):
	"""A new expense claim is refused while the claimant has an approved claim with receipts past the deadline."""
	overdue = overdue_receipts(employee=doc.get("employee"), kind="expense")
	if overdue:
		_refuse(overdue, _("expense claim"))


def block_new_purchase(doc, method=None):
	"""A new purchase request or purchase order is refused while its originator has a purchase with the receipt past the deadline."""
	overdue = overdue_receipts(user=frappe.session.user, kind="purchase")
	if overdue:
		_refuse(overdue, _("purchase request"))


def receipt_deadlines():
	"""Hourly: warn 24 hours before the deadline; at the deadline, tell the originator they are blocked, copied to their line manager."""
	from frappe.utils import add_to_date, now_datetime

	from chemical_erp.utils import notify

	now, hours = now_datetime(), deadline_hours()
	warn_at = add_to_date(now, hours=24)
	sources = (("Expense Claim", {"receipts_status": "Awaiting Receipts"}, lambda d: _employee_user(d.employee), "expense claim"),
	           ("Purchase Order", {"supplier_receipt_status": "Awaiting Supplier Receipt"}, lambda d: d.purchase_originator, "purchase"))
	for doctype, cond, who, label in sources:
		fields = ["name", "receipt_due_by", "receipt_warning_sent", "receipt_breach_sent"] + (["employee"] if doctype == "Expense Claim" else ["purchase_originator"])
		for d in frappe.get_all(doctype, filters={"docstatus": 1, "receipt_due_by": ["is", "set"], **cond}, fields=fields):
			user = who(d)
			if not user:
				continue
			if d.receipt_due_by <= now and not d.receipt_breach_sent:
				emp = frappe.db.get_value("Employee", {"user_id": user}, "reports_to")
				manager = _employee_user(emp)
				notify([user] + ([manager] if manager else []), doctype, d.name,
				       _("Receipt for {0} {1} is over {2} hours late: {3} cannot start another {4} until it is attached.").format(
					       _(doctype), d.name, hours, frappe.utils.get_fullname(user), label), priority="High")
				frappe.db.set_value(doctype, d.name, "receipt_breach_sent", 1, update_modified=False)
			elif d.receipt_due_by <= warn_at and not d.receipt_warning_sent and d.receipt_due_by > now:
				notify(user, doctype, d.name, _("24 hours left to attach the receipt for {0} {1}. After that you cannot start another {2}.").format(
					_(doctype), d.name, label), priority="High")
				frappe.db.set_value(doctype, d.name, "receipt_warning_sent", 1, update_modified=False)
