"""Approval level, segregation of duties and the approval log.

Workflow conditions read only `approval_level`, which this module computes from the
limits in Chemical ERP Settings. Limits default to 0, so until the Managing Director
sets them every document routes for approval (fail closed).
"""

import json

import frappe
from frappe import _
from frappe.utils import flt, now_datetime

from chemical_erp.utils import MD_ROLE, get_settings, has_role

MD_DIRECT = "Approve as MD"
NO_MD_DIRECT_DOCTYPES = {"Quality Inspection", "BOM", "Calibration Record"}


def mark_raised_by_md(doc, method=None):
	"""Every workflow document records whether the Managing Director raised it (for Expense Claims: is the claimant)."""
	if not doc.meta.has_field("raised_by_md") or doc.doctype in NO_MD_DIRECT_DOCTYPES:
		return
	if doc.doctype == "Expense Claim":
		return  # set from the claimant in expenses.set_routing
	raiser = doc.owner if not doc.is_new() else frappe.session.user
	doc.raised_by_md = 1 if raiser and raiser != "Administrator" and has_role(MD_ROLE, raiser) else 0

SIGNING_ACTIONS = ("Sign Results", "Sign", "Send for Approval", "Send for Review", "Send to MD", "Submit", "Confirm",
                   "Revise", "Submit for Approval", "Submit Report")
# Formulas: by Brave's decision the MD may draft and approve alone.
SOD_EXEMPT = {"BOM"}


def _level(amount, first_limit=None, md_limit=None):
	amount = flt(amount)
	if md_limit is not None and amount > flt(md_limit):
		return "MD"
	if first_limit is not None and amount > flt(first_limit):
		return "Manager"
	return "None" if first_limit is not None else "Manager"


def set_approval_level(doc, method=None):
	s = get_settings()
	dt = doc.doctype
	level = None
	if dt == "Purchase Order":
		level = _level(doc.base_grand_total, s.po_limit, s.po_md_limit)
	elif dt == "Expense Claim":
		amount = (doc.get("base_total_sanctioned_amount") or doc.get("total_sanctioned_amount")
		          or doc.get("base_total_claimed_amount") or doc.get("total_claimed_amount"))
		level = "MD" if flt(amount) > flt(s.expense_limit) else "Manager"
	elif dt == "Payment Entry":
		# the limit is for money going out; customer receipts and internal transfers do not wait for the MD
		level = "MD" if doc.get("payment_type") == "Pay" and flt(doc.base_paid_amount) > flt(s.payment_limit) else "None"
	elif dt == "Disposal Order":
		level = "MD" if flt(doc.expected_cost) > flt(s.disposal_limit) else "Manager"
	elif dt == "Estimate Request":
		level = "Manager" if flt(doc.get("base_estimated_value") or doc.estimated_value) > flt(s.estimate_limit) else "None"
	elif dt in ("Quotation", "Sales Order"):
		level = _sales_level(doc, s)
	elif dt == "Work Order":
		level = "MD" if doc.get("differs_from_sales_order") else "None"
	if level is not None:
		doc.approval_level = level


def _sales_level(doc, s):
	limit = flt(s.sales_discount_limit)
	if flt(doc.get("additional_discount_percentage")) > limit:
		return "Manager"
	for row in doc.items:
		if flt(row.get("discount_percentage")) > limit:
			return "Manager"
		if s.enforce_price_floor:
			floor = flt(frappe.get_cached_value("Item", row.item_code, "price_floor"))
			# the floor is per stock unit (kg); a line may be priced per drum or jerrycan
			per_stock_unit = flt(row.base_net_rate or row.base_rate) / (flt(row.get("conversion_factor")) or 1)
			if floor and per_stock_unit < floor:
				return "Manager"
	return "None"


SUBMISSION_ACTIONS = ("Submit Report", "Send for Approval", "Send for Review", "Send to MD", "Submit for Approval", "Submit", "Confirm", "Revise")


def _prior_signers(doc):
	"""People who have already approved or signed. Sending a document for approval is not a signature, and a
	signature the MD gave while covering a vacant position does not bar the MD from signing in their own right."""
	return {r.user for r in (doc.get("approval_log") or [])
	        if r.action not in SUBMISSION_ACTIONS and not r.get("vacancy_cover")}


def _reading_editors(doc):
	"""Users who entered or changed Quality Inspection readings, from Version history."""
	editors = set()
	if doc.doctype != "Quality Inspection" or doc.is_new():
		return editors
	for v in frappe.get_all("Version", filters={"ref_doctype": doc.doctype, "docname": doc.name}, fields=["owner", "data"]):
		try:
			data = json.loads(v.data or "{}")
		except ValueError:
			continue
		touched = any(r and r[0] == "readings" for r in (data.get("added") or []) + (data.get("row_changed") or []))
		if touched:
			editors.add(v.owner)
	# The creator is not counted: inspections are opened by the system for whoever posted the receipt.
	return editors


def before_transition(doc, transition):
	"""Runs for every workflow action on every DocType (hooks: doc_events '*')."""
	if not doc.meta.has_field("approval_log"):
		return
	user = frappe.session.user
	action = transition.get("action") if isinstance(transition, dict) else transition.action
	next_state = transition.get("next_state") if isinstance(transition, dict) else transition.next_state

	md_own = bool(doc.get("raised_by_md")) and has_role(MD_ROLE, user)
	allowed = transition.get("allowed") if isinstance(transition, dict) else getattr(transition, "allowed", None)
	from chemical_erp.people_management.positions import covering

	cover = covering(user, allowed)   # signing only because the post is vacant
	from chemical_erp.controls.delegation import check as delegation_check, record as delegation_record

	delegated = delegation_check(doc, user, allowed)  # signing for the MD while the MD is away
	if action == MD_DIRECT:
		if not md_own:
			frappe.throw(_("Only a document raised by the Managing Director can be approved this way."), title=_("Not allowed"))
		doc.append("approval_log", {"state": next_state, "action": action, "user": user, "on": now_datetime(),
		                            "comment": _("Raised and approved by the Managing Director")})
		return

	if doc.doctype == "Expense Claim" and not md_own:
		from chemical_erp.controls.expenses import check_transition

		check_transition(doc, action, doc.get("workflow_state"))

	if action not in SIGNING_ACTIONS and doc.doctype not in SOD_EXEMPT and user != "Administrator" and not md_own and not cover:
		# Inspections are opened by the system on behalf of whoever posted the receipt or manufacture entry,
		# so their creator is not the person who signs; the reading-editor rule below covers them.
		# The person who must not approve is whoever the document is for: for an expense claim that is the
		# claimant, not whoever keyed it in (HR or the MD may enter claims for staff).
		requester = doc.owner
		if doc.doctype == "Expense Claim" and doc.get("employee"):
			requester = frappe.db.get_value("Employee", doc.employee, "user_id") or doc.owner
		if user == requester and doc.doctype != "Quality Inspection":
			frappe.throw(_("You created this {0}, so you cannot approve it.").format(_(doc.doctype)), title=_("Segregation of duties"))
		if user in _prior_signers(doc):
			frappe.throw(_("You have already signed this {0}. A second person must sign.").format(_(doc.doctype)),
			             title=_("Segregation of duties"))
		if doc.doctype == "Quality Inspection" and not covering(user, "QC Analyst") and (
				user in _reading_editors(doc) or user == doc.get("analyst_signed_by")):
			frappe.throw(_("You entered or signed these results, so you cannot countersign them."), title=_("Segregation of duties"))

	if doc.doctype == "Quality Inspection" and action == "Approve Rejection":
		from chemical_erp.regulatory_compliance.doctype.oos_investigation.oos_investigation import confirmed

		if not confirmed(doc.name):
			frappe.throw(_("Close the OOS investigation for this inspection with 'Confirmed Out of Specification' before rejecting the batch. "
			               "If it was a laboratory error, retest instead."), title=_("OOS investigation required"))

	if doc.doctype == "Quality Inspection" and action == "Sign Results":
		doc.analyst_signed_by = user
		doc.analyst_signed_on = now_datetime()

	comment = (frappe.form_dict.get("comment") or "")[:500]
	if cover:
		position = frappe.db.get_value("Position Role Grant", {"user": user, "role": allowed, "reason": "Vacancy"}, "position")
		comment = (_("Acting for vacant position: {0}").format(position) + (". " + comment if comment else ""))[:500]
	if delegated:
		comment = (_("Signed for the Managing Director under {0}").format(delegated) + (". " + comment if comment else ""))[:500]
		delegation_record(delegated)
	doc.append("approval_log", {"state": next_state, "action": action, "user": user, "on": now_datetime(),
	                            "comment": comment, "vacancy_cover": 1 if cover else 0, "delegation": delegated})


# ---------------------------------------------------------------------------------------------------------------
# Frappe v15 has no "before_transition" document event: apply_workflow goes straight to save/submit/cancel.
# So the checks above run from events every workflow action passes through (validate, before_submit via validate,
# before_cancel, before_update_after_submit). The desk button, bulk approval and /approvals say which action was
# chosen; any other path is identified from the state before and after.
PENDING = "chem_pending_transition"


@frappe.whitelist()
def apply_workflow(doc, action):
	"""Override of frappe.model.workflow.apply_workflow: remembers the chosen action for run_transition_checks."""
	return _apply_workflow(doc, action)


def _apply_workflow(doc, action, *, commit_refresh=True):
	from frappe.model import workflow as wf

	d = doc if hasattr(doc, "doctype") and hasattr(doc, "meta") else frappe.get_doc(frappe.parse_json(doc))
	refresh_level(d.doctype, d.name, commit=commit_refresh)
	frappe.flags[PENDING] = (d.doctype, d.name, action)
	try:
		return wf.apply_workflow(doc, action)
	finally:
		frappe.flags.pop(PENDING, None)


@frappe.whitelist()
def bulk_workflow_approval(docnames, doctype, action):
	"""Override of frappe.model.workflow.bulk_workflow_approval: each document goes through apply_workflow above."""
	names = frappe.parse_json(docnames)
	if len(names) > 500:
		frappe.throw(_("Bulk approval is limited to 500 documents at a time."))
	if len(names) < 20:
		return _bulk(names, doctype, action)
	frappe.msgprint(_("Bulk {0} is running in the background.").format(action), alert=True)
	frappe.enqueue("chemical_erp.controls.approvals._bulk", names=names, doctype=doctype, action=action, queue="short", timeout=1000)


def refresh_level(doctype, name, *, commit=True):
	"""Before Frappe works out which actions to offer: bring the saved approval level up to date (limits changed, or a
	payee's bank details changed), and keep it even if the action then turns out not to apply, so the screen shows the
	right one after a reload."""
	if not frappe.get_meta(doctype).has_field("approval_level"):
		return
	current = frappe.get_doc(doctype, name)
	if current.docstatus != 0:
		return
	old = current.get("approval_level")
	set_approval_level(current)
	if doctype == "Payment Entry":
		from chemical_erp.controls.security import payment_hold

		payment_hold(current)
	if current.get("approval_level") != old:
		frappe.db.set_value(doctype, name, "approval_level", current.approval_level, update_modified=False)
		if commit:
			frappe.db.commit()


def _bulk(names, doctype, action):
	failed = []
	for name in names:
		try:
			frappe.db.savepoint("chem_bulk")
			# A commit here would destroy this document's savepoint and every earlier
			# document's transaction. The batch owns the commit below.
			_apply_workflow(frappe.get_doc(doctype, name), action, commit_refresh=False)
			frappe.db.release_savepoint("chem_bulk")
		except Exception as e:
			frappe.db.rollback(save_point="chem_bulk")
			frappe.clear_last_message()
			failed.append(f"{name}: {frappe.utils.strip_html(str(e))[:160]}")
	frappe.db.commit()
	if failed:
		frappe.msgprint("<br>".join(failed), title=_("Not done ({0})").format(len(failed)), indicator="orange")
	else:
		frappe.msgprint(_("{0}: done for {1} document(s).").format(action, len(names)), indicator="green", alert=True)


def run_transition_checks(doc, method=None):
	"""doc_events '*': validate, before_cancel, before_update_after_submit."""
	if doc.flags.get("chem_transition_checked") or not doc.meta.has_field("approval_log"):
		return
	if frappe.flags.in_install or frappe.flags.in_migrate or frappe.flags.in_patch:
		return
	from frappe.model.workflow import get_workflow_name

	wf_name = get_workflow_name(doc.doctype)
	if not wf_name:
		return
	wf = frappe.get_cached_doc("Workflow", wf_name)
	before = doc.get_doc_before_save()
	field = wf.workflow_state_field
	old, new = (before.get(field) if before else None), doc.get(field)
	if method == "before_cancel" and old and old == new and frappe.session.user != "Administrator":
		# cancelled directly (API), not through the workflow's Cancel action: the workflow's cancel roles still apply
		cancelled = {st.state for st in wf.states if str(st.doc_status) == "2"}
		ways = [t for t in wf.transitions if t.state == old and t.next_state in cancelled]
		if ways and not ({t.allowed for t in ways} & set(frappe.get_roles())):
			frappe.throw(_("Only {0} can cancel this {1}.").format(" / ".join(sorted({t.allowed for t in ways})), _(doc.doctype)),
			             frappe.PermissionError, title=_("Not allowed"))
	if not before or not old or old == new:
		return
	candidates = [t for t in wf.transitions if t.state == old and t.next_state == new]
	pending = frappe.flags.get(PENDING)
	if pending and pending[0] == doc.doctype and pending[1] == doc.name:
		candidates = [t for t in candidates if t.action == pending[2]] or candidates
	roles = set(frappe.get_roles())
	allowed_here = [t for t in candidates if t.allowed in roles]
	if method == "before_cancel" and candidates and not allowed_here and frappe.session.user != "Administrator":
		# Frappe checks workflow roles on save but not on cancel: where the workflow names who cancels, hold to it
		frappe.throw(_("Only {0} can cancel this {1}.").format(" / ".join(sorted({t.allowed for t in candidates})), _(doc.doctype)),
		             frappe.PermissionError, title=_("Not allowed"))
	usable = allowed_here or candidates
	if not usable:
		return  # moved by the system (e.g. a status update), not by a person's workflow action
	if len(usable) > 1:  # e.g. "Approve" and "Approve as MD" both lead to Approved
		md_own = bool(doc.get("raised_by_md")) and has_role(MD_ROLE)
		usable = sorted(usable, key=lambda t: (t.action == MD_DIRECT) != md_own)
	doc.flags.chem_transition_checked = True
	chosen = usable[0]
	# Frappe offered this action from the approval level saved earlier. The level is worked out again during this save
	# (limits may have changed, or a supplier's bank details changed: 48-hour MD hold), so the route must still hold.
	if chosen.condition and "approval_level" in chosen.condition:
		from frappe.model.workflow import is_transition_condition_satisfied

		if not is_transition_condition_satisfied(chosen, doc):
			frappe.throw(_("This {0} now needs approval at level '{1}' (limits or bank details changed since it was saved). "
			               "Reload it and use the action shown.").format(_(doc.doctype), doc.get("approval_level") or "-"),
			             title=_("Approval route changed"))
	before_transition(doc, chosen)
