"""Formula confidentiality: confidential BOMs, premix Work Orders and their Stock Entries exist only
for the Managing Director and the Formula Owner (system delegate)."""

import frappe

from chemical_erp.utils import is_formula_owner


def _cond(table, user):
	if is_formula_owner(user):
		return ""
	return f"ifnull(`tab{table}`.`is_confidential`, 0) = 0"


def bom_query(user=None):
	return _cond("BOM", user or frappe.session.user)


def work_order_query(user=None):
	return _cond("Work Order", user or frappe.session.user)


def stock_entry_query(user=None):
	return _cond("Stock Entry", user or frappe.session.user)


def batch_link_query(user=None):
	return _cond("Batch Link", user or frappe.session.user)


def sle_query(user=None):
	if is_formula_owner(user or frappe.session.user):
		return ""
	return ("`tabStock Ledger Entry`.`voucher_no` not in "
	        "(select name from `tabStock Entry` where ifnull(is_confidential, 0) = 1)")


def has_permission(doc, ptype=None, user=None, debug=False):
	if doc.get("is_confidential") and not is_formula_owner(user or frappe.session.user):
		return False
	return None
