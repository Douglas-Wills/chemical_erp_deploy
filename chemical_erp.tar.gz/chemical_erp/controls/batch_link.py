"""Derived genealogy table, written on submit and removed on cancel."""

import frappe

from chemical_erp.utils import row_batches


def _add(doc, link_type, from_batch=None, to_batch=None, from_party=None, to_party=None, qty=0, confidential=0):
	frappe.get_doc({"doctype": "Batch Link", "from_batch": from_batch, "to_batch": to_batch, "from_party": from_party,
	                "to_party": to_party, "voucher_type": doc.doctype, "voucher_no": doc.name, "qty_kg": qty,
	                "link_type": link_type, "posting_date": doc.get("posting_date"),
	                "is_confidential": confidential}).insert(ignore_permissions=True)


def on_submit(doc, method=None):
	if doc.doctype == "Purchase Receipt":
		for row in doc.items:
			for b, q in row_batches(row):
				_add(doc, "Received", to_batch=b, from_party=doc.supplier, qty=q)
	elif doc.doctype in ("Delivery Note", "Sales Invoice"):
		if doc.doctype == "Sales Invoice" and not doc.get("update_stock"):
			return
		for row in doc.items:
			for b, q in row_batches(row):
				_add(doc, "Delivery", from_batch=b, to_party=doc.customer, qty=q)
	elif doc.doctype == "Stock Entry":
		conf = doc.get("is_confidential") or 0
		if doc.purpose in ("Manufacture", "Repack"):
			sources = [(b, q) for r in doc.items if r.s_warehouse for b, q in row_batches(r)]
			for r in doc.items:
				if not r.t_warehouse or r.s_warehouse:
					continue
				waste = frappe.get_cached_value("Item", r.item_code, "is_waste_item")
				kind = "Waste" if waste else ("Premix" if conf else ("Repack" if doc.purpose == "Repack" else "Manufacture"))
				for tb, _tq in row_batches(r):
					for sb, sq in sources:
						_add(doc, kind, from_batch=sb, to_batch=tb, qty=sq, confidential=conf)
		elif doc.get("disposal_order"):
			for r in doc.items:
				for b, q in row_batches(r):
					_add(doc, "Disposal", from_batch=b, to_party=doc.disposal_order, qty=q)


def on_cancel(doc, method=None):
	frappe.db.delete("Batch Link", {"voucher_type": doc.doctype, "voucher_no": doc.name})
