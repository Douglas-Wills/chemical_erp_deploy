"""Flag repeated small expense claims by one employee, and small claims that together pass the MD's approval limit
(splitting). A flag never blocks the claimant; it makes the approver look: approval needs 'Pattern Reviewed' ticked,
with a note, by someone other than the claimant."""

import frappe
from frappe import _
from frappe.utils import add_days, add_to_date, cint, flt, get_datetime, getdate, now_datetime

from chemical_erp.utils import get_settings, notify, users_with_role

APPROVING_FROM = ("Manager Review", "MD Review")


def _settings():
	s = get_settings()
	return (flt(s.get("small_expense_amount")) or 100000, cint(s.get("small_expense_window_days")) or 7,
	        cint(s.get("small_expense_max_count")) or 3, cint(s.get("split_window_hours")) or 48, flt(s.get("expense_limit")))


def _claims(employee, start, exclude):
	return frappe.get_all("Expense Claim", filters={"employee": employee, "docstatus": ["<", 2], "name": ["!=", exclude or ""],
	                                                "posting_date": [">=", getdate(start)]},
	                      fields=["name", "posting_date", "total_claimed_amount", "creation"], order_by="creation asc")


def find_patterns(doc):
	"""Returns (reasons, related claim names). Pure enough to test with a stubbed frappe."""
	small, days, max_count, hours, md_limit = _settings()
	amount = flt(doc.get("total_claimed_amount")) or sum(flt(r.get("amount")) for r in doc.get("expenses") or [])
	if not doc.get("employee") or not amount or amount >= small:
		return [], []
	when = get_datetime(doc.get("creation") or now_datetime())
	reasons, related = [], set()
	recent = [c for c in _claims(doc.employee, add_days(when, -days), doc.name) if flt(c.total_claimed_amount) < small]
	if len(recent) + 1 > max_count:
		reasons.append(_("{0} claims under {1} in {2} days (this one included); more than {3} is unusual.").format(
			len(recent) + 1, frappe.utils.fmt_money(small, precision=0), days, max_count))
		related.update(c.name for c in recent)
	if md_limit:
		window = [c for c in _claims(doc.employee, add_to_date(when, hours=-hours), doc.name)
		          if flt(c.total_claimed_amount) < small and get_datetime(c.creation) >= add_to_date(when, hours=-hours)]
		combined = amount + sum(flt(c.total_claimed_amount) for c in window)
		if window and combined > md_limit:
			reasons.append(_("Possible split: {0} small claims within {1} hours total {2}, above the {3} limit that needs the MD's approval.").format(
				len(window) + 1, hours, frappe.utils.fmt_money(combined, precision=0), frappe.utils.fmt_money(md_limit, precision=0)))
			related.update(c.name for c in window)
	return reasons, sorted(related)


def check(doc, method=None):
	if doc.docstatus != 0:
		return
	before = doc.get_doc_before_save()
	reasons, related = find_patterns(doc)
	doc.pattern_flag = 1 if reasons else 0
	doc.pattern_reason = "\n".join(reasons) or None
	doc.pattern_related = ", ".join(related) or None
	claimant = frappe.db.get_value("Employee", doc.employee, "user_id") if doc.get("employee") else doc.owner
	if doc.get("pattern_reviewed") and not (before and before.get("pattern_reviewed")):
		if frappe.session.user in (claimant, doc.owner):
			frappe.throw(_("The claimant cannot mark their own claim pattern as reviewed."), frappe.PermissionError)
		if not (doc.get("pattern_review_note") or "").strip():
			frappe.throw(_("Add a note on what was checked when marking the pattern reviewed."))
		doc.pattern_reviewed_by = frappe.session.user
	if doc.pattern_flag and before and before.get("workflow_state") in APPROVING_FROM and doc.get("workflow_state") != before.workflow_state \
			and doc.get("workflow_state") not in ("Rejected", "Draft") and not doc.get("pattern_reviewed"):
		frappe.throw(_("This claim is flagged ({0}). Tick 'Pattern Reviewed' and add a note before approving.").format(
			doc.pattern_reason.replace("\n", " ")), title=_("Expense pattern to review"))
	if doc.pattern_flag and not (before and before.get("pattern_flag")) and not doc.is_new():
		_alert(doc, claimant)


def alert_new(doc, method=None):
	if doc.get("pattern_flag"):
		claimant = frappe.db.get_value("Employee", doc.employee, "user_id") if doc.get("employee") else doc.owner
		_alert(doc, claimant)


def _alert(doc, claimant):
	manager = None
	if doc.get("employee"):
		boss = frappe.db.get_value("Employee", doc.employee, "reports_to")
		manager = frappe.db.get_value("Employee", boss, "user_id") if boss else None
	notify(([manager] if manager else []) + users_with_role("Accounts Manager") + users_with_role("Accounts User"), "Expense Claim", doc.name,
	       _("Expense pattern flagged on {0} ({1}): {2}").format(doc.name, frappe.utils.get_fullname(claimant), doc.pattern_reason.replace("\n", " ")),
	       priority="High")
