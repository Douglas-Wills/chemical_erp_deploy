"""System security: sign-in rules, account hygiene, alerts on risky changes, data export limits and backups.

What runs where
- install/migrate: password policy and lock-out (once, editable after), export limits on sensitive records,
  change tracking on records where fraud starts (bank details, prices, customers, suppliers, staff).
- on login: a privileged user signing in from a new network address is told, and so is the MD.
- hourly: repeated failed sign-ins are reported to the MD.
- daily: leavers' accounts are disabled; dormant accounts are flagged, then disabled; the backup age is checked.
- on change: privilege roles given, bank details changed (payments to that party then need the MD for 48 hours).
- two-factor sign-in for privileged roles is switched on by the MD from Chemical ERP Settings (needs working email).
"""

import os

import frappe
from frappe import _
from frappe.utils import add_days, add_to_date, cint, get_datetime, getdate, now_datetime, today

from chemical_erp.utils import MD_ROLE, get_settings, notify

PRIVILEGED = (MD_ROLE, "System Manager", "Accounts Manager", "HR Manager", "Accounts User")
ROLE_ALERT = (MD_ROLE, "System Manager", "Accounts Manager", "HR Manager", "Formula Owner")
TWO_FACTOR_ROLES = (MD_ROLE, "System Manager", "Accounts Manager", "HR Manager", "Accounts User", "Formula Owner")
EXPORT_ROLES = (MD_ROLE, "System Manager", "Accounts Manager", "HR Manager", "Sales Manager")
SENSITIVE = ("Customer", "Supplier", "Employee", "Item", "Item Price", "BOM", "Sales Invoice", "Purchase Invoice", "Payment Entry",
             "Quotation", "Sales Order", "Purchase Order", "Contact", "Address", "Bank Account", "Lead", "Opportunity", "Journal Entry",
             "Staff Payslip", "Employment Contract", "Commission Entry", "Product Cost Sheet", "Tender", "Water Analysis")
TRACKED = ("Customer", "Supplier", "Employee", "Item", "Item Price", "Price List", "Bank Account", "Company", "Payment Terms Template",
           "Pricing Rule", "Account", "Mode of Payment", "Employment Contract")
BASELINE = {  # System Settings: applied once, then the MD may change them
	"enable_password_policy": 1, "minimum_password_score": "3", "allow_consecutive_login_attempts": 5,
	"allow_login_after_fail": 900, "force_user_to_reset_password": 90, "session_expiry": "12:00",
	"logout_on_password_reset": 1, "allow_error_traceback": 0,
}
BANK_FIELDS = {"Employee": ("bank_name", "bank_ac_no", "iban"), "Supplier": ("default_bank_account",), "Customer": ("default_bank_account",)}
HOLD_HOURS = 48


def md():
	from chemical_erp.people_management.positions import md_users

	return md_users()


# ---------------------------------------------------------------- baseline (install / migrate)
def apply_baseline(force=False):
	s = frappe.get_single("System Settings")
	if not force and frappe.db.get_default("chemical_erp_security_baseline"):
		return []
	changed = []
	for field, value in BASELINE.items():
		if s.meta.has_field(field) and str(s.get(field) or "") != str(value):
			s.set(field, value)
			changed.append(field)
	if changed:
		s.flags.ignore_permissions = True
		s.save()
	frappe.db.set_default("chemical_erp_security_baseline", today())
	return changed


def ensure_export_limits():
	"""Only managers may export lists of sensitive records (customer lists, prices, payroll…)."""
	from frappe.permissions import update_permission_property

	for dt in SENSITIVE:
		if not frappe.db.exists("DocType", dt):
			continue
		perms = frappe.get_all("Custom DocPerm", filters={"parent": dt}, fields=["role", "permlevel", "export"]) or \
			frappe.get_all("DocPerm", filters={"parent": dt}, fields=["role", "permlevel", "export"])
		for p in perms:
			if p.export and p.role not in EXPORT_ROLES:
				try:
					update_permission_property(dt, p.role, p.permlevel, "export", 0, validate=False)
				except Exception:
					frappe.log_error(title=f"Export limit: {dt}/{p.role}", message=frappe.get_traceback())


def ensure_tracking():
	from frappe.custom.doctype.property_setter.property_setter import make_property_setter

	for dt in TRACKED:
		if frappe.db.exists("DocType", dt) and not frappe.get_meta(dt).track_changes:
			make_property_setter(dt, None, "track_changes", 1, "Check", for_doctype=True, validate_fields_for_doctype=False)


def ensure_security():
	apply_baseline()
	ensure_export_limits()
	ensure_tracking()


# ---------------------------------------------------------------- two-factor sign-in
def outgoing_email_ready():
	return bool(frappe.db.exists("Email Account", {"enable_outgoing": 1, "default_outgoing": 1}))


@frappe.whitelist()
def enable_two_factor(roles=None):
	"""Two-factor sign-in (authenticator app) for privileged roles. Users get a set-up link by email at their next sign-in."""
	frappe.only_for((MD_ROLE, "System Manager"))
	if not outgoing_email_ready():
		frappe.throw(_("Set up an outgoing email account first: the set-up link for the authenticator app is sent by email. "
		               "Switching it on without email would lock people out."), title=_("Email not ready"))
	roles = frappe.parse_json(roles) if roles else list(TWO_FACTOR_ROLES)
	s = frappe.get_single("System Settings")
	s.enable_two_factor_auth = 1
	if s.meta.has_field("two_factor_method"):
		s.two_factor_method = "OTP App"
	if s.meta.has_field("otp_issuer_name") and not s.otp_issuer_name:
		from chemical_erp.company import company_name

		s.otp_issuer_name = company_name(short=True) or "ERP"
	s.flags.ignore_permissions = True
	s.save()
	done = []
	for r in roles:
		if frappe.db.exists("Role", r) and frappe.get_meta("Role").has_field("two_factor_auth"):
			frappe.db.set_value("Role", r, "two_factor_auth", 1)
			done.append(r)
	return done


# ---------------------------------------------------------------- events
def on_login(login_manager=None):
	"""A privileged user signing in from a network address never used before: tell them and the MD."""
	try:
		user = frappe.session.user
		if user in ("Guest",) or not set(PRIVILEGED) & set(frappe.get_roles(user)) and user != "Administrator":
			return
		ip = getattr(frappe.local, "request_ip", None)
		if not ip or not frappe.db.exists("DocType", "Activity Log"):
			return
		seen = frappe.db.count("Activity Log", {"user": user, "ip_address": ip, "operation": "Login", "status": "Success",
		                                        "creation": ["<", add_to_date(now_datetime(), minutes=-1)]})
		if seen:
			return
		before = frappe.db.count("Activity Log", {"user": user, "operation": "Login", "status": "Success"})
		if before <= 1:
			return  # first ever sign-in: nothing to compare with
		msg = _("{0} signed in from a new network address ({1}) at {2}. If this was not them, disable the account and reset the password.").format(
			frappe.utils.get_fullname(user), ip, frappe.utils.format_datetime(now_datetime()))
		notify([u for u in md() if u != user] + [user], "User", user, msg, priority="High")
	except Exception:
		frappe.log_error(title="Security: login check failed", message=frappe.get_traceback())


def on_user_update(doc, method=None):
	"""Privileged roles given to someone: the MD is told."""
	before = doc.get_doc_before_save()
	if not before or frappe.flags.in_install or frappe.flags.in_migrate:
		return
	old = {r.role for r in before.get("roles") or []}
	new = {r.role for r in doc.get("roles") or []}
	added = [r for r in (new - old) if r in ROLE_ALERT]
	if added:
		notify(md(), "User", doc.name, _("{0} now holds {1} (changed by {2}).").format(
			doc.full_name or doc.name, ", ".join(added), frappe.utils.get_fullname()), priority="High")
	if before.enabled and not doc.enabled:
		return
	if not before.enabled and doc.enabled and doc.user_type == "System User":
		notify(md(), "User", doc.name, _("{0}'s account was re-enabled by {1}.").format(doc.full_name or doc.name, frappe.utils.get_fullname()))


def bank_details_changed(doc, method=None):
	"""Bank details of a supplier, customer or employee changed: the MD and Accounts are told, and payments to that party
	need the MD's approval for the next 48 hours (the usual route of payment fraud is a 'new account number')."""
	if frappe.flags.in_install or frappe.flags.in_migrate or doc.is_new():
		return
	before = doc.get_doc_before_save()
	if not before:
		return
	if doc.doctype == "Bank Account":
		fields, party_type, party = ("bank_account_no", "iban", "branch_code", "bank"), doc.get("party_type"), doc.get("party")
	else:
		fields, party_type, party = BANK_FIELDS.get(doc.doctype, ()), doc.doctype, doc.name
	changed = [f for f in fields if doc.meta.has_field(f) and (before.get(f) or "") != (doc.get(f) or "")]
	if not changed or not party:
		return
	frappe.cache().set_value(f"chemical_erp:bank_change:{party_type}:{party}", str(now_datetime()), expires_in_sec=HOLD_HOURS * 3600)
	from chemical_erp.utils import users_with_role

	notify(md() + users_with_role("Accounts Manager"), doc.doctype, doc.name,
	       _("Bank details of {0} {1} were changed by {2}. Confirm the change with them by phone before paying. "
	         "Payments to them need the MD's approval for {3} hours.").format(_(party_type or doc.doctype), party,
	                                                                     frappe.utils.get_fullname(), HOLD_HOURS), priority="High")


def payment_hold(doc, method=None):
	"""Payment Entry: paying a party whose bank details changed in the last 48 hours goes to the MD."""
	if doc.get("payment_type") != "Pay" or not doc.get("party"):
		return
	if frappe.cache().get_value(f"chemical_erp:bank_change:{doc.party_type}:{doc.party}") and doc.meta.has_field("approval_level"):
		doc.approval_level = "MD"
		if doc.is_new() or doc.docstatus == 0:
			frappe.msgprint(_("{0}'s bank details changed recently. This payment needs the Managing Director's approval.").format(doc.party),
			                indicator="orange", alert=True)


# ---------------------------------------------------------------- scheduled checks
def hourly():
	failed_logins()


def daily():
	for fn in (disable_leavers, dormant_accounts, check_backups):
		try:
			fn()
			frappe.db.commit()
		except Exception:
			frappe.db.rollback()
			frappe.log_error(title=f"Security check failed: {fn.__name__}", message=frappe.get_traceback())


def failed_logins():
	if not frappe.db.exists("DocType", "Activity Log"):
		return
	limit = cint(get_settings().get("security_failed_login_alert")) or 5
	rows = frappe.db.sql("""select user, count(*) n, group_concat(distinct ip_address) ips from `tabActivity Log`
		where operation='Login' and status='Failed' and creation >= %s group by user having n >= %s""",
	                     (add_to_date(now_datetime(), hours=-1), limit), as_dict=True)
	for r in rows:
		key = f"chemical_erp:failed_login_alert:{r.user}"
		if frappe.cache().get_value(key):
			continue
		frappe.cache().set_value(key, 1, expires_in_sec=6 * 3600)
		notify(md(), "User", r.user if frappe.db.exists("User", r.user) else None,
		       _("{0} failed sign-ins for {1} in the last hour (from {2}). Someone may be guessing the password.").format(
			       r.n, r.user, r.ips or "?"), priority="High")


def disable_leavers():
	"""Staff who have left lose their system access on their last day."""
	for e in frappe.get_all("Employee", filters={"user_id": ["is", "set"], "status": ["in", ["Left", "Inactive", "Suspended"]]},
	                        fields=["name", "employee_name", "user_id", "status", "relieving_date"]):
		if e.status == "Left" and e.relieving_date and getdate(e.relieving_date) > getdate(today()):
			continue
		if frappe.db.get_value("User", e.user_id, "enabled") and e.user_id != "Administrator" and MD_ROLE not in frappe.get_roles(e.user_id):
			frappe.db.set_value("User", e.user_id, "enabled", 0)
			frappe.sessions.clear_sessions(e.user_id, force=True)
			notify(md(), "Employee", e.name, _("{0} is {1}: their system account has been disabled.").format(e.employee_name, e.status))


def dormant_accounts():
	"""Accounts unused for a long time are a door left open: flagged, then disabled (never the MD or Administrator)."""
	warn = cint(get_settings().get("security_inactive_days")) or 60
	stop = cint(get_settings().get("security_disable_days")) or 90
	for u in frappe.get_all("User", filters={"enabled": 1, "user_type": "System User", "name": ["not in", ["Administrator", "Guest"]]},
	                        fields=["name", "full_name", "last_login", "creation"]):
		if MD_ROLE in frappe.get_roles(u.name):
			continue
		last = get_datetime(u.last_login or u.creation)
		days = (now_datetime() - last).days
		if days >= stop:
			frappe.db.set_value("User", u.name, "enabled", 0)
			notify(md(), "User", u.name, _("{0} has not signed in for {1} days: the account has been disabled. Re-enable it if still needed.").format(
				u.full_name or u.name, days))
		elif days == warn:
			notify(md() + [u.name], "User", u.name, _("{0} has not signed in for {1} days. The account will be disabled after {2} days.").format(
				u.full_name or u.name, days, stop))


def last_backup():
	folder = frappe.get_site_path("private", "backups")
	if not os.path.isdir(folder):
		return None
	files = [os.path.join(folder, f) for f in os.listdir(folder) if f.endswith((".sql.gz", ".sql"))]
	if not files:
		return None
	from datetime import datetime

	return datetime.fromtimestamp(max(os.path.getmtime(f) for f in files))


def check_backups():
	hours = cint(get_settings().get("security_backup_hours")) or 26
	when = last_backup()
	if not when or (now_datetime() - when).total_seconds() > hours * 3600:
		notify(md() + [u for u in frappe.get_all("Has Role", filters={"role": "System Manager", "parenttype": "User"}, pluck="parent")
		               if u != "Administrator"], "System Settings", None,
		       _("No database backup in the last {0} hours (last: {1}). Check the server's backup schedule and off-site copies.").format(
			       hours, frappe.utils.format_datetime(when) if when else _("none found")), priority="High")


# ---------------------------------------------------------------- status for the MD
@frappe.whitelist()
def status():
	frappe.only_for((MD_ROLE, "System Manager"))
	s = frappe.get_single("System Settings")
	privileged = sorted({r.parent for r in frappe.get_all("Has Role", filters={"role": ["in", list(PRIVILEGED)], "parenttype": "User"},
	                                                      fields=["parent"]) if r.parent not in ("Administrator",)
	                     and frappe.db.get_value("User", r.parent, "enabled")})
	admins = [r for r in frappe.get_all("Has Role", filters={"role": "System Manager", "parenttype": "User"}, pluck="parent")
	          if r != "Administrator" and frappe.db.get_value("User", r, "enabled")]
	failed = frappe.db.count("Activity Log", {"operation": "Login", "status": "Failed", "creation": [">=", add_days(now_datetime(), -1)]}) \
		if frappe.db.exists("DocType", "Activity Log") else 0
	twofa_roles = [r for r in TWO_FACTOR_ROLES if frappe.db.exists("Role", r) and frappe.get_meta("Role").has_field("two_factor_auth")
	               and frappe.db.get_value("Role", r, "two_factor_auth")]
	backup = last_backup()
	ok = lambda b: "ok" if b else "attention"
	checks = [
		{"check": _("Password policy (strength 3 of 4)"), "state": ok(cint(s.get("enable_password_policy"))),
		 "detail": _("Score required: {0}").format(s.get("minimum_password_score") or "-")},
		{"check": _("Lock-out after failed sign-ins"), "state": ok(cint(s.get("allow_consecutive_login_attempts"))),
		 "detail": _("{0} attempts, then {1} minutes").format(s.get("allow_consecutive_login_attempts") or "-", cint(s.get("allow_login_after_fail")) // 60)},
		{"check": _("Two-factor sign-in for privileged roles"), "state": ok(cint(s.get("enable_two_factor_auth")) and twofa_roles),
		 "detail": ", ".join(twofa_roles) or _("Off. Use 'Turn On Two-Factor Sign-in'.")},
		{"check": _("Outgoing email (needed for alerts and two-factor set-up)"), "state": ok(outgoing_email_ready()), "detail": ""},
		{"check": _("Database backup in the last 26 hours"), "state": ok(backup and (now_datetime() - backup).total_seconds() < 26 * 3600),
		 "detail": frappe.utils.format_datetime(backup) if backup else _("No backup found on this server")},
		{"check": _("System Managers (keep to 1-2 people)"), "state": ok(len(admins) <= 2), "detail": ", ".join(admins) or "-"},
		{"check": _("Failed sign-ins in the last 24 hours"), "state": ok(failed < 10), "detail": str(failed)},
		{"check": _("People with financial or admin rights"), "state": "info", "detail": str(len(privileged))},
	]
	return checks


def dashboard_cards():
	"""For the MD's dashboard: the security items needing attention."""
	try:
		checks = status()
	except frappe.PermissionError:
		return []
	bad = [c for c in checks if c["state"] == "attention"]
	return [{"label": _("Security items needing attention (Chemical ERP Settings > Security Check)"), "value": len(bad),
	         "tone": "red" if bad else "green", "doctype": "Chemical ERP Settings", "filters": {},
	         "route": {"doctype": "Chemical ERP Settings", "name": "Chemical ERP Settings"}}]
