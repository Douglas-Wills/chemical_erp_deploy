"""Approvals from a phone: /approvals lists what waits on the signed-in user, with Approve / Reject buttons.

The same workflow rules apply as on the desk (segregation of duties, delegation, comments are logged)."""

import frappe
from frappe import _
from frappe.utils import date_diff, flt, today

from chemical_erp.utils import pending_approvals

PARTY_FIELDS = ("supplier_name", "supplier", "customer_name", "party_name", "party", "employee_name", "title", "customer")
ITEM_TABLES = {"Purchase Order": "items", "Purchase Receipt": "items", "Quotation": "items", "Sales Order": "items",
               "Expense Claim": "expenses"}


def summary(doc):
	from chemical_erp.controls.delegation import amount_of

	party = next((doc.get(f) for f in PARTY_FIELDS if doc.meta.has_field(f) and doc.get(f)), "")
	amount = amount_of(doc) or flt(doc.get("base_grand_total") or doc.get("grand_total"))
	lines = []
	table = ITEM_TABLES.get(doc.doctype)
	if table:
		for row in (doc.get(table) or [])[:4]:
			if doc.doctype == "Expense Claim":
				lines.append(f"{row.get('expense_type') or ''}: {row.get('description') or ''} {flt(row.get('amount')):,.0f}".strip())
			else:
				lines.append(f"{row.get('item_name') or row.get('item_code')} × {flt(row.get('qty')):g} {row.get('uom') or ''}".strip())
		more = len(doc.get(table) or []) - 4
		if more > 0:
			lines.append(_("and {0} more line(s)").format(more))
	remarks = next((doc.get(f) for f in ("remarks", "reason", "description") if isinstance(doc.get(f), str) and doc.get(f).strip()), "")
	return {"party": party, "amount": amount, "lines": lines, "remarks": frappe.utils.strip_html(remarks)[:300]}


@frappe.whitelist()
def listing():
	if frappe.session.user == "Guest":
		frappe.throw(_("Please log in."), frappe.PermissionError)
	from frappe.model.workflow import get_transitions

	from chemical_erp.controls.delegation import DELEGATE_ROLE
	from chemical_erp.utils import company_currency

	currency = company_currency()
	out = []
	for r in pending_approvals():
		try:
			doc = frappe.get_doc(r.reference_doctype, r.reference_name)
			transitions = get_transitions(doc)
		except Exception:
			continue
		actions = []
		for t in transitions:
			if t.get("action") not in [a["action"] for a in actions]:
				actions.append({"action": t.get("action"), "delegated": t.get("allowed") == DELEGATE_ROLE,
				                "negative": t.get("action") in ("Reject", "Return", "Return to Auditor", "Return to Analyst")})
		if not actions:
			continue
		row = {"doctype": doc.doctype, "name": doc.name, "state": doc.get("workflow_state"), "days": date_diff(today(), r.creation),
		       "currency": currency, "actions": actions,
		       "url": f"/app/{frappe.scrub(doc.doctype).replace('_', '-')}/{doc.name}",
		       "pdf": f"/api/method/frappe.utils.print_format.download_pdf?doctype={frappe.utils.quote(doc.doctype)}&name={frappe.utils.quote(doc.name)}"}
		row.update(summary(doc))
		out.append(row)
	return out


@frappe.whitelist(methods=["POST"])
def act(doctype, name, action, comment=None):
	from frappe.model.workflow import get_transitions

	from chemical_erp.controls.approvals import apply_workflow

	doc = frappe.get_doc(doctype, name)
	if action not in {t.get("action") for t in get_transitions(doc)}:
		frappe.throw(_("'{0}' is not available to you on {1} {2} any more.").format(action, _(doctype), name))
	if action in ("Reject", "Return", "Return to Auditor", "Return to Analyst") and not (comment or "").strip():
		frappe.throw(_("Say why, so the sender knows what to fix."))
	frappe.form_dict.comment = (comment or "")[:500]  # before_transition writes it into the approval log
	doc = apply_workflow(doc, action)
	if comment:
		doc.add_comment("Comment", _("{0}: {1}").format(action, comment))
	return {"state": doc.get("workflow_state"), "name": doc.name}
