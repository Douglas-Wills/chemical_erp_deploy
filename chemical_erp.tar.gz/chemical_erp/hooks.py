app_name = "chemical_erp"
app_title = "Brave ERP"
app_publisher = "Brave Chemicals"
app_description = "Chemical manufacturing and distribution on ERPNext: batch release, formulas, waste, EFRIS, maintenance, tenders and HR"
app_email = "admin@bravechemicals.com"
app_license = "mit"

required_apps = ["frappe", "erpnext", "hrms"]

add_to_apps_screen = [
	{"name": "chemical_erp", "logo": "/assets/chemical_erp/images/brave_logo.png", "title": "My Dashboard", "route": "/app/my-dashboard"},
]

app_logo_url = "/assets/chemical_erp/images/brave_logo_wide.png"
website_context = {
	"favicon": "/assets/chemical_erp/images/brave_logo.png",
	"splash_image": "/assets/chemical_erp/images/brave_logo_wide.png"
}

# Bump THEME_VER whenever brave_theme.css/js change: assets are served with a 12-hour cache and unchanged URLs
THEME_VER = "20261017e"
app_include_css = [f"/assets/chemical_erp/css/brave_theme.css?v={THEME_VER}"]
web_include_css = [f"/assets/chemical_erp/css/brave_theme.css?v={THEME_VER}"]

app_include_js = [
	"/assets/chemical_erp/js/request_deletion.js",
	"/assets/chemical_erp/js/help.js",
	"/assets/chemical_erp/js/house_pdf.js",
	f"/assets/chemical_erp/js/brave_theme.js?v={THEME_VER}",
	f"/assets/chemical_erp/js/brave_dashboard.js?v={THEME_VER}"
]
web_include_js = [f"/assets/chemical_erp/js/brave_theme.js?v={THEME_VER}"]
boot_session = "chemical_erp.controls.deletion.boot_session"
on_login = "chemical_erp.controls.security.on_login"

website_route_rules = [{"from_route": "/my-documents", "to_route": "my_documents"},
                       {"from_route": "/quick-order", "to_route": "quick_order"},
                       {"from_route": "/shared-doc/<token>", "to_route": "shared_doc"},
                       {"from_route": "/doc-preview/<token>", "to_route": "shared_doc"}]

# /field-lab (offline field screen), its service worker and manifest
page_renderer = ["chemical_erp.field_laboratory.offline.FieldLabRenderer"]

jinja = {"methods": ["chemical_erp.doc_qr.qr_for_doc", "chemical_erp.doc_qr.qr_text_image",
                      "chemical_erp.doc_style.brave_money", "chemical_erp.doc_style.brave_qty", "chemical_erp.doc_style.brave_words",
                      "chemical_erp.doc_style.brave_tax_label", "chemical_erp.doc_style.brave_status", "chemical_erp.doc_style.brave_agent",
                      "chemical_erp.doc_style.brave_logo", "chemical_erp.regulatory_compliance.documents.cert_title", "chemical_erp.regulatory_compliance.documents.cert_statement", "chemical_erp.regulatory_compliance.labels.label_data",
                      "chemical_erp.company.company_name", "chemical_erp.company.company_block", "chemical_erp.company.company_email", "chemical_erp.company.company_phone",
                      "chemical_erp.company.emergency_phone", "chemical_erp.company.bank_lines", "chemical_erp.company.company_logo",
                      "chemical_erp.company.brand_colour", "chemical_erp.field_laboratory.analytics.water_technical_section",
                      "chemical_erp.field_laboratory.specs.water_sheet_rows", "chemical_erp.field_laboratory.specs.water_sheet_data", "chemical_erp.company.quotation_title", "chemical_erp.company.fill",
                      "chemical_erp.print_pdf.party_short"]}

after_install = "chemical_erp.setup.install.after_install"
after_migrate = "chemical_erp.setup.install.after_migrate"

doctype_js = {
	"Employee": "public/js/employee.js",
	"Stock Entry": "public/js/stock_entry.js",
	"Sales Invoice": "public/js/sales_invoice.js",
	"Batch": "public/js/batch.js",
	"Training Event": "public/js/training_event.js",
	"BOM": "public/js/bom.js",
	"Work Order": "public/js/work_order.js",
	"Expense Claim": "public/js/expense_claim.js",
	"Appraisal": "public/js/appraisal.js",
	"Price List": "public/js/price_list.js",
	"Customer": "public/js/customer.js",
}
doctype_list_js = {"Price List": "public/js/price_list_list.js"}

C = "chemical_erp.controls"
T = "chemical_erp.tenders_desk.integrations"
APPROVAL = f"{C}.approvals.set_approval_level"
LINK_ON, LINK_OFF = f"{C}.batch_link.on_submit", f"{C}.batch_link.on_cancel"

doc_events = {
	# Approval checks and the approval log run on every workflow action (Frappe v15 has no before_transition event)
	"*": {"validate": [f"{C}.approvals.mark_raised_by_md", f"{C}.approvals.run_transition_checks"],
	      "before_cancel": f"{C}.approvals.run_transition_checks",
	      "before_update_after_submit": f"{C}.approvals.run_transition_checks",
	      "on_trash": f"{C}.deletion.on_trash"},
	"Purchase Order": {"before_insert": f"{C}.attachments.block_new_purchase",
	                   "validate": [APPROVAL, f"{C}.attachments.approved_supplier", "chemical_erp.regulatory_compliance.documents.purchase_order_request"],
	                   "on_update_after_submit": f"{C}.attachments.po_receipt_status"},
	"Communication": {"after_insert": "chemical_erp.tenders_desk.scanner.from_email"},
	"Material Request": {"before_insert": f"{C}.attachments.block_new_purchase"},
	"Purchase Invoice": {"before_submit": f"{C}.attachments.invoice_needs_po_receipt",
	                     "on_submit": f"{C}.attachments.invoice_as_receipt"},
	"Purchase Receipt": {
		"validate": [f"{C}.qc_zones.validate_zone", "chemical_erp.regulatory_compliance.documents.receipt_check", "chemical_erp.regulatory_compliance.storage.check"],
		"on_submit": [f"{C}.quality.purchase_receipt_on_submit", LINK_ON, f"{C}.attachments.goods_received", "chemical_erp.regulatory_compliance.documents.receipt_submitted"],
		"on_cancel": LINK_OFF,
	},
	"Quality Inspection": {
		"validate": f"{C}.quality.inspection_validate",
		"on_update": "chemical_erp.regulatory_compliance.doctype.oos_investigation.oos_investigation.open_if_failed",
		"on_submit": f"{C}.quality.inspection_on_submit",
		"before_cancel": f"{C}.quality.inspection_before_cancel",
		"on_cancel": f"{C}.quality.inspection_on_cancel",
	},
	"Stock Entry": {
		"validate": [f"{C}.manufacturing.stock_entry_validate", f"{C}.qc_zones.validate_zone", "chemical_erp.regulatory_compliance.storage.check"],
		"on_update": f"{C}.manufacturing.notify_excess_waste",
		"on_submit": [f"{C}.quality.manufacture_on_submit", LINK_ON, "chemical_erp.tasks.count_batches_for_pm"],
		"on_cancel": LINK_OFF,
	},
	"Stock Reconciliation": {"validate": f"{C}.qc_zones.validate_zone"},
	"Delivery Note": {
		"validate": [f"{C}.delivery_block.check", f"{C}.delivery_block.returns_to_quarantine", f"{C}.attachments.carry_customer_po",
		             "chemical_erp.chemical_core.doctype.container_movement.container_movement.default_from_customer",
		             "chemical_erp.regulatory_compliance.doctype.product_certification.product_certification.attention"],
		"before_submit": [f"{C}.delivery_block.check", f"{C}.delivery_block.stamp_sds", "chemical_erp.chemical_core.collections.stop_on_hold",
		                  "chemical_erp.regulatory_compliance.doctype.dispatch_safety_check.dispatch_safety_check.required"],
		"on_submit": [LINK_ON, "chemical_erp.chemical_core.doctype.container_movement.container_movement.on_delivery", "chemical_erp.regulatory_compliance.documents.use_exceptions"],
		"on_cancel": [LINK_OFF, "chemical_erp.chemical_core.doctype.container_movement.container_movement.on_delivery_cancel"],
	},
	"Sales Invoice": {
		"validate": [f"{C}.delivery_block.check", f"{C}.attachments.carry_customer_po", "chemical_erp.people_management.commission.set_originator"],
		"before_submit": [f"{C}.delivery_block.check", f"{C}.attachments.invoice_po"],
		"on_submit": ["chemical_erp.integrations.efris.on_submit", LINK_ON, "chemical_erp.chemical_core.doctype.wht_certificate.wht_certificate.from_invoice",
		              "chemical_erp.people_management.commission.on_invoice_submit", "chemical_erp.regulatory_compliance.documents.use_exceptions"],
		"on_update_after_submit": ["chemical_erp.integrations.efris.on_update_after_submit", "chemical_erp.chemical_core.doctype.wht_certificate.wht_certificate.from_invoice"],
		"before_cancel": "chemical_erp.integrations.efris.before_cancel",
		"on_cancel": [LINK_OFF, "chemical_erp.chemical_core.doctype.wht_certificate.wht_certificate.on_invoice_cancel",
		              "chemical_erp.people_management.commission.on_invoice_cancel"],
	},
	"BOM": {"validate": f"{C}.manufacturing.bom_validate", "on_submit": f"{C}.manufacturing.bom_on_submit",
	        "before_update_after_submit": "chemical_erp.chemical_core.costing.bom_costing"},
	"Work Order": {"validate": [f"{C}.manufacturing.work_order_validate", APPROVAL, "chemical_erp.chemical_core.material_check.on_validate"],
	               "on_submit": "chemical_erp.chemical_core.material_check.on_submit"},
	"Job Card": {"validate": f"{C}.manufacturing.job_card_validate"},
	"Quotation": {"validate": [APPROVAL, "chemical_erp.people_management.commission.set_originator", "chemical_erp.regulatory_compliance.documents.quotation_attention",
	                           "chemical_erp.regulatory_compliance.controlled.sales_order_check", "chemical_erp.regulatory_compliance.doctype.product_certification.product_certification.attention"],
	              "on_submit": f"{T}.quotation_submitted"},
	"Sales Order": {"on_update": "chemical_erp.regulatory_compliance.controlled.sales_order_flagged",
	                "validate": [APPROVAL, "chemical_erp.people_management.commission.set_originator", "chemical_erp.regulatory_compliance.documents.quotation_attention",
	                             "chemical_erp.regulatory_compliance.controlled.sales_order_check", "chemical_erp.regulatory_compliance.doctype.product_certification.product_certification.attention",
	                             f"{C}.attachments.sales_order_po"],
	                "before_submit": "chemical_erp.chemical_core.collections.stop_on_hold",
	                "on_submit": f"{T}.sales_order_submitted"},
	"Expense Claim": {"before_insert": f"{C}.attachments.block_new_expense",
	                  "validate": [f"{C}.expenses.set_routing", APPROVAL, f"{C}.attachments.expense_privacy", f"{C}.expense_patterns.check"],
	                  "after_insert": f"{C}.expense_patterns.alert_new",
	                  "on_update": f"{C}.expenses.notify_next",
	                  "on_submit": [f"{C}.attachments.expense_receipts", "chemical_erp.people_management.commission.on_expense_change"],
	                  "on_cancel": "chemical_erp.people_management.commission.on_expense_change",
	                  "before_update_after_submit": f"{C}.attachments.expense_privacy",
	                  "on_update_after_submit": f"{C}.attachments.expense_receipts"},
	"Payment Entry": {"before_insert": "chemical_erp.numbering.payment_series",
	                  "validate": [APPROVAL, "chemical_erp.controls.security.payment_hold", f"{C}.attachments.payment_needs_receipts", "chemical_erp.people_management.commission.payment_validate"],
	                  "on_submit": ["chemical_erp.chemical_core.doctype.wht_certificate.wht_certificate.expect_from_payment",
	                                "chemical_erp.people_management.commission.payment_submit"],
	                  "on_cancel": "chemical_erp.people_management.commission.payment_cancel"},
	"Payroll Run": {"validate": "chemical_erp.people_management.commission.payroll_validate",
	                "before_submit": "chemical_erp.people_management.commission.payroll_before_submit",
	                "on_submit": "chemical_erp.people_management.commission.payroll_submit",
	                "on_cancel": "chemical_erp.people_management.commission.payroll_cancel"},
	"Item": {"validate": "chemical_erp.regulatory_compliance.documents.item_validate"},
	"Delivery Trip": {"validate": "chemical_erp.chemical_core.dispatch.trip_validate", "before_submit": "chemical_erp.chemical_core.dispatch.trip_before_submit"},
	"Water Sample": {"on_update": "chemical_erp.field_laboratory.site_stock.apply_readings"},
	"Maintenance Job": {"validate": "chemical_erp.regulatory_compliance.doctype.work_permit.work_permit.maintenance_needs_permit"},
	"Event": {"validate": "chemical_erp.dashboard.calendar.validate_event", "on_update": "chemical_erp.dashboard.calendar.share_with_attendees"},
	"Disposal Order": {"validate": APPROVAL},
	"Estimate Request": {"validate": APPROVAL},
	"Customer": {"validate": ["chemical_erp.chemical_core.doctype.credit_limit_request.credit_limit_request.guard_customer_limit", "chemical_erp.chemical_core.collections.guard_customer"],
	             "on_update": "chemical_erp.controls.security.bank_details_changed"},
	"Period Closing Voucher": {"validate": f"{C}.accounting.period_closing_validate"},
	"User": {"before_insert": "chemical_erp.people_management.accounts.guard", "validate": "chemical_erp.people_management.accounts.guard",
	         "on_update": "chemical_erp.controls.security.on_user_update"},
	"Employee": {"validate": ["chemical_erp.people_management.staff.validate_employee", f"{C}.attachments.employee", f"{C}.attachments.employee_privacy"],
	             "on_update": "chemical_erp.controls.security.bank_details_changed"},
	"Bank Account": {"on_update": "chemical_erp.controls.security.bank_details_changed"},
	"Supplier": {"on_update": "chemical_erp.controls.security.bank_details_changed"},
	"Employment Contract": {"validate": [f"{C}.attachments.employment_contract", f"{C}.attachments.contract_privacy"]},
	"Calibration Record": {"validate": f"{C}.attachments.calibration_record"},
	"Training Event": {"validate": "chemical_erp.learning.events.training_event_validate",
	                   "on_submit": "chemical_erp.learning.events.training_event_on_submit"},
	"Training Result": {"validate": "chemical_erp.learning.results.fill_online_minutes",
	                    "on_submit": "chemical_erp.learning.needs.training_result_on_submit"},
	"Bank Guarantee": {"on_submit": f"{T}.bank_guarantee_submitted", "on_cancel": f"{T}.bank_guarantee_cancelled"},
	"Request for Quotation": {"after_insert": f"{T}.rfq_created"},
}

# House-style PDFs: made and saved when a document is submitted (invoices: when EFRIS fiscalises), re-made on cancel.
def _add_event(doctype, event, handler):
	ev = doc_events.setdefault(doctype, {})
	current = ev.get(event)
	ev[event] = ([current] if isinstance(current, str) else list(current or [])) + [handler]


for _dt in ("Quotation", "Sales Order", "Delivery Note", "Sales Invoice", "Purchase Order", "Request for Quotation", "Payment Entry"):
	_add_event(_dt, "on_submit", "chemical_erp.print_pdf.queue")
	_add_event(_dt, "on_cancel", "chemical_erp.print_pdf.queue")
_add_event("Sales Invoice", "on_update_after_submit", "chemical_erp.print_pdf.efris_done")

override_whitelisted_methods = {
	"erpnext.buying.doctype.purchase_order.purchase_order.update_status": "chemical_erp.controls.attachments.update_po_status",
	"erpnext.buying.doctype.purchase_order.purchase_order.close_or_unclose_purchase_orders": "chemical_erp.controls.attachments.close_or_unclose_pos",
	# Every workflow action goes through the approval checks (see controls/approvals.py)
	"frappe.model.workflow.apply_workflow": "chemical_erp.controls.approvals.apply_workflow",
	"frappe.model.workflow.bulk_workflow_approval": "chemical_erp.controls.approvals.bulk_workflow_approval",
	# Deleting: the MD anything; line managers their team's documents (MD told, copy kept); nobody their own
	"frappe.client.delete": "chemical_erp.controls.deletion.client_delete",
	"frappe.desk.reportview.delete_items": "chemical_erp.controls.deletion.delete_items",
}

permission_query_conditions = {
	"Access Grant": "chemical_erp.people_management.doctype.access_grant.access_grant.query_conditions",
	"BOM": f"{C}.confidentiality.bom_query",
	"Work Order": f"{C}.confidentiality.work_order_query",
	"Stock Entry": f"{C}.confidentiality.stock_entry_query",
	"Stock Ledger Entry": f"{C}.confidentiality.sle_query",
	"Batch Link": f"{C}.confidentiality.batch_link_query",
	"Commission Entry": "chemical_erp.people_management.commission.query_conditions",
}
has_permission = {dt: f"{C}.confidentiality.has_permission" for dt in ("BOM", "Work Order", "Stock Entry", "Batch Link")}
has_permission["Commission Entry"] = "chemical_erp.people_management.commission.has_permission"

scheduler_events = {
	"daily": ["chemical_erp.people_management.positions.sync_positions", "chemical_erp.people_management.access.expire_grants", "chemical_erp.tasks.daily", "chemical_erp.tenders_desk.tasks.daily", "chemical_erp.people_management.tasks.daily",
	          "chemical_erp.management_systems.tasks.flag_documents_due_for_review",
	          "chemical_erp.management_systems.tasks.flag_legal_requirements_due_for_review",
	          "chemical_erp.learning.needs.daily",
	          "chemical_erp.management_systems.audit.plan_quarterly_audit",
	          "chemical_erp.ops_tasks.daily", "chemical_erp.field_laboratory.seed.due_for_sampling",
	          "chemical_erp.chemical_core.material_check.daily_recheck", "chemical_erp.tenders_desk.scanner.daily",
	          "chemical_erp.controls.delegation.daily",
	          "chemical_erp.regulatory_compliance.doctype.document_exception.document_exception.expire", "chemical_erp.regulatory_compliance.controlled.daily", "chemical_erp.chemical_core.collections.daily", "chemical_erp.field_laboratory.site_stock.daily", "chemical_erp.people_management.commission.daily", "chemical_erp.controls.security.daily"],
	"monthly": ["chemical_erp.ops_tasks.monthly", "chemical_erp.chemical_core.diagnostics.monthly"],
	"hourly": ["chemical_erp.tasks.hourly", "chemical_erp.regulatory_compliance.doctype.work_permit.work_permit.expire", "chemical_erp.controls.security.hourly", "chemical_erp.controls.attachments.receipt_deadlines",
	           "chemical_erp.tenders_desk.scanner.run_due_sources", "chemical_erp.documents.tasks.expire_shared_links"],
	"weekly": ["chemical_erp.tasks.weekly", "chemical_erp.tenders_desk.tasks.weekly_digest",
	           "chemical_erp.management_systems.tasks.send_compliance_digest"],
	"cron": {"*/5 * * * *": ["chemical_erp.tasks.every_five_minutes"]},
}
