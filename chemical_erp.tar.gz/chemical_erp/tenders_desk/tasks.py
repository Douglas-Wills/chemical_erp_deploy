import frappe
from frappe import _
from frappe.utils import (
	add_days,
	cint,
	date_diff,
	escape_html,
	formatdate,
	format_datetime,
	get_url_to_form,
	getdate,
	today,
)

from chemical_erp.tenders_desk.utils import (
	CLOSED_STATUSES,
	OPEN_STATUSES,
	SUBMITTED_STATUSES,
	notify,
	credential_status,
	get_settings,
	open_todo_exists,
	users_with_role,
)


def _recipient(doc_or_row, settings):
	user = doc_or_row.get("bid_manager") or doc_or_row.get("responsible") or doc_or_row.get("owner")
	if user and user not in ("Guest",):
		return user
	users = users_with_role(settings.digest_role)
	return users[0] if users else None


def _refresh(doc):
	"""Recompute dates and readiness without running status rules, then persist quietly."""
	doc.set_dates()
	doc.refresh_requirements()
	doc.evaluate_readiness()
	doc.db_update()
	for row in doc.requirements:
		row.db_update()


# ---------------------------------------------------------------------- daily
def daily():
	settings = get_settings()
	for job in (refresh_credentials, refresh_open_tenders, follow_up_bid_validity):
		try:
			job(settings)
			frappe.db.commit()
		except Exception:
			frappe.db.rollback()
			frappe.log_error(title=f"Tenders Desk daily job failed: {job.__name__}", message=frappe.get_traceback())


def refresh_credentials(settings):
	warn_days = cint(settings.credential_warning_days) or 30
	for c in frappe.get_all(
		"Bid Credential",
		fields=["name", "credential_name", "company", "valid_until", "no_expiry", "status", "days_to_expiry",
		        "responsible", "owner", "last_reminder_on"],
	):
		status, days = credential_status(c.valid_until, c.no_expiry, warn_days)
		if status != c.status or days != c.days_to_expiry:
			frappe.db.set_value("Bid Credential", c.name, {"status": status, "days_to_expiry": days}, update_modified=False)
		if status in ("Expiring Soon", "Expired") and (
			not c.last_reminder_on or date_diff(today(), c.last_reminder_on) >= 7
		):
			if status == "Expired":
				text = _("{0} ({1}) expired on {2}. Renew it before the next bid.")
			else:
				text = _("{0} ({1}) expires on {2}. Start the renewal now.")
			notify(
				_recipient(c, settings), "Bid Credential", c.name,
				subject=_("{0} has expired").format(c.credential_name) if status == "Expired"
				else _("{0} expires in {1} days").format(c.credential_name, days),
				message=text.format(c.credential_name, c.company, formatdate(c.valid_until)),
				priority="High" if status == "Expired" else "Medium",
			)
			frappe.db.set_value("Bid Credential", c.name, "last_reminder_on", today(), update_modified=False)


def refresh_open_tenders(settings):
	thresholds = {cint(d) for d in (settings.reminder_days or "").split(",") if d.strip().isdigit()}
	for name in frappe.get_all("Tender", filters={"status": ["in", OPEN_STATUSES + SUBMITTED_STATUSES]}, pluck="name"):
		doc = frappe.get_doc("Tender", name)
		_refresh(doc)
		if doc.status not in OPEN_STATUSES or doc.days_to_close is None:
			continue
		days = cint(doc.days_to_close)
		sent = {s for s in (doc.reminders_sent or "").split(",") if s}
		if days in thresholds and str(days) not in sent:
			when = _("today") if days == 0 else (_("tomorrow") if days == 1 else _("in {0} days").format(days))
			text = _("{0} closes {1} ({2}). Mandatory items ready: {3}%.").format(
				doc.tender_title, when, format_datetime(doc.closing_datetime, "d MMM yyyy, HH:mm"),
				cint(doc.readiness_percent),
			)
			if doc.readiness_issues:
				text += " " + _("Still to fix: {0}").format(doc.readiness_issues.replace("\n", "; "))
			priority = "High" if days <= 3 else "Medium"
			manager = _recipient(doc, settings)
			notify(manager, "Tender", doc.name, subject=_("{0} closes {1}").format(doc.tender_title, when),
			       message=text, priority=priority)

			# Each responsible officer gets their own list of outstanding items.
			by_user = {}
			for row in doc.requirements:
				if row.responsible and cint(row.mandatory) and not cint(row.done):
					by_user.setdefault(row.responsible, []).append(row.requirement)
			for user, items in by_user.items():
				if user == manager:
					continue
				notify(
					user, "Tender", doc.name,
					subject=_("Your items for {0} are due: closes {1}").format(doc.tender_title, when),
					message=_("{0} closes {1}. These items assigned to you are not ready yet: {2}. Tick each one as Ready on the tender when done.").format(
						doc.tender_title, format_datetime(doc.closing_datetime, "d MMM yyyy, HH:mm"), "; ".join(items)
					),
					priority=priority,
				)
			sent.add(str(days))
			doc.db_set("reminders_sent", ",".join(sorted(sent, key=int)), update_modified=False)


def follow_up_bid_validity(settings):
	soon = add_days(today(), 7)
	for t in frappe.get_all(
		"Tender",
		filters={"status": ["in", SUBMITTED_STATUSES], "bid_validity_until": ["between", [today(), soon]]},
		fields=["name", "tender_title", "bid_validity_until", "bid_manager", "owner"],
	):
		if open_todo_exists("Tender", t.name, "bid validity"):
			continue
		notify(
			_recipient(t, settings), "Tender", t.name,
			subject=_("Bid validity ending: {0}").format(t.tender_title),
			message=_("Our bid validity for {0} ends on {1}. Ask the procuring entity about the result or a validity extension.").format(
				t.tender_title, formatdate(t.bid_validity_until)
			),
		)


def refresh_tenders_for_credential(credential):
	names = frappe.db.sql_list(
		"""select distinct parent from `tabTender Requirement`
		where credential=%s and parenttype='Tender'""",
		credential,
	)
	for name in set(names):
		if frappe.db.get_value("Tender", name, "status") in OPEN_STATUSES + SUBMITTED_STATUSES:
			_refresh(frappe.get_doc("Tender", name))


# ---------------------------------------------------------------------- weekly
def remind_security_returns(settings):
	for t in frappe.get_all(
		"Tender",
		filters={
			"status": ["in", CLOSED_STATUSES],
			"bid_security_required": 1,
			"bid_security_returned": 0,
			"bid_security_type": ["in", ["Bank Guarantee", "Insurance Bond", "Bank Draft / Cash"]],
		},
		fields=["name", "tender_title", "status", "bid_security_type", "bid_manager", "owner"],
	):
		if open_todo_exists("Tender", t.name, "bid security"):
			continue
		notify(
			_recipient(t, settings), "Tender", t.name,
			subject=_("Recover bid security: {0}").format(t.tender_title),
			message=_("{0} is {1}. Recover the bid security ({2}) from the procuring entity and tick Security Returned.").format(
				t.tender_title, t.status.lower(), t.bid_security_type
			),
		)


def weekly_digest():
	settings = get_settings()
	try:
		remind_security_returns(settings)
		frappe.db.commit()
	except Exception:
		frappe.db.rollback()
		frappe.log_error(title="Tenders Desk security-return reminders failed", message=frappe.get_traceback())

	if not cint(settings.send_weekly_digest):
		return
	recipients = [frappe.db.get_value("User", u, "email") for u in users_with_role(settings.digest_role)]
	recipients = [r for r in recipients if r]
	if not recipients:
		return

	def link(doctype, name, label):
		return f'<a href="{get_url_to_form(doctype, name)}">{escape_html(label or name)}</a>'

	open_tenders = frappe.get_all(
		"Tender",
		filters={"status": ["in", OPEN_STATUSES]},
		fields=["name", "tender_title", "procuring_entity_name", "closing_datetime", "days_to_close",
		        "readiness_percent", "ready_to_submit", "status"],
		order_by="closing_datetime asc",
	)
	awaiting = frappe.get_all(
		"Tender", filters={"status": ["in", SUBMITTED_STATUSES]},
		fields=["name", "tender_title", "procuring_entity_name", "submitted_on", "bid_validity_until"],
		order_by="submitted_on asc",
	)
	credentials = frappe.get_all(
		"Bid Credential", filters={"status": ["in", ["Expired", "Expiring Soon", "Date Missing"]]},
		fields=["name", "credential_name", "company", "status", "valid_until"], order_by="valid_until asc",
	)
	week_ago = add_days(today(), -7)
	outcomes = frappe.get_all(
		"Tender", filters={"status": ["in", ["Awarded", "Lost"]], "modified": [">=", week_ago]},
		fields=["name", "tender_title", "status", "price_gap_percent", "lost_reason"],
	)

	td = 'style="padding:6px 10px;border-bottom:1px solid #e3e6e8;text-align:left;vertical-align:top"'

	def table(headers, rows):
		if not rows:
			return "<p style='color:#6b7280'>Nothing here this week.</p>"
		head = "".join(f"<th {td}>{h}</th>" for h in headers)
		body = "".join("<tr>" + "".join(f"<td {td}>{c}</td>" for c in r) + "</tr>" for r in rows)
		return f"<table style='border-collapse:collapse;width:100%;font-size:14px'><tr>{head}</tr>{body}</table>"

	html = [f"<h3>Tenders: week of {formatdate(today())}</h3>", "<h4>Open tenders</h4>"]
	html.append(table(
		["Tender", "Entity", "Closes", "Days", "Ready", "Status"],
		[[link("Tender", t.name, t.tender_title), escape_html(t.procuring_entity_name or ""),
		  format_datetime(t.closing_datetime, "d MMM, HH:mm") if t.closing_datetime else "Not set",
		  "" if t.days_to_close is None else t.days_to_close,
		  "Yes" if t.ready_to_submit else f"{cint(t.readiness_percent)}%", t.status] for t in open_tenders],
	))
	html.append("<h4>Credentials needing attention</h4>")
	html.append(table(
		["Credential", "Company", "Status", "Valid until"],
		[[link("Bid Credential", c.name, c.credential_name), escape_html(c.company), c.status,
		  formatdate(c.valid_until) if c.valid_until else "Not recorded"] for c in credentials],
	))
	html.append("<h4>Submitted, awaiting results</h4>")
	html.append(table(
		["Tender", "Entity", "Submitted", "Bid valid until"],
		[[link("Tender", t.name, t.tender_title), escape_html(t.procuring_entity_name or ""),
		  formatdate(t.submitted_on) if t.submitted_on else "", formatdate(t.bid_validity_until) if t.bid_validity_until else ""]
		 for t in awaiting],
	))
	if outcomes:
		html.append("<h4>Results recorded this week</h4>")
		html.append(table(
			["Tender", "Result", "Our price vs winner", "Lost reason"],
			[[link("Tender", t.name, t.tender_title), t.status,
			  f"{t.price_gap_percent:+.1f}%" if t.price_gap_percent else "", escape_html(t.lost_reason or "")] for t in outcomes],
		))

	frappe.sendmail(
		recipients=recipients,
		subject=_("Tender digest: {0} open, {1} awaiting results").format(len(open_tenders), len(awaiting)),
		message="".join(html),
		reference_doctype="Tender Settings",
		reference_name="Tender Settings",
	)
