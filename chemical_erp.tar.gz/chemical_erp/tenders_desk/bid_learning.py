"""The Bid Library: learn reusable sections from the company's own bids.

A sample bid (Word or PDF) is split at its headings; each section is recognised by its heading and wording and saved
as a Bid Library Block for the Bid Manager to review. Approved blocks then replace the standard wording in new drafts,
preferring blocks from the same tender category, then winning bids, then the most recent.

`split_docx`, `split_text` and `classify` are pure, so they can be tested without a site.
"""

import hashlib
import io
import re

SECTION_WORDS = [  # (section, words that identify it, in heading first, then in text)
	("Bid Submission Sheet", ("bid submission sheet", "form of bid", "bid form", "letter of bid", "we, the undersigned")),
	("Understanding of Requirement", ("understanding", "our understanding", "background", "scope of the assignment", "appreciation of the")),
	("Company Profile", ("company profile", "about us", "who we are", "corporate profile", "company background", "firm profile")),
	("Methodology and Delivery", ("methodology", "approach", "work plan", "implementation plan", "logistics", "delivery plan", "supply plan",
	                              "execution", "technical proposal")),
	("Quality, Health, Safety and Environment", ("quality", "hse", "health and safety", "qhse", "environment", "quality assurance",
	                                             "quality control", "iso 9001", "safety")),
	("Relevant Experience", ("experience", "past performance", "similar contracts", "references", "track record", "previous contracts", "clients")),
	("Key Personnel", ("key personnel", "key staff", "team", "personnel", "staffing", "curriculum vitae", "cv")),
	("Delivery Schedule", ("delivery schedule", "schedule of delivery", "time schedule", "lead time", "programme of works")),
	("Warranty and After-sales", ("warranty", "after-sales", "after sales", "guarantee", "service support", "maintenance support")),
	("Declarations", ("declaration", "anti-bribery", "conflict of interest", "code of ethical conduct", "undertaking", "integrity")),
]
NUMBERED = re.compile(r"^\s*((section|part)\s+)?(\d+(\.\d+)*|[A-H]|[IVX]+)[.)]?\s+\S", re.I)


def classify(heading, text):
	h, t = (heading or "").lower(), (text or "").lower()[:1500]
	for section, words in SECTION_WORDS:
		if any(w in h for w in words):
			return section
	best, points = "Other", 0
	for section, words in SECTION_WORDS:
		n = sum(t.count(w) for w in words)
		if n > points:
			best, points = section, n
	return best if points >= 2 else "Other"


def _is_heading_line(line):
	s = line.strip()
	if not (3 <= len(s) <= 90) or s.endswith((".", ",", ";")) and not NUMBERED.match(s):
		return False
	words = s.split()
	if NUMBERED.match(s) and len(words) <= 12:
		return True
	letters = [c for c in s if c.isalpha()]
	return bool(letters) and sum(c.isupper() for c in letters) / len(letters) > 0.8 and len(words) <= 10


def split_docx(content):
	"""[(heading, text)] from a .docx, in document order, tables included."""
	from docx import Document
	from docx.table import Table
	from docx.text.paragraph import Paragraph

	doc = Document(io.BytesIO(content))
	sections, heading, buf = [], None, []

	def flush():
		text = "\n".join(x for x in buf if x.strip()).strip()
		if heading or text:
			sections.append((heading or "", text))

	for el in doc.element.body.iterchildren():
		tag = el.tag.split("}")[-1]
		if tag == "p":
			p = Paragraph(el, doc)
			text = p.text.strip()
			if not text:
				continue
			style = (p.style.name if p.style is not None else "").lower()
			bold = p.runs and all(r.bold for r in p.runs if r.text.strip())
			if style.startswith(("heading", "title")) or (bold and len(text) <= 90 and not text.endswith(".")) or _is_heading_line(text):
				flush()
				heading, buf = text, []
			else:
				buf.append(text)
		elif tag == "tbl":
			t = Table(el, doc)
			for row in t.rows:
				cells = []
				for c in row.cells:
					v = c.text.strip()
					if v and (not cells or cells[-1] != v):
						cells.append(v)
				if cells:
					buf.append(" | ".join(cells))
	flush()
	return sections


def split_text(text):
	"""[(heading, text)] from plain text (PDF)."""
	sections, heading, buf = [], None, []
	for line in (text or "").splitlines():
		if not line.strip():
			continue
		if _is_heading_line(line):
			if heading or buf:
				sections.append((heading or "", "\n".join(buf).strip()))
			heading, buf = line.strip(), []
		else:
			buf.append(line.strip())
	if heading or buf:
		sections.append((heading or "", "\n".join(buf).strip()))
	return sections


def pdf_text(content):
	from pypdf import PdfReader

	return "\n".join((page.extract_text() or "") for page in PdfReader(io.BytesIO(content)).pages)


def blocks_from(sections, min_chars=120):
	"""Reusable blocks: long enough to be worth reusing, merged when one section continues under sub-headings."""
	out = []
	for heading, text in sections:
		section = classify(heading, text)
		if out and section == out[-1]["section"] and section != "Other":
			out[-1]["content"] += "\n\n" + (f"{heading}\n" if heading else "") + text
			continue
		out.append({"section": section, "heading": heading[:140], "content": text})
	return [b for b in out if len(b["content"]) >= min_chars]


# ------------------------------------------------------------------ with the site
def learn(sample_name):
	import frappe
	from frappe.utils import now_datetime

	sample = frappe.get_doc("Bid Sample", sample_name)
	f = frappe.get_doc("File", {"file_url": sample.sample_file})
	content = f.get_content()
	name = (f.file_name or sample.sample_file or "").lower()
	try:
		if name.endswith(".docx"):
			sections = split_docx(content)
		elif name.endswith(".pdf"):
			sections = split_text(pdf_text(content))
		else:
			frappe.throw(frappe._("Upload the sample as a Word (.docx) or PDF file."))
	except frappe.ValidationError:
		raise
	except Exception:
		sample.db_set({"status": "Could Not Read"})
		frappe.log_error(title=f"Bid sample could not be read: {sample.name}", message=frappe.get_traceback())
		return 0
	made = 0
	for b in blocks_from(sections):
		fp = hashlib.sha1(re.sub(r"\s+", " ", b["content"].lower()).encode()).hexdigest()
		if frappe.db.exists("Bid Library Block", {"fingerprint": fp}):
			continue
		frappe.get_doc({"doctype": "Bid Library Block", "section": b["section"], "heading": b["heading"], "content": b["content"],
		                "source_sample": sample.name, "category": sample.category, "outcome": sample.outcome, "fingerprint": fp}
		               ).insert(ignore_permissions=True)
		made += 1
	sample.db_set({"status": "Learned", "learned_on": now_datetime(),
	               "sections_found": frappe.db.count("Bid Library Block", {"source_sample": sample.name})})
	from chemical_erp.utils import notify, users_with_role

	if made:
		notify(users_with_role("Tender Manager"), "Bid Sample", sample.name,
		       frappe._("{0} section(s) learned from {1}: review and approve the ones to reuse").format(made, sample.title))
	return made


def best_block(section, category=None):
	"""The approved block to reuse for a section: same category first, then won bids, then the newest."""
	import frappe

	rows = frappe.get_all("Bid Library Block", filters={"section": section, "approved": 1},
	                      fields=["name", "content", "category", "outcome", "modified", "source_sample"])
	if not rows:
		return None
	rank = lambda r: ((r.category == category and category is not None), r.outcome == "Won", r.modified)
	return sorted(rows, key=rank, reverse=True)[0]


def library_status():
	import frappe

	return {"samples": frappe.db.count("Bid Sample"), "approved": frappe.db.count("Bid Library Block", {"approved": 1}),
	        "to_review": frappe.db.count("Bid Library Block", {"approved": 0})}
