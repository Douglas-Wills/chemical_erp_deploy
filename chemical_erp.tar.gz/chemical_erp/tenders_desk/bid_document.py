"""Draft bid document (Microsoft Word) for a tender, for the Bid Manager to complete.

`collect(tender)` gathers everything the system already knows (the company, the advert, requirements and credentials,
price lines, bid security, clarifications, past awards, key people); `build(data, logo_path)` is pure and returns .docx
bytes. Anything the system cannot know is left as a [bracketed placeholder], highlighted yellow, so nothing is missed.

House style: Arial throughout, 11pt body with 1.15 line spacing, navy headings, real Word headings so the
table of contents updates (Word asks to update fields when the file is opened).
"""

import io
import re

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_COLOR_INDEX
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

NAVY = RGBColor(0x1F, 0x38, 0x64)
GREY = RGBColor(0x55, 0x5F, 0x6B)
RED = RGBColor(0xB3, 0x26, 0x1E)
GREEN = RGBColor(0x2A, 0x6A, 0x4A)
PLACEHOLDER = re.compile(r"(\[[^\]]*\])")


# ------------------------------------------------------------------ helpers
def _font(run, size=None, bold=None, color=None, italic=None):
	run.font.name = "Arial"
	run._element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "Arial")
	if size:
		run.font.size = Pt(size)
	if bold is not None:
		run.bold = bold
	if italic is not None:
		run.italic = italic
	if color is not None:
		run.font.color.rgb = color
	return run


def _write(p, text, size=None, bold=None, color=None, italic=None):
	"""Write text; [placeholders] are highlighted yellow for the Bid Manager."""
	for part in PLACEHOLDER.split(str(text if text is not None else "")):
		if not part:
			continue
		r = _font(p.add_run(part), size, bold, color, italic)
		if PLACEHOLDER.fullmatch(part):
			r.font.highlight_color = WD_COLOR_INDEX.YELLOW
	return p


def _para(doc, text="", size=11, bold=None, color=None, italic=None, align=None, after=6):
	p = doc.add_paragraph()
	p.paragraph_format.space_after = Pt(after)
	p.paragraph_format.line_spacing = 1.15
	if align:
		p.alignment = align
	return _write(p, text, size, bold, color, italic)


def _heading(doc, text, level=1):
	h = doc.add_heading(level=level)
	h.paragraph_format.space_before = Pt(14 if level == 1 else 10)
	h.paragraph_format.space_after = Pt(6)
	_font(h.add_run(text), 14 if level == 1 else 12, True, NAVY)
	return h


def _shade(cell, fill):
	tc = cell._element.get_or_add_tcPr()
	shd = OxmlElement("w:shd")
	shd.set(qn("w:val"), "clear")
	shd.set(qn("w:color"), "auto")
	shd.set(qn("w:fill"), fill)
	tc.append(shd)


def _cell(cell, text, size=10, bold=False, color=None, align=None):
	cell.text = ""
	p = cell.paragraphs[0]
	p.paragraph_format.space_after = Pt(0)
	p.paragraph_format.line_spacing = 1.0
	if align:
		p.alignment = align
	_write(p, text, size, bold, color)


def _table(doc, header, rows, widths=None, align_right=()):
	t = doc.add_table(rows=1, cols=len(header))
	t.style = "Table Grid"
	t.alignment = WD_TABLE_ALIGNMENT.CENTER
	for i, h in enumerate(header):
		_cell(t.rows[0].cells[i], h, 9.5, True, RGBColor(0xFF, 0xFF, 0xFF))
		_shade(t.rows[0].cells[i], "1F3864")
	for row in rows:
		cells = t.add_row().cells
		for i, v in enumerate(row):
			color = None
			if isinstance(v, tuple):
				v, color = v
			_cell(cells[i], v, 9.5, False, color, WD_ALIGN_PARAGRAPH.RIGHT if i in align_right else None)
	if widths:
		_widths(t, widths)
	doc.add_paragraph().paragraph_format.space_after = Pt(2)
	return t


def _widths(t, widths):
	"""Fixed column widths that Word and LibreOffice both respect."""
	t.autofit = False
	tbl_pr = t._tbl.tblPr
	layout = OxmlElement("w:tblLayout")
	layout.set(qn("w:type"), "fixed")
	tbl_pr.append(layout)
	grid = t._tbl.tblGrid
	for i, col in enumerate(grid.findall(qn("w:gridCol"))):
		if i < len(widths):
			col.set(qn("w:w"), str(int(Cm(widths[i]).twips)))
	for row in t.rows:
		for i, w in enumerate(widths):
			if i < len(row.cells):
				row.cells[i].width = Cm(w)


def _kv(doc, pairs, key_width=5.5, total=16.5):
	t = doc.add_table(rows=0, cols=2)
	t.style = "Table Grid"
	for k, v in pairs:
		cells = t.add_row().cells
		_cell(cells[0], k, 10, True)
		_shade(cells[0], "EEF1F6")
		_cell(cells[1], v, 10)
	_widths(t, [key_width, total - key_width])
	doc.add_paragraph().paragraph_format.space_after = Pt(2)
	return t


def _field(paragraph, instruction):
	"""A Word field (page numbers, table of contents)."""
	run = paragraph.add_run()
	_font(run, 9, color=GREY)
	for tag, attr in (("w:fldChar", {"w:fldCharType": "begin"}), ("w:instrText", None), ("w:fldChar", {"w:fldCharType": "separate"}),
	                  ("w:t", None), ("w:fldChar", {"w:fldCharType": "end"})):
		el = OxmlElement(tag)
		if attr:
			for k, v in attr.items():
				el.set(qn(k), v)
		if tag == "w:instrText":
			el.set(qn("xml:space"), "preserve")
			el.text = instruction
		if tag == "w:t":
			el.text = "1" if "PAGE" in instruction else "Right-click and choose Update Field to build the table of contents."
		run._element.append(el)


def _update_fields_on_open(doc):
	settings = doc.settings.element
	el = OxmlElement("w:updateFields")
	el.set(qn("w:val"), "true")
	settings.append(el)


def money(v, currency):
	try:
		return f"{currency} {float(v or 0):,.0f}" if currency in ("UGX", "KES", "TZS", "RWF") else f"{currency} {float(v or 0):,.2f}"
	except (TypeError, ValueError):
		return f"{currency} {v}"


def _library(doc, lib, section, intro=None):
	"""Write an approved Bid Library section; returns True if one was used."""
	block = (lib or {}).get(section)
	if not block:
		return False
	if intro:
		_para(doc, intro)
	rows = []

	def flush_table():
		if rows:  # table rows from the sample become a table again; the first row is its header
			width = max(len(r) for r in rows)
			body = [r + [""] * (width - len(r)) for r in rows]
			_table(doc, body[0], body[1:] or [[""] * width])
			rows.clear()

	for line in [l.strip() for l in block["text"].split("\n") if l.strip()]:
		if " | " in line:
			rows.append([c.strip() for c in line.split(" | ")])
			continue
		flush_table()
		_para(doc, line, after=4)
	flush_table()
	_para(doc, f"From the bid library ({block['source']}). Check names, figures and dates against this tender. [Review]", 8.5, italic=True, color=GREY)
	return True


# ------------------------------------------------------------------ the document
def build(d, logo_path=None):
	doc = Document()
	st = doc.styles["Normal"]
	st.font.name, st.font.size = "Arial", Pt(11)
	st.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
	st.paragraph_format.line_spacing = 1.15
	for s in doc.sections:
		s.page_width, s.page_height = Cm(21), Cm(29.7)
		s.left_margin = s.right_margin = Cm(2.2)
		s.top_margin, s.bottom_margin = Cm(2.0), Cm(1.8)
	_update_fields_on_open(doc)
	c, t = d["company"], d["tender"]
	cur = t.get("currency") or "UGX"

	# header and footer
	sec = doc.sections[0]
	sec.different_first_page_header_footer = True
	hp = sec.header.paragraphs[0]
	_write(hp, f"{c['legal_name']}  ·  Bid for {t.get('reference_no') or '[Procurement reference]'}", 8.5, color=GREY)
	fp = sec.footer.paragraphs[0]
	fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
	_write(fp, f"DRAFT for review  ·  {t.get('name')}  ·  Page ", 8.5, color=GREY)
	_field(fp, "PAGE")

	# ---------------- cover
	if logo_path:
		try:
			doc.add_picture(logo_path, width=Cm(6.5))
		except Exception:
			pass
	_para(doc, "", after=40)
	_para(doc, "BID SUBMISSION", 26, True, NAVY, after=4)
	_para(doc, t.get("tender_title") or "[Tender title]", 16, True, after=18)
	_kv(doc, [("Procurement reference", t.get("reference_no") or "[Procurement reference number]"),
	          ("Procuring entity", t.get("procuring_entity") or "[Procuring and disposing entity]"),
	          ("Procurement method", t.get("procurement_method") or "[Open domestic bidding / RFQ / …]"),
	          ("Bid submission deadline", t.get("closing") or "[Date and time]"),
	          ("Submitted by", c["legal_name"]),
	          ("Bidding as", t.get("bidding_as") or "Sole bidder" + (f" with {t['partners']}" if t.get("partners") else "")),
	          ("Contact", "; ".join(x for x in (c.get("phone"), c.get("email")) if x) or "[Phone, email]")], key_width=5.5)
	_para(doc, "", after=30)
	_para(doc, f"DRAFT prepared {d['today']} by {t.get('bid_manager') or '[Bid Manager]'} for review. "
	           "Yellow [placeholders] must be completed or removed before submission. Use the exact forms in the bidding document "
	           "where they differ from this draft.", 9, italic=True, color=RED)
	doc.add_page_break()

	# ---------------- contents
	_para(doc, "Contents", 14, True, NAVY)
	_field(doc.add_paragraph(), 'TOC \\o "1-2" \\h \\z \\u')
	doc.add_page_break()

	# ---------------- 1. bid submission sheet
	_heading(doc, "1. Bid Submission Sheet")
	_para(doc, f"Date: [Date of submission]        Procurement reference: {t.get('reference_no') or '[Reference]'}")
	_para(doc, f"To: {t.get('procuring_entity') or '[Procuring and disposing entity]'}")
	_para(doc, "We, the undersigned, declare that:")
	clauses = [
		"We have examined and have no reservations to the bidding document, including addenda No.: "
		+ (", ".join(x["subject"] for x in d["clarifications"] if x["type"] == "Addendum") or "[list addenda, or 'none']") + ".",
		f"We offer to supply in conformity with the bidding document and in accordance with the delivery schedule specified: "
		f"{t.get('tender_title') or '[description of the supplies or services]'}.",
		f"The total price of our bid, excluding any discounts offered below, is {money(t.get('total_incl_vat'), cur)} "
		f"({(t.get('total_in_words') or '[amount in words]').rstrip('.')}), inclusive of VAT.",
		"The discounts offered and the method of application are: [none / describe].",
		f"Our bid shall be valid for {t.get('validity_days') or '[number]'} days from the bid submission deadline, and shall remain binding "
		"upon us and may be accepted at any time before the expiry of that period.",
		"If our bid is accepted, we commit to obtain a performance security in accordance with the bidding document.",
		"We, including any subcontractors or suppliers for any part of the contract, have nationalities from eligible countries.",
		"We have no conflict of interest as described in the bidding document.",
		"We are not participating, as bidders, in more than one bid in this bidding process.",
		"We are not suspended by the PPDA Authority, nor debarred by any other procuring entity.",
		"We have read and understood the Code of Ethical Conduct for Bidders and Providers, and will abide by it.",
		"We understand that you are not bound to accept the lowest evaluated bid or any other bid that you may receive.",
	]
	for i, text in enumerate(clauses):
		_para(doc, f"({chr(97 + i)})  {text}", after=4)
	_kv(doc, [("Name", "[Name of authorised signatory]"), ("In the capacity of", "[Title]"),
	          ("Signed", "[Signature]"), ("Duly authorised to sign for and on behalf of", c["legal_name"]),
	          ("Date", "[Date]")], key_width=6.5)
	doc.add_page_break()

	# ---------------- 2. company profile
	_heading(doc, "2. Company Profile")
	_kv(doc, [("Legal name", c["legal_name"]), ("Trading name", c.get("trading_name") or c["legal_name"]),
	          ("Physical and postal address", c.get("address") or "[Address]"), ("Telephone", c.get("phone") or "[Telephone]"),
	          ("Email", c.get("email") or "[Email]"), ("Website", c.get("website") or "[Website]"),
	          ("Tax Identification Number (TIN)", c.get("tin") or "[TIN]"), ("VAT registration", c.get("vat_no") or "[VAT number]"),
	          ("Company registration (URSB)", c.get("registration_no") or "[URSB registration number]"),
	          ("National Supplier Database", c.get("nsd_no") or "[NSD registration number and validity]")])
	_heading(doc, "2.1 Scope of work", 2)
	_para(doc, c.get("scope_of_work") or "[Describe what the company supplies and does.]")
	if c.get("sectors_served"):
		_heading(doc, "2.2 Sectors served", 2)
		_para(doc, c["sectors_served"])
	if (d.get("library") or {}).get("Company Profile"):
		_heading(doc, "2.3 About us", 2)
		_library(doc, d["library"], "Company Profile")
	_heading(doc, "2.4 Management system" if (d.get("library") or {}).get("Company Profile") else "2.3 Management system", 2)
	_para(doc, "Our Integrated Management System is structured to ISO 9001 (quality), ISO 14001 (environment) and ISO 45001 (occupational "
	           "health and safety). Third-party certification status: [not yet certified / certified by … on …].")
	if d["policies"]:
		_table(doc, ["Reference", "Policy", "Revision"], [(p["number"], p["title"], p["revision"]) for p in d["policies"]], [3.5, 10, 3])

	# ---------------- 3. eligibility and administrative documents
	_heading(doc, "3. Eligibility and Administrative Documents")
	ready = d["readiness"]
	_para(doc, f"Readiness at drafting: {ready['done']} of {ready['total']} required documents in hand"
	           + (f"; outstanding: {ready['missing']}." if ready["missing"] else "."), 10, italic=True,
	      color=GREEN if not ready["missing"] else RED)
	rows = []
	for r in d["requirements"]:
		status = r["status"]
		colour = GREEN if status == "In hand" else RED
		rows.append((r["requirement"], r["type"] or "", "Yes" if r["mandatory"] else "No", (status, colour), r["valid_until"] or "", r["reference"] or ""))
	_table(doc, ["Document", "Type", "Mandatory", "Status", "Valid until", "Certificate / reference"],
	       rows or [("[Load the requirement template on the tender]", "", "", "", "", "")], [5.4, 2.2, 1.8, 2.2, 2.2, 3])

	# ---------------- 4. technical proposal
	_heading(doc, "4. Technical Proposal")
	_heading(doc, "4.1 Understanding of the requirement", 2)
	_para(doc, d["understanding"] or "[Summarise the requirement from the bidding document: what is to be supplied, where, when and to what standard.]")
	_heading(doc, "4.2 Statement of compliance with specifications", 2)
	comp = [(i + 1, x["item"], x["offered"], f"{x['qty']:g}" if x["qty"] else "", "[Comply / deviation]", x["origin"]) for i, x in enumerate(d["lines"])]
	_table(doc, ["#", "Item required", "Offered (specification)", "Qty", "Compliance", "Origin / make"],
	       comp or [(1, "[Item]", "[Specification offered]", "", "[Comply]", "[Make]")], [0.8, 4, 4.8, 1.4, 2.5, 3], align_right=(3,))
	_heading(doc, "4.3 Methodology and delivery", 2)
	if not _library(doc, d.get("library"), "Methodology and Delivery"):
		for line in d["methodology"]:
			_para(doc, f"•  {line}", after=3)
	_heading(doc, "4.4 Quality, health, safety and environment", 2)
	if not _library(doc, d.get("library"), "Quality, Health, Safety and Environment"):
		for line in d["qhse"]:
			_para(doc, f"•  {line}", after=3)
	_heading(doc, "4.5 Relevant experience", 2)
	_library(doc, d.get("library"), "Relevant Experience")
	exp = [(x["client"], x["title"], x["value"], x["year"]) for x in d["experience"]] + \
	      [("[Client]", "[Similar supply or service]", "[Contract value]", "[Year]")] * max(0, 3 - len(d["experience"]))
	_table(doc, ["Client", "Contract", "Value", "Year"], exp, [4.5, 7, 3, 2])
	_para(doc, "Attach reference letters or completion certificates for the contracts listed. [Attach]", 9.5, italic=True)
	_heading(doc, "4.6 Key personnel", 2)
	_table(doc, ["Name", "Position on this contract", "Qualifications and experience"],
	       [(p["name"], p["position"], "[Qualifications; years of experience]") for p in d["people"]] or
	       [("[Name]", "[Role]", "[Qualifications]")], [4.5, 5, 7])
	_library(doc, d.get("library"), "Key Personnel")
	_heading(doc, "4.7 Delivery schedule", 2)
	_table(doc, ["Item", "Quantity", "Delivery period", "Delivery site"],
	       [(x["item"], f"{x['qty']:g} {x['uom']}".strip() if x["qty"] else "", "[within … days of order]", "[Site]") for x in d["lines"]] or
	       [("[Item]", "[Qty]", "[Period]", "[Site]")], [6.5, 2.5, 3.8, 3.7])

	if (d.get("library") or {}).get("Warranty and After-sales"):
		_heading(doc, "4.8 Warranty and after-sales support", 2)
		_library(doc, d["library"], "Warranty and After-sales")

	# ---------------- 5. financial proposal
	_heading(doc, "5. Financial Proposal")
	_heading(doc, "5.1 Price schedule", 2)
	price = [(i + 1, x["item"], f"{x['qty']:g} {x['uom']}".strip() if x["qty"] else "", money(x["unit_price"], cur), money(x["line_value"], cur))
	         for i, x in enumerate(d["lines"])]
	tbl = _table(doc, ["#", "Item", "Quantity", "Unit price", "Total"],
	             price or [(1, "[Item]", "[Qty]", "[Unit price]", "[Total]")], [0.8, 6.4, 2.6, 3, 3.8], align_right=(2, 3, 4))
	for label, value in (("Sub-total", money(t.get("bid_value"), cur)),
	                     (f"VAT ({t.get('vat_rate') or 0:g}%)", money(t.get("vat_amount"), cur)),
	                     ("Total bid price (VAT inclusive)", money(t.get("total_incl_vat"), cur))):
		cells = tbl.add_row().cells
		merged = cells[0].merge(cells[3])
		_cell(merged, label, 9.5, True, align=WD_ALIGN_PARAGRAPH.RIGHT)
		_cell(cells[4], value, 9.5, True, align=WD_ALIGN_PARAGRAPH.RIGHT)
	_para(doc, f"Amount in words: {(t.get('total_in_words') or '[amount in words]').rstrip('.')}.", 10)
	_para(doc, f"Prices are in {cur}, delivered [to site / ex-works], and include all taxes, duties and charges unless stated. "
	           f"Bid validity: {t.get('validity_days') or '[number]'} days" + (f" (until {t['validity_until']})" if t.get("validity_until") else "") + ".", 10)
	_heading(doc, "5.2 Bid security", 2)
	if t.get("security_required"):
		_kv(doc, [("Form", t.get("security_type") or "[Bank guarantee / insurance bond / bid-securing declaration]"),
		          ("Amount", money(t.get("security_amount"), cur) if t.get("security_amount") else "[Amount]"),
		          ("Issued by / reference", t.get("security_reference") or "[Bank or insurer and reference]"),
		          ("Valid until", t.get("security_valid_until") or "[Date: at least the bid validity plus the period required]")])
	else:
		_para(doc, "No bid security is required by the bidding document. [Confirm; if a bid-securing declaration is required, attach it.]")

	# ---------------- 6. clarifications
	if d["clarifications"]:
		_heading(doc, "6. Clarifications and Addenda")
		_table(doc, ["Date", "Type", "Subject", "Response / effect"],
		       [(x["date"], x["type"], x["subject"], x["response"]) for x in d["clarifications"]], [2.4, 3, 5.5, 5.6])

	# ---------------- declarations and annexes
	n = 7 if d["clarifications"] else 6
	_heading(doc, f"{n}. Declarations")
	_library(doc, d.get("library"), "Declarations")
	for text in (
		f"Anti-bribery: {c['legal_name']} prohibits bribery in any form and abides by the Anti-Corruption Act 2009 and its "
		f"Anti-Bribery Policy{(' (' + d['anti_bribery_ref'] + ')') if d.get('anti_bribery_ref') else ''}.",
		"Conflict of interest: we declare that no officer of the procuring entity has an interest in our firm. [Declare any interest.]",
		"Code of Ethical Conduct: we confirm we have signed and will abide by the Code of Ethical Conduct for Bidders and Providers. [Attach signed code.]",
		"Accuracy: the information in this bid is true and complete to the best of our knowledge.",
	):
		_para(doc, f"•  {text}", after=4)
	_heading(doc, f"{n + 1}. Annexes")
	annex = [(i + 1, a["document"], a["status"]) for i, a in enumerate(d["annexes"])]
	_table(doc, ["#", "Document attached", "Status"], annex or [(1, "[Annex]", "")], [1, 11.5, 4])

	buf = io.BytesIO()
	doc.save(buf)
	return buf.getvalue()


# ------------------------------------------------------------------ data from the system
def collect(tender):
	import frappe
	from frappe.utils import flt, format_date, format_datetime, getdate, money_in_words, today

	from chemical_erp.company import bank_lines, get_profile

	p = get_profile(tender.company)
	phones = [x for x in p.get("phones") or [] if x.get("print_on_documents")]
	email = next((e.email for e in p.get("emails") or [] if e.get("print_on_documents")), None)
	company = {"legal_name": p.get("legal_name") or tender.company, "trading_name": p.get("trading_name"),
	           "address": ", ".join(l.strip() for l in (p.get("address_lines") or "").split("\n") if l.strip()),
	           "phone": "; ".join(f"{x.label}: {x.number}" for x in phones), "email": email, "website": p.get("website"),
	           "tin": p.get("tin"), "vat_no": p.get("vat_no"), "registration_no": p.get("registration_no"), "nsd_no": p.get("nsd_no"),
	           "scope_of_work": p.get("scope_of_work"), "sectors_served": p.get("sectors_served")}
	cur = tender.currency or "UGX"
	total = flt(tender.bid_value_incl_vat) or flt(tender.bid_value)
	t = {"name": tender.name, "tender_title": tender.tender_title, "reference_no": tender.reference_no,
	     "procuring_entity": tender.procuring_entity_name or (frappe.db.get_value("Customer", tender.customer, "customer_name") if tender.customer else None),
	     "procurement_method": tender.procurement_method,
	     "closing": format_datetime(tender.closing_datetime, "d MMMM yyyy, HH:mm") if tender.closing_datetime else None,
	     "bidding_as": tender.bidding_as, "partners": tender.partners,
	     "bid_manager": frappe.utils.get_fullname(tender.bid_manager) if tender.bid_manager else None,
	     "currency": cur, "bid_value": tender.bid_value, "vat_rate": flt(tender.vat_rate), "vat_amount": tender.vat_amount,
	     "total_incl_vat": total, "total_in_words": money_in_words(total, cur) if total else None,
	     "validity_days": tender.bid_validity_days, "validity_until": format_date(tender.bid_validity_until) if tender.bid_validity_until else None,
	     "security_required": tender.bid_security_required, "security_type": tender.bid_security_type,
	     "security_amount": tender.bid_security_amount, "security_reference": tender.bid_security_reference,
	     "security_valid_until": format_date(tender.bid_security_valid_until) if tender.bid_security_valid_until else None}

	requirements, annexes, missing = [], [], []
	for r in tender.requirements:
		cred = frappe.db.get_value("Bid Credential", r.credential, ["certificate_no", "valid_until", "attachment", "status"], as_dict=True) if r.credential else None
		in_hand = bool(r.done or r.attachment or (cred and cred.attachment and cred.status != "Expired"))
		status = "In hand" if in_hand else ("Expired" if cred and cred.status == "Expired" else "[Obtain]")
		if r.mandatory and not in_hand:
			missing.append(r.requirement)
		requirements.append({"requirement": r.requirement, "type": r.requirement_type, "mandatory": r.mandatory, "status": status,
		                     "valid_until": format_date(r.valid_until or (cred.valid_until if cred else None)) if (r.valid_until or (cred and cred.valid_until)) else "",
		                     "reference": cred.certificate_no if cred else ""})
		annexes.append({"document": r.requirement, "status": "Attached" if in_hand else "[To attach]"})
	done = sum(1 for r in requirements if r["status"] == "In hand")

	lines = []
	for x in tender.cost_lines:
		item = frappe.db.get_value("Item", x.item_code, ["item_name", "description", "stock_uom", "is_purchase_item", "item_group"], as_dict=True) if x.item_code else None
		lines.append({"item": x.description or (item.item_name if item else ""), "offered": (item.item_name if item else x.description) or "",
		              "qty": flt(x.qty), "uom": item.stock_uom if item else "", "unit_price": x.unit_price, "line_value": x.line_value,
		              "origin": (f"Manufactured by {company['trading_name'] or company['legal_name']}" if item and not item.is_purchase_item
		                         else "[Make / country of origin]")})

	understanding = (tender.ai_summary or "").strip() or (tender.notice_text or "").strip()[:1500]
	cat = (tender.category or "").lower()
	method = ["Order acknowledged in writing within one working day, with a confirmed delivery date.",
	          "Products are supplied from stock held in [Bweyogerere, Kampala] or sourced from approved manufacturers under our supplier-evaluation procedure.",
	          "Every batch is tested and released by our QC laboratory before dispatch, with a Certificate of Analysis for the batch supplied.",
	          "Each chemical is delivered with its current Safety Data Sheet in English, in labelled, UN-approved packaging where required.",
	          "Hazardous loads pass a dispatch safety check (vehicle, driver training, spill kit, segregation) and travel with a transport emergency card.",
	          "Delivery note, COA and invoice quote the procurement reference; returnable containers are tracked where applicable.",
	          "Account management: a named contact, [response time] for queries, and after-sales technical support."]
	if any(w in cat for w in ("water", "cleaning", "consult", "equipment")):
		method.insert(3, "Site work follows an approved method statement and risk assessment, with trained, PPE-equipped staff and a permit to work where the site requires it.")
	if "water" in cat:
		method.insert(4, "Water treatment programmes include on-site testing (HACH DR900 and HANNA meters) and a written Water Analysis Report after each visit.")
	qhse = ["Integrated Management System structured to ISO 9001, ISO 14001 and ISO 45001, with annual management review and quarterly internal audits.",
	        "Batch traceability from raw material to customer, with recall capability.",
	        "Hazardous waste disposed of only through licensed handlers under signed manifests.",
	        "Chemical-handling and PPE training for all staff; incident reporting and corrective action.",
	        "[Add the procuring entity's specific HSE requirements and how we meet them.]"]

	policies = frappe.get_all("IMS Document", filters={"document_type": "Policy", "status": ["in", ["Active", "Draft"]]},
	                          fields=["document_number", "title", "current_revision"], order_by="document_number", limit=12) \
		if frappe.db.exists("DocType", "IMS Document") else []
	anti = next((x.document_number for x in policies if "bribery" in (x.title or "").lower()), None)

	awards = frappe.get_all("Tender", filters={"status": "Awarded", "name": ["!=", tender.name]},
	                        fields=["procuring_entity_name", "customer", "tender_title", "contract_value", "currency", "award_date"],
	                        order_by="award_date desc", limit=5)
	experience = [{"client": a.procuring_entity_name or a.customer or "", "title": a.tender_title,
	               "value": money(a.contract_value, a.currency or cur) if a.contract_value else "[Value]",
	               "year": str(getdate(a.award_date).year) if a.award_date else ""} for a in awards]

	people = []
	if frappe.db.exists("DocType", "Company Position"):
		for pos in ("Managing Director", "Plant Manager", "QC Manager", "QC Analyst", "HSE Officer", "Technical Sales Officer", "Procurement Officer"):
			for h in frappe.get_all("Position Holder", filters={"parent": pos}, fields=["user"]):
				people.append({"name": frappe.utils.get_fullname(h.user), "position": pos})
	if tender.bid_manager and not any(x["name"] == frappe.utils.get_fullname(tender.bid_manager) for x in people):
		people.insert(0, {"name": frappe.utils.get_fullname(tender.bid_manager), "position": "Bid Manager"})

	clar = [{"date": format_date(x.entry_date) if x.entry_date else "", "type": x.entry_type, "subject": x.subject,
	         "response": x.response or x.details or ""} for x in tender.clarifications]
	library, used = {}, []
	if frappe.db.exists("DocType", "Bid Library Block"):
		from chemical_erp.tenders_desk.bid_learning import best_block

		for section in ("Company Profile", "Methodology and Delivery", "Quality, Health, Safety and Environment", "Relevant Experience",
		                "Key Personnel", "Warranty and After-sales", "Declarations"):
			b = best_block(section, tender.category)
			if b:
				title = frappe.db.get_value("Bid Sample", b.source_sample, "title") if b.source_sample else b.name
				library[section] = {"text": b.content, "source": f"{title}, {b.outcome or 'outcome not known'}"}
				used.append(b.name)
	return {"library": library, "library_used": used,
	        "company": company, "tender": t, "requirements": requirements, "annexes": annexes,
	        "readiness": {"done": done, "total": len(requirements), "missing": ", ".join(missing)},
	        "lines": lines, "understanding": understanding, "methodology": method, "qhse": qhse,
	        "policies": [{"number": x.document_number, "title": x.title, "revision": x.current_revision} for x in policies],
	        "anti_bribery_ref": anti, "experience": experience, "people": people, "clarifications": clar,
	        "today": format_date(today(), "d MMMM yyyy")}


def logo_path(company):
	import os

	import frappe

	from chemical_erp.company import get_profile

	url = get_profile(company).get("logo_wide") or get_profile(company).get("logo_square") or ""
	if "/files/" in url:
		folder = "private" if url.startswith("/private") else "public"
		path = frappe.get_site_path(folder, "files", url.split("/files/")[-1])
		if os.path.exists(path):
			return path
	if url.startswith("/assets/"):
		path = frappe.get_app_path("chemical_erp", "public", url.split("/assets/chemical_erp/public/")[-1].split("/assets/chemical_erp/")[-1])
		if os.path.exists(path):
			return path
	return None
