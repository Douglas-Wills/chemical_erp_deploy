"""Keep Tenders in sync when linked ERPNext documents change.

Every handler is defensive: a problem updating the tender is logged, never allowed
to block the user's Bank Guarantee, Quotation or Sales Order.
"""

import frappe
from frappe import _


def _update_tender(name, values, note=None):
	if not name or not frappe.db.exists("Tender", name):
		return
	try:
		tender = frappe.get_doc("Tender", name)
		tender.update(values)
		tender.flags.ignore_permissions = True
		tender.save()
		if note:
			tender.add_comment("Info", note)
	except Exception:
		frappe.log_error(title=f"Could not update Tender {name}", message=frappe.get_traceback())


def bank_guarantee_submitted(doc, method=None):
	if doc.get("bg_type") != "Providing" or not doc.get("tender"):
		return
	values = {"bank_guarantee": doc.name, "bid_security_obtained": 1}
	if doc.get("end_date"):
		values["bid_security_valid_until"] = doc.end_date
	if doc.get("bank_guarantee_number"):
		values["bid_security_reference"] = doc.bank_guarantee_number
	_update_tender(doc.tender, values, _("Bank Guarantee {0} submitted and linked as bid security.").format(doc.name))


def bank_guarantee_cancelled(doc, method=None):
	if not doc.get("tender"):
		return
	if frappe.db.get_value("Tender", doc.tender, "bank_guarantee") == doc.name:
		_update_tender(
			doc.tender,
			{"bid_security_obtained": 0, "bid_security_valid_until": None},
			_("Bank Guarantee {0} was cancelled. Bid security needs replacing.").format(doc.name),
		)


def quotation_submitted(doc, method=None):
	if not doc.get("tender"):
		return
	values = {}
	if not frappe.db.get_value("Tender", doc.tender, "quotation"):
		values["quotation"] = doc.name
	if values:
		_update_tender(doc.tender, values)


def sales_order_submitted(doc, method=None):
	if doc.get("tender"):
		_update_tender(doc.tender, {"sales_order": doc.name})


def rfq_created(doc, method=None):
	if doc.get("tender") and not frappe.db.get_value("Tender", doc.tender, "rfq"):
		frappe.db.set_value("Tender", doc.tender, "rfq", doc.name, update_modified=False)
