import re

import frappe
from frappe.utils import cint, date_diff, getdate, today

OPEN_STATUSES = ("Identified", "Go/No-Go Review", "Preparing", "Internal Review")
SUBMITTED_STATUSES = ("Submitted", "Under Evaluation")
CLOSED_STATUSES = ("Awarded", "Lost", "Not Bidding", "Cancelled")
NO_PRICE_METHODS = ("Expression of Interest", "Prequalification")

# Order matters: the first pattern that matches wins.
STANDARD_KEY_PATTERNS = (
	("NSSF Clearance", r"\bnssf\b|social security"),
	("URA Tax Clearance", r"tax clearance|\bura\b|tax compliance"),
	("Trading Licence", r"trading licen[cs]e"),
	("PPDA Register of Providers", r"register of providers|ppda reg"),
	("PAU National Supplier Database", r"national supplier database|\bpau\b|\bnsd\b"),
	("Certificate of Incorporation", r"incorporat|certificate of registration|registration certificate|business registration"),
	("Audited Accounts", r"audited|financial statements"),
	("Bank Reference", r"bank (reference|letter)"),
	("UNBS Certification", r"\bunbs\b|q-?mark|s-?mark|product certification"),
	("NEMA Licence", r"\bnema\b"),
	("UNGM Registration", r"\bungm\b"),
)


def get_settings():
	return frappe.get_cached_doc("Tender Settings")


def guess_standard_key(text):
	text = (text or "").lower()
	for key, pattern in STANDARD_KEY_PATTERNS:
		if re.search(pattern, text):
			return key
	return None


def find_credential(company, standard_key):
	if not (company and standard_key):
		return None
	rows = frappe.get_all(
		"Bid Credential",
		filters={"company": company, "standard_key": standard_key},
		fields=["name", "valid_until", "no_expiry"],
		order_by="no_expiry desc, valid_until desc",
		limit=1,
	)
	return rows[0].name if rows else None


def credential_validity(name):
	"""Returns (valid_until, no_expiry)."""
	row = frappe.db.get_value("Bid Credential", name, ["valid_until", "no_expiry"], as_dict=True)
	if not row:
		return None, 0
	return row.valid_until, cint(row.no_expiry)


def reference_validity(doctype, name):
	"""Returns (date, tracked). tracked=False when no date field is configured for this record type."""
	for row in get_settings().validity_sources or []:
		if row.reference_doctype == doctype and row.date_field:
			if frappe.get_meta(doctype).has_field(row.date_field):
				return frappe.db.get_value(doctype, name, row.date_field), True
	return None, False


def credential_status(valid_until, no_expiry, warn_days=30):
	"""Returns (status, days_to_expiry)."""
	if cint(no_expiry):
		return "No Expiry", None
	if not valid_until:
		return "Date Missing", None
	days = date_diff(getdate(valid_until), getdate(today()))
	if days < 0:
		return "Expired", days
	if days <= cint(warn_days):
		return "Expiring Soon", days
	return "Valid", days
from chemical_erp.utils import users_with_role  # noqa: E402,F401  (one shared copy)


def create_todo(user, tender_or_doctype, name, description, date=None, priority="Medium"):
	if not user:
		return None
	todo = frappe.get_doc(
		{
			"doctype": "ToDo",
			"allocated_to": user,
			"reference_type": tender_or_doctype,
			"reference_name": name,
			"description": description,
			"date": date or today(),
			"priority": priority,
			"status": "Open",
		}
	)
	todo.insert(ignore_permissions=True)
	return todo.name


def open_todo_exists(doctype, name, phrase):
	return frappe.db.exists(
		"ToDo",
		{
			"reference_type": doctype,
			"reference_name": name,
			"status": "Open",
			"description": ["like", f"%{phrase}%"],
		},
	)


def notify(users, doctype, name, subject, message=None, priority="Medium", todo=True):
	"""Tell people about something: ToDo + notification bell + (optionally) email.

	`users` may be one user or a list. Disabled users, Guest and Administrator are skipped.
	Never raises: a failed notification must not block the save or the scheduler.
	"""
	if isinstance(users, str):
		users = [users]
	users = [
		u for u in dict.fromkeys(users or [])
		if u and u not in ("Guest", "Administrator") and frappe.db.get_value("User", u, "enabled")
	]
	if not users:
		return
	message = message or subject
	link = frappe.utils.get_url_to_form(doctype, name)
	settings = get_settings()

	for user in users:
		try:
			if todo:
				create_todo(user, doctype, name, message, priority=priority)
			from frappe.desk.doctype.notification_log.notification_log import enqueue_create_notification

			enqueue_create_notification(
				user,
				{
					"type": "Alert",
					"document_type": doctype,
					"document_name": name,
					"subject": subject,
					"email_content": message,
					"from_user": frappe.session.user if frappe.session.user != "Guest" else "Administrator",
				},
			)
			if cint(settings.email_notifications):
				email = frappe.db.get_value("User", user, "email")
				if email:
					frappe.sendmail(
						recipients=[email],
						subject=subject,
						message=f"<p>{frappe.utils.escape_html(message)}</p><p><a href=\"{link}\">Open {frappe.utils.escape_html(name)}</a></p>",
						reference_doctype=doctype,
						reference_name=name,
					)
		except Exception:
			frappe.log_error(title=f"Tender notification to {user} failed", message=frappe.get_traceback())
