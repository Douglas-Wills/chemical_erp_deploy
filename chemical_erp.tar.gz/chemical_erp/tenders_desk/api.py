import frappe
from frappe import _
from frappe.utils import add_days, cint, flt, get_datetime, getdate, nowdate, strip_html

from chemical_erp.tenders_desk.utils import get_settings


def _tender(name, ptype="write"):
	doc = frappe.get_doc("Tender", name)
	doc.check_permission(ptype)
	return doc


def _priced_lines(doc):
	lines = [r for r in doc.cost_lines if r.item_code]
	if not lines:
		frappe.throw(
			_("Add cost lines linked to Items first. Lines without an Item can't be carried into ERPNext documents."),
			title=_("No items to use"),
		)
	return lines


@frappe.whitelist()
def get_tender_defaults():
	s = get_settings()
	return {
		"vat_rate": flt(s.vat_rate),
		"wht_rate": flt(s.wht_rate),
		"bid_validity_days": cint(s.default_bid_validity_days) or 90,
		"default_requirement_template": s.default_requirement_template,
		"enable_ai": cint(s.enable_ai),
	}


@frappe.whitelist()
def create_opportunity(tender):
	doc = _tender(tender)
	if doc.opportunity:
		return doc.opportunity
	if not doc.customer:
		frappe.throw(_("Link the procuring entity to a Customer first."))
	opp = frappe.new_doc("Opportunity")
	opp.opportunity_from = "Customer"
	opp.party_name = doc.customer
	opp.company = doc.company
	opp.currency = doc.currency
	opp.expected_closing = get_datetime(doc.closing_datetime).date() if doc.closing_datetime else None
	opp.opportunity_amount = flt(doc.bid_value_incl_vat)
	opp.tender = doc.name
	opp.insert()
	doc.db_set("opportunity", opp.name)
	return opp.name


@frappe.whitelist()
def create_rfq(tender):
	doc = _tender(tender)
	if doc.rfq:
		return doc.rfq
	lines = _priced_lines(doc)
	needed_by = add_days(get_datetime(doc.closing_datetime).date(), -3) if doc.closing_datetime else add_days(nowdate(), 7)
	if getdate(needed_by) < getdate(nowdate()):
		needed_by = nowdate()
	rfq = frappe.new_doc("Request for Quotation")
	rfq.company = doc.company
	rfq.transaction_date = nowdate()
	rfq.tender = doc.name
	rfq.message_for_supplier = _(
		"Please quote your best price and delivery period for the items below. "
		"This is for tender {0} ({1}). We need your quotation by {2}."
	).format(doc.reference_no or doc.name, doc.tender_title, frappe.utils.formatdate(needed_by))
	for line in lines:
		item = frappe.get_cached_value("Item", line.item_code, ["item_name", "stock_uom", "description"], as_dict=True)
		rfq.append(
			"items",
			{
				"item_code": line.item_code,
				"item_name": item.item_name,
				"description": line.description or item.description or item.item_name,
				"qty": flt(line.qty) or 1,
				"uom": item.stock_uom,
				"stock_uom": item.stock_uom,
				"conversion_factor": 1,
				"schedule_date": add_days(needed_by, 14),
			},
		)
	# Suppliers are chosen by the buyer on the RFQ itself.
	rfq.flags.ignore_mandatory = True
	rfq.insert()
	doc.db_set("rfq", rfq.name)
	return rfq.name


@frappe.whitelist()
def create_quotation(tender):
	doc = _tender(tender)
	if doc.quotation:
		return doc.quotation
	if not doc.customer:
		frappe.throw(_("Link the procuring entity to a Customer first."))
	lines = _priced_lines(doc)
	q = frappe.new_doc("Quotation")
	q.quotation_to = "Customer"
	q.party_name = doc.customer
	q.company = doc.company
	q.currency = doc.currency
	q.transaction_date = nowdate()
	q.valid_till = doc.bid_validity_until or add_days(nowdate(), cint(doc.bid_validity_days) or 90)
	q.order_type = "Sales"
	q.tender = doc.name
	for line in lines:
		q.append(
			"items",
			{"item_code": line.item_code, "qty": flt(line.qty) or 1, "rate": flt(line.unit_price), "description": line.description},
		)
	q.run_method("set_missing_values")
	for row, line in zip(q.items, lines):
		row.rate = flt(line.unit_price)
	q.run_method("calculate_taxes_and_totals")
	q.insert()
	doc.db_set("quotation", q.name)
	return q.name


@frappe.whitelist()
def make_sales_order(source_name, target_doc=None):
	"""Used with frappe.model.open_mapped_doc from the Tender form."""
	doc = _tender(source_name)
	if doc.status != "Awarded":
		frappe.throw(_("Record the award before creating a Sales Order."))
	if not doc.quotation:
		frappe.throw(_("Create and submit the Quotation for this tender first."))
	if frappe.db.get_value("Quotation", doc.quotation, "docstatus") != 1:
		frappe.throw(_("Submit Quotation {0} first, then create the Sales Order.").format(doc.quotation))
	from erpnext.selling.doctype.quotation.quotation import make_sales_order as erpnext_make_sales_order

	so = erpnext_make_sales_order(doc.quotation, target_doc)
	so.tender = doc.name
	return so


@frappe.whitelist()
def create_project(tender):
	doc = _tender(tender)
	if doc.project:
		return doc.project
	if doc.status != "Awarded":
		frappe.throw(_("Record the award before creating a Project."))
	project = frappe.new_doc("Project")
	project.project_name = f"{doc.tender_title[:100]} ({doc.name})"
	project.company = doc.company
	project.customer = doc.customer
	project.sales_order = doc.sales_order
	project.expected_start_date = doc.award_date or nowdate()
	project.estimated_costing = flt(doc.total_landed_cost)
	project.tender = doc.name
	project.insert()
	doc.db_set("project", project.name)
	return project.name


@frappe.whitelist()
def create_tender_from_alert(
	title, procuring_entity=None, reference_no=None, closing_datetime=None, notice_url=None,
	source=None, notice_text=None, category=None, company=None,
):
	"""Entry point for automated tender alerts (REST: /api/method/chemical_erp.tenders_desk.api.create_tender_from_alert).

	Skips duplicates by reference number or notice link and returns the existing tender instead.
	"""
	frappe.has_permission("Tender", "create", throw=True)
	for field, value in (("reference_no", reference_no), ("notice_url", notice_url)):
		if value:
			existing = frappe.db.get_value("Tender", {field: value}, "name")
			if existing:
				return {"name": existing, "created": False}
	doc = frappe.new_doc("Tender")
	doc.tender_title = (title or "")[:140] or _("Untitled tender")
	doc.procuring_entity_name = procuring_entity
	doc.reference_no = reference_no
	doc.notice_url = notice_url
	doc.source = source if source in ("PPDA GPP", "UNGM", "Newspaper", "Direct Invitation", "Email", "Website", "Other") else "Other"
	doc.notice_text = strip_html(notice_text or "")[:100000] or None
	if category and frappe.db.exists("Tender Category", category):
		doc.category = category
	if company:
		doc.company = company
	if closing_datetime:
		try:
			doc.closing_datetime = get_datetime(closing_datetime)
		except Exception:
			pass
	doc.insert()
	return {"name": doc.name, "created": True}


@frappe.whitelist()
def test_claude_connection():
	frappe.only_for(("System Manager", "Tender Manager"))
	from chemical_erp.tenders_desk.ai import call_claude

	reply = call_claude([{"type": "text", "text": "Reply with the single word: connected"}], max_tokens=20)
	return reply.strip()
