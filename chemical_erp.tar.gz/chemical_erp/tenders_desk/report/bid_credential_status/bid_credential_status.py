import frappe
from frappe import _


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = {}
	for field in ("company", "status"):
		if filters.get(field):
			conditions[field] = filters.get(field)
	data = frappe.get_all(
		"Bid Credential",
		filters=conditions,
		fields=["name", "credential_name", "standard_key", "company", "certificate_no", "valid_until",
		        "days_to_expiry", "status", "responsible"],
		order_by="valid_until asc",
	)
	columns = [
		{"label": _("Credential"), "fieldname": "name", "fieldtype": "Link", "options": "Bid Credential", "width": 110},
		{"label": _("Name"), "fieldname": "credential_name", "fieldtype": "Data", "width": 240},
		{"label": _("Standard Document"), "fieldname": "standard_key", "fieldtype": "Data", "width": 190},
		{"label": _("Company"), "fieldname": "company", "fieldtype": "Link", "options": "Company", "width": 170},
		{"label": _("Certificate No."), "fieldname": "certificate_no", "fieldtype": "Data", "width": 130},
		{"label": _("Valid Until"), "fieldname": "valid_until", "fieldtype": "Date", "width": 105},
		{"label": _("Days Left"), "fieldname": "days_to_expiry", "fieldtype": "Int", "width": 85},
		{"label": _("Status"), "fieldname": "status", "fieldtype": "Data", "width": 115},
		{"label": _("Responsible"), "fieldname": "responsible", "fieldtype": "Link", "options": "User", "width": 160},
	]
	return columns, data
