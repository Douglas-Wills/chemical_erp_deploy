frappe.query_reports["Bid Credential Status"] = {
	filters: [
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "status", label: __("Status"), fieldtype: "Select", options: ["", "Valid", "Expiring Soon", "Expired", "No Expiry", "Date Missing"].join("\n") },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "status" && data) {
			const c = { "Expired": "var(--red-600)", "Expiring Soon": "var(--orange-600)", "Valid": "var(--green-600)" }[data.status];
			if (c) value = `<span style="color:${c};font-weight:600">${value}</span>`;
		}
		return value;
	},
};
