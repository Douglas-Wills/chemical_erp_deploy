import frappe
from frappe import _
from frappe.utils import flt

from chemical_erp.tenders_desk.utils import OPEN_STATUSES, SUBMITTED_STATUSES


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = {}
	scope = filters.scope or "Open"
	if scope == "Open":
		conditions["status"] = ["in", OPEN_STATUSES]
	elif scope == "Submitted / Under Evaluation":
		conditions["status"] = ["in", SUBMITTED_STATUSES]
	elif scope == "Open and Submitted":
		conditions["status"] = ["in", OPEN_STATUSES + SUBMITTED_STATUSES]
	for field in ("company", "category", "bid_manager"):
		if filters.get(field):
			conditions[field] = filters.get(field)

	data = frappe.get_all(
		"Tender",
		filters=conditions,
		fields=["name", "tender_title", "procuring_entity_name", "category", "status", "closing_datetime",
		        "days_to_close", "readiness_percent", "ready_to_submit", "bid_security_required",
		        "bid_value_incl_vat", "gross_margin_percent", "bid_manager", "currency"],
		order_by="closing_datetime asc",
	)

	columns = [
		{"label": _("Tender"), "fieldname": "name", "fieldtype": "Link", "options": "Tender", "width": 140},
		{"label": _("Title"), "fieldname": "tender_title", "fieldtype": "Data", "width": 260},
		{"label": _("Procuring Entity"), "fieldname": "procuring_entity_name", "fieldtype": "Data", "width": 180},
		{"label": _("Category"), "fieldname": "category", "fieldtype": "Link", "options": "Tender Category", "width": 150},
		{"label": _("Status"), "fieldname": "status", "fieldtype": "Data", "width": 120},
		{"label": _("Closes"), "fieldname": "closing_datetime", "fieldtype": "Datetime", "width": 150},
		{"label": _("Days Left"), "fieldname": "days_to_close", "fieldtype": "Int", "width": 85},
		{"label": _("Ready %"), "fieldname": "readiness_percent", "fieldtype": "Percent", "width": 85},
		{"label": _("Ready"), "fieldname": "ready_to_submit", "fieldtype": "Check", "width": 65},
		{"label": _("Security"), "fieldname": "bid_security_required", "fieldtype": "Check", "width": 75},
		{"label": _("Bid Value"), "fieldname": "bid_value_incl_vat", "fieldtype": "Currency", "options": "currency", "width": 130},
		{"label": _("Margin %"), "fieldname": "gross_margin_percent", "fieldtype": "Percent", "width": 85},
		{"label": _("Bid Manager"), "fieldname": "bid_manager", "fieldtype": "Link", "options": "User", "width": 150},
	]

	by_status = {}
	for row in data:
		by_status[row.status] = by_status.get(row.status, 0) + 1
	chart = {
		"data": {"labels": list(by_status), "datasets": [{"name": _("Tenders"), "values": list(by_status.values())}]},
		"type": "bar",
	} if by_status else None

	summary = [
		{"label": _("Tenders"), "value": len(data), "indicator": "Blue"},
		{"label": _("Ready to Submit"), "value": sum(1 for r in data if r.ready_to_submit), "indicator": "Green"},
		{"label": _("Closing in 7 Days"), "value": sum(1 for r in data if r.days_to_close is not None and 0 <= r.days_to_close <= 7), "indicator": "Orange"},
		{"label": _("Pipeline Value"), "value": flt(sum(flt(r.bid_value_incl_vat) for r in data), 0), "datatype": "Currency", "indicator": "Blue"},
	]
	return columns, data, None, chart, summary
