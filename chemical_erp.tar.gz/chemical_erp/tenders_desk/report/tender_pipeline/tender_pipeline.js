frappe.query_reports["Tender Pipeline"] = {
	filters: [
		{ fieldname: "scope", label: __("Show"), fieldtype: "Select", options: ["Open", "Submitted / Under Evaluation", "Open and Submitted", "All"].join("\n"), default: "Open" },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "category", label: __("Category"), fieldtype: "Link", options: "Tender Category" },
		{ fieldname: "bid_manager", label: __("Bid Manager"), fieldtype: "Link", options: "User" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "days_to_close" && data && data.days_to_close !== null && data.days_to_close <= 3) {
			value = `<span style="color:var(--red-600);font-weight:600">${value}</span>`;
		}
		return value;
	},
};
