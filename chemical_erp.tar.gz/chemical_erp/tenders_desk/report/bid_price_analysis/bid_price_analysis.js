frappe.query_reports["Bid Price Analysis"] = {
	filters: [
		{ fieldname: "from_date", label: __("Closing From"), fieldtype: "Date", default: frappe.datetime.add_months(frappe.datetime.get_today(), -24) },
		{ fieldname: "to_date", label: __("Closing To"), fieldtype: "Date", default: frappe.datetime.get_today() },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "category", label: __("Category"), fieldtype: "Link", options: "Tender Category" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "price_gap_percent" && data && data.price_gap_percent) {
			const color = data.price_gap_percent > 0 ? "var(--red-600)" : "var(--green-600)";
			value = `<span style="color:${color}">${value}</span>`;
		}
		return value;
	},
};
