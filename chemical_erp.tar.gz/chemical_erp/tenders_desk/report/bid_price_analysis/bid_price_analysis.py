import frappe
from frappe import _
from frappe.utils import add_months, flt, today


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = {
		"status": ["in", ["Awarded", "Lost"]],
		"winning_bid_amount": [">", 0],
		"closing_datetime": ["between", [f"{filters.from_date or add_months(today(), -24)} 00:00:00", f"{filters.to_date or today()} 23:59:59"]],
	}
	for field in ("company", "category"):
		if filters.get(field):
			conditions[field] = filters.get(field)
	data = frappe.get_all(
		"Tender",
		filters=conditions,
		fields=["name", "tender_title", "procuring_entity_name", "category", "status", "closing_datetime",
		        "our_bid_amount", "bid_value_incl_vat", "winning_bid_amount", "winning_bidder",
		        "price_gap_percent", "our_rank", "lost_reason", "gross_margin_percent", "currency"],
		order_by="closing_datetime desc",
	)
	for row in data:
		row.our_bid_amount = flt(row.our_bid_amount) or flt(row.bid_value_incl_vat)

	columns = [
		{"label": _("Tender"), "fieldname": "name", "fieldtype": "Link", "options": "Tender", "width": 140},
		{"label": _("Title"), "fieldname": "tender_title", "fieldtype": "Data", "width": 240},
		{"label": _("Procuring Entity"), "fieldname": "procuring_entity_name", "fieldtype": "Data", "width": 170},
		{"label": _("Result"), "fieldname": "status", "fieldtype": "Data", "width": 85},
		{"label": _("Our Bid"), "fieldname": "our_bid_amount", "fieldtype": "Currency", "options": "currency", "width": 130},
		{"label": _("Winning Bid"), "fieldname": "winning_bid_amount", "fieldtype": "Currency", "options": "currency", "width": 130},
		{"label": _("Winner"), "fieldname": "winning_bidder", "fieldtype": "Link", "options": "Competitor", "width": 150},
		{"label": _("Our Price vs Winner"), "fieldname": "price_gap_percent", "fieldtype": "Percent", "width": 130},
		{"label": _("Our Rank"), "fieldname": "our_rank", "fieldtype": "Int", "width": 80},
		{"label": _("Our Margin %"), "fieldname": "gross_margin_percent", "fieldtype": "Percent", "width": 105},
		{"label": _("Lost Reason"), "fieldname": "lost_reason", "fieldtype": "Link", "options": "Opportunity Lost Reason", "width": 180},
	]

	lost = [r for r in data if r.status == "Lost" and r.price_gap_percent]
	chart = {
		"data": {"labels": [r.name for r in reversed(lost[:20])], "datasets": [{"name": _("% above winner"), "values": [r.price_gap_percent for r in reversed(lost[:20])]}]},
		"type": "bar",
	} if lost else None
	avg_gap = sum(r.price_gap_percent for r in lost) / len(lost) if lost else None
	message = None
	if lost:
		message = _("On lost tenders with a price recorded, we were on average {0:.1f}% {1} the winning bid.").format(
			abs(avg_gap), _("above") if avg_gap > 0 else _("below")
		)
	summary = [
		{"label": _("Tenders with Winning Price"), "value": len(data), "indicator": "Blue"},
		{"label": _("Average Gap on Lost Bids"), "value": f"{avg_gap:+.1f}%" if avg_gap is not None else "–", "indicator": "Orange"},
	]
	return columns, data, message, chart, summary
