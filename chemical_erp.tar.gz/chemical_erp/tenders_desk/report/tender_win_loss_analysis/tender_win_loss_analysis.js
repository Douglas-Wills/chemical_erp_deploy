frappe.query_reports["Tender Win Loss Analysis"] = {
	filters: [
		{ fieldname: "group_by", label: __("Group By"), fieldtype: "Select", options: ["Category", "Procuring Entity", "Procurement Method", "Source", "Bid Manager", "Lost Reason"].join("\n"), default: "Category" },
		{ fieldname: "from_date", label: __("Closing From"), fieldtype: "Date", default: frappe.datetime.add_months(frappe.datetime.get_today(), -12) },
		{ fieldname: "to_date", label: __("Closing To"), fieldtype: "Date", default: frappe.datetime.get_today() },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
	],
};
