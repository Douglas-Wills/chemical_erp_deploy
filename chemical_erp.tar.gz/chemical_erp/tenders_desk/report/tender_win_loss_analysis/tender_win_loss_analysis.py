import frappe
from frappe import _
from frappe.utils import add_months, flt, today

GROUP_FIELDS = {
	"Category": "category",
	"Procuring Entity": "procuring_entity_name",
	"Procurement Method": "procurement_method",
	"Source": "source",
	"Bid Manager": "bid_manager",
	"Lost Reason": "lost_reason",
}
BID_STATUSES = ["Submitted", "Under Evaluation", "Awarded", "Lost", "Cancelled"]


def execute(filters=None):
	filters = frappe._dict(filters or {})
	group_label = filters.group_by or "Category"
	group_field = GROUP_FIELDS.get(group_label, "category")
	from_date = filters.from_date or add_months(today(), -12)
	to_date = filters.to_date or today()

	conditions = {
		"status": ["in", BID_STATUSES],
		"closing_datetime": ["between", [f"{from_date} 00:00:00", f"{to_date} 23:59:59"]],
	}
	if filters.company:
		conditions["company"] = filters.company
	tenders = frappe.get_all(
		"Tender",
		filters=conditions,
		fields=["status", "our_bid_amount", "bid_value_incl_vat", "contract_value", "gross_margin_percent", group_field],
	)

	groups = {}
	for t in tenders:
		key = t.get(group_field) or _("Not set")
		g = groups.setdefault(key, {"group": key, "bids": 0, "won": 0, "lost": 0, "pending": 0, "cancelled": 0,
		                            "value_bid": 0.0, "value_won": 0.0, "margins": []})
		g["bids"] += 1
		amount = flt(t.our_bid_amount) or flt(t.bid_value_incl_vat)
		g["value_bid"] += amount
		if t.status == "Awarded":
			g["won"] += 1
			g["value_won"] += flt(t.contract_value) or amount
		elif t.status == "Lost":
			g["lost"] += 1
		elif t.status == "Cancelled":
			g["cancelled"] += 1
		else:
			g["pending"] += 1
		if flt(t.gross_margin_percent):
			g["margins"].append(flt(t.gross_margin_percent))

	data = []
	for g in sorted(groups.values(), key=lambda x: -x["bids"]):
		decided = g["won"] + g["lost"]
		g["win_rate"] = flt(g["won"] / decided * 100, 1) if decided else None
		g["avg_margin"] = flt(sum(g["margins"]) / len(g["margins"]), 1) if g["margins"] else None
		g.pop("margins")
		data.append(g)

	columns = [
		{"label": _(group_label), "fieldname": "group", "fieldtype": "Data", "width": 220},
		{"label": _("Bids"), "fieldname": "bids", "fieldtype": "Int", "width": 70},
		{"label": _("Won"), "fieldname": "won", "fieldtype": "Int", "width": 70},
		{"label": _("Lost"), "fieldname": "lost", "fieldtype": "Int", "width": 70},
		{"label": _("Awaiting"), "fieldname": "pending", "fieldtype": "Int", "width": 85},
		{"label": _("Cancelled"), "fieldname": "cancelled", "fieldtype": "Int", "width": 85},
		{"label": _("Win Rate"), "fieldname": "win_rate", "fieldtype": "Percent", "width": 90},
		{"label": _("Value Bid"), "fieldname": "value_bid", "fieldtype": "Currency", "width": 140},
		{"label": _("Value Won"), "fieldname": "value_won", "fieldtype": "Currency", "width": 140},
		{"label": _("Avg Margin %"), "fieldname": "avg_margin", "fieldtype": "Percent", "width": 110},
	]

	chart_rows = [d for d in data if d["win_rate"] is not None][:12]
	chart = {
		"data": {"labels": [d["group"] for d in chart_rows], "datasets": [{"name": _("Win rate %"), "values": [d["win_rate"] for d in chart_rows]}]},
		"type": "bar",
		"colors": ["#2A6A4A"],
	} if chart_rows else None

	won = sum(d["won"] for d in data)
	lost = sum(d["lost"] for d in data)
	summary = [
		{"label": _("Bids"), "value": sum(d["bids"] for d in data), "indicator": "Blue"},
		{"label": _("Won"), "value": won, "indicator": "Green"},
		{"label": _("Lost"), "value": lost, "indicator": "Red"},
		{"label": _("Win Rate"), "value": f"{(won / (won + lost) * 100):.1f}%" if won + lost else "–", "indicator": "Blue"},
		{"label": _("Value Won"), "value": sum(d["value_won"] for d in data), "datatype": "Currency", "indicator": "Green"},
	]
	return columns, data, None, chart, summary
