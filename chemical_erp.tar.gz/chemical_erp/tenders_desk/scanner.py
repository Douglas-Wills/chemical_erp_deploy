"""Tender scanner: reads tender sources, scores each notice against the company's scope, and records relevant ones as
Tender Leads for review.

Sources
  PPDA e-GP Portal  egpuganda.go.ug public bid notices (HTML, paged)
  World Bank API    search.worldbank.org/api/v2/procnotices (official, public JSON)
  RSS / Atom Feed   any feed
  Web Page          any page, using CSS selectors set on the source
  Email Inbox       alert emails arriving in the tender inbox: UNGM Tender Alert Service, LinkedIn notifications,
                    newspaper tender alerts and anything else forwarded there. LinkedIn and paid newspaper
                    pages are not read directly: their terms forbid automated reading, so their own alert emails are used.
"""

import hashlib
import re
import xml.etree.ElementTree as ET
from urllib.parse import urljoin

import frappe
from frappe import _
from frappe.utils import add_to_date, cint, getdate, now_datetime, today

UA = "Mozilla/5.0 (compatible; TenderScanner/1.0; +ERPNext)"
MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


# ------------------------------------------------------------------ readiness
def scope_ready(need_enabled=True):
	"""(ready, what is missing). Scanning waits for the company's profile and scope."""
	from chemical_erp.company import default_company

	missing = []
	company = default_company()
	if not company or not frappe.db.exists("Company Profile", company):
		missing.append(_("the Company Profile (company name, address, contacts)"))
	if not frappe.db.exists("Tender Scope Keyword", {"parenttype": "Tender Settings", "parentfield": "scope_keywords", "kind": "Include"}):
		missing.append(_("the company scope: at least one Include keyword in Tender Settings > Tender Scanning"))
	if need_enabled and not frappe.db.get_single_value("Tender Settings", "scan_enabled"):
		missing.append(_("'Scan Automatically' switched on in Tender Settings > Tender Scanning"))
	return not missing, missing


# ------------------------------------------------------------------ scoring
def score(text, keywords, country_terms=None):
	"""(score, matched keywords, mentions_uganda). Keywords: list of (keyword, kind, weight).

	Plurals match too ("coagulant" finds "coagulants"). Each stretch of text counts once, for the longest keyword that
	covers it, so "chemicals" is not scored as both "chemical" and "chemicals"."""
	low = " " + re.sub(r"\s+", " ", (text or "").lower()) + " "
	total, matched, taken = 0, [], []
	for kw, kind, weight in sorted(keywords, key=lambda k: -len((k[0] or "").strip())):
		k = (kw or "").strip().lower()
		if not k:
			continue
		hit = False
		for m in re.finditer(r"(?<![a-z])" + re.escape(k) + r"(?:s|es)?(?![a-z])", low):
			span = (m.start(), m.end())
			if any(span[0] < e and s_ < span[1] for s_, e in taken):
				continue
			taken.append(span)
			hit = True
		if hit:
			total += weight if kind == "Include" else -weight
			matched.append(k if kind == "Include" else f"-{k}")
	uganda = any(re.search(r"(?<![a-z])" + re.escape(t.strip().lower()) + r"(?![a-z])", low) for t in (country_terms or []) if t.strip())
	return total, matched, uganda


def parse_date(text):
	"""Dates as they appear in notices: 'Jan-12 2026', '12 January 2026', '12th Jan, 2026', '12/01/2026', '2026-01-12'."""
	t = (text or "").lower()
	m = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})", t)
	if m:
		return _safe(int(m.group(1)), int(m.group(2)), int(m.group(3)))
	m = re.search(r"\b([a-z]{3})[a-z]*[-\s.](\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})", t)
	if m and m.group(1) in MONTHS:
		return _safe(int(m.group(3)), MONTHS[m.group(1)], int(m.group(2)))
	m = re.search(r"\b(\d{1,2})(?:st|nd|rd|th)?[\s\-]+([a-z]{3})[a-z]*,?[\s\-]+(\d{4})", t)
	if m and m.group(2) in MONTHS:
		return _safe(int(m.group(3)), MONTHS[m.group(2)], int(m.group(1)))
	m = re.search(r"\b(\d{1,2})[/.](\d{1,2})[/.](\d{4})", t)
	if m:  # East African style: day first
		return _safe(int(m.group(3)), int(m.group(2)), int(m.group(1)))
	return None


def _safe(y, mo, d):
	try:
		import datetime

		return datetime.date(y, mo, d)
	except ValueError:
		return None


def closing_from(text):
	"""The closing date: the date after a deadline phrase if present, else none."""
	t = (text or "")
	m = re.search(r"(closing|deadline|submission|bids? (?:must|shall) be delivered|on or before)[^.]{0,80}", t, re.I)
	return parse_date(m.group(0)) if m else None


# ------------------------------------------------------------------ readers: each returns [{title, url, date, text, entity, ref}]
def _get(url, params=None):
	import requests

	r = requests.get(url, params=params, headers={"User-Agent": UA}, timeout=30)
	r.raise_for_status()
	return r


def read_egp(src):
	from bs4 import BeautifulSoup

	items, base = [], src.url or "https://egpuganda.go.ug/"
	for page in range(1, max(cint(src.max_pages), 1) + 1):
		html = _get(base, params={"page": page} if page > 1 else None).text
		soup = BeautifulSoup(html, "html.parser")
		for tr in soup.select("table tr"):
			a = tr.find("a")
			text = tr.get_text(" ", strip=True)
			if not text or (a is None and len(text) < 15):
				continue
			title = (a.get_text(" ", strip=True) if a else text).strip(" .")
			items.append({"title": title, "url": urljoin(base, a["href"]) if a and a.get("href") else base,
			              "date": parse_date(text), "text": text, "entity": None, "ref": None, "truncated": title.endswith("..") or "..." in text})
	return items


def read_worldbank(src):
	_s, kws, _t = _settings()
	terms = [k for k, kind, w in sorted(kws, key=lambda x: -x[2]) if kind == "Include"][:8]
	params = {"format": "json", "rows": 50, "srt": "submission_date", "order": "desc",
	          "qterm": " OR ".join(f'"{t}"' if " " in t else t for t in terms)}
	if src.uganda_only:
		params["countryshortname_exact"] = "Uganda"
	data = _get(src.url or "https://search.worldbank.org/api/v2/procnotices", params=params).json()
	notices = data.get("procnotices") or data.get("documents") or []
	if isinstance(notices, dict):
		notices = list(notices.values())
	items = []
	for n in notices:
		if not isinstance(n, dict):
			continue
		title = n.get("bid_description") or n.get("project_name") or n.get("notice_text", "")[:150]
		nid = n.get("id") or n.get("notice_id")
		text = " ".join(str(n.get(k) or "") for k in ("bid_description", "project_name", "notice_type", "procurement_group",
		                                               "project_ctry_name", "contact_organization", "notice_text"))
		items.append({"title": (title or "World Bank notice").strip(), "ref": n.get("bid_reference_no") or nid,
		              "url": f"https://projects.worldbank.org/en/projects-operations/procurement-detail/{nid}" if nid else src.url,
		              "date": parse_date(str(n.get("noticedate") or n.get("submission_date") or "")),
		              "closing": parse_date(str(n.get("submission_deadline_date") or n.get("deadline_date") or "")),
		              "entity": n.get("contact_organization"), "text": text})
	return items


def read_rss(src):
	root = ET.fromstring(_get(src.url).content)
	items = []
	for node in root.iter():
		tag = node.tag.split("}")[-1]
		if tag not in ("item", "entry"):
			continue
		get = lambda name: next((c for c in node if c.tag.split("}")[-1] == name), None)
		title = (get("title").text if get("title") is not None else "") or ""
		link_el = get("link")
		link = (link_el.get("href") or link_el.text) if link_el is not None else src.url
		desc = get("description") if get("description") is not None else get("summary")
		dt = get("pubDate") if get("pubDate") is not None else get("updated")
		text = re.sub(r"<[^>]+>", " ", (desc.text if desc is not None else "") or "")
		items.append({"title": title.strip(), "url": link, "date": parse_date(dt.text if dt is not None else ""), "text": f"{title} {text}",
		              "entity": None, "ref": None})
	return items


def read_web(src):
	from bs4 import BeautifulSoup

	soup = BeautifulSoup(_get(src.url).text, "html.parser")
	items = []
	for node in soup.select(src.item_selector or "article, li, tr")[:200]:
		t = node.select_one(src.title_selector) if src.title_selector else node
		a = node.select_one(src.link_selector or "a")
		d = node.select_one(src.date_selector) if src.date_selector else node
		title = (t.get_text(" ", strip=True) if t else "")[:250]
		if len(title) < 8:
			continue
		items.append({"title": title, "url": urljoin(src.url, a["href"]) if a and a.get("href") else src.url,
		              "date": parse_date(d.get_text(" ", strip=True) if d else ""), "text": node.get_text(" ", strip=True)[:3000],
		              "entity": None, "ref": None})
	return items


READERS = {"PPDA e-GP Portal": read_egp, "World Bank API": read_worldbank, "RSS / Atom Feed": read_rss, "Web Page": read_web}


# ------------------------------------------------------------------ leads
def _settings():
	s = frappe.get_cached_doc("Tender Settings")
	kws = [(k.keyword, k.kind, cint(k.weight) or 1) for k in s.scope_keywords]
	frappe.local._tender_kw_category = {(k.keyword or "").strip().lower(): k.get("category") for k in s.scope_keywords if k.get("category")}
	terms = [t for t in (s.country_terms or "Uganda").split("\n") if t.strip()]
	return s, kws, terms


def fingerprint(source, item):
	key = (item.get("url") or "") if item.get("url") and item.get("url") != source.url else f"{source.name}|{item.get('title')}"
	return hashlib.sha1(key.lower().encode()).hexdigest()


def detail_text(url):
	"""Full notice text for truncated titles (PPDA lists cut titles short)."""
	from bs4 import BeautifulSoup

	try:
		return BeautifulSoup(_get(url).text, "html.parser").get_text(" ", strip=True)[:4000]
	except Exception:
		return ""


def consider(source, item, settings, keywords, terms, details_left):
	text = f"{item.get('title', '')} {item.get('text', '')}"
	pts, matched, uganda = score(text, keywords, terms)
	if item.get("truncated") and pts > 0 and details_left[0] > 0 and item.get("url"):
		details_left[0] -= 1
		full = detail_text(item["url"])
		if full:
			item["text"] = full
			pts, matched, uganda = score(f"{item['title']} {full}", keywords, terms)
	international = source.channel in ("UN / Development Partners", "World Bank") or source.source_type == "World Bank API"
	if source.uganda_only and international and not uganda and source.source_type != "World Bank API":
		return None
	if pts < cint(settings.min_score):
		return None
	fp = fingerprint(source, item)
	if frappe.db.exists("Tender Lead", {"fingerprint": fp}):
		return None
	cat_points = {}
	for word in matched:
		cat = getattr(frappe.local, "_tender_kw_category", {}).get(word)
		if cat:
			cat_points[cat] = cat_points.get(cat, 0) + next((w for k, kind, w in keywords if k.strip().lower() == word), 1)
	category = max(cat_points, key=cat_points.get) if cat_points else None
	closing = item.get("closing") or closing_from(item.get("text"))
	if closing and getdate(closing) < getdate(today()):
		return None
	lead = frappe.get_doc({"doctype": "Tender Lead", "title": item["title"][:140], "source": source.name, "score": pts,
	                       "matched_keywords": ", ".join(matched), "category": category, "published_on": item.get("date"), "closing_date": closing,
	                       "procuring_entity": item.get("entity"), "reference_no": item.get("ref"), "url": item.get("url"),
	                       "summary": (item.get("text") or "")[:2000], "fingerprint": fp})
	lead.insert(ignore_permissions=True)
	if pts >= cint(settings.alert_score):
		from chemical_erp.utils import notify, users_with_role

		notify(users_with_role(settings.notify_role or "Tender Manager"), "Tender Lead", lead.name,
		       _("Tender lead (score {0}) from {1}: {2}").format(pts, source.name, lead.title), priority="High")
	return lead.name


@frappe.whitelist()
def scan_source(source_name):
	ready, missing = scope_ready(need_enabled=False)
	if not ready:
		return _("Set these up first: {0}.").format("; ".join(missing))
	source = frappe.get_doc("Tender Source", source_name)
	reader = READERS.get(source.source_type)
	if not reader:
		return _("Email sources are read as emails arrive.")
	settings, keywords, terms = _settings()
	try:
		items = reader(source)
	except Exception as e:
		frappe.db.set_value("Tender Source", source.name, {"last_scanned_on": now_datetime(), "last_result": _("Could not read: {0}").format(str(e)[:300])})
		frappe.log_error(title=f"Tender scan failed: {source.name}", message=frappe.get_traceback())
		return _("Could not read {0}: {1}").format(source.name, e)
	details_left = [15]
	made = [n for n in (consider(source, i, settings, keywords, terms, details_left) for i in items) if n]
	msg = _("{0} notices read, {1} new lead(s)").format(len(items), len(made))
	frappe.db.set_value("Tender Source", source.name, {"last_scanned_on": now_datetime(), "last_result": msg,
	                                                  "leads_found": cint(source.leads_found) + len(made)})
	return msg


def run_due_sources():
	"""Hourly: scan each enabled source when its interval has passed."""
	if not scope_ready()[0]:
		return
	for s in frappe.get_all("Tender Source", filters={"enabled": 1, "source_type": ["!=", "Email Inbox"]},
	                        fields=["name", "last_scanned_on", "scan_every_hours"]):
		due = not s.last_scanned_on or s.last_scanned_on <= add_to_date(now_datetime(), hours=-(cint(s.scan_every_hours) or 6))
		if due:
			scan_source(s.name)
			frappe.db.commit()


# ------------------------------------------------------------------ alert emails (LinkedIn, UNGM, newspapers, others)
def from_email(doc, method=None):
	"""Communication received in the tender inbox: read it as a notice from the matching email source."""
	account = frappe.db.get_single_value("Tender Settings", "scan_email_account")
	if not account or doc.get("email_account") != account or doc.get("sent_or_received") != "Received":
		return
	if not scope_ready()[0]:
		return
	sender = (doc.get("sender") or "").lower()
	source = None
	for s in frappe.get_all("Tender Source", filters={"enabled": 1, "source_type": "Email Inbox"}, fields=["name", "sender_contains"]):
		if s.sender_contains and any(part.strip().lower() in sender for part in s.sender_contains.split(",") if part.strip()):
			source = s.name
			break
	source = source or _fallback_email_source()
	src = frappe.get_doc("Tender Source", source)
	settings, keywords, terms = _settings()
	from bs4 import BeautifulSoup

	body = BeautifulSoup(doc.get("content") or "", "html.parser").get_text(" ", strip=True)
	links = re.findall(r"https?://[^\s\"'<>]+", doc.get("content") or "")
	item = {"title": (doc.get("subject") or "Tender alert").strip(), "url": links[0] if links else None,
	        "date": getdate(doc.get("communication_date") or today()), "text": body[:4000], "entity": None, "ref": None}
	name = consider(src, item, settings, keywords, terms, [0])
	if name:
		frappe.db.set_value("Tender Source", src.name, "leads_found", cint(src.leads_found) + 1)


def _fallback_email_source():
	if not frappe.db.exists("Tender Source", "Other Tender Emails"):
		frappe.get_doc({"doctype": "Tender Source", "source_name": "Other Tender Emails", "source_type": "Email Inbox",
		                "channel": "Other", "uganda_only": 0}).insert(ignore_permissions=True)
	return "Other Tender Emails"


# ------------------------------------------------------------------ daily: digest and expiry
def daily():
	for name in frappe.get_all("Tender Lead", filters={"status": ["in", ["New", "Shortlisted"]], "closing_date": ["<", today()]}, pluck="name"):
		frappe.db.set_value("Tender Lead", name, "status", "Expired")
	s = frappe.get_cached_doc("Tender Settings")
	recipients = [r.strip() for r in (s.digest_recipients or "").split("\n") if r.strip()]
	leads = frappe.get_all("Tender Lead", filters={"creation": [">=", add_to_date(now_datetime(), days=-1)], "status": "New"},
	                       fields=["name", "title", "source", "score", "closing_date", "url"], order_by="score desc")
	if not (recipients and leads):
		return
	from chemical_erp.company import company_name

	rows = "".join(f"<tr><td style='padding:4px 8px;border-bottom:1px solid #e5e7eb'><a href='{frappe.utils.get_url()}/app/tender-lead/{l.name}'>"
	               f"{frappe.utils.escape_html(l.title)}</a></td><td style='padding:4px 8px;border-bottom:1px solid #e5e7eb'>{l.source}</td>"
	               f"<td style='padding:4px 8px;border-bottom:1px solid #e5e7eb;text-align:center'>{l.score}</td>"
	               f"<td style='padding:4px 8px;border-bottom:1px solid #e5e7eb'>{l.closing_date or ''}</td></tr>" for l in leads)
	frappe.sendmail(recipients=recipients, subject=_("{0} new tender lead(s) for {1}").format(len(leads), company_name(short=True)),
	                message=f"<div style='font-family:Arial,sans-serif;font-size:10pt'><p>New tenders matching the company's scope "
	                        f"in the last 24 hours:</p><table style='border-collapse:collapse'><tr style='background:#e5e7eb'>"
	                        f"<th style='padding:4px 8px;text-align:left'>Notice</th><th style='padding:4px 8px;text-align:left'>Source</th>"
	                        f"<th style='padding:4px 8px'>Score</th><th style='padding:4px 8px;text-align:left'>Closes</th></tr>{rows}</table></div>")
