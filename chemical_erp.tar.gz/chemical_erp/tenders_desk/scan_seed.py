"""Starting tender sources (Uganda) and optional example scopes.

The company's scope is never loaded automatically: scanning stays off until the company's profile and scope are set.
An example scope can be loaded on purpose from Tender Settings (Tender Scanning) and then edited."""

import frappe

SOURCES = [
	("PPDA e-GP Portal", "PPDA e-GP Portal", "Government (PPDA)", "https://egpuganda.go.ug/", 1, 6, 3, None,
	 "Uganda's electronic Government Procurement portal: public bid notices."),
	("World Bank Procurement Notices", "World Bank API", "World Bank", "https://search.worldbank.org/api/v2/procnotices", 1, 12, 1, None,
	 "Official public World Bank procurement notices data, filtered to Uganda."),
	("UNGM Tender Alert Service", "Email Inbox", "UN / Development Partners", None, 1, 0, 0, "ungm.org",
	 "UNGM has no free feed. Subscribe to the Tender Alert Service (paid) and send its emails to the tender inbox."),
	("LinkedIn Alerts", "Email Inbox", "LinkedIn", None, 1, 0, 0, "linkedin.com",
	 "LinkedIn cannot be read automatically. Follow procuring entities and turn on email notifications to the tender inbox."),
	("New Vision Tenders", "Email Inbox", "Newspaper", None, 1, 0, 0, "newvision.co.ug, visiongroup",
	 "Subscribe to New Vision tender alerts or the e-paper, and forward tender adverts to the tender inbox."),
	("Daily Monitor Tenders", "Email Inbox", "Newspaper", None, 1, 0, 0, "monitor.co.ug, nationmedia",
	 "Subscribe to Daily Monitor tender alerts or the e-paper, and forward tender adverts to the tender inbox."),
	("Client and Agency Websites", "Web Page", "Website", None, 0, 24, 1, None,
	 "Template: copy for each procurement page worth watching (e.g. a water utility, a ministry, an NGO); enter the address and selectors."),
]

CHEMICALS_KEYWORDS = [(k, "Include", 3) for k in (
	"chemical", "chemicals", "water treatment", "boiler", "cooling tower", "chlorine", "hypochlorite", "polyelectrolyte", "flocculant",
	"coagulant", "aluminium sulphate", "alum", "caustic soda", "laboratory reagents", "reagents", "detergent", "disinfectant",
	"sanitiser", "sanitizer", "water testing", "water analysis", "test kit", "water quality")] + \
	[(k, "Include", 2) for k in ("laboratory supplies", "laboratory consumables", "cleaning materials", "cleaning detergents", "fertiliser",
	                             "fertilizer", "dap", "urea", "soap", "swimming pool", "effluent treatment", "scale inhibitor",
	                             "corrosion inhibitor", "oxygen scavenger", "lime", "soda ash", "biocide")] + \
	[(k, "Include", 1) for k in ("supply and delivery", "framework contract", "supplies")] + \
	[(k, "Exclude", 4) for k in ("construction", "civil works", "consultancy", "consultant", "motor vehicle", "vehicles", "ict",
	                             "software", "catering", "security services", "insurance", "audit services", "furniture",
	                             "fuel", "cleaning services", "valuation", "funeral")]


EXCLUDE_COMMON = [(k, "Exclude", 4) for k in ("funeral", "valuation", "motor vehicle", "catering", "insurance")]
# Brave Chemicals' scope as published on its website (27 September 2026): six service lines plus the Brave Home range,
# with polyelectrolyte and fertilisers (DAP, urea) kept in scope at the company's request.
BRAVE_WEBSITE_SCOPE_TEXT = (
	"Ugandan-owned supplier of generic and specialty chemicals including water treatment solutions (boiler, cooling-tower and "
	"chiller programmes with dosing and water testing), industrial chemicals cleaning (plant and tank cleaning, commissioning "
	"spill clean-up, emergency spill response), industrial equipment supply and servicing (pumps, dosing systems, mixers, tanks, "
	"valves, piping, heat exchangers, filtration, instrumentation), chemical laboratory supplies, personal protective equipment "
	"(PPE), and chemicals and safety consultancy. Also distributes industrial gases, solvents and surfactants, and makes the "
	"Brave Home household and institutional cleaning range, and supplies polyelectrolyte and fertilisers (DAP, urea).")
BRAVE_SECTORS_TEXT = "Major projects and remote sites (project owners, EPC contractors, camps); manufacturing; water and utilities; healthcare and laboratories; government and NGOs."
BRAVE_WEBSITE_KEYWORDS = (
	[(k, "Include", 3) for k in (
		# generic and specialty chemicals, water treatment
		"chemicals", "chemical", "water treatment", "boiler water", "boiler chemicals", "cooling tower", "chiller", "sodium hypochlorite",
		"hypochlorite", "chlorine", "caustic soda", "sodium hydroxide", "hydrochloric acid", "sulphuric acid", "sulfuric acid",
		"descaling", "oxygen scavenger", "scale inhibitor", "corrosion inhibitor", "biocide", "disinfectant", "disinfection",
		"polyelectrolyte", "flocculant",
		"water testing", "water analysis", "water quality", "dosing pump", "dosing system", "cip",
		# industrial chemicals cleaning
		"industrial cleaning", "tank cleaning", "chemical spill", "spill response", "spill clean-up",
		# laboratory supplies
		"laboratory reagents", "reagents", "laboratory chemicals", "laboratory glassware", "laboratory consumables", "laboratory equipment",
		# PPE
		"personal protective equipment", "ppe",
		# consultancy
		"chemical safety", "safety audit")] +
	[(k, "Include", 2) for k in (
		# distributed products
		"industrial gases", "carbon dioxide", "oxygen", "propane", "acetone", "ethanol", "methanol", "solvents", "surfactants",
		# polyelectrolyte relatives and fertilisers (kept in scope beyond the website)
		"coagulant", "fertiliser", "fertilisers", "fertilizer", "fertilizers", "dap", "urea", "diammonium phosphate",
		# Brave Home: household and institutional cleaning
		"detergent", "detergents", "bleach", "hand wash", "hand sanitiser", "hand sanitizer", "cleaning materials", "cleaning chemicals",
		"cleaning detergents", "sanitary materials", "janitorial supplies", "toilet cleaner", "dishwashing liquid", "fabric softener",
		# PPE items
		"gloves", "safety goggles", "face shields", "respirators", "coveralls", "chemical resistant clothing", "safety boots", "safety footwear",
		# equipment supply and servicing
		"pumps", "mixers", "agitators", "storage tanks", "process tanks", "valves", "pipes and fittings", "heat exchanger", "filtration",
		"instrumentation", "ph meter", "conductivity meter", "water treatment plant", "sewage treatment", "wastewater treatment",
		"effluent treatment",
		# consultancy
		"risk assessment", "chemical handling", "chemical storage", "msds", "safety data sheet")] +
	[(k, "Include", 1) for k in ("supply and delivery", "framework contract", "supplies", "maintenance and servicing", "camp", "epc")] +
	[(k, "Exclude", 4) for k in (
		"civil works", "building works", "construction of", "road works", "motor vehicle", "vehicles", "ict", "software", "computers",
		"catering", "insurance", "audit of accounts", "external audit", "legal services", "furniture", "stationery", "printing",
		"security services", "fuel supply", "petrol and diesel", "petroleum products", "valuation", "funeral", "consultancy for design",
		"design and supervision")] +
	[(k, "Exclude", 2) for k in ("office cleaning services", "cleaning services", "compound maintenance", "fumigation")]
)
BRAVE_WEBSITE_CATEGORIES = ("Generic and Specialty Chemicals", "Water Treatment", "Industrial Chemicals Cleaning",
                            "Industrial Equipment Supply and Servicing", "Chemical Laboratory Supplies", "PPE Supply",
                            "Chemicals and Safety Consultancy", "Household and Institutional Cleaning (Brave Home)",
                            "Fertilisers and Agro-inputs")

BRAVE_KEYWORD_CATEGORY = {
	"Water Treatment": ("water treatment", "boiler water", "boiler chemicals", "cooling tower", "chiller", "oxygen scavenger", "scale inhibitor",
	                    "corrosion inhibitor", "biocide", "water testing", "water analysis", "water quality", "polyelectrolyte", "flocculant",
	                    "coagulant", "water treatment plant", "sewage treatment", "wastewater treatment", "effluent treatment"),
	"Generic and Specialty Chemicals": ("chemicals", "chemical", "sodium hypochlorite", "hypochlorite", "chlorine", "caustic soda",
	                                    "sodium hydroxide", "hydrochloric acid", "sulphuric acid", "sulfuric acid", "disinfectant", "disinfection",
	                                    "industrial gases", "carbon dioxide", "oxygen", "propane", "acetone", "ethanol", "methanol", "solvents",
	                                    "surfactants", "cip", "descaling"),
	"Industrial Chemicals Cleaning": ("industrial cleaning", "tank cleaning", "chemical spill", "spill response", "spill clean-up"),
	"Industrial Equipment Supply and Servicing": ("dosing pump", "dosing system", "pumps", "mixers", "agitators", "storage tanks", "process tanks",
	                                              "valves", "pipes and fittings", "heat exchanger", "filtration", "instrumentation", "ph meter",
	                                              "conductivity meter", "maintenance and servicing"),
	"Chemical Laboratory Supplies": ("laboratory reagents", "reagents", "laboratory chemicals", "laboratory glassware", "laboratory consumables",
	                                 "laboratory equipment"),
	"PPE Supply": ("personal protective equipment", "ppe", "gloves", "safety goggles", "face shields", "respirators", "coveralls",
	               "chemical resistant clothing", "safety boots", "safety footwear"),
	"Chemicals and Safety Consultancy": ("chemical safety", "safety audit", "risk assessment", "chemical handling", "chemical storage", "msds",
	                                     "safety data sheet"),
	"Household and Institutional Cleaning (Brave Home)": ("detergent", "detergents", "bleach", "hand wash", "hand sanitiser", "hand sanitizer",
	                                                      "cleaning materials", "cleaning chemicals", "cleaning detergents", "sanitary materials",
	                                                      "janitorial supplies", "toilet cleaner", "dishwashing liquid", "fabric softener"),
	"Fertilisers and Agro-inputs": ("fertiliser", "fertilisers", "fertilizer", "fertilizers", "dap", "urea", "diammonium phosphate"),
}


def _category_of(keyword):
	return next((cat for cat, words in BRAVE_KEYWORD_CATEGORY.items() if keyword in words), None)


EXAMPLE_SCOPES = {
	"Brave Chemicals (website 27 Sep 2026, plus fertilisers)": {
		"keywords": BRAVE_WEBSITE_KEYWORDS,
		"categories": BRAVE_WEBSITE_CATEGORIES,
		"scope_text": BRAVE_WEBSITE_SCOPE_TEXT,
		"sectors_text": BRAVE_SECTORS_TEXT,
	},
	"Chemicals and water treatment": {
		"keywords": CHEMICALS_KEYWORDS,
		"categories": ("Generic and Specialty Chemicals", "Water Treatment", "Industrial Chemical Cleaning",
		               "Industrial Equipment Supply and Servicing", "Laboratory Supplies", "PPE Supply", "Chemicals and Safety Consultancy"),
	},
	"Civil works and design": {
		"keywords": [(k, "Include", 3) for k in ("construction", "civil works", "rehabilitation", "building works", "roads",
		                                         "drainage", "design and supervision", "structural design")] +
		            [(k, "Include", 2) for k in ("renovation", "boundary wall", "water supply system", "borehole", "culvert")] +
		            [(k, "Exclude", 4) for k in ("supply of chemicals", "software", "catering", "insurance", "motor vehicle")],
		"categories": ("Building Works", "Roads and Drainage", "Design and Supervision"),
	},
	"General supplies (starting point)": {
		"keywords": [(k, "Include", 2) for k in ("supply and delivery", "framework contract", "supplies")] + EXCLUDE_COMMON,
		"categories": (),
	},
}


def ensure_tender_scan():
	for name, stype, channel, url, enabled, every, pages, sender, notes in SOURCES:
		if not frappe.db.exists("Tender Source", name):
			frappe.get_doc({"doctype": "Tender Source", "source_name": name, "source_type": stype, "channel": channel, "url": url,
			                "enabled": enabled, "scan_every_hours": every or 6, "max_pages": pages or 1, "sender_contains": sender,
			                "uganda_only": 1, "notes": notes}).insert(ignore_permissions=True)
	if not frappe.db.get_single_value("Tender Settings", "min_score"):
		s = frappe.get_single("Tender Settings")
		s.scan_enabled, s.min_score, s.alert_score = 0, 3, 6  # off until the company's scope is set
		s.flags.ignore_permissions = True
		s.save()


@frappe.whitelist()
def load_example_scope(scope, skip_role_check=False):
	"""Add an example scope's keywords (and its tender categories) to the settings, to edit for the company."""
	if not skip_role_check:
		frappe.only_for(("System Manager", "Managing Director", "Tender Manager"))
	ex = EXAMPLE_SCOPES.get(scope)
	if not ex:
		frappe.throw(frappe._("Unknown example scope."))
	for c in ex["categories"]:  # categories first: keywords link to them
		if not frappe.db.exists("Tender Category", c):
			frappe.get_doc({"doctype": "Tender Category", "category_name": c}).insert(ignore_permissions=True)
	s = frappe.get_single("Tender Settings")
	have = {(k.keyword or "").lower() for k in s.scope_keywords}
	for k, kind, w in ex["keywords"]:
		if k.lower() not in have:
			cat = _category_of(k) if kind == "Include" and scope.startswith("Brave") else None
			s.append("scope_keywords", {"keyword": k, "kind": kind, "weight": w,
			                      "category": cat if cat and frappe.db.exists("Tender Category", cat) else None})
	s.flags.ignore_permissions = True
	s.save()
	if ex.get("scope_text"):  # record the scope on the Company Profile if it has none yet
		from chemical_erp.company import default_company

		company = default_company()
		if company and frappe.db.exists("Company Profile", company):
			if not frappe.db.get_value("Company Profile", company, "scope_of_work"):
				frappe.db.set_value("Company Profile", company, {"scope_of_work": ex["scope_text"], "sectors_served": ex.get("sectors_text")})
	return len(s.scope_keywords)
