"""Idempotent setup. Runs after install and after every migrate; never overwrites records you have edited."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

ROLES = ("Tender Manager", "Tender User")

LINKED_DOCTYPES = {
	"Opportunity": "party_name",
	"Request for Quotation": "transaction_date",
	"Supplier Quotation": "supplier",
	"Quotation": "party_name",
	"Sales Order": "customer",
	"Project": "project_name",
	"Bank Guarantee": "bg_type",
}

CATEGORIES = (  # neutral, PPDA procurement types; company-specific categories come with the company's scope
	"Supplies (Goods)",
	"Works",
	"Non-consultancy Services",
	"Consultancy Services",
	"Framework Agreements",
)

LOST_REASONS = (
	"Price higher than winner",
	"Technically non-responsive",
	"Missing or expired document",
	"Late or incomplete submission",
	"Experience or capacity not enough",
	"Tender cancelled by entity",
	"Reason not disclosed",
)

A, T, FI, C = "Administrative", "Technical", "Financial", "Commercial"
TEMPLATES = {
	"Open Bidding - Goods (PPDA)": [
		("Bid submission sheet, signed and stamped", A, 1, ""),
		("Price schedule", C, 1, ""),
		("Certificate of incorporation", A, 1, "Certificate of Incorporation"),
		("Trading licence (current)", A, 1, "Trading Licence"),
		("URA tax clearance certificate", A, 1, "URA Tax Clearance"),
		("NSSF clearance certificate", A, 1, "NSSF Clearance"),
		("PPDA register of providers certificate", A, 0, "PPDA Register of Providers"),
		("Power of attorney for the signatory", A, 1, ""),
		("Statement of compliance with technical specifications", T, 1, ""),
		("Evidence of similar supplies (contracts, LPOs, completion certificates)", T, 1, ""),
		("Manufacturer's authorisation", T, 0, ""),
		("Product data sheets / safety data sheets", T, 0, ""),
		("Audited accounts", FI, 1, "Audited Accounts"),
		("Bank reference letter", FI, 0, "Bank Reference"),
		("Delivery schedule", C, 1, ""),
		("Signed code of ethical conduct for bidders", A, 1, ""),
	],
	"Request for Quotations": [
		("Signed quotation / price schedule", C, 1, ""),
		("Certificate of incorporation", A, 1, "Certificate of Incorporation"),
		("Trading licence (current)", A, 1, "Trading Licence"),
		("URA tax clearance certificate", A, 1, "URA Tax Clearance"),
		("NSSF clearance certificate", A, 0, "NSSF Clearance"),
		("Statement of compliance with specifications", T, 1, ""),
		("Delivery period", C, 1, ""),
	],
	"Expression of Interest / Prequalification": [
		("Letter of interest, signed", A, 1, ""),
		("Company profile and capability statement", T, 1, ""),
		("Certificate of incorporation", A, 1, "Certificate of Incorporation"),
		("Trading licence (current)", A, 1, "Trading Licence"),
		("URA tax clearance certificate", A, 1, "URA Tax Clearance"),
		("NSSF clearance certificate", A, 1, "NSSF Clearance"),
		("Evidence of similar assignments or supplies", T, 1, ""),
		("CVs of key staff", T, 0, ""),
		("Audited accounts", FI, 0, "Audited Accounts"),
		("Joint venture or subcontract agreement", A, 0, ""),
		("HSE policy and certifications", T, 0, ""),
	],
	"Oil & Gas Supplier Prequalification": [
		("National Supplier Database registration (PAU)", A, 1, "PAU National Supplier Database"),
		("Company profile and capability statement", T, 1, ""),
		("Certificate of incorporation", A, 1, "Certificate of Incorporation"),
		("Trading licence (current)", A, 1, "Trading Licence"),
		("URA tax clearance certificate", A, 1, "URA Tax Clearance"),
		("NSSF clearance certificate", A, 1, "NSSF Clearance"),
		("HSE policy, statistics and certifications", T, 1, ""),
		("Quality management certification", T, 0, ""),
		("Local content plan", C, 1, ""),
		("Evidence of similar supplies to industrial or remote sites", T, 1, ""),
		("Joint venture agreement", A, 0, ""),
		("Audited accounts", FI, 1, "Audited Accounts"),
	],
}

STATES = (
	("Identified", "Primary"),
	("Go/No-Go Review", "Warning"),
	("Preparing", "Info"),
	("Internal Review", "Warning"),
	("Submitted", "Primary"),
	("Under Evaluation", "Info"),
	("Awarded", "Success"),
	("Lost", "Danger"),
	("Not Bidding", "Inverse"),
	("Cancelled", "Inverse"),
)

M, U = "Tender Manager", "Tender User"
TRANSITIONS = (
	("Identified", "Send for Go/No-Go", "Go/No-Go Review", U, None),
	("Identified", "Decline", "Not Bidding", M, None),
	("Go/No-Go Review", "Approve Bid", "Preparing", M, 'doc.go_decision == "Go"'),
	("Go/No-Go Review", "Decline", "Not Bidding", M, None),
	("Preparing", "Send for Review", "Internal Review", U, None),
	("Preparing", "Withdraw", "Not Bidding", M, None),
	("Internal Review", "Return for Changes", "Preparing", M, None),
	("Internal Review", "Mark Submitted", "Submitted", M, "doc.ready_to_submit or doc.override_readiness"),
	("Submitted", "Bids Opened", "Under Evaluation", U, None),
	("Submitted", "Record Award", "Awarded", M, None),
	("Submitted", "Record Loss", "Lost", U, None),
	("Submitted", "Tender Cancelled", "Cancelled", M, None),
	("Under Evaluation", "Record Award", "Awarded", M, None),
	("Under Evaluation", "Record Loss", "Lost", U, None),
	("Under Evaluation", "Tender Cancelled", "Cancelled", M, None),
	("Not Bidding", "Reopen", "Identified", M, None),
)


def ensure_setup(first_install=False):
	ensure_roles()
	ensure_custom_fields()
	ensure_masters()
	ensure_workflow()
	if first_install or not frappe.db.get_single_value("Tender Settings", "reminder_days"):
		# Only on first setup, so values you deliberately set to 0 are never reset.
		ensure_settings()
	frappe.db.commit()


def ensure_roles():
	for role in ROLES:
		if not frappe.db.exists("Role", role):
			frappe.get_doc({"doctype": "Role", "role_name": role, "desk_access": 1}).insert(ignore_permissions=True)


def ensure_custom_fields():
	fields = {}
	for doctype, insert_after in LINKED_DOCTYPES.items():
		if not frappe.db.exists("DocType", doctype):
			continue
		if not frappe.get_meta(doctype).has_field(insert_after):
			insert_after = None
		field = {"fieldname": "tender", "label": "Tender", "fieldtype": "Link", "options": "Tender", "in_standard_filter": 1}
		if insert_after:
			field["insert_after"] = insert_after
		fields[doctype] = [field]
	create_custom_fields(fields, update=True)


def ensure_masters():
	for name in CATEGORIES:
		if not frappe.db.exists("Tender Category", name):
			frappe.get_doc({"doctype": "Tender Category", "category_name": name}).insert(ignore_permissions=True)
	for reason in LOST_REASONS:
		if not frappe.db.exists("Opportunity Lost Reason", reason):
			frappe.get_doc({"doctype": "Opportunity Lost Reason", "lost_reason": reason}).insert(ignore_permissions=True)
	for template, items in TEMPLATES.items():
		if frappe.db.exists("Tender Requirement Template", template):
			continue
		frappe.get_doc(
			{
				"doctype": "Tender Requirement Template",
				"template_name": template,
				"items": [
					{"requirement": r, "requirement_type": t, "mandatory": m, "standard_key": k} for r, t, m, k in items
				],
			}
		).insert(ignore_permissions=True)


def ensure_workflow():
	for state, style in STATES:
		if not frappe.db.exists("Workflow State", state):
			frappe.get_doc({"doctype": "Workflow State", "workflow_state_name": state, "style": style}).insert(
				ignore_permissions=True
			)
	for action in {t[1] for t in TRANSITIONS}:
		if not frappe.db.exists("Workflow Action Master", action):
			frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": action}).insert(
				ignore_permissions=True
			)
	if frappe.db.exists("Workflow", "Tender Workflow"):
		return
	frappe.get_doc(
		{
			"doctype": "Workflow",
			"workflow_name": "Tender Workflow",
			"document_type": "Tender",
			"workflow_state_field": "status",
			"is_active": 1,
			"send_email_alert": 0,
			"states": [{"state": s, "doc_status": "0", "allow_edit": U} for s, _style in STATES],
			"transitions": [
				{"state": s, "action": a, "next_state": n, "allowed": r, "allow_self_approval": 1, "condition": c}
				for s, a, n, r, c in TRANSITIONS
			],
		}
	).insert(ignore_permissions=True)


def ensure_settings():
	settings = frappe.get_single("Tender Settings")
	changed = False
	defaults = {
		"vat_rate": 18,
		"wht_rate": 6,
		"default_bid_validity_days": 90,
		"bid_security_margin_days": 28,
		"reminder_days": "7,3,1",
		"credential_warning_days": 30,
		"digest_role": "Tender Manager",
		"send_weekly_digest": 1,
		"claude_model": "claude-sonnet-5-5",
		"default_requirement_template": "Open Bidding - Goods (PPDA)",
	}
	for field, value in defaults.items():
		if settings.get(field) in (None, ""):
			settings.set(field, value)
			changed = True
	if settings.is_new() or changed:
		settings.flags.ignore_permissions = True
		settings.save()
