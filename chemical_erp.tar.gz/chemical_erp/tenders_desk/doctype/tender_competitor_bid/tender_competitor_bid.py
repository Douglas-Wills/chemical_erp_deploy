from frappe.model.document import Document


class TenderCompetitorBid(Document):
	pass
