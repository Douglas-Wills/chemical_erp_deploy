frappe.listview_settings["Bid Credential"] = {
	add_fields: ["status", "valid_until"],
	get_indicator(doc) {
		const colors = { "Valid": "green", "Expiring Soon": "orange", "Expired": "red", "No Expiry": "blue", "Date Missing": "gray" };
		return [__(doc.status || "Date Missing"), colors[doc.status] || "gray", "status,=," + (doc.status || "")];
	},
};
