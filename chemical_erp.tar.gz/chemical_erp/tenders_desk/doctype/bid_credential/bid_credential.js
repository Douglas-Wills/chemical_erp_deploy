frappe.ui.form.on("Bid Credential", {
	refresh(frm) {
		if (frm.is_new()) return;
		frm.add_custom_button(__("Tenders Using This"), () => {
			frappe.route_options = { "Tender Requirement.credential": frm.doc.name };
			frappe.set_route("List", "Tender");
		});
	},
	no_expiry(frm) {
		if (frm.doc.no_expiry) frm.set_value("valid_until", null);
	},
});
