import frappe
from frappe.model.document import Document
from frappe.utils import cint

from chemical_erp.tenders_desk.utils import credential_status, get_settings, guess_standard_key


class BidCredential(Document):
	def validate(self):
		if cint(self.no_expiry):
			self.valid_until = None
		if not self.standard_key:
			self.standard_key = guess_standard_key(self.credential_name) or ""
		self.set_status()

	def set_status(self):
		warn_days = cint(get_settings().credential_warning_days) or 30
		self.status, self.days_to_expiry = credential_status(self.valid_until, self.no_expiry, warn_days)

	def on_update(self):
		# Re-check readiness of open tenders that rely on this credential
		before = self.get_doc_before_save()
		if before and before.valid_until == self.valid_until and before.no_expiry == self.no_expiry:
			return
		frappe.enqueue(
			"chemical_erp.tenders_desk.tasks.refresh_tenders_for_credential",
			credential=self.name,
			enqueue_after_commit=True,
		)
