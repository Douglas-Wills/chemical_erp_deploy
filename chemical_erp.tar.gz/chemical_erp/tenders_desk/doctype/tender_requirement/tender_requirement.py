from frappe.model.document import Document


class TenderRequirement(Document):
	pass
