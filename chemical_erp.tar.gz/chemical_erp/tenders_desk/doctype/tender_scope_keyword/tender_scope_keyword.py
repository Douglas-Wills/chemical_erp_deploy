from frappe.model.document import Document


class TenderScopeKeyword(Document):
	pass
