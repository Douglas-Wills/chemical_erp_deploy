from frappe.model.document import Document


class TenderCostLine(Document):
	pass
