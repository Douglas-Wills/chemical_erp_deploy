import frappe
from frappe.model.document import Document
from frappe.utils import getdate, today


class BidSample(Document):
	def validate(self):
		if self.tender:
			t = frappe.db.get_value("Tender", self.tender, ["category", "procuring_entity_name", "status"], as_dict=True) or {}
			self.category = self.category or t.get("category")
			self.procuring_entity = self.procuring_entity or t.get("procuring_entity_name")
			if self.outcome == "Not Known" and t.get("status") in ("Awarded", "Lost"):
				self.outcome = "Won" if t.get("status") == "Awarded" else "Lost"
		self.year = self.year or getdate(today()).year
		self.sections_approved = frappe.db.count("Bid Library Block", {"source_sample": self.name, "approved": 1}) if not self.is_new() else 0

	def after_insert(self):
		from chemical_erp.tenders_desk.bid_learning import learn

		learn(self.name)

	@frappe.whitelist()
	def learn_again(self):
		from chemical_erp.tenders_desk.bid_learning import learn

		return learn(self.name)
