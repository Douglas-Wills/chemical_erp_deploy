frappe.ui.form.on("Bid Sample", {
	refresh(frm) {
		if (frm.is_new()) return;
		frm.add_custom_button(__("Review Learned Sections"), () => frappe.set_route("List", "Bid Library Block", { source_sample: frm.doc.name }));
		frm.add_custom_button(__("Learn Again"), () => frm.call({ doc: frm.doc, method: "learn_again", freeze: true })
			.then((r) => { frappe.show_alert({ message: __("{0} new section(s) learned", [r.message || 0]), indicator: "green" }); frm.reload_doc(); }));
		frm.dashboard.set_headline_alert(__("{0} section(s) learned, {1} approved for reuse", [frm.doc.sections_found || 0, frm.doc.sections_approved || 0]),
			frm.doc.sections_approved ? "green" : "orange");
	},
});
