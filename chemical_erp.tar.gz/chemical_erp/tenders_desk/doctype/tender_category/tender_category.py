from frappe.model.document import Document


class TenderCategory(Document):
	pass
