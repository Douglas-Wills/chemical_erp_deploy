import frappe
from frappe.model.document import Document

SOURCE_MAP = {"Government (PPDA)": "PPDA GPP", "UN / Development Partners": "UNGM", "World Bank": "Website", "Newspaper": "Newspaper",
              "LinkedIn": "Email", "Website": "Website"}


class TenderLead(Document):
	def validate(self):
		before = self.get_doc_before_save()
		if before and before.status != self.status and self.status in ("Not Relevant", "Shortlisted", "Duplicate"):
			self.reviewed_by = frappe.session.user

	@frappe.whitelist()
	def convert_to_tender(self):
		if self.tender:
			return self.tender
		from chemical_erp.company import default_company

		t = frappe.get_doc({"doctype": "Tender", "tender_title": self.title, "status": "Identified", "company": default_company(),
		                    "reference_no": self.reference_no, "procuring_entity_name": self.procuring_entity,
		                    "source": SOURCE_MAP.get(self.channel, "Other"), "notice_url": self.url, "published_on": self.published_on,
		                    "category": self.category,
		                    "closing_datetime": f"{self.closing_date} 10:00:00" if self.closing_date else None})
		t.insert()
		self.db_set({"tender": t.name, "status": "Converted", "reviewed_by": frappe.session.user})
		return t.name
