frappe.ui.form.on("Tender Lead", {
	refresh(frm) {
		if (frm.is_new()) return;
		if (frm.doc.url) frm.add_custom_button(__("Open Notice"), () => window.open(frm.doc.url, "_blank"));
		if (!frm.doc.tender && !["Not Relevant", "Duplicate", "Expired"].includes(frm.doc.status)) {
			frm.add_custom_button(__("Convert to Tender"), () => frm.call({ doc: frm.doc, method: "convert_to_tender" })
				.then((r) => frappe.set_route("Form", "Tender", r.message))).addClass("btn-primary");
			frm.add_custom_button(__("Not Relevant"), () => { frm.set_value("status", "Not Relevant"); frm.save(); });
		}
		if (frm.doc.matched_keywords) frm.dashboard.set_headline_alert(__("Score {0}: {1}", [frm.doc.score, frm.doc.matched_keywords]), "blue");
	},
});
