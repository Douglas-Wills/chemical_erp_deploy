from frappe.model.document import Document


class TenderRequirementTemplate(Document):
	pass
