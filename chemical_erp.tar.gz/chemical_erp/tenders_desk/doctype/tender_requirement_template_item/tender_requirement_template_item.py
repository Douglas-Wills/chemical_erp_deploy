from frappe.model.document import Document


class TenderRequirementTemplateItem(Document):
	pass
