frappe.views.calendar["Tender"] = {
	field_map: {
		start: "closing_datetime",
		end: "closing_datetime",
		id: "name",
		title: "tender_title",
		status: "status",
	},
	style_map: {
		"Identified": "info", "Go/No-Go Review": "warning", "Preparing": "info", "Internal Review": "warning",
		"Submitted": "default", "Under Evaluation": "default", "Awarded": "success", "Lost": "danger",
	},
	filters: [
		{ fieldtype: "Link", fieldname: "company", options: "Company", label: __("Company") },
		{ fieldtype: "Link", fieldname: "category", options: "Tender Category", label: __("Category") },
	],
	get_events_method: "frappe.desk.calendar.get_events",
};
