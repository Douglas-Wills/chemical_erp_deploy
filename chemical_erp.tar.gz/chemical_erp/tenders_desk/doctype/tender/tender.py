import re
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import (
	add_days,
	cint,
	date_diff,
	flt,
	format_datetime,
	formatdate,
	get_datetime,
	getdate,
	now_datetime,
	today,
)

from chemical_erp.tenders_desk.utils import (
	NO_PRICE_METHODS,
	OPEN_STATUSES,
	credential_validity,
	find_credential,
	get_settings,
	guess_standard_key,
	notify,
	reference_validity,
)

BLOCKING_VALIDITY = ("Expired", "Expires before closing", "Expiry date missing")


class Tender(Document):
	def validate(self):
		self.set_defaults()
		self.set_dates()
		self.set_go_decision()
		self.calculate_costing()
		self.refresh_requirements()
		self.evaluate_readiness()
		self.validate_status_change()
		self.set_outcome_fields()

	def on_update(self):
		self.notify_people()

	def notify_people(self):
		"""Tell people when they are given work on this tender or its status changes."""
		if self.flags.in_import or frappe.flags.in_install:
			return
		me = frappe.session.user
		before = self.get_doc_before_save()
		closes = format_datetime(self.closing_datetime, "d MMM yyyy, HH:mm") if self.closing_datetime else _("date not set")

		# New or changed bid manager
		if self.bid_manager and self.bid_manager != me and (not before or before.bid_manager != self.bid_manager):
			notify(
				self.bid_manager, "Tender", self.name,
				subject=_("You are bid manager for {0}").format(self.tender_title),
				message=_("You have been made bid manager for {0} ({1}). It closes {2}. Status: {3}.").format(
					self.tender_title, self.procuring_entity_name or _("procuring entity not set"), closes, self.status
				),
			)

		# Newly assigned checklist items, grouped per officer
		previous = {r.name: r.responsible for r in (before.requirements if before else [])}
		new_items = {}
		for row in self.requirements:
			if row.responsible and row.responsible != me and not cint(row.done) and previous.get(row.name) != row.responsible:
				new_items.setdefault(row.responsible, []).append(row.requirement)
		for user, items in new_items.items():
			notify(
				user, "Tender", self.name,
				subject=_("Tender items assigned to you: {0}").format(self.tender_title),
				message=_("You are responsible for these items on {0}, which closes {1}: {2}. Tick each one as Ready on the tender when done.").format(
					self.tender_title, closes, "; ".join(items)
				),
			)

		# Status change made by someone other than the bid manager
		if before and before.status != self.status and self.bid_manager and self.bid_manager != me:
			notify(
				self.bid_manager, "Tender", self.name,
				subject=_("{0}: now {1}").format(self.tender_title, self.status),
				message=_("{0} moved {1} from {2} to {3}.").format(
					frappe.utils.get_fullname(me), self.tender_title, before.status, self.status
				),
				todo=False,
			)

	def after_insert(self):
		# Created by an incoming email (Email Account "Append To: Tender")
		if self.intake_sender:
			settings = get_settings()
			if cint(settings.enable_ai) and cint(settings.auto_extract_on_email):
				frappe.enqueue(
					"chemical_erp.tenders_desk.ai.process_email_intake",
					tender=self.name,
					queue="long",
					enqueue_after_commit=True,
				)

	# ------------------------------------------------------------------ defaults & dates
	def set_defaults(self):
		settings = get_settings()
		if not self.company:
			self.company = frappe.defaults.get_user_default("Company") or frappe.db.get_single_value(
				"Global Defaults", "default_company"
			)
		if not self.currency and self.company:
			self.currency = frappe.get_cached_value("Company", self.company, "default_currency")
		base = frappe.get_cached_value("Company", self.company, "default_currency") if self.company else None
		if self.currency and base and self.currency != base and not flt(self.exchange_rate):
			from chemical_erp.utils import exchange_rate

			self.exchange_rate = exchange_rate(self.currency, base)
		elif self.currency == base:
			self.exchange_rate = 1
		if not cint(self.bid_validity_days):
			self.bid_validity_days = cint(settings.default_bid_validity_days) or 90
		if self.vat_rate is None:
			self.vat_rate = flt(settings.vat_rate)
		if self.wht_rate is None:
			self.wht_rate = flt(settings.wht_rate)
		if self.customer and not self.procuring_entity_name:
			self.procuring_entity_name = frappe.db.get_value("Customer", self.customer, "customer_name")
		if self.is_new() and not self.requirements:
			template = self.requirement_template or settings.default_requirement_template
			if template and frappe.db.exists("Tender Requirement Template", template):
				self.load_template(template)

	def set_dates(self):
		if self.closing_datetime:
			closing = get_datetime(self.closing_datetime)
			self.bid_validity_until = add_days(closing.date(), cint(self.bid_validity_days))
			self.days_to_close = date_diff(closing.date(), getdate(today()))
		else:
			self.bid_validity_until = None
			self.days_to_close = None

	def set_go_decision(self):
		ratings = []
		for field in ("strategic_fit", "capacity_to_deliver", "price_competitiveness", "compliance_readiness"):
			value = flt(self.get(field))
			if value:
				# Rating is stored as 0-1 in v14+; older sites store 0-5.
				ratings.append(value / 5 if value > 1 else value)
		self.go_score = flt(sum(ratings) / len(ratings) * 100, 1) if ratings else 0

		before = self.get_doc_before_save()
		if self.go_decision and (not before or before.go_decision != self.go_decision):
			self.decision_by = frappe.session.user
			self.decision_date = today()
		if not self.go_decision:
			self.decision_by = None
			self.decision_date = None

	# ------------------------------------------------------------------ costing
	def calculate_costing(self):
		total_cost = 0.0
		value = 0.0
		for row in self.cost_lines:
			qty = flt(row.qty)
			landed = flt(row.unit_cost) * (1 + flt(row.duty_percent) / 100) + flt(row.logistics_per_unit)
			row.landed_unit_cost = flt(landed, 2)
			if not flt(row.unit_price) and flt(row.markup_percent):
				row.unit_price = flt(landed * (1 + flt(row.markup_percent) / 100), 2)
			row.line_cost = flt(landed * qty, 2)
			row.line_value = flt(flt(row.unit_price) * qty, 2)
			total_cost += row.line_cost
			value += row.line_value

		self.total_landed_cost = flt(total_cost, 2)
		self.bid_value = flt(value, 2)
		self.bid_value_company_currency = flt(value * (flt(self.exchange_rate) or 1), 2)
		self.vat_amount = flt(value * flt(self.vat_rate) / 100, 2)
		self.bid_value_incl_vat = flt(value + self.vat_amount, 2)
		self.gross_margin = flt(value - total_cost - flt(self.other_bid_costs), 2)
		self.gross_margin_percent = flt(self.gross_margin / value * 100, 2) if value else 0
		self.wht_amount = flt(value * flt(self.wht_rate) / 100, 2) if cint(self.wht_applicable) else 0
		self.cash_after_wht = flt(self.bid_value_incl_vat - self.wht_amount, 2)

	@frappe.whitelist()
	def pull_supplier_prices(self):
		"""Fill unit costs from the cheapest supplier quotation per item (company currency)."""
		parents = set(
			frappe.get_all("Supplier Quotation", filters={"tender": self.name, "docstatus": ["<", 2]}, pluck="name")
		)
		if self.rfq:
			parents.update(
				frappe.db.sql_list(
					"""select distinct parent from `tabSupplier Quotation Item`
					where request_for_quotation=%s and docstatus < 2""",
					self.rfq,
				)
			)
		if not parents:
			frappe.throw(_("No supplier quotations are linked to this tender or its Request for Quotation yet."))

		rows = frappe.db.sql(
			"""select parent, item_code, base_rate, conversion_factor
			from `tabSupplier Quotation Item` where parent in %(parents)s""",
			{"parents": tuple(parents)},
			as_dict=True,
		)
		best = {}
		for r in rows:
			# quotations are read in company currency; the bid is priced in the tender currency
			unit = flt(r.base_rate) / (flt(r.conversion_factor) or 1) / (flt(self.exchange_rate) or 1)
			if unit and (r.item_code not in best or unit < best[r.item_code][0]):
				best[r.item_code] = (unit, r.parent)

		updated = 0
		for line in self.cost_lines:
			if line.item_code in best:
				line.unit_cost, line.supplier_quotation = flt(best[line.item_code][0], 2), best[line.item_code][1]
				updated += 1
		self.calculate_costing()
		return updated

	# ------------------------------------------------------------------ requirements & readiness
	@frappe.whitelist()
	def load_template(self, template=None):
		template = template or self.requirement_template
		if not template:
			frappe.throw(_("Choose a requirement template first."))
		self.requirement_template = template
		existing = {(r.requirement or "").strip().lower() for r in self.requirements}
		added = 0
		for item in frappe.get_doc("Tender Requirement Template", template).items:
			if (item.requirement or "").strip().lower() in existing:
				continue
			self.append(
				"requirements",
				{
					"requirement": item.requirement,
					"requirement_type": item.requirement_type,
					"mandatory": item.mandatory,
					"standard_key": item.standard_key,
				},
			)
			added += 1
		self.refresh_requirements()
		return added

	def refresh_requirements(self):
		closing = get_datetime(self.closing_datetime).date() if self.closing_datetime else None
		validity_end = getdate(self.bid_validity_until) if self.bid_validity_until else None
		for row in self.requirements:
			if not row.standard_key:
				row.standard_key = guess_standard_key(row.requirement) or ""
			if not row.credential and row.standard_key and self.company:
				row.credential = find_credential(self.company, row.standard_key)

			valid_until, no_expiry, tracked = None, 0, False
			if row.credential:
				valid_until, no_expiry = credential_validity(row.credential)
				tracked = True
			elif row.reference_doctype and row.reference_name:
				valid_until, tracked = reference_validity(row.reference_doctype, row.reference_name)

			row.valid_until = valid_until
			if not tracked:
				row.validity_status = "Linked" if row.reference_name else ""
			elif no_expiry:
				row.validity_status = "No expiry"
			elif not valid_until:
				row.validity_status = "Expiry date missing"
			elif getdate(valid_until) < getdate(today()):
				row.validity_status = "Expired"
			elif closing and getdate(valid_until) < closing:
				row.validity_status = "Expires before closing"
			elif validity_end and getdate(valid_until) < validity_end:
				row.validity_status = "Expires during bid validity"
			else:
				row.validity_status = "Valid"

	def evaluate_readiness(self):
		issues, warnings = [], []

		mandatory = [r for r in self.requirements if cint(r.mandatory)]
		ready = [r for r in mandatory if cint(r.done)]
		self.readiness_percent = flt(len(ready) / len(mandatory) * 100, 1) if mandatory else 0
		missing = [r.requirement for r in mandatory if not cint(r.done)]
		if not self.requirements:
			issues.append(_("No requirements checklist yet"))
		elif missing:
			shown = ", ".join(missing[:5]) + ("…" if len(missing) > 5 else "")
			issues.append(_("{0} mandatory item(s) not ready: {1}").format(len(missing), shown))

		for r in self.requirements:
			if r.validity_status in BLOCKING_VALIDITY:
				issues.append(f"{r.requirement}: {r.validity_status.lower()}")
			elif r.validity_status == "Expires during bid validity":
				warnings.append(_("{0} expires before the bid validity period ends").format(r.requirement))

		if self.go_decision != "Go":
			issues.append(_("Go/No-Go decision is not recorded as Go"))

		if not self.closing_datetime:
			issues.append(_("Closing date not set"))
		else:
			reference_time = get_datetime(self.submitted_on) if self.submitted_on else now_datetime()
			if reference_time > get_datetime(self.closing_datetime) and (
				self.status in OPEN_STATUSES or self.submitted_on
			):
				issues.append(_("Closing date and time has passed"))

		if self.procurement_method not in NO_PRICE_METHODS and not (flt(self.bid_value) or flt(self.our_bid_amount)):
			issues.append(_("No price yet: add cost lines with bid prices or enter our bid amount"))

		self.security_required_until = None
		if cint(self.bid_security_required):
			issues.extend(self.bid_security_issues())

		self.ready_to_submit = 0 if issues else 1
		self.readiness_issues = "\n".join(issues + [_("Note: {0}").format(w) for w in warnings])
		self._blocking_issues = issues

	def bid_security_issues(self):
		issues = []
		security_type = self.bid_security_type
		if not security_type:
			return [_("Bid security type not selected")]

		if security_type == "Bid-Securing Declaration":
			if not cint(self.bid_security_obtained):
				issues.append(_("Bid-securing declaration not yet signed"))
			return issues

		if not flt(self.bid_security_amount):
			issues.append(_("Bid security amount not entered"))

		if security_type == "Bank Guarantee":
			if not self.bank_guarantee:
				issues.append(_("No Bank Guarantee linked"))
			else:
				bg = frappe.db.get_value(
					"Bank Guarantee", self.bank_guarantee, ["docstatus", "end_date", "amount"], as_dict=True
				)
				if bg:
					if bg.docstatus != 1:
						issues.append(_("Bank Guarantee {0} is not submitted yet").format(self.bank_guarantee))
					else:
						self.bid_security_obtained = 1
					if bg.end_date:
						self.bid_security_valid_until = bg.end_date
					if flt(bg.amount) and flt(bg.amount) < flt(self.bid_security_amount):
						issues.append(_("Bank Guarantee amount is below the required bid security"))
		elif not cint(self.bid_security_obtained):
			issues.append(_("{0} not yet obtained").format(security_type))

		if self.bid_validity_until:
			margin = cint(get_settings().bid_security_margin_days)
			self.security_required_until = add_days(self.bid_validity_until, margin)
			if not self.bid_security_valid_until:
				issues.append(_("Bid security validity date not recorded"))
			elif getdate(self.bid_security_valid_until) < getdate(self.security_required_until):
				issues.append(
					_("Bid security must stay valid until at least {0}").format(
						formatdate(self.security_required_until)
					)
				)
		return issues

	# ------------------------------------------------------------------ status & outcome
	def validate_status_change(self):
		before = self.get_doc_before_save()
		previous = before.status if before else None
		if self.status == previous:
			return

		if self.status == "Submitted":
			if not self.ready_to_submit and not cint(self.override_readiness):
				frappe.throw(
					_("This tender can't be marked Submitted yet:")
					+ "<br>• "
					+ "<br>• ".join(self._blocking_issues),
					title=_("Not ready to submit"),
				)
			if not self.submitted_on:
				self.submitted_on = now_datetime()
			if not flt(self.our_bid_amount):
				self.our_bid_amount = self.bid_value_incl_vat

		if self.status == "Lost" and not self.lost_reason:
			frappe.throw(_("Record the lost reason before marking this tender as Lost."), title=_("Lost reason needed"))

		if self.status == "Awarded":
			self.award_date = self.award_date or today()
			if not flt(self.contract_value):
				self.contract_value = flt(self.our_bid_amount) or flt(self.bid_value_incl_vat)

	def set_outcome_fields(self):
		winners = [c for c in self.competitor_bids if cint(c.is_winner)]
		if winners:
			self.winning_bidder = self.winning_bidder or winners[0].competitor
			if not flt(self.winning_bid_amount):
				self.winning_bid_amount = winners[0].bid_amount
		ours = flt(self.our_bid_amount) or flt(self.bid_value_incl_vat)
		winning = flt(self.winning_bid_amount)
		self.price_gap_percent = flt((ours - winning) / winning * 100, 2) if ours and winning else 0

		if cint(self.bid_security_returned) and not self.bid_security_returned_on:
			self.bid_security_returned_on = today()

	# ------------------------------------------------------------------ bid document
	@frappe.whitelist()
	def generate_bid_document(self):
		"""Draft bid in Word from everything the system knows; saved on the tender as a private attachment."""
		self.check_permission("write")
		from chemical_erp.tenders_desk.bid_document import build, collect, logo_path

		data = collect(self)
		content = build(data, logo_path(self.company))
		for used in data.get("library_used") or []:
			frappe.db.sql("update `tabBid Library Block` set times_used = ifnull(times_used, 0) + 1, last_used_on = %s where name = %s",
			              (now_datetime(), used))
		ref = re.sub(r"[^A-Za-z0-9._-]+", "-", self.reference_no or self.name).strip("-")
		f = frappe.get_doc({"doctype": "File", "file_name": f"Bid Draft {ref} {frappe.utils.nowdate()}.docx", "attached_to_doctype": "Tender",
		                    "attached_to_name": self.name, "is_private": 1, "content": content})
		f.save(ignore_permissions=True)
		self.db_set({"bid_draft": f.file_url, "bid_draft_generated_on": now_datetime()})
		self.add_comment("Info", _("Bid document draft generated: {0}").format(f.file_name))
		return f.file_url

	@frappe.whitelist()
	def bid_library_status(self):
		from chemical_erp.tenders_desk.bid_learning import library_status

		status = library_status()
		status["has_sample_for_tender"] = bool(frappe.db.exists("Bid Sample", {"tender": self.name}))
		return status

	@frappe.whitelist()
	def add_bid_to_library(self, file_url, outcome=None, title=None):
		"""Keep a bid (a sample, or this tender's final submission) in the Bid Library and learn from it."""
		self.check_permission("write")
		sample = frappe.get_doc({"doctype": "Bid Sample", "title": title or self.tender_title, "sample_file": file_url, "tender": self.name,
		                         "outcome": outcome or {"Awarded": "Won", "Lost": "Lost"}.get(self.status, "Not Known")})
		sample.insert()
		return {"sample": sample.name, "sections": frappe.db.count("Bid Library Block", {"source_sample": sample.name})}

	# ------------------------------------------------------------------ Claude
	@frappe.whitelist()
	def read_notice(self):
		from chemical_erp.tenders_desk.ai import apply_extraction, extract_tender_details

		files = [self.notice_file] if self.notice_file else []
		data = extract_tender_details(text=self.notice_text, file_urls=files)
		apply_extraction(self, data)
		self.ai_extracted_on = now_datetime()
		self.refresh_requirements()
		return data.get("summary") or ""
