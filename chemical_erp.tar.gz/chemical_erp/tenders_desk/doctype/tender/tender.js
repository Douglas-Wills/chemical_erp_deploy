const OPEN_STATUSES = ["Identified", "Go/No-Go Review", "Preparing", "Internal Review"];

frappe.ui.form.on("Tender", {
	setup(frm) {
		frm.set_query("credential", "requirements", () => ({ filters: { company: frm.doc.company } }));
		frm.set_query("reference_doctype", "requirements", () => ({ filters: { istable: 0, issingle: 0 } }));
		frm.set_query("bank_guarantee", () => ({ filters: { bg_type: "Providing", docstatus: ["<", 2] } }));
		frm.set_query("supplier_quotation", "cost_lines", () => ({ filters: { docstatus: ["<", 2] } }));
	},

	onload(frm) {
		if (!frm.is_new()) return;
		frappe.call("chemical_erp.tenders_desk.api.get_tender_defaults").then(({ message: d }) => {
			if (!d) return;
			if (!frm.doc.vat_rate) frm.set_value("vat_rate", d.vat_rate);
			if (!frm.doc.wht_rate) frm.set_value("wht_rate", d.wht_rate);
			if (!frm.doc.bid_validity_days) frm.set_value("bid_validity_days", d.bid_validity_days);
			if (!frm.doc.requirement_template && d.default_requirement_template && !(frm.doc.requirements || []).length) {
				frm.set_value("requirement_template", d.default_requirement_template);
			}
		});
	},

	refresh(frm) {
		show_headline(frm);
		add_action_buttons(frm);
		if (!frm.is_new()) add_create_buttons(frm);
	},

	requirement_template(frm) {
		if (frm.doc.requirement_template) load_requirements(frm, frm.doc.requirement_template, true);
	},

	vat_rate: recalc_totals,
	wht_rate: recalc_totals,
	wht_applicable: recalc_totals,
	other_bid_costs: recalc_totals,
	cost_lines_remove: recalc_totals,

	bid_security_required(frm) {
		if (!frm.doc.bid_security_required) {
			frm.set_value({ bid_security_type: "", bid_security_amount: 0 });
		}
	},
});

frappe.ui.form.on("Tender Cost Line", {
	qty: recalc_line,
	unit_cost: recalc_line,
	duty_percent: recalc_line,
	logistics_per_unit: recalc_line,
	markup_percent(frm, cdt, cdn) {
		locals[cdt][cdn].unit_price = 0; // let the markup suggest a new price
		recalc_line(frm, cdt, cdn);
	},
	unit_price: recalc_line,
});

// ------------------------------------------------------------------ headline
function show_headline(frm) {
	frm.dashboard.clear_headline();
	if (frm.is_new()) return;
	const d = frm.doc;
	if (OPEN_STATUSES.includes(d.status)) {
		if (!d.closing_datetime) {
			frm.dashboard.set_headline_alert(__("Set the closing date so reminders can start."), "orange");
			return;
		}
		const days = d.days_to_close;
		const when = days < 0 ? __("Closing date has passed") : days === 0 ? __("Closes today") : days === 1 ? __("Closes tomorrow") : __("Closes in {0} days", [days]);
		const ready = d.ready_to_submit ? __("Ready to submit") : __("{0}% of mandatory items ready", [Math.round(d.readiness_percent || 0)]);
		const color = days <= 3 ? "red" : days <= 7 ? "orange" : "blue";
		frm.dashboard.set_headline_alert(`<b>${when}</b> &nbsp;·&nbsp; ${ready}`, d.ready_to_submit ? "green" : color);
	} else if (d.status === "Lost" && d.price_gap_percent) {
		const gap = d.price_gap_percent;
		frm.dashboard.set_headline_alert(
			gap > 0 ? __("We were {0}% above the winning price.", [gap.toFixed(1)]) : __("We were {0}% below the winning price.", [Math.abs(gap).toFixed(1)]),
			"gray"
		);
	} else if (["Lost", "Not Bidding", "Cancelled", "Awarded"].includes(d.status) && d.bid_security_required
		&& d.bid_security_type && d.bid_security_type !== "Bid-Securing Declaration" && !d.bid_security_returned) {
		frm.dashboard.set_headline_alert(__("Remember to recover the bid security and tick Security Returned."), "orange");
	}
}

// ------------------------------------------------------------------ buttons
function add_action_buttons(frm) {
	const group = __("Actions");
	frm.add_custom_button(__("Generate Bid Document (Word)"), () => generate_bid(frm));
	frm.add_custom_button(__("Teach with a Sample Bid"), () => ask_for_sample(frm, false), __("Bid Library"));
	frm.add_custom_button(__("Review Learned Sections"), () => frappe.set_route("List", "Bid Library Block", { approved: 0 }), __("Bid Library"));
	if (["Submitted", "Under Evaluation", "Awarded", "Lost"].includes(frm.doc.status)) {
		frm.call({ doc: frm.doc, method: "bid_library_status" }).then((r) => {
			if (r.message && !r.message.has_sample_for_tender) {
				frm.dashboard.add_comment(__("Add the bid you submitted to the Bid Library, so future drafts learn from it."), "blue", true);
				frm.add_custom_button(__("Add Submitted Bid to Library"), () => ask_for_sample(frm, true));
			}
		});
	}
	frm.add_custom_button(__("Load Requirements"), () => {
		frappe.prompt(
			{ fieldname: "template", fieldtype: "Link", options: "Tender Requirement Template", label: __("Template"), reqd: 1, default: frm.doc.requirement_template },
			(v) => load_requirements(frm, v.template, false),
			__("Add requirements from a template"),
			__("Add")
		);
	}, group);

	frm.add_custom_button(__("Read Notice with Claude"), () => {
		if (!frm.doc.notice_text && !frm.doc.notice_file) {
			frappe.msgprint(__("Paste the notice into Notice Text, or attach it under Tender Notice (PDF), then try again."));
			frm.scroll_to_field("notice_file");
			return;
		}
		frm.call({ doc: frm.doc, method: "read_notice", freeze: true, freeze_message: __("Claude is reading the notice…") }).then((r) => {
			frm.refresh();
			frm.dirty();
			frappe.msgprint({
				title: __("Notice read"),
				indicator: "green",
				message: (r.message ? `<p>${frappe.utils.escape_html(r.message)}</p>` : "") + __("Empty fields were filled in and new requirements added. Check them, then save."),
			});
		});
	}, group);

	if ((frm.doc.cost_lines || []).some((l) => l.item_code)) {
		frm.add_custom_button(__("Pull Supplier Prices"), () => {
			frm.call({ doc: frm.doc, method: "pull_supplier_prices", freeze: true }).then((r) => {
				frm.refresh();
				frm.dirty();
				frappe.show_alert({ message: __("Unit costs updated on {0} line(s). Save to keep them.", [r.message || 0]), indicator: "green" });
			});
		}, group);
	}

	if (!frm.is_new()) {
		frm.add_custom_button(__("Share on WhatsApp"), () => {
			const d = frm.doc;
			const lines = [
				`*${d.tender_title}*`,
				d.procuring_entity_name,
				d.reference_no ? `Ref: ${d.reference_no}` : "",
				d.closing_datetime ? `Closes: ${frappe.datetime.str_to_user(d.closing_datetime)}` : "",
				d.bid_security_required && d.bid_security_amount ? `Bid security: ${format_currency(d.bid_security_amount, d.currency)}` : "",
				`Status: ${d.status}${OPEN_STATUSES.includes(d.status) ? `, ${Math.round(d.readiness_percent || 0)}% ready` : ""}`,
				d.notice_url || "",
			].filter(Boolean);
			window.open("https://wa.me/?text=" + encodeURIComponent(lines.join("\n")), "_blank", "noopener");
		}, group);
	}
}

function add_create_buttons(frm) {
	const d = frm.doc;
	const group = __("Create");
	const lost_or_closed = ["Lost", "Not Bidding", "Cancelled"].includes(d.status);

	if (!d.opportunity && !lost_or_closed) {
		frm.add_custom_button(__("Opportunity"), () => create_linked(frm, "create_opportunity", "Opportunity"), group);
	}
	if (!d.rfq && OPEN_STATUSES.includes(d.status)) {
		frm.add_custom_button(__("Request for Quotation"), () => create_linked(frm, "create_rfq", "Request for Quotation"), group);
	}
	if (!d.quotation && !lost_or_closed) {
		frm.add_custom_button(__("Quotation"), () => create_linked(frm, "create_quotation", "Quotation"), group);
	}
	if (d.bid_security_required && d.bid_security_type === "Bank Guarantee" && !d.bank_guarantee) {
		frm.add_custom_button(__("Bank Guarantee"), () => {
			frappe.new_doc("Bank Guarantee", {
				bg_type: "Providing",
				customer: d.customer,
				amount: d.bid_security_amount,
				start_date: frappe.datetime.get_today(),
				end_date: d.security_required_until || d.bid_validity_until,
				name_of_beneficiary: d.procuring_entity_name,
				tender: d.name,
			});
		}, group);
	}
	if (d.status === "Awarded" && d.quotation && !d.sales_order) {
		frm.add_custom_button(__("Sales Order"), () => {
			frappe.model.open_mapped_doc({ method: "chemical_erp.tenders_desk.api.make_sales_order", frm });
		}, group);
	}
	if (d.status === "Awarded" && !d.project) {
		frm.add_custom_button(__("Project"), () => create_linked(frm, "create_project", "Project"), group);
	}
}

function create_linked(frm, method, doctype) {
	if (frm.is_dirty()) {
		frappe.msgprint(__("Save the tender first."));
		return;
	}
	frappe.call({ method: `chemical_erp.tenders_desk.api.${method}`, args: { tender: frm.doc.name }, freeze: true }).then((r) => {
		if (!r.message) return;
		frm.reload_doc();
		frappe.show_alert({ message: __("{0} {1} created", [__(doctype), r.message]), indicator: "green" });
		frappe.set_route("Form", doctype, r.message);
	});
}

function load_requirements(frm, template, quiet) {
	frm.call({ doc: frm.doc, method: "load_template", args: { template } }).then((r) => {
		frm.refresh_field("requirements");
		frm.dirty();
		if (!quiet || r.message) {
			frappe.show_alert({ message: __("{0} requirement(s) added", [r.message || 0]), indicator: r.message ? "green" : "blue" });
		}
	});
}

// ------------------------------------------------------------------ live costing
function recalc_line(frm, cdt, cdn) {
	const row = locals[cdt][cdn];
	const landed = flt(row.unit_cost) * (1 + flt(row.duty_percent) / 100) + flt(row.logistics_per_unit);
	row.landed_unit_cost = flt(landed, 2);
	if (!flt(row.unit_price) && flt(row.markup_percent)) {
		row.unit_price = flt(landed * (1 + flt(row.markup_percent) / 100), 2);
	}
	row.line_cost = flt(landed * flt(row.qty), 2);
	row.line_value = flt(flt(row.unit_price) * flt(row.qty), 2);
	frm.refresh_field("cost_lines");
	recalc_totals(frm);
}

function recalc_totals(frm) {
	const d = frm.doc;
	let cost = 0, value = 0;
	(d.cost_lines || []).forEach((r) => { cost += flt(r.line_cost); value += flt(r.line_value); });
	d.total_landed_cost = flt(cost, 2);
	d.bid_value = flt(value, 2);
	d.vat_amount = flt(value * flt(d.vat_rate) / 100, 2);
	d.bid_value_incl_vat = flt(value + d.vat_amount, 2);
	d.gross_margin = flt(value - cost - flt(d.other_bid_costs), 2);
	d.gross_margin_percent = value ? flt(d.gross_margin / value * 100, 2) : 0;
	d.wht_amount = d.wht_applicable ? flt(value * flt(d.wht_rate) / 100, 2) : 0;
	d.cash_after_wht = flt(d.bid_value_incl_vat - d.wht_amount, 2);
	frm.refresh_fields(["total_landed_cost", "bid_value", "vat_amount", "bid_value_incl_vat", "gross_margin",
		"gross_margin_percent", "wht_amount", "cash_after_wht"]);
}


function generate_bid(frm) {
	// Always drafts at once. The Bid Library only improves the wording; it is never required.
	frappe.call({ doc: frm.doc, method: "generate_bid_document", freeze: true, freeze_message: __("Drafting the bid document") })
		.then((r) => {
			if (!r.message) return;
			window.open(r.message);
			frm.reload_doc();
			frm.call({ doc: frm.doc, method: "bid_library_status" }).then((st) => {
				if (st.message && !st.message.approved) {
					frappe.show_alert({ indicator: "blue", message: __("Draft ready, in standard wording. Tip: Bid Library → Teach with a Sample Bid, so future drafts use your own proven wording.") }, 10);
				}
			});
		});
}

function ask_for_sample(frm, submitted_bid) {
	const intro = submitted_bid
		? __("Upload the bid you submitted for this tender, so future drafts learn from it.")
		: __("Upload a past bid (Word or PDF), ideally one you won. Its sections are learned for you to review and approve; approved wording then improves every future draft. Optional: drafts work without it.");
	const d = new frappe.ui.Dialog({
		title: submitted_bid ? __("Add submitted bid to the library") : __("Teach with a sample bid"),
		fields: [
			{ fieldtype: "HTML", options: `<p class="text-muted">${intro}</p>` },
			{ fieldname: "file_url", fieldtype: "Attach", label: __("Bid document (Word or PDF)"), reqd: 1 },
			{ fieldname: "outcome", fieldtype: "Select", label: __("Outcome of that bid"), options: "Won\nLost\nNot Known\nTemplate",
			  default: frm.doc.status === "Awarded" ? "Won" : (frm.doc.status === "Lost" ? "Lost" : "Not Known") },
		],
		primary_action_label: __("Learn from It"),
		primary_action(v) {
			frm.call({ doc: frm.doc, method: "add_bid_to_library", args: { file_url: v.file_url, outcome: v.outcome }, freeze: true,
				freeze_message: __("Learning from the sample") }).then((r) => {
				d.hide();
				frappe.show_alert({ message: __("{0} section(s) learned: review and approve the ones to reuse", [r.message.sections]), indicator: "green" });
				frm.reload_doc();
			});
		},
	});
	d.show();
}
