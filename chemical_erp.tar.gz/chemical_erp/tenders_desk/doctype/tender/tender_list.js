frappe.listview_settings["Tender"] = {
	add_fields: ["status", "days_to_close", "ready_to_submit", "closing_datetime"],
	get_indicator(doc) {
		const colors = {
			"Identified": "blue", "Go/No-Go Review": "orange", "Preparing": "cyan", "Internal Review": "orange",
			"Submitted": "purple", "Under Evaluation": "purple", "Awarded": "green", "Lost": "red",
			"Not Bidding": "gray", "Cancelled": "gray",
		};
		const open = ["Identified", "Go/No-Go Review", "Preparing", "Internal Review"].includes(doc.status);
		if (open && doc.closing_datetime && doc.days_to_close !== null && doc.days_to_close <= 3) {
			const label = doc.days_to_close < 0 ? __("Deadline passed") : __("{0}: {1}d left", [__(doc.status), doc.days_to_close]);
			return [label, "red", "status,=," + doc.status];
		}
		return [__(doc.status), colors[doc.status] || "gray", "status,=," + doc.status];
	},
};
