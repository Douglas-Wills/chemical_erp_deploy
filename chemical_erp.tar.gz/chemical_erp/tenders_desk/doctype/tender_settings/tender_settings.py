import frappe
from frappe import _
from frappe.model.document import Document


class TenderSettings(Document):
	def validate(self):
		days = [d.strip() for d in (self.reminder_days or "").split(",") if d.strip()]
		if any(not d.isdigit() for d in days):
			frappe.throw(_("Closing reminders must be whole numbers separated by commas, for example 7,3,1."))
		self.reminder_days = ",".join(days)
		for row in self.validity_sources:
			if not frappe.get_meta(row.reference_doctype).has_field(row.date_field):
				frappe.throw(
					_("Row {0}: {1} has no field called {2}.").format(row.idx, row.reference_doctype, row.date_field)
				)
		if self.scan_enabled:
			if not any(k.kind == "Include" and (k.keyword or "").strip() for k in self.scope_keywords):
				frappe.throw(_("Enter the company scope (at least one Include keyword) before switching scanning on."))
			from chemical_erp.company import default_company

			if not frappe.db.exists("Company Profile", default_company() or ""):
				frappe.throw(_("Complete the Company Profile before switching scanning on."))
