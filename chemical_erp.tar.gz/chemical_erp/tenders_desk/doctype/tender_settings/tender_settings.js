frappe.ui.form.on("Tender Settings", {
	refresh(frm) {
		frm.add_custom_button(__("Load Example Scope"), () => {
			frappe.prompt([{ fieldname: "scope", fieldtype: "Select", label: __("Example"), reqd: 1,
				options: ["Brave Chemicals (website 27 Sep 2026, plus fertilisers)", "Chemicals and water treatment", "Civil works and design", "General supplies (starting point)"] }],
				(v) => frappe.call("chemical_erp.tenders_desk.scan_seed.load_example_scope", v).then(() => frm.reload_doc()),
				__("Load an example scope to edit"), __("Load"));
		}, __("Tender Scanning"));
		if (!frm.doc.scan_enabled) {
			frm.dashboard.set_headline_alert(__("Tender scanning is off. Set the Company Profile and the company scope, then tick Scan Automatically."), "orange");
		}
		if (frm.doc.enable_ai) {
			frm.add_custom_button(__("Test Claude Connection"), () => {
				if (frm.is_dirty()) {
					frappe.msgprint(__("Save the settings first."));
					return;
				}
				frappe.call({ method: "chemical_erp.tenders_desk.api.test_claude_connection", freeze: true }).then((r) => {
					frappe.msgprint({ title: __("Claude replied"), indicator: "green", message: frappe.utils.escape_html(r.message || "") });
				});
			});
		}
	},
});
