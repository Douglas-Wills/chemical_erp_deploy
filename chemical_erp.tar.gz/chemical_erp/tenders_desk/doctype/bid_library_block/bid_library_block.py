import frappe
from frappe import _
from frappe.model.document import Document


class BidLibraryBlock(Document):
	def validate(self):
		before = self.get_doc_before_save()
		if self.approved and not (before and before.approved):
			roles = set(frappe.get_roles())
			if not roles & {"Tender Manager", "Managing Director", "System Manager"}:
				frappe.throw(_("Only a Tender Manager or the Managing Director can approve library sections."), frappe.PermissionError)
			self.approved_by = frappe.session.user
		if not self.approved:
			self.approved_by = None

	def on_update(self):
		if self.source_sample:
			frappe.db.set_value("Bid Sample", self.source_sample, "sections_approved",
			                    frappe.db.count("Bid Library Block", {"source_sample": self.source_sample, "approved": 1}), update_modified=False)
