from frappe.model.document import Document


class TenderValiditySource(Document):
	pass
