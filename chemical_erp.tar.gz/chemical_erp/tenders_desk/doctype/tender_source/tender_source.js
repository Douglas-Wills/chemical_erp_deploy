frappe.ui.form.on("Tender Source", {
	refresh(frm) {
		if (frm.is_new() || frm.doc.source_type === "Email Inbox") return;
		frm.add_custom_button(__("Scan Now"), () => frappe.call({ method: "chemical_erp.tenders_desk.scanner.scan_source",
			args: { source_name: frm.doc.name }, freeze: true, freeze_message: __("Reading {0}", [frm.doc.source_name]) })
			.then((r) => { frappe.msgprint(r.message); frm.reload_doc(); }));
	},
});
