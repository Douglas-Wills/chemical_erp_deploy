from frappe.model.document import Document


class TenderSource(Document):
	pass
