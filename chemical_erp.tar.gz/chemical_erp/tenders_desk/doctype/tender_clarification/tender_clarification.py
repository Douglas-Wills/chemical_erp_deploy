from frappe.model.document import Document


class TenderClarification(Document):
	pass
