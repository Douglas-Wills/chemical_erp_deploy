"""Optional starter data for Brave Chemicals.

Run once on the site:
    bench --site <site> execute chemical_erp.tenders_desk.seed.load_brave_starter_data --kwargs "{'company': 'Brave Chemicals Ltd'}"

Safe to run twice: existing records are skipped. Expiry dates are left blank on purpose;
enter the real dates from the certificates.
"""

import frappe

CREDENTIALS = (
	("Certificate of Incorporation", "Certificate of Incorporation", "Registration", 1, ""),
	("Trading Licence", "Trading Licence", "Trade Licence", 0, ""),
	("URA Tax Clearance Certificate", "URA Tax Clearance", "Tax", 0, ""),
	("NSSF Clearance Certificate", "NSSF Clearance", "Social Security", 0, ""),
	("PPDA Register of Providers Certificate", "PPDA Register of Providers", "Registration", 0, ""),
	("Audited Accounts", "Audited Accounts", "Financial", 0, ""),
	("Bank Reference Letter", "Bank Reference", "Financial", 0, ""),
	("UNGM Registration", "UNGM Registration", "Registration", 1, "1260833"),
)

TENDERS = (
	{
		"tender_title": "Workover fluids supply, Tilenga project (EOI)",
		"reference_no": "IA031281",
		"procurement_method": "Expression of Interest",
		"procuring_entity_name": "TotalEnergies EP Uganda",
		"category": "Generic and Specialty Chemicals",
		"bidding_as": "",
		"partners": "REDA Industrial Materials FZE (UAE), joint venture partner",
		"closing_datetime": "2026-10-13 00:00:00",
		"requirement_template": "Oil & Gas Supplier Prequalification",
		"decision_notes": "Closing time not confirmed; set to the start of 13 Oct 2026 until checked. "
		"Confirm whether Brave or REDA leads the joint venture.",
	},
	{
		"tender_title": "Mercury-free ASGM equipment: procurement, importation and delivery (EOI / prequalification)",
		"procurement_method": "Prequalification",
		"procuring_entity_name": "Impact Transform / planetGOLD Uganda",
		"category": "Industrial Equipment Supply and Servicing",
		"bidding_as": "Prime Contractor with Subcontractors",
		"partners": "DTS Global Logistics: logistics, clearing, freight, warehousing and last-mile delivery",
		"requirement_template": "Expression of Interest / Prequalification",
		"decision_notes": "Closing date not yet recorded.",
	},
)


def load_brave_starter_data(company=None):
	company = company or frappe.defaults.get_global_default("company")
	if not company or not frappe.db.exists("Company", company):
		frappe.throw("Pass the exact Company name, e.g. --kwargs \"{'company': 'Brave Chemicals Ltd'}\"")

	for name, key, ctype, no_expiry, cert_no in CREDENTIALS:
		if frappe.db.exists("Bid Credential", {"company": company, "standard_key": key}):
			continue
		frappe.get_doc(
			{
				"doctype": "Bid Credential",
				"credential_name": name,
				"standard_key": key,
				"credential_type": ctype,
				"company": company,
				"no_expiry": no_expiry,
				"certificate_no": cert_no,
			}
		).insert(ignore_permissions=True)

	for data in TENDERS:
		if frappe.db.exists("Tender", {"tender_title": data["tender_title"]}):
			continue
		doc = frappe.new_doc("Tender")
		doc.update(data)
		doc.company = company
		doc.insert(ignore_permissions=True)
		doc.load_template(data["requirement_template"])
		if "REDA" in (data.get("partners") or ""):
			doc.append("requirements", {"requirement": "Joint venture agreement with REDA Industrial Materials FZE", "requirement_type": "Administrative", "mandatory": 1})
		else:
			doc.append("requirements", {"requirement": "Subcontract agreement with DTS Global Logistics", "requirement_type": "Administrative", "mandatory": 1})
		doc.save(ignore_permissions=True)

	frappe.db.commit()
	return "Brave starter data loaded"
