"""Reads tender notices (PDF, image or text) with the Claude API and maps the result onto a Tender."""

import base64
import json
import re

import frappe
import requests
from frappe import _
from frappe.utils import cint, get_datetime, now_datetime, strip_html

from chemical_erp.tenders_desk.utils import get_settings, guess_standard_key

API_URL = "https://api.anthropic.com/v1/messages"
API_VERSION = "2023-06-01"
MAX_FILE_BYTES = 25 * 1024 * 1024

PROCUREMENT_METHODS = (
	"Open Domestic Bidding", "Open International Bidding", "Restricted Domestic Bidding",
	"Restricted International Bidding", "Request for Quotations", "Request for Proposals",
	"Direct Procurement", "Micro Procurement", "Expression of Interest", "Prequalification",
	"Framework Contract", "Private Sector RFQ", "Other",
)
SECURITY_TYPES = ("Bank Guarantee", "Insurance Bond", "Bid-Securing Declaration", "Bank Draft / Cash")
REQ_TYPES = ("Administrative", "Technical", "Financial", "Commercial")

PROMPT = """You are reading a public or private procurement notice (tender, RFQ, EOI or prequalification), usually from Uganda or East Africa. Today is {today}.

Reply with ONLY one JSON object, no other text, using exactly these keys:
{{
 "title": "short descriptive title of what is being procured",
 "procuring_entity": "",
 "reference_no": "",
 "procurement_method": one of {methods} or "",
 "published_on": "YYYY-MM-DD or empty",
 "closing_date": "YYYY-MM-DD or empty",
 "closing_time": "HH:MM 24-hour or empty",
 "clarification_deadline": "YYYY-MM-DD HH:MM or empty",
 "pre_bid_meeting": "YYYY-MM-DD HH:MM or empty",
 "site_visit": "YYYY-MM-DD HH:MM or empty",
 "bid_validity_days": integer or null,
 "bid_security_required": true, false, or null if the notice does not say,
 "bid_security_type": one of {security} or "",
 "bid_security_amount": number or null,
 "bid_security_currency": "ISO code such as UGX or USD, or empty",
 "requirements": [{{"requirement": "", "type": one of {req_types}, "mandatory": true}}],
 "items": [{{"description": "", "quantity": number or null, "unit": ""}}],
 "summary": "2-3 plain sentences: what is wanted, by whom, key deadline, anything unusual"
}}

Rules:
- Use "" or null for anything the notice does not state. Never guess dates, amounts or reference numbers.
- If the notice says no bid security is required, set bid_security_required to false.
- A bid-securing declaration is a bid security type, not an absence of security.
- requirements: every document or evidence the bidder must submit, short plain wording, at most 30.
- items: the goods or services and quantities if listed, at most 40."""


def _api_key():
	settings = get_settings()
	if not cint(settings.enable_ai):
		frappe.throw(_("Turn on Claude notice reading in Tender Settings first."), title=_("Claude is off"))
	key = settings.get_password("claude_api_key", raise_exception=False)
	if not key:
		frappe.throw(_("Add an Anthropic API key in Tender Settings."), title=_("API key missing"))
	return key, (settings.claude_model or "claude-sonnet-5-5").strip()


def _file_block(file_url):
	name = frappe.db.get_value("File", {"file_url": file_url}, "name")
	if not name:
		return None
	file_doc = frappe.get_doc("File", name)
	content = file_doc.get_content()
	if isinstance(content, str):
		content = content.encode()
	if len(content) > MAX_FILE_BYTES:
		frappe.msgprint(_("{0} is too large to read and was skipped.").format(file_doc.file_name))
		return None
	lower = (file_doc.file_name or file_url).lower()
	encoded = base64.b64encode(content).decode()
	if lower.endswith(".pdf"):
		return {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": encoded}}
	for ext, media in ((".png", "image/png"), (".jpg", "image/jpeg"), (".jpeg", "image/jpeg"), (".webp", "image/webp")):
		if lower.endswith(ext):
			return {"type": "image", "source": {"type": "base64", "media_type": media, "data": encoded}}
	if lower.endswith((".txt", ".md", ".csv", ".html", ".htm", ".eml")):
		return {"type": "text", "text": strip_html(content.decode("utf-8", "ignore"))[:150000]}
	return None


def call_claude(content, max_tokens=4000):
	key, model = _api_key()
	try:
		response = requests.post(
			API_URL,
			headers={"x-api-key": key, "anthropic-version": API_VERSION, "content-type": "application/json"},
			json={"model": model, "max_tokens": max_tokens, "messages": [{"role": "user", "content": content}]},
			timeout=180,
		)
	except requests.RequestException:
		frappe.log_error(title="Claude request failed", message=frappe.get_traceback())
		frappe.throw(_("Couldn't reach the Claude API. Check the server's internet connection and try again."))
	if response.status_code != 200:
		frappe.log_error(title=f"Claude API error {response.status_code}", message=response.text[:4000])
		hint = {
			401: _("The API key was rejected. Check it in Tender Settings."),
			404: _("The model name in Tender Settings wasn't recognised."),
			413: _("The notice is too large. Attach a smaller PDF or paste the main text."),
			429: _("Too many requests right now. Wait a minute and try again."),
		}.get(response.status_code, _("The Claude API returned an error ({0}). Details are in the Error Log.").format(response.status_code))
		frappe.throw(hint, title=_("Couldn't read the notice"))
	body = response.json()
	return "".join(b.get("text", "") for b in body.get("content", []) if b.get("type") == "text")


def _parse_json(text):
	text = (text or "").strip()
	text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
	start, end = text.find("{"), text.rfind("}")
	if start == -1 or end == -1:
		frappe.throw(_("Claude's reply didn't contain the tender details. Try pasting just the main notice text."))
	try:
		return json.loads(text[start : end + 1])
	except ValueError:
		frappe.log_error(title="Claude reply was not valid JSON", message=text[:4000])
		frappe.throw(_("Claude's reply couldn't be read. Try again, or paste just the main notice text."))


def extract_tender_details(text=None, file_urls=None):
	content = []
	for url in file_urls or []:
		block = _file_block(url)
		if block:
			content.append(block)
	if text and strip_html(text).strip():
		content.append({"type": "text", "text": "Notice text:\n" + strip_html(text)[:150000]})
	if not content:
		frappe.throw(_("Paste the notice text or attach the notice as a PDF first."), title=_("Nothing to read"))
	content.append(
		{
			"type": "text",
			"text": PROMPT.format(
				today=frappe.utils.today(),
				methods=json.dumps(PROCUREMENT_METHODS),
				security=json.dumps(SECURITY_TYPES),
				req_types=json.dumps(REQ_TYPES),
			),
		}
	)
	data = _parse_json(call_claude(content))
	return frappe._dict(data) if isinstance(data, dict) else frappe._dict()


def _dt(value, default_time=None):
	value = (value or "").strip()
	if not value:
		return None
	if default_time and len(value) == 10:
		value = f"{value} {default_time}"
	try:
		return get_datetime(value)
	except Exception:
		return None


def apply_extraction(doc, data, overwrite=()):
	"""Fill empty fields only (plus any listed in `overwrite`). Never removes what a person typed."""

	def put(field, value):
		if value in (None, "", []):
			return
		if field in overwrite or not doc.get(field):
			doc.set(field, value)

	put("tender_title", (data.get("title") or "")[:140])
	entity = (data.get("procuring_entity") or "").strip()
	put("procuring_entity_name", entity)
	if entity and not doc.customer:
		customer = frappe.db.get_value("Customer", {"customer_name": entity}, "name")
		if customer:
			doc.customer = customer
	put("reference_no", data.get("reference_no"))
	if data.get("procurement_method") in PROCUREMENT_METHODS:
		put("procurement_method", data.get("procurement_method"))

	if data.get("closing_date"):
		# No time stated: assume the start of the day so reminders err on the early side.
		put("closing_datetime", _dt(data.get("closing_date") + " " + (data.get("closing_time") or "00:00")))
	put("published_on", (data.get("published_on") or "")[:10] or None)
	put("clarification_deadline", _dt(data.get("clarification_deadline"), "23:59"))
	put("pre_bid_meeting", _dt(data.get("pre_bid_meeting"), "10:00"))
	put("site_visit", _dt(data.get("site_visit"), "10:00"))
	if cint(data.get("bid_validity_days")) > 0:
		doc.bid_validity_days = cint(data.get("bid_validity_days"))

	if data.get("bid_security_required") is True:
		doc.bid_security_required = 1
		if data.get("bid_security_type") in SECURITY_TYPES:
			put("bid_security_type", data.get("bid_security_type"))
		amount = data.get("bid_security_amount")
		if isinstance(amount, (int, float)) and amount > 0:
			put("bid_security_amount", amount)
	elif data.get("bid_security_required") is False and not doc.bank_guarantee:
		doc.bid_security_required = 0

	existing = {(r.requirement or "").strip().lower() for r in doc.requirements}
	for req in (data.get("requirements") or [])[:30]:
		label = (req.get("requirement") if isinstance(req, dict) else str(req) or "").strip()
		if not label or label.lower() in existing:
			continue
		existing.add(label.lower())
		doc.append(
			"requirements",
			{
				"requirement": label[:140],
				"requirement_type": req.get("type") if isinstance(req, dict) and req.get("type") in REQ_TYPES else "",
				"mandatory": 0 if isinstance(req, dict) and req.get("mandatory") is False else 1,
				"standard_key": guess_standard_key(label) or "",
			},
		)

	if not doc.cost_lines:
		for item in (data.get("items") or [])[:40]:
			if not isinstance(item, dict) or not item.get("description"):
				continue
			unit = (item.get("unit") or "").strip()
			doc.append(
				"cost_lines",
				{
					"description": (item["description"] + (f" ({unit})" if unit else ""))[:140],
					"qty": item.get("quantity") if isinstance(item.get("quantity"), (int, float)) else 1,
				},
			)

	summary = (data.get("summary") or "").strip()
	currency = (data.get("bid_security_currency") or "").strip().upper()
	if currency and doc.currency and currency != doc.currency:
		summary += f" Bid security is stated in {currency}."
	if summary:
		doc.ai_summary = summary
	doc.ai_extracted_on = now_datetime()


def process_email_intake(tender):
	"""Background job: read a tender created from an incoming email."""
	doc = frappe.get_doc("Tender", tender)
	comms = frappe.get_all(
		"Communication",
		filters={"reference_doctype": "Tender", "reference_name": tender, "sent_or_received": "Received"},
		fields=["name", "content"],
		order_by="creation asc",
		limit=1,
	)
	text = comms[0].content if comms else doc.notice_text
	attached_to = [("Tender", tender)] + ([("Communication", comms[0].name)] if comms else [])
	files = []
	for doctype, name in attached_to:
		files += frappe.get_all(
			"File", filters={"attached_to_doctype": doctype, "attached_to_name": name}, pluck="file_url"
		)
	files = [f for f in dict.fromkeys(files) if f and f.lower().endswith(".pdf")][:3]

	if text and not doc.notice_text:
		doc.notice_text = strip_html(text)[:100000]
	if files and not doc.notice_file:
		doc.notice_file = files[0]
	doc.source = doc.source or "Email"
	try:
		data = extract_tender_details(text=text, file_urls=files)
		apply_extraction(doc, data, overwrite=("tender_title",))
		doc.flags.ignore_permissions = True
		doc.save()
		doc.add_comment("Comment", _("Claude read the emailed notice and filled in the details. Check them before relying on them."))
	except Exception:
		frappe.db.rollback()
		frappe.log_error(title=f"Tender notice reading failed: {tender}", message=frappe.get_traceback())
		frappe.get_doc("Tender", tender).add_comment(
			"Comment", _("Claude couldn't read this notice automatically. Use Actions > Read Notice with Claude, or fill it in by hand.")
		)
