"""URA EFRIS fiscalisation for Sales Invoices and Credit Notes.

Two modes, set in Chemical ERP Settings:
- Manual (URA Desktop App): the stopgap until URA approves the system-to-system connection.
  Accounts issues the fiscal document in the Desktop App and keys the number onto the invoice.
- Offline Enabler: invoices are queued and posted to URA's offline-mode enabler running on the
  same server, which forwards them to URA when the line is up.

IMPORTANT: the envelope and field names below follow the published EFRIS system-to-system
interface (invoice upload, interface code T109). Verify every field against the interface
specification downloaded from the EFRIS portal, and test in URA's sandbox, before going live.
"""

import base64
import json
import uuid

import frappe
import requests
from frappe import _
from frappe.utils import add_to_date, cint, flt, now_datetime

from chemical_erp.utils import get_settings, notify, users_with_role

RETRY_MINUTES = (5, 15, 60, 240)


def on_submit(doc, method=None):
	if frappe.db.exists("EFRIS Submission Log", {"reference_doctype": doc.doctype, "reference_name": doc.name}):
		return
	log = frappe.get_doc({"doctype": "EFRIS Submission Log", "reference_doctype": doc.doctype,
	                      "reference_name": doc.name, "status": "Queued", "next_attempt": now_datetime()})
	log.insert(ignore_permissions=True)
	doc.db_set("efris_status", "Pending")
	if get_settings().efris_mode == "Offline Enabler":
		frappe.enqueue("chemical_erp.integrations.efris.send", log=log.name, queue="short", enqueue_after_commit=True)


def on_update_after_submit(doc, method=None):
	"""Manual mode: Accounts keys in the fiscal number from the Desktop App."""
	if doc.get("efris_fdn") and doc.get("efris_status") != "Fiscalised":
		doc.db_set({"efris_status": "Fiscalised", "efris_fiscalised_on": now_datetime()})
		log = frappe.db.get_value("EFRIS Submission Log", {"reference_doctype": doc.doctype, "reference_name": doc.name})
		if log:
			frappe.db.set_value("EFRIS Submission Log", log, {"status": "Fiscalised", "fiscal_number": doc.efris_fdn})


def before_cancel(doc, method=None):
	"""A fiscalised invoice stays on URA's record, so it is reversed with a credit note, not cancelled."""
	if doc.get("efris_fdn"):
		frappe.throw(_("{0} is fiscalised with URA (FDN {1}). Issue a credit note (Create > Return / Credit Note) instead of cancelling it.")
		             .format(doc.name, doc.efris_fdn), title=_("Fiscalised invoice"))


def retry_due():
	if get_settings().efris_mode != "Offline Enabler":
		return
	for name in frappe.get_all("EFRIS Submission Log", filters={"status": ["in", ["Queued", "Failed"]],
	                                                           "next_attempt": ["<=", now_datetime()]}, pluck="name", limit=50):
		send(name)


def send(log):
	log = frappe.get_doc("EFRIS Submission Log", log)
	inv = frappe.get_doc(log.reference_doctype, log.reference_name)
	s = get_settings()
	try:
		content = build_invoice_content(inv, s)
		envelope = _envelope("T110" if inv.get("is_return") else "T109", content, s)
		log.request_payload = json.dumps(envelope, indent=1, default=str)
		resp = requests.post(s.efris_enabler_url, json=envelope, timeout=60)
		body = resp.json()
		log.response = json.dumps(body, indent=1)
		state = (body.get("returnStateInfo") or {})
		if str(state.get("returnCode")) not in ("00", "0"):
			raise ValueError(state.get("returnMessage") or _("EFRIS returned an error"))
		data = json.loads(base64.b64decode(body["data"]["content"]).decode()) if body.get("data", {}).get("content") else {}
		basic = data.get("basicInformation") or {}
		summary = data.get("summary") or {}
		fdn = basic.get("invoiceNo")
		if not fdn:
			raise ValueError(_("EFRIS reply had no fiscal document number"))
		inv.db_set({"efris_fdn": fdn, "efris_verification_code": basic.get("antifakeCode"),
		            "efris_qr_code": summary.get("qrCode"), "efris_status": "Fiscalised",
		            "efris_fiscalised_on": now_datetime()})
		log.update({"status": "Fiscalised", "fiscal_number": fdn, "verification_code": basic.get("antifakeCode"),
		            "last_message": ""})
		from chemical_erp.print_pdf import queue as queue_pdf

		queue_pdf(inv)  # the saved copy is now the valid tax invoice
	except Exception as e:
		log.attempts = cint(log.attempts) + 1
		log.status = "Failed"
		log.last_message = str(e)[:1000]
		log.next_attempt = add_to_date(now_datetime(), minutes=RETRY_MINUTES[min(log.attempts, len(RETRY_MINUTES)) - 1])
		inv.db_set("efris_status", "Failed")
		if log.attempts == cint(s.efris_alert_after or 3):
			notify(users_with_role("Accounts Manager") + users_with_role("Accounts User"), log.reference_doctype,
			       log.reference_name, _("EFRIS failed for {0}: {1}").format(log.reference_name, log.last_message), priority="High")
	log.save(ignore_permissions=True)
	frappe.db.commit()


def _envelope(interface_code, content, s):
	return {
		"data": {"content": base64.b64encode(json.dumps(content, default=str).encode()).decode(), "signature": "",
		         "dataDescription": {"codeType": "0", "encryptCode": "1", "zipCode": "0"}},
		"globalInfo": {"appId": "AP04", "version": "1.1.20191201", "dataExchangeId": uuid.uuid4().hex,
		               "interfaceCode": interface_code, "requestCode": "TP", "requestTime": now_datetime().strftime("%Y-%m-%d %H:%M:%S"),
		               "responseCode": "TA", "userName": "admin", "deviceMAC": "FFFFFFFFFFFF",
		               "deviceNo": s.efris_device_no or "", "tin": s.efris_tin or "", "brn": "", "taxpayerID": "1",
		               "longitude": "", "latitude": "", "agentType": "0",
		               "extendField": {"responseDateFormat": "dd/MM/yyyy", "responseTimeFormat": "dd/MM/yyyy HH:mm:ss"}},
		"returnStateInfo": {"returnCode": "", "returnMessage": ""},
	}


def _profile_tin(inv):
	from chemical_erp.company import get_profile

	return get_profile(inv.company).get("tin")


def _net_amount(row):
	# Zero is a valid net value for a fully discounted line.
	net = row.get("net_amount")
	return abs(flt(row.amount if net is None else net))


def _line_taxes(inv):
	"""Each invoice line's VAT rate and amount, from ERPNext's own item-wise tax breakdown on the tax rows."""
	per_item = {}
	for t in inv.get("taxes") or []:
		try:
			detail = json.loads(t.get("item_wise_tax_detail") or "{}")
		except ValueError:
			continue
		for item_code, val in detail.items():
			rate, amount = (val + [0, 0])[:2] if isinstance(val, list) else (flt(val), 0)
			r = per_item.setdefault(item_code, [0.0, 0.0])
			r[0] += flt(rate)
			r[1] += flt(amount)
	out = {}
	for item_code, (rate, amount) in per_item.items():
		rows = [r for r in inv.items if r.item_code == item_code]
		total = sum(_net_amount(r) for r in rows) or 1
		for r in rows:  # the same product on several lines: share its tax by line value
			out[r.name] = (rate, amount * _net_amount(r) / total)
	return out


def build_invoice_content(inv, s):
	"""Map a Sales Invoice to EFRIS invoice content. Check field names against URA's specification."""
	customer = frappe.get_cached_doc("Customer", inv.customer)
	goods, by_rate = [], {}
	line_tax = _line_taxes(inv)
	for i, row in enumerate(inv.items):
		code = frappe.get_cached_value("Item", row.item_code, "efris_commodity_code")
		if not code:
			frappe.throw(_("Item {0} has no EFRIS commodity code.").format(row.item_code))
		net = _net_amount(row)  # after any invoice discount, so lines add up to the totals
		rate, tax = line_tax.get(row.name, (0.0, 0.0))
		goods.append({"item": row.item_name, "itemCode": row.item_code, "qty": str(abs(row.qty)),
		              "unitOfMeasure": frappe.get_cached_value("Item", row.item_code, "efris_unit") or row.uom,
		              "unitPrice": str(flt(net / abs(flt(row.qty) or 1), 2)), "total": str(flt(net, 2)), "taxRate": str(flt(rate / 100, 4)),
		              "tax": str(flt(abs(tax), 2)), "orderNumber": str(i), "discountFlag": "2",
		              "deemedFlag": "2", "exciseFlag": "2", "goodsCategoryId": code})
		g = by_rate.setdefault(flt(rate, 4), [0.0, 0.0])
		g[0] += net
		g[1] += abs(tax)
	# one tax line per rate, from the invoice's own figures (the same ones the printed invoice shows).
	# 18% = standard rated (01); 0% is sent as zero-rated (02): exempt goods (03) need their own Item Tax Template mapping.
	taxes = [{"taxCategoryCode": "01" if rate else "02", "netAmount": str(flt(n, 2)), "taxRate": str(flt(rate / 100, 4)),
	          "taxAmount": str(flt(t, 2)), "grossAmount": str(flt(n + t, 2))} for rate, (n, t) in sorted(by_rate.items(), reverse=True)]
	content = {
		"sellerDetails": {"tin": s.efris_tin or _profile_tin(inv), "referenceNo": inv.name},
		"basicInformation": {"invoiceNo": "", "deviceNo": s.efris_device_no, "issuedDate": str(inv.posting_date),
		                     "operator": frappe.session.user, "currency": inv.currency, "invoiceType": "1",
		                     "invoiceKind": "1", "dataSource": "103", "invoiceIndustryCode": "101"},
		"buyerDetails": {"buyerTin": customer.get("tax_id") or "", "buyerLegalName": customer.customer_name,
		                 "buyerType": {"Business": "0", "Individual": "1", "Government": "3", "Foreigner": "2"}.get(
		                     customer.get("efris_buyer_type") or "Business", "0")},
		"goodsDetails": goods, "taxDetails": taxes,
		"summary": {"netAmount": str(flt(abs(inv.net_total), 2)), "taxAmount": str(flt(abs(inv.total_taxes_and_charges), 2)),
		            "grossAmount": str(flt(abs(inv.grand_total), 2)), "itemCount": str(len(goods)), "modeCode": "1"},
	}
	if inv.get("is_return") and inv.get("return_against"):
		content["oriInvoiceNo"] = frappe.db.get_value("Sales Invoice", inv.return_against, "efris_fdn")
	return content
