"""Quarterly internal audits under procedure BC/IMS/020.

- Quarters follow the financial year (July start by default, set in Chemical ERP Settings).
- Each quarter an Internal Audit is planned automatically, with its checklist built from the live IMS
  register, and open findings from the previous audit carried forward for follow-up.
- The report downloads as a Word document (form BC/HSE/006).
"""

import frappe
from frappe import _
from frappe.utils import add_days, add_months, cint, get_first_day, getdate, today

from chemical_erp.utils import get_settings, notify, users_with_role

MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
AUDITED_TYPES = ("Procedure", "Policy", "Plan", "Manual", "Process Map", "Register")
NONCONFORMING = ("Minor Nonconformity", "Major Nonconformity", "Observation", "Opportunity for Improvement")


def quarter_for(date=None):
	"""(start, end, label) of the audit quarter containing `date`."""
	date = getdate(date or today())
	start_month = MONTHS.index(get_settings().get("audit_cycle_start_month") or "July") + 1
	offset = (date.month - start_month) % 12
	q_index = offset // 3
	start = get_first_day(add_months(date, -(offset % 3)))
	end = add_days(add_months(start, 3), -1)
	fy_start_year = date.year if date.month >= start_month else date.year - 1
	fy = f"FY{fy_start_year}/{str(fy_start_year + 1)[-2:]}" if start_month != 1 else f"{date.year}"
	label = f"Q{q_index + 1} {fy} ({MONTHS[start.month - 1]} – {MONTHS[end.month - 1]} {end.year})"
	return start, end, label


def build_checklist(audit):
	"""Fill the checklist from the IMS register, legal register and open watch items."""
	audit.set("checklist", [])
	for d in frappe.get_all("IMS Document", filters={"status": "Active", "document_type": ["in", AUDITED_TYPES]},
	                        fields=["name", "document_number", "title", "current_revision", "owner_role", "governing_clause",
	                                "review_status", "document_type"], order_by="owner_role, document_number"):
		note = _("Document review is overdue.") if d.review_status == "Overdue" else ""
		what = _("records are complete and current") if d.document_type == "Register" else _("is implemented and its records are kept")
		audit.append("checklist", {"area": d.owner_role or _("General"), "source_doctype": "IMS Document", "source_name": d.name,
		                           "requirement": f"{d.title} (rev {d.current_revision or '0.0'}) {what}",
		                           "clause": (d.governing_clause or "")[:140], "system_note": note})
	for r in frappe.get_all("Legal Requirement", filters={"compliance_status": ["!=", "Not Applicable"]},
	                        fields=["name", "law_name", "citation", "requirement_description", "compliance_status", "expiry_date",
	                                "licence_permit_filing"], order_by="law_name"):
		notes = [_("Register status: {0}").format(r.compliance_status)] if r.compliance_status else []
		if r.expiry_date and getdate(r.expiry_date) < getdate(today()):
			notes.append(_("Permit expired on {0}").format(r.expiry_date))
		req = f"{r.law_name}" + (f" ({r.citation})" if r.citation else "") + ": " + (r.licence_permit_filing or (r.requirement_description or "")[:160])
		audit.append("checklist", {"area": _("Legal requirements"), "source_doctype": "Legal Requirement", "source_name": r.name,
		                           "requirement": req, "clause": _("Legal requirement"), "system_note": "; ".join(notes)})
	for w in frappe.get_all("Compliance Watch Item", filters={"status": ["!=", "Resolved"]}, fields=["name", "title", "status"]):
		audit.append("checklist", {"area": _("Open compliance issues"), "source_doctype": "Compliance Watch Item", "source_name": w.name,
		                           "requirement": _("Progress on: {0}").format(w.title), "system_note": _("Status: {0}").format(w.status)})


def carry_forward(audit):
	"""Bring open findings from earlier audits into this audit for follow-up."""
	have = {(f.carried_from, f.description) for f in audit.findings}
	prior = frappe.get_all("Internal Audit", filters={"docstatus": 1, "name": ["!=", audit.name or ""]}, pluck="name")
	for name in prior:
		for f in frappe.get_all("Internal Audit Finding", filters={"parent": name, "status": ["!=", "Closed"]},
		                        fields=["finding_no", "finding_type", "area", "clause", "description", "corrective_action",
		                                "action_owner", "due_date", "status"]):
			if (name, f.description) in have:
				continue
			audit.append("findings", {**{k: f[k] for k in ("finding_type", "area", "clause", "description", "corrective_action",
			                                               "action_owner", "due_date", "status")},
			                          "carried_from": name, "finding_no": f"{f.finding_no} ({name})"})


def plan_quarterly_audit():
	"""Daily: make sure the current quarter has an internal audit, and chase overdue ones."""
	start, end, label = quarter_for()
	s = get_settings()
	if not frappe.db.exists("Internal Audit", {"period_from": start, "docstatus": ["<", 2]}):
		lead = (users_with_role("HSE Officer") or users_with_role("Managing Director") or [None])[0]
		if not lead:
			return
		audit = frappe.new_doc("Internal Audit")
		audit.update({"period_from": start, "period_to": end, "lead_auditor": lead,
		              "scheduled_date": add_days(end, -cint(s.get("audit_days_before_quarter_end") or 21)),
		              "procedure_ref": s.get("audit_procedure") or "BC/IMS/020"})
		build_checklist(audit)
		carry_forward(audit)
		audit.flags.ignore_permissions = True
		audit.insert()
		notify(users_with_role("HSE Officer") + users_with_role("Managing Director"), "Internal Audit", audit.name,
		       _("Internal audit planned for {0}, scheduled {1}").format(label, audit.scheduled_date))
	for a in frappe.get_all("Internal Audit", filters={"docstatus": 0, "scheduled_date": ["<", today()]},
	                        fields=["name", "lead_auditor", "quarter"]):
		notify(a.lead_auditor, "Internal Audit", a.name, _("Internal audit {0} ({1}) is past its scheduled date").format(a.name, a.quarter),
		       priority="High")


@frappe.whitelist()
def download_report(name):
	audit = frappe.get_doc("Internal Audit", name)
	audit.check_permission("read")
	from chemical_erp.management_systems.audit_report import build_docx, collect, logo_path

	frappe.local.response.filename = f"Internal Audit Report {audit.name}.docx"
	frappe.local.response.filecontent = build_docx(collect(audit), logo_path(audit))
	frappe.local.response.type = "download"
