# Copyright (c) 2026, Brave Chemicals
# License: MIT. See license.txt
#
# Shows every Active IMS Document, ordered so Overdue appears first,
# then Due Soon, then everything still OK \u2014 a one-screen answer to
# "what needs my attention right now" rather than requiring someone to
# page through the whole document register.

import frappe


def execute(filters=None):
	columns = get_columns()
	data = get_data(filters)
	return columns, data


def get_columns():
	return [
		{"fieldname": "document_number", "label": "Document No.", "fieldtype": "Link",
		 "options": "IMS Document", "width": 130},
		{"fieldname": "title", "label": "Title", "fieldtype": "Data", "width": 260},
		{"fieldname": "series", "label": "Series", "fieldtype": "Link", "options": "IMS Document Series", "width": 100},
		{"fieldname": "owner_role", "label": "Owning Role", "fieldtype": "Data", "width": 120},
		{"fieldname": "review_date", "label": "Next Review Date", "fieldtype": "Date", "width": 120},
		{"fieldname": "days_until_review", "label": "Days", "fieldtype": "Int", "width": 70},
		{"fieldname": "review_status", "label": "Status", "fieldtype": "Data", "width": 100},
	]


def get_data(filters):
	conditions = ["status = 'Active'"]
	values = {}

	if filters and filters.get("series"):
		conditions.append("series = %(series)s")
		values["series"] = filters["series"]

	if filters and filters.get("review_status"):
		conditions.append("review_status = %(review_status)s")
		values["review_status"] = filters["review_status"]

	where_clause = " and ".join(conditions)

	rows = frappe.db.sql(
		f"""
		select document_number, title, series, owner_role,
			review_date, days_until_review, review_status
		from `tabIMS Document`
		where {where_clause}
		order by
			case review_status
				when 'Overdue' then 0
				when 'Due Soon' then 1
				else 2
			end,
			review_date asc
		""",
		values,
		as_dict=True,
	)
	return rows
