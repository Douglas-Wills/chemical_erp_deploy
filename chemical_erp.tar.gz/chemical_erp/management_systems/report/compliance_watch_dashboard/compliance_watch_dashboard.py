# Copyright (c) 2026, Brave Chemicals
# License: MIT. See license.txt
#
# Combines Legal Requirement review status with open Compliance Watch
# Items into a single list, since both represent the same underlying
# question: "is there a legal/compliance matter that needs attention
# right now." Kept as one report rather than two so nothing gets missed
# by only checking one screen.

import frappe


def execute(filters=None):
	columns = get_columns()
	data = get_legal_requirement_rows() + get_watch_item_rows()
	# Overdue/High priority first, matching the ordering principle used
	# throughout Brave Chemicals' own registers (critical items surface
	# first, not buried alphabetically).
	priority_rank = {"Overdue": 0, "High": 0, "Due Soon": 1, "Medium": 1, "OK": 2, "Low": 2, "": 2}
	data.sort(key=lambda r: priority_rank.get(r.get("status_or_priority"), 2))
	return columns, data


def get_columns():
	return [
		{"fieldname": "record_type", "label": "Type", "fieldtype": "Data", "width": 140},
		{"fieldname": "title", "label": "Title", "fieldtype": "Data", "width": 320},
		{"fieldname": "status_or_priority", "label": "Status / Priority", "fieldtype": "Data", "width": 120},
		{"fieldname": "due_date", "label": "Due / Target Date", "fieldtype": "Date", "width": 130},
		{"fieldname": "reference", "label": "Reference", "fieldtype": "Dynamic Link",
		 "options": "reference_doctype", "width": 160},
		{"fieldname": "reference_doctype", "label": "", "fieldtype": "Data", "width": 0, "hidden": 1},
	]


def get_legal_requirement_rows():
	rows = frappe.get_all(
		"Legal Requirement",
		filters={"review_status": ["in", ["Due Soon", "Overdue"]]},
		fields=["name", "law_name", "citation", "review_status", "next_review_date"],
	)
	out = []
	for r in rows:
		label = r.law_name + (f" ({r.citation})" if r.citation else "")
		out.append({
			"record_type": "Legal Requirement",
			"title": label,
			"status_or_priority": r.review_status,
			"due_date": r.next_review_date,
			"reference": r.name,
			"reference_doctype": "Legal Requirement",
		})
	return out


def get_watch_item_rows():
	rows = frappe.get_all(
		"Compliance Watch Item",
		filters={"status": ["!=", "Resolved"]},
		fields=["name", "title", "priority", "target_resolution_date"],
	)
	out = []
	for r in rows:
		out.append({
			"record_type": "Compliance Watch Item",
			"title": r.title,
			"status_or_priority": r.priority,
			"due_date": r.target_resolution_date,
			"reference": r.name,
			"reference_doctype": "Compliance Watch Item",
		})
	return out
