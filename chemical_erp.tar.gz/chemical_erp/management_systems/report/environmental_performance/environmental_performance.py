"""Environmental performance by month: totals per aspect, use per tonne produced, exceedances."""

import frappe
from frappe import _
from frappe.utils import add_months, flt, get_first_day, today


def execute(filters=None):
	f = frappe._dict(filters or {})
	since = get_first_day(f.get("from_date") or add_months(today(), -11))
	rows = frappe.db.sql("""select date_format(reading_date, '%%Y-%%m') m, aspect, unit, sum(value) total, count(*) n,
			sum(within_limit = 'Exceeded') exceeded
		from `tabEnvironmental Reading` where reading_date >= %s group by m, aspect, unit order by m, aspect""", since, as_dict=True)
	made = {r.m: flt(r.kg) for r in frappe.db.sql("""select date_format(se.posting_date, '%%Y-%%m') m, sum(sed.transfer_qty) kg
		from `tabStock Entry` se join `tabStock Entry Detail` sed on sed.parent = se.name
		where se.docstatus=1 and se.purpose='Manufacture' and sed.is_finished_item=1 and se.posting_date >= %s group by m""", since, as_dict=True)}
	data = []
	for r in rows:
		tonnes = made.get(r.m, 0) / 1000
		per = flt(r.total) / tonnes if tonnes and r.aspect in ("Electricity", "Water use", "Fuel (generator and boiler)", "Waste generated") else None
		data.append({"month": r.m, "aspect": r.aspect, "unit": r.unit, "total": r.total, "readings": r.n, "exceeded": r.exceeded,
		             "tonnes": tonnes, "per_tonne": per})
	c = lambda n, l, t="Float", w=120: {"fieldname": n, "label": l, "fieldtype": t, "width": w}
	return [c("month", _("Month"), "Data", 80), c("aspect", _("Aspect"), "Data", 190), c("total", _("Total")), c("unit", _("Unit"), "Data", 70),
	        c("readings", _("Readings"), "Int", 80), c("exceeded", _("Exceedances"), "Int", 100), c("tonnes", _("Produced (t, stock units/1000)")),
	        c("per_tonne", _("Per Tonne Produced"))], data
