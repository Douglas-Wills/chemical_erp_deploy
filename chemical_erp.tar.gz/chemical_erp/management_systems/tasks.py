# Copyright (c) 2026, Brave Chemicals
# License: MIT. See license.txt
#
# Scheduled tasks registered in hooks.py. These are what make this a
# tracking module rather than a static filing cabinet: every day they
# re-check each Active IMS Document and each Legal Requirement against
# today's date, and raise a ToDo the first time something tips into
# "Due Soon" or "Overdue" so it cannot quietly go stale unnoticed.

import frappe
from frappe.utils import today

from chemical_erp.management_systems.doctype.ims_document.ims_document import set_review_flags as set_ims_review_flags
from chemical_erp.management_systems.doctype.legal_requirement.legal_requirement import (
	set_review_flags as set_legal_review_flags,
)


def _raise_todo_once(reference_doctype, reference_name, user, description):
	"""Create a ToDo for `user` pointing at the given document, unless an
	open ToDo already exists for it \u2014 avoids spamming a fresh ToDo every
	single day while something sits in Due Soon/Overdue."""
	if not user:
		return

	existing = frappe.db.exists(
		"ToDo",
		{
			"reference_type": reference_doctype,
			"reference_name": reference_name,
			"allocated_to": user,
			"status": "Open",
		},
	)
	if existing:
		return

	frappe.get_doc(
		{
			"doctype": "ToDo",
			"allocated_to": user,
			"reference_type": reference_doctype,
			"reference_name": reference_name,
			"description": description,
			"priority": "High",
		}
	).insert(ignore_permissions=True)


def flag_documents_due_for_review():
	"""Daily: refresh every Active IMS Document's Review Status, and
	raise a ToDo for its Responsible User the moment it becomes Due Soon
	or Overdue."""
	documents = frappe.get_all(
		"IMS Document",
		filters={"status": "Active"},
		fields=["name"],
	)
	for d in documents:
		doc = frappe.get_doc("IMS Document", d.name)
		set_ims_review_flags(doc)
		doc.save(ignore_permissions=True)

		if doc.review_status in ("Due Soon", "Overdue"):
			_raise_todo_once(
				"IMS Document",
				doc.name,
				doc.responsible_user,
				f"{doc.document_number} \u2014 {doc.title} is {doc.review_status.lower()} "
				f"for review (Next Review Date: {doc.review_date}).",
			)

	frappe.db.commit()


def flag_legal_requirements_due_for_review():
	"""Daily: the same pattern as above, for Legal Requirement records.
	This is the half of the module that specifically tracks legal/
	regulatory compliance updates, as distinct from internal IMS
	document review cycles."""
	requirements = frappe.get_all(
		"Legal Requirement",
		filters={"compliance_status": ["!=", "Non-Compliant"]},
		fields=["name"],
	)
	for r in requirements:
		doc = frappe.get_doc("Legal Requirement", r.name)
		set_legal_review_flags(doc)
		doc.save(ignore_permissions=True)

		if doc.review_status in ("Due Soon", "Overdue"):
			_raise_todo_once(
				"Legal Requirement",
				doc.name,
				doc.responsible_user,
				f"{doc.law_name} ({doc.citation or 'no citation recorded'}) is "
				f"{doc.review_status.lower()} for re-verification against the "
				f"current law (Next Review Date: {doc.next_review_date}).",
			)

	frappe.db.commit()


def send_compliance_digest():
	"""Weekly: email every user who holds the HSE Officer role a single
	consolidated digest of everything currently Due Soon or Overdue,
	plus any open Compliance Watch Item past its target resolution
	date \u2014 the same "don't let it go quiet" principle used for the
	Management Review Action Log in Brave Chemicals' own IMS."""
	recipients = frappe.get_all(
		"Has Role", filters={"role": "HSE Officer", "parenttype": "User"}, fields=["parent"]
	)
	emails = [r.parent for r in recipients if r.parent and r.parent != "Administrator"]
	if not emails:
		return

	overdue_docs = frappe.get_all(
		"IMS Document",
		filters={"review_status": "Overdue", "status": "Active"},
		fields=["document_number", "title", "review_date"],
	)
	due_soon_docs = frappe.get_all(
		"IMS Document",
		filters={"review_status": "Due Soon", "status": "Active"},
		fields=["document_number", "title", "review_date"],
	)
	overdue_legal = frappe.get_all(
		"Legal Requirement",
		filters={"review_status": "Overdue"},
		fields=["law_name", "citation", "next_review_date"],
	)
	open_watch_items = frappe.get_all(
		"Compliance Watch Item",
		filters={"status": ["!=", "Resolved"], "target_resolution_date": ["<", today()]},
		fields=["title", "target_resolution_date", "priority"],
	)

	if not (overdue_docs or due_soon_docs or overdue_legal or open_watch_items):
		return

	message = frappe.render_template(
		"""
		<h3>Management Systems \u2014 Weekly Compliance Digest</h3>
		{% if overdue_docs %}
		<h4>IMS Documents Overdue for Review</h4>
		<ul>{% for d in overdue_docs %}<li>{{ d.document_number }} \u2014 {{ d.title }} (was due {{ d.review_date }})</li>{% endfor %}</ul>
		{% endif %}
		{% if due_soon_docs %}
		<h4>IMS Documents Due Soon</h4>
		<ul>{% for d in due_soon_docs %}<li>{{ d.document_number }} \u2014 {{ d.title }} (due {{ d.review_date }})</li>{% endfor %}</ul>
		{% endif %}
		{% if overdue_legal %}
		<h4>Legal Requirements Overdue for Re-Verification</h4>
		<ul>{% for l in overdue_legal %}<li>{{ l.law_name }} {{ l.citation or "" }} (was due {{ l.next_review_date }})</li>{% endfor %}</ul>
		{% endif %}
		{% if open_watch_items %}
		<h4>Compliance Watch Items Past Target Resolution Date</h4>
		<ul>{% for w in open_watch_items %}<li>[{{ w.priority }}] {{ w.title }} (target was {{ w.target_resolution_date }})</li>{% endfor %}</ul>
		{% endif %}
		""",
		{
			"overdue_docs": overdue_docs,
			"due_soon_docs": due_soon_docs,
			"overdue_legal": overdue_legal,
			"open_watch_items": open_watch_items,
		},
	)

	frappe.sendmail(
		recipients=emails,
		subject="Management Systems: Weekly Compliance Digest",
		message=message,
	)
