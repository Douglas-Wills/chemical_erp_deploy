from frappe.model.document import Document


class ManagementReviewAction(Document):
	pass
