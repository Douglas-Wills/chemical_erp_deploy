import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt


class EnvironmentalReading(Document):
	def validate(self):
		if self.limit_min in (None, 0) and self.limit_max in (None, 0):
			self.within_limit = "No limit"
		else:
			v = flt(self.value)
			over = (flt(self.limit_max) and v > flt(self.limit_max)) or (flt(self.limit_min) and v < flt(self.limit_min))
			self.within_limit = "Exceeded" if over else "Within limit"
		if self.within_limit == "Exceeded" and not self.is_new() and not (self.action or "").strip():
			frappe.msgprint(_("Record the action taken for this exceedance."), indicator="orange", alert=True)

	def after_insert(self):
		if self.within_limit == "Exceeded":
			from chemical_erp.people_management.positions import md_users
			from chemical_erp.utils import notify, users_with_role

			notify(md_users() + users_with_role("HSE Officer"), self.doctype, self.name,
			       _("{0} {1} at {2}: {3} {4}, outside the limit.").format(self.aspect, self.parameter or "", self.location or "-", self.value,
			                                                              self.unit or ""), priority="High")
