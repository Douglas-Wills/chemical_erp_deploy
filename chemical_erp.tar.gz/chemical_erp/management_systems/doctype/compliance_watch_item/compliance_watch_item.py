# Copyright (c) 2026, Brave Chemicals
# License: MIT. See license.txt

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import today


class ComplianceWatchItem(Document):
	def validate(self):
		if self.status == "Resolved" and not self.date_resolved:
			self.date_resolved = today()
		if self.status != "Resolved" and self.date_resolved:
			# Don't silently keep a resolved-date on a reopened item.
			self.date_resolved = None
		if self.status == "Resolved" and not self.resolution_notes:
			frappe.msgprint(
				_("Consider recording how this was resolved in Resolution Notes."),
				indicator="orange",
				alert=True,
			)
