# Copyright (c) 2026, Brave Chemicals
# License: MIT. See license.txt

from frappe.model.document import Document
from frappe.utils import add_months, date_diff, getdate, today

DUE_SOON_WINDOW_DAYS = 60


class LegalRequirement(Document):
	def validate(self):
		self.set_default_review_date()
		self.refresh_review_status()

	def set_default_review_date(self):
		if not self.next_review_date and self.last_verified_date:
			months = self.review_frequency_months or 12
			self.next_review_date = add_months(getdate(self.last_verified_date), months)

	def refresh_review_status(self):
		if not self.next_review_date:
			self.review_status = ""
			self.days_until_review = 0
			return

		days = date_diff(getdate(self.next_review_date), getdate(today()))
		self.days_until_review = days

		if days < 0:
			self.review_status = "Overdue"
		elif days <= DUE_SOON_WINDOW_DAYS:
			self.review_status = "Due Soon"
		else:
			self.review_status = "OK"


def set_review_flags(doc, method=None):
	"""Hook target used from hooks.py doc_events, and reused by the
	daily scheduled task in tasks.py."""
	doc.set_default_review_date()
	doc.refresh_review_status()
