from frappe.model.document import Document


class InternalAuditTeamMember(Document):
	pass
