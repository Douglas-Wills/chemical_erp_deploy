from frappe.model.document import Document

from chemical_erp.management_systems.management import achieved


class QualityObjective(Document):
	def validate(self):
		for m in self.measurements:
			m.achieved = 1 if achieved(self, m.value) else 0
		if self.measurements:
			latest = sorted(self.measurements, key=lambda m: (m.measured_on or "", m.idx))[-1]
			self.latest_value, self.on_target = latest.value, latest.achieved
