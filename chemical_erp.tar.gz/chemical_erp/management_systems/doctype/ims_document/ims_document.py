# Copyright (c) 2026, Brave Chemicals
# License: MIT. See license.txt

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_months, date_diff, getdate, today

# A document within this many days of its Next Review Date is flagged
# "Due Soon" rather than left showing "OK" until the day it tips over
# into "Overdue". Matches the spirit of the house review cadence used
# throughout Brave Chemicals' own procedures (reviewed ~annually, with
# earlier review for higher-risk/HSE-Officer-owned areas).
DUE_SOON_WINDOW_DAYS = 60


class IMSDocument(Document):
	def validate(self):
		self.set_default_review_date()
		self.refresh_review_status()
		self.validate_legal_requirement_link()

	def set_default_review_date(self):
		"""If no Next Review Date was entered, compute one from the
		Effective Date and the Review Frequency, consistent with how
		Brave Chemicals' own procedures set an Expected Review Date
		when they are first issued."""
		if not self.review_date and self.effective_date:
			months = self.review_frequency_months or 12
			self.review_date = add_months(getdate(self.effective_date), months)

	def refresh_review_status(self):
		"""Keep Review Status and Days Until Review in sync with today's
		date every time the record is saved. The daily scheduled task
		(see tasks.py) re-saves every active document so this also stays
		correct between manual edits, not only when someone opens the
		record."""
		if not self.review_date:
			self.review_status = ""
			self.days_until_review = 0
			return

		days = date_diff(getdate(self.review_date), getdate(today()))
		self.days_until_review = days

		if days < 0:
			self.review_status = "Overdue"
		elif days <= DUE_SOON_WINDOW_DAYS:
			self.review_status = "Due Soon"
		else:
			self.review_status = "OK"

	def validate_legal_requirement_link(self):
		if self.is_legally_mandated and not self.linked_legal_requirement:
			frappe.msgprint(
				_(
					"This document is marked as legally mandated but has no "
					"Linked Legal Requirement. Consider linking the specific "
					"statute/regulation so compliance tracking stays accurate."
				),
				indicator="orange",
				alert=True,
			)


def set_review_flags(doc, method=None):
	"""Hook target used from hooks.py doc_events — kept as a thin wrapper
	so the scheduled task (tasks.py) can call the same logic on a bare
	Document instance without re-importing the class name."""
	doc.set_default_review_date()
	doc.refresh_review_status()
