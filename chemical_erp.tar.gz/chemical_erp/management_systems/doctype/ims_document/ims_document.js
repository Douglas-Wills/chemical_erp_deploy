// Copyright (c) 2026, Brave Chemicals
// License: MIT. See license.txt

frappe.ui.form.on("IMS Document", {
	refresh(frm) {
		// Surface the review status as a coloured indicator next to the
		// title, so an overdue or soon-due document is obvious without
		// opening the record.
		if (frm.doc.review_status === "Overdue") {
			frm.dashboard.set_headline_alert(
				__("This document is overdue for review ({0} days).", [Math.abs(frm.doc.days_until_review)]),
				"red"
			);
		} else if (frm.doc.review_status === "Due Soon") {
			frm.dashboard.set_headline_alert(
				__("Due for review in {0} days.", [frm.doc.days_until_review]),
				"orange"
			);
		}
	},
});

// List view colour-coding: Active/OK documents stay neutral, anything
// Due Soon or Overdue stands out immediately in the document register.
frappe.listview_settings["IMS Document"] = {
	add_fields: ["review_status", "status"],
	get_indicator(doc) {
		if (doc.status === "Withdrawn") {
			return [__("Withdrawn"), "darkgrey", "status,=,Withdrawn"];
		}
		if (doc.status === "Superseded") {
			return [__("Superseded"), "grey", "status,=,Superseded"];
		}
		if (doc.review_status === "Overdue") {
			return [__("Review Overdue"), "red", "review_status,=,Overdue"];
		}
		if (doc.review_status === "Due Soon") {
			return [__("Due Soon"), "orange", "review_status,=,Due Soon"];
		}
		return [__("Active"), "green", "status,=,Active"];
	},
};
