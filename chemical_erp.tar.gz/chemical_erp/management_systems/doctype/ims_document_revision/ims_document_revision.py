# Copyright (c) 2026, Brave Chemicals
# License: MIT. See license.txt

from frappe.model.document import Document


class IMSDocumentRevision(Document):
	pass
