import frappe
from frappe import _
from frappe.model.document import Document

from chemical_erp.management_systems.management import compile_inputs


class ManagementReview(Document):
	def before_submit(self):
		if not self.decisions:
			frappe.throw(_("Record the decisions before the review is approved."))

	@frappe.whitelist()
	def compile(self):
		self.inputs = compile_inputs(self)
		self.save()
		return True
