frappe.ui.form.on("Management Review", {
	refresh(frm) {
		if (frm.doc.docstatus === 0 && !frm.is_new()) {
			frm.add_custom_button(__("Compile Inputs from the System"), () =>
				frm.call({ doc: frm.doc, method: "compile", freeze: true }).then(() => frm.reload_doc())).addClass("btn-primary");
		}
	},
});
