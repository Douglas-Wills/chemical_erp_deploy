from frappe.model.document import Document


class ObjectiveMeasurement(Document):
	pass
