from frappe.model.document import Document


class InternalAuditChecklistItem(Document):
	pass
