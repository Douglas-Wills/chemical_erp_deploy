from frappe.model.document import Document


class ReviewAttendee(Document):
	pass
