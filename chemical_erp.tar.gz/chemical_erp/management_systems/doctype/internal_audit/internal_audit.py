import frappe
from frappe import _
from frappe.model.document import Document

from chemical_erp.management_systems.audit import NONCONFORMING, build_checklist, carry_forward, quarter_for


class InternalAudit(Document):
	def validate(self):
		start, end, label = quarter_for(self.period_from)
		self.period_from, self.period_to, self.quarter = start, end, label
		self.title = _("Internal Audit {0}").format(label)
		self.check_independence()
		self.raise_findings()
		self.summarise()
		if self.docstatus == 0:
			self.audit_status = "In Progress" if any(r.result for r in self.checklist) else "Planned"

	def check_independence(self):
		"""Auditors must not audit their own area (BC/IMS/020)."""
		for row in self.checklist:
			if not (row.auditor and row.area):
				continue
			held = frappe.get_all("Position Holder", filters={"user": row.auditor, "parenttype": "Company Position"}, pluck="parent")
			for pos in held:
				if pos.lower() in row.area.lower():
					frappe.throw(_("Row {0}: {1} holds the {2} post and cannot audit their own area ({3}). Assign another auditor.").format(
						row.idx, frappe.utils.get_fullname(row.auditor), pos, row.area), title=_("Auditor independence"))

	def raise_findings(self):
		for row in self.checklist:
			if not row.name:
				row.name = frappe.generate_hash(length=10)  # stable link from finding to checklist row before first save
		existing = {f.checklist_row for f in self.findings if f.checklist_row}
		for row in self.checklist:
			if row.result in NONCONFORMING and row.name not in existing:
				self.append("findings", {"finding_type": row.result, "area": row.area, "clause": row.clause or row.source_name,
				                         "description": row.evidence or row.requirement, "evidence": row.evidence,
				                         "checklist_row": row.name, "status": "Open"})
		# drop findings whose checklist row no longer shows a finding
		keep = []
		for f in self.findings:
			row = next((r for r in self.checklist if r.name == f.checklist_row), None) if f.checklist_row else None
			if f.checklist_row and (not row or row.result not in NONCONFORMING) and self.docstatus == 0:
				continue
			keep.append(f)
		self.set("findings", keep)
		n = 0
		for f in self.findings:
			if not f.carried_from:
				n += 1
				f.finding_no = f"F-{n:02d}"

	def summarise(self):
		counts = {}
		for r in self.checklist:
			counts[r.result or "Not Audited"] = counts.get(r.result or "Not Audited", 0) + 1
		self.items_audited = sum(v for k, v in counts.items() if k != "Not Audited")
		self.conforming = sum(counts.get(k, 0) for k in ("Conforms", "Observation", "Opportunity for Improvement"))
		self.major_nc = counts.get("Major Nonconformity", 0)
		self.minor_nc = counts.get("Minor Nonconformity", 0)
		self.observations = counts.get("Observation", 0)
		self.ofis = counts.get("Opportunity for Improvement", 0)
		self.compliance_score = round(self.conforming / self.items_audited * 100, 1) if self.items_audited else 0
		self.open_findings = sum(1 for f in self.findings if f.status != "Closed")

	def before_submit(self):
		if not self.items_audited:
			frappe.throw(_("Record the results of the checklist before issuing the report."))
		missing = [f.finding_no for f in self.findings if f.finding_type in ("Major Nonconformity", "Minor Nonconformity")
		           and not f.carried_from and not (f.corrective_action and f.action_owner and f.due_date)]
		if missing:
			frappe.throw(_("Give every nonconformity a corrective action, owner and due date before issuing: {0}").format(", ".join(missing)))
		if not self.conclusion:
			frappe.throw(_("Write the conclusion before issuing the report."))

	def on_submit(self):
		self.db_set("audit_status", "Report Issued")
		from chemical_erp.utils import notify

		for f in self.findings:
			if f.action_owner and f.status != "Closed":
				notify(f.action_owner, self.doctype, self.name,
				       _("Audit finding {0} ({1}): {2} Due {3}").format(f.finding_no, f.finding_type, f.corrective_action or "", f.due_date or ""))

	def on_update_after_submit(self):
		self.summarise()
		for f in self.findings:
			if f.status == "Closed" and not f.verified_by:
				frappe.throw(_("Finding {0}: record who verified the corrective action before closing it.").format(f.finding_no))
		self.db_set({"open_findings": self.open_findings,
		             "audit_status": "Closed" if not self.open_findings else "Report Issued"})

	@frappe.whitelist()
	def load_checklist(self):
		if self.docstatus != 0:
			frappe.throw(_("The checklist is fixed once the report is issued."))
		build_checklist(self)
		carry_forward(self)
		return len(self.checklist)
