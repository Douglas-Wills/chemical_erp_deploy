frappe.ui.form.on("Internal Audit", {
	refresh(frm) {
		if (!frm.is_new()) {
			frm.add_custom_button(__("Download Word Report"), () => {
				if (frm.is_dirty()) return frappe.msgprint(__("Save first, then download."));
				window.open(frappe.urllib.get_full_url(
					`/api/method/chemical_erp.management_systems.audit.download_report?name=${encodeURIComponent(frm.doc.name)}`));
			}).addClass("btn-primary");
		}
		if (frm.doc.docstatus === 0 && !frm.is_new()) {
			frm.add_custom_button(__("Rebuild Checklist from IMS Register"), () =>
				frappe.confirm(__("Replace the checklist with a fresh one from the IMS register? Results already entered will be lost."), () =>
					frm.call({ doc: frm.doc, method: "load_checklist", freeze: true }).then((r) => {
						frm.dirty(); frm.refresh();
						frappe.show_alert({ message: __("{0} checklist items loaded", [r.message]), indicator: "green" });
					})), __("Actions"));
		}
		const c = { Planned: "blue", "In Progress": "orange", "Report Issued": "purple", Closed: "green" }[frm.doc.audit_status];
		if (frm.doc.audit_status) frm.dashboard.set_headline_alert(
			__("{0}: compliance {1}%, {2} open finding(s)", [frm.doc.audit_status, frm.doc.compliance_score || 0, frm.doc.open_findings || 0]), c);
	},
});
