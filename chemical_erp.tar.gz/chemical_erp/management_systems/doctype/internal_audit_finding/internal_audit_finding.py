from frappe.model.document import Document


class InternalAuditFinding(Document):
	pass
