from frappe.model.document import Document
from frappe.utils import cint

from chemical_erp.management_systems.management import risk_level


class IMSRisk(Document):
	def validate(self):
		self.score = cint(self.likelihood) * cint(self.impact)
		self.level = risk_level(self.score)
		self.residual_score = cint(self.residual_likelihood) * cint(self.residual_impact)
		self.residual_level = risk_level(self.residual_score)
