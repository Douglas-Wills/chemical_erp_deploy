"""Operational gates from the legal register: a lapsed permit warns on, or blocks, the operation it governs.

A Legal Requirement with an expiry date and `Checked On` set (Disposal, Delivery or Production)
is checked whenever that operation runs. `When Lapsed` decides whether the user is warned or stopped.
"""

import frappe
from frappe import _
from frappe.utils import today


def lapsed(operation):
	return frappe.get_all(
		"Legal Requirement",
		filters={"enforced_on": operation, "expiry_date": ["<", today()], "compliance_status": ["!=", "Not Applicable"]},
		fields=["name", "law_name", "licence_permit_filing", "expiry_date", "enforcement"],
	)


def check(operation):
	rows = lapsed(operation)
	if not rows:
		return
	blocks = [r for r in rows if r.enforcement == "Block"]
	lines = [_("{0} ({1}) expired on {2}").format(r.licence_permit_filing or r.law_name, r.name, r.expiry_date) for r in rows]
	if blocks:
		frappe.throw(_("{0} is stopped because a required permit has lapsed:").format(_(operation)) + "<br>" + "<br>".join(lines),
		             title=_("Permit lapsed"))
	frappe.msgprint("<br>".join(lines), title=_("Permit lapsed: {0} allowed with warning").format(_(operation)), indicator="orange")
