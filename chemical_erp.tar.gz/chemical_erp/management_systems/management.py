"""Management review inputs, objective measurements and risk scoring."""

import frappe
from frappe import _
from frappe.utils import add_days, flt, get_first_day, get_last_day, getdate, today


def risk_level(score):
	score = int(score or 0)
	return "Critical" if score >= 15 else "High" if score >= 10 else "Medium" if score >= 5 else "Low" if score else ""


# ------------------------------------------------------------------ objective measures
def measure(source, start, end):
	"""Value of a built-in measure for a period. None for manual objectives."""
	between = ["between", [start, end]]
	if source == "Customer complaints (count)":
		return frappe.db.count("Customer Complaint", {"received_on": between})
	if source == "Lost-time injuries (count)":
		return frappe.db.count("HSE Incident", {"occurred_on": between, "lost_time": 1})
	if source == "HSE incidents (count)":
		return frappe.db.count("HSE Incident", {"occurred_on": between})
	if source == "Internal audit compliance score (%)":
		v = frappe.db.get_value("Internal Audit", {"docstatus": 1, "period_to": ["<=", end]}, "compliance_score", order_by="period_to desc")
		return flt(v) if v is not None else None
	if source == "Batches rejected (%)":
		total = frappe.db.count("Quality Inspection", {"docstatus": 1, "report_date": between})
		rejected = frappe.db.count("Quality Inspection", {"docstatus": 1, "report_date": between, "status": "Rejected"})
		return flt(rejected / total * 100, 1) if total else 0
	if source == "On-time deliveries (%)":
		rows = frappe.db.sql("""select dn.posting_date, max(so.delivery_date) due from `tabDelivery Note` dn
			join `tabDelivery Note Item` dni on dni.parent = dn.name left join `tabSales Order` so on so.name = dni.against_sales_order
			where dn.docstatus = 1 and dn.is_return = 0 and dn.posting_date between %s and %s group by dn.name""", (start, end), as_dict=True)
		return flt(sum(1 for r in rows if not r.due or r.posting_date <= r.due) / len(rows) * 100, 1) if rows else None
	if source == "Average supplier score (%)":
		v = frappe.db.sql("select avg(total_score) from `tabSupplier Evaluation` where docstatus=1 and period_to between %s and %s", (start, end))
		return flt(v[0][0], 1) if v and v[0][0] is not None else None
	if source == "Open audit findings (count)":
		return frappe.db.count("Internal Audit Finding", {"parenttype": "Internal Audit", "status": ["!=", "Closed"]})
	return None


def achieved(obj, value):
	if value is None:
		return False
	return value <= flt(obj.target) if obj.direction == "At or below target" else value >= flt(obj.target)


def record_measurements():
	"""Monthly (1st of the month): measure last month for every objective with a built-in measure."""
	end = add_days(get_first_day(today()), -1)
	start = get_first_day(end)
	period = end.strftime("%B %Y")
	for name in frappe.get_all("Quality Objective", filters={"measure": ["!=", "Manual"]}, pluck="name"):
		obj = frappe.get_doc("Quality Objective", name)
		if obj.frequency == "Quarterly" and end.month % 3:
			continue
		if any(m.period == period for m in obj.measurements):
			continue
		value = measure(obj.measure, start if obj.frequency == "Monthly" else get_first_day(add_days(start, -62)), end)
		if value is None:
			continue
		obj.append("measurements", {"period": period, "measured_on": today(), "value": value, "source": obj.measure})
		obj.flags.ignore_permissions = True
		obj.save()


# ------------------------------------------------------------------ management review inputs
def compile_inputs(review):
	s, e = review.period_from, review.period_to
	between = ["between", [s, e]]
	parts = []

	def section(title, lines):
		parts.append(f"<h4>{title}</h4><ul>" + "".join(f"<li>{frappe.utils.escape_html(l)}</li>" for l in lines) + "</ul>")

	prev = frappe.get_all("Management Review Action", filters={"parenttype": "Management Review", "parent": ["!=", review.name or ""]},
	                      fields=["action", "status", "parent"])
	section(_("Actions from earlier reviews"), [f"{a.action} ({a.parent}): {a.status}" for a in prev] or [_("None recorded.")])
	audits = frappe.get_all("Internal Audit", filters={"docstatus": 1, "period_to": between},
	                        fields=["name", "quarter", "compliance_score", "major_nc", "minor_nc", "open_findings"])
	section(_("Internal audit results"), [f"{a.quarter}: score {a.compliance_score}%, {a.major_nc} major / {a.minor_nc} minor NCs, {a.open_findings} open finding(s)" for a in audits] or [_("No audit issued in the period.")])
	comp = frappe.get_all("Customer Complaint", filters={"received_on": between}, fields=["complaint_type", "justified", "status"])
	section(_("Customer feedback and complaints"), [
		_("{0} complaint(s): {1} justified, {2} still open.").format(len(comp), sum(1 for c in comp if c.justified == "Justified"),
		                                                              sum(1 for c in comp if c.status != "Closed"))] +
	        [f"{t}: {sum(1 for c in comp if c.complaint_type == t)}" for t in sorted({c.complaint_type for c in comp})])
	inc = frappe.get_all("HSE Incident", filters={"occurred_on": between}, fields=["incident_type", "lost_time", "severity"])
	section(_("Health, safety and environment"), [
		_("{0} incident(s), {1} lost-time injury(ies), {2} high or critical.").format(len(inc), sum(1 for i in inc if i.lost_time),
		                                                                            sum(1 for i in inc if i.severity in ("High", "Critical")))])
	objs = frappe.get_all("Quality Objective", fields=["objective", "target", "latest_value", "on_target"])
	section(_("Objectives"), [f"{o.objective}: latest {o.latest_value} against target {o.target} ({'on target' if o.on_target else 'off target'})" for o in objs] or [_("No objectives set.")])
	sup = frappe.get_all("Supplier Evaluation", filters={"docstatus": 1, "period_to": between}, fields=["supplier", "rating", "total_score"])
	section(_("External providers (suppliers)"), [f"{x.supplier}: {x.rating} ({x.total_score}%)" for x in sup] or [_("No evaluations in the period.")])
	qis = frappe.db.count("Quality Inspection", {"docstatus": 1, "report_date": between})
	rej = frappe.db.count("Quality Inspection", {"docstatus": 1, "report_date": between, "status": "Rejected"})
	section(_("Process performance and product conformity"), [_("{0} inspections, {1} rejected.").format(qis, rej)])
	risks = frappe.get_all("IMS Risk", filters={"status": "Open", "level": ["in", ["High", "Critical"]]}, fields=["title", "level"])
	section(_("Risks and opportunities"), [f"{r.title} ({r.level})" for r in risks] or [_("No high or critical risks open.")])
	legal = frappe.db.count("Legal Requirement", {"compliance_status": ["in", ["Non-Compliant", "Partially Compliant"]]})
	section(_("Compliance obligations"), [_("{0} legal requirement(s) not fully compliant.").format(legal)])
	return "".join(parts)
