"""Internal Audit Report as a Microsoft Word document (form BC/HSE/006).

`build_docx(data, logo_path)` is pure: it takes a plain dict and returns .docx bytes, so it can be
tested without a site. `collect(audit)` gathers that dict from an Internal Audit record.
House style: Arial throughout, 11pt body with 1.15 line spacing, navy headings.
"""

import io
from collections import OrderedDict

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

NAVY = RGBColor(0x1F, 0x38, 0x64)
RED = RGBColor(0xB3, 0x26, 0x1E)
AMBER = RGBColor(0x9A, 0x5B, 0x00)
GREEN = RGBColor(0x2A, 0x6A, 0x4A)
GREY = RGBColor(0x55, 0x5F, 0x6B)
RESULT_COLOUR = {"Major Nonconformity": RED, "Minor Nonconformity": RED, "Observation": AMBER,
                 "Opportunity for Improvement": AMBER, "Conforms": GREEN, "Not Audited": GREY}
TYPE_ORDER = ["Conforms", "Observation", "Opportunity for Improvement", "Minor Nonconformity", "Major Nonconformity", "Not Audited"]


# ------------------------------------------------------------------ low-level helpers
from chemical_erp.tenders_desk.bid_document import _font  # noqa: E402  (one shared copy)

def _shade(cell, hex_fill):
	tc_pr = cell._element.get_or_add_tcPr()
	shd = OxmlElement("w:shd")
	shd.set(qn("w:val"), "clear")
	shd.set(qn("w:color"), "auto")
	shd.set(qn("w:fill"), hex_fill)
	tc_pr.append(shd)


def _cell_text(cell, text, size=10, bold=False, color=None, align=None):
	cell.text = ""
	p = cell.paragraphs[0]
	p.paragraph_format.space_after = Pt(0)
	p.paragraph_format.line_spacing = 1.0
	if align:
		p.alignment = align
	lines = str(text if text is not None else "").split("\n")
	for i, line in enumerate(lines):
		if i:
			p = cell.add_paragraph()
			p.paragraph_format.space_after = Pt(0)
		_font(p.add_run(line), size=size, bold=bold, color=color)


def _widths(table, widths_cm):
	"""Word reads cell widths, LibreOffice and Google Docs read the grid: set both."""
	table.autofit = False
	tbl_pr = table._tbl.tblPr
	layout = OxmlElement("w:tblLayout")
	layout.set(qn("w:type"), "fixed")
	tbl_pr.append(layout)
	for i, w in enumerate(widths_cm):
		table.columns[i].width = Cm(w)
		for cell in table.columns[i].cells:
			cell.width = Cm(w)


def _repeat_header(row):
	tr_pr = row._tr.get_or_add_trPr()
	el = OxmlElement("w:tblHeader")
	el.set(qn("w:val"), "true")
	tr_pr.append(el)


def _table(doc, headers, rows, widths_cm, size=10, colour_col=None):
	t = doc.add_table(rows=1, cols=len(headers))
	t.style = "Table Grid"
	t.alignment = WD_TABLE_ALIGNMENT.CENTER
	t.autofit = False
	hdr = t.rows[0]
	_repeat_header(hdr)
	for i, h in enumerate(headers):
		_cell_text(hdr.cells[i], h, size=size, bold=True, color=RGBColor(0xFF, 0xFF, 0xFF))
		_shade(hdr.cells[i], "1F3864")
	for r in rows:
		new_row = t.add_row()
		no_split = OxmlElement("w:cantSplit")
		no_split.set(qn("w:val"), "true")
		new_row._tr.get_or_add_trPr().append(no_split)
		cells = new_row.cells
		for i, val in enumerate(r):
			color = RESULT_COLOUR.get(str(val)) if colour_col is not None and i == colour_col else None
			_cell_text(cells[i], val, size=size, bold=bool(color and color in (RED,)), color=color)
	_widths(t, widths_cm)
	doc.add_paragraph().paragraph_format.space_after = Pt(2)
	return t


def _kv_table(doc, pairs, widths=(5.0, 11.5)):
	t = doc.add_table(rows=0, cols=2)
	t.style = "Table Grid"
	t.autofit = False
	for k, v in pairs:
		cells = t.add_row().cells
		_cell_text(cells[0], k, bold=True)
		_shade(cells[0], "EEF1F6")
		_cell_text(cells[1], v)
	_widths(t, widths)
	doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _heading(doc, text, level=1):
	p = doc.add_paragraph()
	p.paragraph_format.space_before = Pt(12 if level == 1 else 8)
	p.paragraph_format.space_after = Pt(4)
	p.paragraph_format.keep_with_next = True
	p.style = doc.styles["Heading 1" if level == 1 else "Heading 2"]
	_font(p.add_run(text), size=13 if level == 1 else 11.5, bold=True, color=NAVY)
	return p


def _para(doc, text, bold=False, italic=False, color=None, size=11):
	p = doc.add_paragraph()
	_font(p.add_run(text), size=size, bold=bold, italic=italic, color=color)
	return p


def _field(paragraph, instr):
	def part(kind=None, text=None, result=None):
		run = _font(paragraph.add_run(), size=8.5, color=GREY)
		if kind:
			el = OxmlElement("w:fldChar")
			el.set(qn("w:fldCharType"), kind)
			run._r.append(el)
		elif text:
			el = OxmlElement("w:instrText")
			el.set(qn("xml:space"), "preserve")
			el.text = text
			run._r.append(el)
		else:
			run.text = result

	part("begin")
	part(text=f" {instr} ")
	part("separate")
	part(result="1")
	part("end")


# ------------------------------------------------------------------ the report
def build_docx(d, logo_path=None):
	doc = Document()
	sec = doc.sections[0]
	sec.orientation = WD_ORIENT.PORTRAIT
	sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
	sec.top_margin = sec.bottom_margin = Cm(2.0)
	sec.left_margin = sec.right_margin = Cm(2.2)

	normal = doc.styles["Normal"]
	normal.font.name = "Arial"
	normal.font.size = Pt(11)
	normal.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), "Arial")
	normal.paragraph_format.line_spacing = 1.15
	normal.paragraph_format.space_after = Pt(6)
	for name in ("Heading 1", "Heading 2", "Table Grid"):
		st = doc.styles[name]
		st.font.name = "Arial"
		if name.startswith("Heading"):
			st.font.color.rgb = NAVY

	# Header: logo left, company right
	ht = sec.header.add_table(rows=1, cols=2, width=Cm(16.6))
	_widths(ht, (4.0, 12.6))
	left, right = ht.rows[0].cells
	if logo_path:
		try:
			left.paragraphs[0].add_run().add_picture(logo_path, height=Cm(1.5))
		except Exception:
			pass
	rp = right.paragraphs[0]
	rp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
	_font(rp.add_run(d.get("company_name", "")), size=12, bold=True, color=NAVY)
	for line in d.get("company_lines", []):
		p = right.add_paragraph()
		p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
		p.paragraph_format.space_after = Pt(0)
		_font(p.add_run(line), size=8.5)
	sec.header.paragraphs[0].text = ""

	# Footer: form reference and page x of y
	fp = sec.footer.paragraphs[0]
	fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
	_font(fp.add_run(f"{d.get('form_ref', 'BC/HSE/006')} Internal Audit Checklist and Report Form  |  Report {d['name']}  |  Page "),
	      size=8.5, color=GREY)
	_field(fp, "PAGE")
	_font(fp.add_run(" of "), size=8.5, color=GREY)
	_field(fp, "NUMPAGES")

	# Title block
	t = doc.add_paragraph()
	t.alignment = WD_ALIGN_PARAGRAPH.CENTER
	t.paragraph_format.space_before = Pt(6)
	t.paragraph_format.space_after = Pt(2)
	_font(t.add_run("INTERNAL AUDIT REPORT"), size=17, bold=True, color=NAVY)
	s = doc.add_paragraph()
	s.alignment = WD_ALIGN_PARAGRAPH.CENTER
	_font(s.add_run(f"Integrated Management System  ·  {d['quarter']}"), size=11, color=GREY)
	if d.get("status") != "Report Issued" and d.get("status") != "Closed":
		w = doc.add_paragraph()
		w.alignment = WD_ALIGN_PARAGRAPH.CENTER
		_font(w.add_run("DRAFT: not yet approved by the Managing Director"), size=10, bold=True, color=RED)

	_kv_table(doc, [
		("Report No.", d["name"]),
		("Quarter audited", f"{d['quarter']} ({d['period_from']} to {d['period_to']})"),
		("Audit date(s)", d.get("audit_dates") or "Not yet recorded"),
		("Audit criteria", d.get("standards", "")),
		("Procedure followed", d.get("procedure_ref", "BC/IMS/020")),
		("Lead auditor", d.get("lead_auditor", "")),
		("Audit team", d.get("team", "") or "Lead auditor only"),
		("Areas audited", ", ".join(d.get("areas", [])) or "None"),
		("Report status", d.get("status", "")),
	])

	# 1. Objective and scope
	_heading(doc, "1. Objective and scope")
	_para(doc, d.get("scope", ""))

	# 2. Executive summary
	_heading(doc, "2. Executive summary")
	c = d["counts"]
	audited = d["items_audited"]
	score = d["score"]
	_para(doc, (f"{audited} requirement(s) were audited across {len(d.get('areas', []))} area(s). "
	            f"The overall compliance score is {score:.0f}%, with {c.get('Major Nonconformity', 0)} major and "
	            f"{c.get('Minor Nonconformity', 0)} minor nonconformities, {c.get('Observation', 0)} observation(s) and "
	            f"{c.get('Opportunity for Improvement', 0)} opportunit{'y' if c.get('Opportunity for Improvement', 0) == 1 else 'ies'} for improvement."))
	_table(doc, ["Result", "Number of requirements"],
	       [(k, c.get(k, 0)) for k in TYPE_ORDER] + [("Compliance score", f"{score:.0f}%")], [9.0, 7.6], colour_col=0)
	if d.get("verdict"):
		_para(doc, d["verdict"], bold=True, color=RED if c.get("Major Nonconformity") else NAVY)

	# 3. Follow-up of previous findings
	_heading(doc, "3. Follow-up of previous audit findings")
	if d.get("carried"):
		_table(doc, ["No.", "From audit", "Finding", "Corrective action", "Status"],
		       [(f["no"], f["from"], f["description"], f.get("action") or "", f["status"]) for f in d["carried"]],
		       [1.3, 2.4, 6.0, 4.9, 2.0])
	else:
		_para(doc, "No findings from earlier audits remained open at the start of this audit.", italic=True)

	# 4. Results by area
	_heading(doc, "4. Audit results by area")
	if not d.get("by_area"):
		_para(doc, "No checklist items have been recorded yet.", italic=True)
	for area, items in d.get("by_area", {}).items():
		_heading(doc, area, level=2)
		_table(doc, ["Ref.", "Requirement / clause", "Evidence seen", "Result"],
		       [(i["ref"], i["requirement"] + (f"\n{i['clause']}" if i.get("clause") else ""), i.get("evidence") or "",
		         i.get("result") or "Not Audited") for i in items],
		       [2.4, 6.6, 4.8, 2.8], size=9.5, colour_col=3)

	# 5. Findings and corrective actions
	_heading(doc, "5. Findings and corrective actions")
	ncs = [f for f in d.get("findings", []) if not f.get("carried")]
	if ncs:
		_table(doc, ["No.", "Type", "Area / clause", "Finding", "Corrective action", "Owner, due date, status"],
		       [(f["no"], f["type"], f["area"] + (f"\n{f['clause']}" if f.get("clause") else ""), f["description"],
		         f.get("action") or "", "\n".join(x for x in (f.get("owner"), f.get("due") and f"Due {f['due']}", f["status"]) if x))
		        for f in ncs],
		       [1.2, 3.0, 2.4, 3.6, 3.5, 2.9], size=9, colour_col=1)
	else:
		_para(doc, "No nonconformities, observations or opportunities for improvement were raised.", italic=True)

	# 6. Conclusion
	_heading(doc, "6. Conclusion and recommendations")
	_para(doc, d.get("conclusion") or "To be completed by the lead auditor.")

	# 7. Approval and distribution
	_heading(doc, "7. Approval and distribution")
	t = _table(doc, ["", "Name", "Position", "Date", "Signature"],
	           [("Prepared by", d.get("lead_auditor", ""), "Lead Auditor", d.get("prepared_on", ""), ""),
	            ("Approved by", d.get("approved_by", ""), d.get("approver_title", "Managing Director"), d.get("approved_on", ""), "")],
	           [2.6, 4.0, 3.2, 3.2, 3.6])
	for row in t.rows[1:]:
		row.height = Cm(1.2)
	_para(doc, f"Distribution: {d.get('distribution', '')}", size=10)
	_para(doc, "This report is a controlled IMS record. Printed copies are uncontrolled.", italic=True, color=GREY, size=9)

	buf = io.BytesIO()
	doc.save(buf)
	return buf.getvalue()


# ------------------------------------------------------------------ data from the record
def collect(audit):
	import frappe
	from frappe.utils import format_date, get_fullname

	from chemical_erp.company import company_block, company_email, company_name

	s = frappe.get_cached_doc("Chemical ERP Settings")
	areas = OrderedDict()
	for i, row in enumerate(audit.checklist, start=1):
		areas.setdefault(row.area or "General", []).append({
			"ref": row.source_name or f"Item {i}", "requirement": row.requirement, "clause": row.clause,
			"evidence": row.evidence, "result": row.result or "Not Audited"})
	counts = {}
	for row in audit.checklist:
		counts[row.result or "Not Audited"] = counts.get(row.result or "Not Audited", 0) + 1
	findings = [{"no": f.finding_no, "type": f.finding_type, "area": f.area or "", "clause": f.clause, "description": f.description,
	             "action": f.corrective_action, "owner": get_fullname(f.action_owner) if f.action_owner else "",
	             "due": format_date(f.due_date) if f.due_date else "", "status": f.status, "from": f.carried_from or "",
	             "carried": bool(f.carried_from)} for f in audit.findings]
	approval = [r for r in (audit.get("approval_log") or []) if r.action in ("Approve", "Approve as MD")]
	team = "; ".join(f"{m.full_name or m.user} ({m.audit_role})" for m in audit.team)
	dates = ""
	if audit.audit_date_from:
		dates = format_date(audit.audit_date_from) + (f" to {format_date(audit.audit_date_to)}" if audit.audit_date_to and audit.audit_date_to != audit.audit_date_from else "")
	verdict = ""
	if counts.get("Major Nonconformity"):
		verdict = "Major nonconformities were found. The IMS is not effectively implemented in the areas concerned until corrective actions are verified."
	elif audit.items_audited:
		verdict = "No major nonconformities were found. The IMS is generally implemented and maintained, subject to closing the findings below."
	return {
		"name": audit.name, "quarter": audit.quarter, "period_from": format_date(audit.period_from),
		"period_to": format_date(audit.period_to), "audit_dates": dates, "standards": audit.standards,
		"procedure_ref": audit.procedure_ref, "lead_auditor": get_fullname(audit.lead_auditor), "team": team,
		"areas": list(areas), "status": audit.audit_status, "scope": audit.scope, "counts": counts,
		"items_audited": audit.items_audited or 0, "score": float(audit.compliance_score or 0), "verdict": verdict,
		"carried": [f for f in findings if f["carried"]], "by_area": areas, "findings": findings,
		"conclusion": audit.conclusion, "distribution": audit.distribution,
		"prepared_on": format_date(audit.audit_date_to or audit.modified),
		"approved_by": get_fullname(approval[-1].user) if approval else "",
		"approved_on": format_date(approval[-1].on) if approval else "",
		"approver_title": "Managing Director", "form_ref": s.get("audit_report_form") or "BC/HSE/006",
		"company_name": company_name(audit),
		"company_lines": company_block(audit, "letter") + ([f"Email: {company_email(audit)}"] if company_email(audit) else []),
	}


def logo_path(doc=None):
	"""File path of the company's square logo, for the Word report."""
	import os

	import frappe

	from chemical_erp.company import get_profile

	url = (get_profile((doc or {}).get("company") if doc else None).get("logo_square")
	       or get_profile((doc or {}).get("company") if doc else None).get("logo_wide"))
	if url and "/files/" in url:
		folder = "private" if url.startswith("/private") else "public"
		path = frappe.get_site_path(folder, "files", url.split("/files/")[-1])
		if os.path.exists(path):
			return path
	return frappe.get_app_path("chemical_erp", "public", "images", "brave_logo.png")
