"""Management Systems setup: house document series and the real seed data (85 IMS documents,
31 legal requirements, 6 compliance watch items). Seed data loads only into empty tables,
so it never duplicates or overwrites records already on the site."""

import csv
import json
import os

import frappe

DATA = os.path.join(os.path.dirname(__file__), "data")


def ensure_setup(first_install=False):
	ensure_series()
	counts = {}
	for doctype, filename in (("Legal Requirement", "legal_requirement_seed.csv"),
	                          ("IMS Document", "ims_document_seed.csv"),
	                          ("Compliance Watch Item", "compliance_watch_item_seed.csv")):
		counts[doctype] = load_seed(doctype, filename)
	link_tender_validity()
	return counts


def ensure_series():
	for row in json.load(open(os.path.join(DATA, "ims_document_series.json"))):
		if not frappe.db.exists("IMS Document Series", row["series_code"]):
			frappe.get_doc(row).insert(ignore_permissions=True)


def load_seed(doctype, filename):
	if frappe.db.count(doctype):
		return 0
	meta = frappe.get_meta(doctype)
	loaded = 0
	with open(os.path.join(DATA, filename), encoding="utf-8-sig") as fh:
		for row in csv.DictReader(fh):
			values = {k: v for k, v in row.items() if v not in (None, "") and meta.has_field(k)}
			try:
				doc = frappe.get_doc({"doctype": doctype, **values})
				doc.flags.ignore_permissions = True
				doc.insert()
				loaded += 1
			except Exception:
				frappe.log_error(title=f"Management Systems seed row not loaded ({doctype})", message=f"{row}\n\n{frappe.get_traceback()}")
	return loaded


def link_tender_validity():
	"""Tenders check permits and documents against the IMS records instead of keeping copies."""
	if not frappe.db.exists("DocType", "Tender Settings"):
		return
	s = frappe.get_single("Tender Settings")
	have = {r.reference_doctype for r in s.validity_sources}
	added = False
	for dt, field in (("Legal Requirement", "expiry_date"), ("IMS Document", "review_date")):
		if dt not in have:
			s.append("validity_sources", {"reference_doctype": dt, "date_field": field})
			added = True
	if added:
		s.flags.ignore_permissions = True
		s.save()
