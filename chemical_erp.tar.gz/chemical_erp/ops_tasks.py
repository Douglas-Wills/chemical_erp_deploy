"""Daily reminders for complaints, samples, stability, laboratory, certification, drills, imports, suppliers,
reviews, risks and field visits. Each check is independent and never stops the others."""

import frappe
from frappe import _
from frappe.utils import add_days, add_months, cint, getdate, now_datetime, today

from chemical_erp.utils import approver_role, get_settings, notify, users_with_role


def _run(fn):
	try:
		fn()
		frappe.db.commit()
	except Exception:
		frappe.db.rollback()
		frappe.log_error(title=f"chemical_erp daily check failed: {fn.__name__}", message=frappe.get_traceback())


def daily():
	for fn in (complaints, retained_samples, stability, reagents, certifications, drills, imports, supplier_evaluations,
	           management_review, risks, field_visits, wht_certificates, receipts):
		_run(fn)


def monthly():
	from chemical_erp.management_systems.management import record_measurements

	_run(record_measurements)


def complaints():
	s = get_settings()
	ack, close = cint(s.get("complaint_ack_days")) or 2, cint(s.get("complaint_close_days")) or 30
	who = users_with_role(approver_role("quality")) + users_with_role("Sales Manager")
	for c in frappe.get_all("Customer Complaint", filters={"status": "Open", "acknowledged_on": ["is", "not set"],
	                                                      "received_on": ["<", add_days(now_datetime(), -ack)]}, fields=["name", "customer"]):
		notify(who, "Customer Complaint", c.name, _("Complaint {0} from {1} has not been acknowledged").format(c.name, c.customer), priority="High")
	for c in frappe.get_all("Customer Complaint", filters={"status": ["!=", "Closed"], "received_on": ["<", add_days(now_datetime(), -close)]},
	                        fields=["name", "customer"]):
		notify(who, "Customer Complaint", c.name, _("Complaint {0} from {1} is open for more than {2} days").format(c.name, c.customer, close))


def retained_samples():
	for r in frappe.get_all("Retained Sample", filters={"status": "Retained", "retain_until": ["<=", today()]}, fields=["name", "batch"]):
		notify(users_with_role("QC Analyst"), "Retained Sample", r.name, _("Retained sample for batch {0} can now be disposed of").format(r.batch))


def stability():
	soon = add_days(today(), 7)
	for p in frappe.get_all("Stability Point", filters={"parenttype": "Stability Study", "tested_on": ["is", "not set"], "due_date": ["<=", soon]},
	                        fields=["parent", "month", "due_date"]):
		if frappe.db.get_value("Stability Study", p.parent, "status") == "Running":
			notify(users_with_role("QC Analyst"), "Stability Study", p.parent, _("Stability test at month {0} due {1} ({2})").format(p.month, p.due_date, p.parent))


def reagents():
	for r in frappe.get_all("Reagent Solution", filters={"status": "Valid", "expires_on": ["<", today()]}, pluck="name"):
		frappe.db.set_value("Reagent Solution", r, "status", "Expired")
	for r in frappe.get_all("Reagent Solution", filters={"status": "Valid", "expires_on": ["between", [today(), add_days(today(), 7)]]},
	                        fields=["name", "reagent", "expires_on"]):
		notify(users_with_role("QC Analyst"), "Reagent Solution", r.name, _("{0} ({1}) expires on {2}: prepare a fresh solution").format(r.reagent, r.name, r.expires_on))


def certifications():
	from chemical_erp.regulatory_compliance.doctype.product_certification.product_certification import compute_status

	for name in frappe.get_all("Product Certification", pluck="name"):
		doc = frappe.get_doc("Product Certification", name)
		status = compute_status(doc)
		if status != doc.status:
			frappe.db.set_value("Product Certification", name, "status", status)
		if status in ("Expiring", "Expired", "Certificate Missing"):
			notify(users_with_role("HSE Officer") + users_with_role("Sales Manager"), "Product Certification", name,
			       _("Product certification for {0}: {1}").format(doc.item_code, status.lower()))


def drills():
	latest = {}
	for d in frappe.get_all("Emergency Drill", fields=["drill_type", "next_drill_due"], order_by="drill_date asc"):
		latest[d.drill_type] = d.next_drill_due
	for kind, due in latest.items():
		if due and getdate(due) <= getdate(add_days(today(), 14)):
			notify(users_with_role("HSE Officer"), "Emergency Drill", None, _("{0} drill due by {1}").format(kind, due))
	if not latest:
		notify(users_with_role("HSE Officer"), "Emergency Drill", None, _("No emergency drill recorded yet: schedule a fire evacuation drill"))


def imports():
	who = users_with_role("Purchase User") + users_with_role("Purchase Manager")
	for i in frappe.get_all("Import Shipment", filters={"status": ["in", ["Paid", "Shipped"]], "eta": ["between", [today(), add_days(today(), 3)]]},
	                        fields=["name", "supplier", "eta"]):
		notify(who + users_with_role("Stock User"), "Import Shipment", i.name, _("{0} from {1} arrives about {2}: prepare clearing").format(i.name, i.supplier, i.eta))
	for i in frappe.get_all("Import Shipment", filters={"status": ["not in", ["Received", "Closed"]], "lc_expiry": ["between", [today(), add_days(today(), 14)]]},
	                        fields=["name", "lc_number", "lc_expiry"]):
		notify(who + users_with_role("Accounts Manager"), "Import Shipment", i.name, _("LC {0} for {1} expires on {2}").format(i.lc_number, i.name, i.lc_expiry), priority="High")


def supplier_evaluations():
	months = cint(get_settings().get("supplier_evaluation_months")) or 12
	cutoff = add_months(today(), -months)
	for sup in frappe.get_all("Supplier", filters={"disabled": 0, "is_approved_vendor": 1}, fields=["name", "last_evaluated_on"]):
		if sup.last_evaluated_on and getdate(sup.last_evaluated_on) > getdate(cutoff):
			continue
		if frappe.db.exists("Supplier Evaluation", {"supplier": sup.name, "docstatus": 0}):
			continue
		doc = frappe.get_doc({"doctype": "Supplier Evaluation", "supplier": sup.name,
		                      "period_from": sup.last_evaluated_on or cutoff, "period_to": today()}).insert(ignore_permissions=True)
		notify(users_with_role("Purchase User"), "Supplier Evaluation", doc.name, _("Supplier evaluation due for {0}").format(sup.name))


def management_review():
	months = cint(get_settings().get("management_review_months")) or 6
	last = frappe.db.get_value("Management Review", {"docstatus": 1}, "max(meeting_date)")
	if (not last or getdate(last) <= getdate(add_months(today(), -months))) and not frappe.db.exists("Management Review", {"docstatus": 0}):
		notify(users_with_role("HSE Officer") + users_with_role("Managing Director"), "Management Review", None,
		       _("A management review is due (last held {0})").format(last or _("never")))


def risks():
	for r in frappe.get_all("IMS Risk", filters={"status": ["!=", "Closed"], "review_date": ["<=", today()]}, fields=["name", "title", "owner_user"]):
		notify(r.owner_user, "IMS Risk", r.name, _("Review risk: {0}").format(r.title))


def field_visits():
	days = cint(get_settings().get("field_visit_report_days")) or 2
	for e in frappe.get_all("Event", filters={"event_kind": "Field Visit", "ends_on": ["<", add_days(now_datetime(), -days)],
	                                         "visit_report": ["is", "not set"]}, fields=["name", "subject", "owner"]):
		notify(e.owner, "Event", e.name, _("Write the visit report for: {0}").format(e.subject))


def receipts():
	"""Replaced by the hourly 72-hour receipt deadline check (controls.attachments.receipt_deadlines)."""
	return


def wht_certificates():
	"""Not a chase: a monthly summary, and weekly from the year-end follow-up month, since certificates arrive late."""
	from chemical_erp.chemical_core.doctype.wht_certificate.wht_certificate import follow_up

	follow_up()
