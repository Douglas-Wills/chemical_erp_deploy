frappe.ui.form.on("Customer", {
	refresh(frm) {
		if (frm.is_new()) return;
		frm.add_custom_button(__("Send Statement"), () =>
			frappe.call("chemical_erp.chemical_core.collections.send_statement", { customer: frm.doc.name })
				.then(({ message }) => frappe.show_alert({ message: __("Statement sent ({0} outstanding)", [format_currency(message)]), indicator: "green" })),
			__("Credit"));
		frm.add_custom_button(__("Record Payment Promise"), () => frappe.new_doc("Payment Promise", { customer: frm.doc.name }), __("Credit"));
		frm.add_custom_button(__("End-User Declaration"), () => frappe.new_doc("End-User Declaration", { customer: frm.doc.name }), __("Compliance"));
		if (frm.doc.credit_hold) frm.dashboard.set_headline_alert(__("On credit hold: {0}", [frappe.utils.escape_html(frm.doc.credit_hold_reason || "")]), "red");
	},
});
