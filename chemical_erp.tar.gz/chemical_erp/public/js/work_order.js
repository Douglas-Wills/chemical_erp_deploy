frappe.ui.form.on("Work Order", {
	refresh(frm) {
		if (frm.is_new() || frm.doc.docstatus === 2) return;
		frm.add_custom_button(__("Check Materials"), () =>
			frappe.call("chemical_erp.chemical_core.material_check.check", { work_order: frm.doc.name }).then(() => frm.reload_doc()), __("Materials"));
		if ((frm.doc.material_check || []).some((r) => r.status === "Order Now" && !r.purchase_order)) {
			frm.add_custom_button(__("Create Purchase Orders"), () =>
				frappe.confirm(__("Raise draft purchase orders (one per supplier) for the materials marked Order Now?"), () =>
					frappe.call({ method: "chemical_erp.chemical_core.material_check.create_purchase_orders", args: { work_order: frm.doc.name }, freeze: true })
						.then((r) => {
							frappe.msgprint({ title: __("Draft purchase orders"), indicator: "green",
								message: (r.message || []).map((n) => `<a href="/app/purchase-order/${n}">${n}</a>`).join("<br>") });
							frm.reload_doc();
						})), __("Materials"));
		}
		const c = { "All Available": "green", "Shortages Covered": "blue", "Late Supplies": "orange", "Order Needed": "red" }[frm.doc.material_status];
		if (c) {
			const short = (frm.doc.material_check || []).filter((r) => r.status !== "Available");
			frm.dashboard.set_headline_alert(__("Materials: {0}", [frm.doc.material_status]) +
				(short.length ? " (" + short.map((r) => `${r.item_code}: ${r.status}`).join("; ") + ")" : ""), c);
		}
	},
});
