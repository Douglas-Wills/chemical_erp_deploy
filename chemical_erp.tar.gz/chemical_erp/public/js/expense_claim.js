frappe.ui.form.on("Expense Claim", {
	refresh(frm) {
		if (frm.doc.pattern_flag) {
			const related = frm.doc.pattern_related ? " " + __("Related: {0}", [frm.doc.pattern_related]) : "";
			const reviewed = frm.doc.pattern_reviewed ? " " + __("Reviewed by {0}.", [frappe.user.full_name(frm.doc.pattern_reviewed_by)]) : "";
			frm.dashboard.set_headline_alert(__("Expense pattern flagged: {0}", [frm.doc.pattern_reason]) + related + reviewed,
				frm.doc.pattern_reviewed ? "orange" : "red");
		}
	},
});
