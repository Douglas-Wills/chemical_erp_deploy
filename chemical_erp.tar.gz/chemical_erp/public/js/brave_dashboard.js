/* ==========================================================================
   BRAVE CHEMICALS - EXECUTIVE OPERATIONAL DASHBOARD
   Preserves the Desk left sidebar with full navigation while rendering
   high-performance, real-time departmental summary cards.
   ========================================================================== */

(function () {
	window.BraveDashboard = {
		currentFilter: 'all',
		searchQuery: '',
		cachedData: null,
		isLoading: false,
		mountRetryTimer: null,
		mountRetries: 0,

		init: function () {
			const me = this;

			// Route and page change listeners
			frappe.router.on('change', () => {
				me.checkRoute();
			});

			$(document).ready(() => {
				me.checkRoute();
			});

			$(document).on('page-change', () => {
				me.checkRoute();
			});

			// Re-check when sidebar items are clicked
			$(document).on('click', '.sidebar-item-container, .desk-sidebar-item', function () {
				setTimeout(() => me.checkRoute(), 80);
			});
		},

		isDashboardRoute: function () {
			const route = frappe.get_route() || [];
			if (!route.length) {
				const hash = (window.location.hash || '').toLowerCase();
				if (hash.includes('dashboard') || hash.includes('operations-dashboard')) return true;
				return false;
			}
			const r0 = (route[0] || '').toLowerCase();
			const r1 = (route[1] || '').toLowerCase();
			if (r0 === 'dashboard') return true;
			if ((r0 === 'workspaces' || r0 === 'workspace') && (r1 === 'dashboard' || r1 === 'operations-dashboard')) return true;
			return false;
		},

		checkRoute: function () {
			const me = this;
			if (me.mountRetryTimer) {
				clearTimeout(me.mountRetryTimer);
				me.mountRetryTimer = null;
			}
			me.mountRetries = 0;
			me.maintainSidebarAndDashboard();
		},

		maintainSidebarAndDashboard: function () {
			const me = this;

			// 1. ALWAYS preserve and keep the left Desk sidebar visible
			const $sidebar = $('.layout-side-section, .desk-sidebar');
			if ($sidebar.length) {
				$sidebar.show().removeClass('hidden hide-sidebar');
			}

			// 2. Check if we are on the dashboard route
			if (me.isDashboardRoute()) {
				let $main = null;
				if (frappe.workspace && frappe.workspace.body && frappe.workspace.body.length && frappe.workspace.body.is(':visible')) {
					$main = frappe.workspace.body;
				} else {
					$main = $('.layout-main-section:visible, [data-page-route="Workspaces"] .layout-main-section').first();
				}

				if ($main && $main.length) {
					if (!$main.find('#brave-graphical-dashboard').length) {
						me.render();
					}
				} else {
					// Container is still being mounted by Frappe: retry up to 8 times with backoff
					if (me.mountRetries < 8) {
						me.mountRetries++;
						me.mountRetryTimer = setTimeout(() => me.maintainSidebarAndDashboard(), 120);
					}
				}
			} else {
				// Clean up dashboard container when navigating to another workspace or page
				const $dash = $('#brave-graphical-dashboard');
				if ($dash.length) {
					$dash.remove();
					$('.layout-main-section').find('.codex-editor, .workspace-skeleton, .editor-js-container, .page-head-content').show();
				}
			}
		},

		render: function () {
			const me = this;

			let $mainSection = null;
			if (frappe.workspace && frappe.workspace.body && frappe.workspace.body.length && frappe.workspace.body.is(':visible')) {
				$mainSection = frappe.workspace.body;
			} else {
				$mainSection = $('.layout-main-section:visible, [data-page-route="Workspaces"] .layout-main-section').first();
			}

			if (!$mainSection || !$mainSection.length) {
				return;
			}

			// Keep Desk sidebar intact
			$('.layout-side-section').show().removeClass('hidden hide-sidebar');
			$('.desk-sidebar').show().removeClass('hidden');

			// Highlight Dashboard item in left sidebar
			$('.sidebar-item-container').removeClass('active');
			$('.desk-sidebar-item').removeClass('selected');
			const $dashSideItem = $('.sidebar-item-container[item-name="Dashboard"], .sidebar-item-container[item-name="Operations Dashboard"]').first();
			if ($dashSideItem.length) {
				$dashSideItem.addClass('active');
				$dashSideItem.find('.desk-sidebar-item').addClass('selected');
			}

			// Hide standard editorjs / widgets in main section only
			$mainSection.find('.codex-editor, .workspace-skeleton, .editor-js-container, .ce-block, .standard-actions').hide();

			// Mount #brave-graphical-dashboard
			let $dashboardWrap = $mainSection.find('#brave-graphical-dashboard');
			if (!$dashboardWrap.length) {
				$dashboardWrap = $('<div id="brave-graphical-dashboard" class="brave-dash-container"></div>').appendTo($mainSection);
			} else {
				$dashboardWrap.show();
			}

			// Show loading skeleton if no cached data
			if (!me.cachedData) {
				$dashboardWrap.html(`
					<div class="dash-loading-state">
						<div class="spinner-border text-primary" role="status"></div>
						<div class="mt-2 text-muted font-weight-500">${__('Loading Operational Summaries…')}</div>
					</div>
				`);
			}

			me.fetchData(false, function (data) {
				me.cachedData = data;
				me.buildDashboard($dashboardWrap, data);
			});
		},

		fetchData: function (refresh, callback) {
			const me = this;
			me.isLoading = true;
			frappe.call({
				method: 'chemical_erp.dashboard.graphical_summary.get_dashboard_cards',
				args: {
					refresh: refresh ? 1 : 0
				},
				freeze: false,
				callback: function (r) {
					me.isLoading = false;
					if (r && r.message) {
						callback(r.message);
					}
				},
				error: function () {
					me.isLoading = false;
					$('#brave-graphical-dashboard').html(`
						<div class="alert alert-danger m-4">
							<h5>${__('Failed to load dashboard data')}</h5>
							<p>${__('Please ensure the server is running and try refreshing.')}</p>
							<button class="btn btn-sm btn-primary" onclick="BraveDashboard.render()">${__('Retry')}</button>
						</div>
					`);
				}
			});
		},

		buildDashboard: function ($wrapper, data) {
			const me = this;
			$wrapper.empty();

			// 1. Top Header Banner with Live Network status and Controls
			$(me.renderHeader(data)).appendTo($wrapper);

			// 2. Departmental Operational Summary Cards Container
			const $sectionCardsWrap = $('<div class="dash-section-cards-container"></div>').appendTo($wrapper);
			me.renderSectionCards($sectionCardsWrap, data.sections || []);

			// 3. Bind interactive events
			me.bindDashboardEvents($wrapper, data);
		},

		renderHeader: function (data) {
			const greeting = this.getGreeting();
			const userFirstName = (data.user || 'Administrator').split(' ')[0];
			const todayFormatted = frappe.datetime ? frappe.datetime.str_to_user(frappe.datetime.get_today()) : new Date().toLocaleDateString();

			return `
				<div class="dash-hero-header">
					<div class="dash-hero-left">
						<div class="dash-greeting-badge">
							<span class="live-pulse"></span>
							<span>${__('Live Chemical ERP Network')} · ${todayFormatted}</span>
						</div>
						<h1 class="dash-title">
							${greeting}, <span class="text-cyan">${frappe.utils.escape_html(userFirstName)}</span>
						</h1>
						<p class="dash-subtitle">
							${__('Real-time operational summaries across production, laboratory, quality, safety, sales, and accounts.')}
						</p>
					</div>
					<div class="dash-hero-actions">
						<button class="btn btn-dash-action" id="btn-dash-refresh" title="${__('Refresh live metrics with real-time database state')}">
							<svg class="refresh-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
							</svg>
							<span>${__('Refresh')}</span>
						</button>
						<button class="btn btn-dash-primary" id="btn-dash-export" title="${__('Print or export executive report')}">
							<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
								<polyline points="6 9 6 2 18 2 18 9"></polyline>
								<path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
								<rect x="6" y="14" width="12" height="8"></rect>
							</svg>
							<span>${__('Export Report')}</span>
						</button>
					</div>
				</div>

				<div class="dash-filter-bar">
					<div class="dash-filter-tabs">
						<button class="dash-filter-tab active" data-filter="all">${__('All Sections')}</button>
						<button class="dash-filter-tab" data-filter="management">${__('Executive')}</button>
						<button class="dash-filter-tab" data-filter="sales">${__('Sales & Tenders')}</button>
						<button class="dash-filter-tab" data-filter="quality">${__('Quality & Lab')}</button>
						<button class="dash-filter-tab" data-filter="production">${__('Production & Stores')}</button>
						<button class="dash-filter-tab" data-filter="hse">${__('HSE & Safety')}</button>
						<button class="dash-filter-tab" data-filter="accounts">${__('Accounts & Finance')}</button>
						<button class="dash-filter-tab" data-filter="documents">${__('Documents')}</button>
					</div>
					<div class="dash-search-box">
						<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
							<circle cx="11" cy="11" r="8"></circle>
							<line x1="21" y1="21" x2="16.65" y2="16.65"></line>
						</svg>
						<input type="text" id="dash-card-search" placeholder="${__('Search any card or metric…')}" />
						<button class="btn-clear-search" id="btn-clear-search" style="display:none;" title="${__('Clear search')}">✕</button>
					</div>
				</div>
			`;
		},

		renderSectionCards: function ($container, sections) {
			const me = this;
			$container.empty();

			const query = (me.searchQuery || '').toLowerCase().trim();
			const activeFilter = me.currentFilter || 'all';

			let totalVisibleCards = 0;
			let totalVisibleSections = 0;

			(sections || []).forEach(sec => {
				if (!sec) return;
				const secKey = (sec.key || '').toLowerCase();
				const secTitle = (sec.title || '').toLowerCase();

				// Filter matching
				if (activeFilter !== 'all') {
					let matches = (secKey === activeFilter) || secTitle.includes(activeFilter);
					if (activeFilter === 'management' && (secKey === 'management' || secKey === 'delegation')) matches = true;
					if (activeFilter === 'sales' && (secKey === 'sales' || secKey === 'tenders')) matches = true;
					if (activeFilter === 'quality' && (secKey === 'quality' || secKey === 'field_lab')) matches = true;
					if (activeFilter === 'production' && (secKey === 'production' || secKey === 'stores' || secKey === 'procurement')) matches = true;
					if (activeFilter === 'hse' && (secKey === 'hse')) matches = true;
					if (activeFilter === 'accounts' && (secKey === 'accounts')) matches = true;
					if (activeFilter === 'documents' && (secKey === 'documents')) matches = true;
					if (!matches) return;
				}

				const matchingCards = (sec.cards || []).filter(c => {
					if (!c) return false;
					if (!query) return true;
					const lbl = (c.label || '').toLowerCase();
					const dt = (c.doctype || '').toLowerCase();
					return lbl.includes(query) || dt.includes(query) || secTitle.includes(query);
				});

				if (query && !matchingCards.length) return;

				totalVisibleSections++;
				totalVisibleCards += matchingCards.length;

				const secIcon = me.getSectionIcon(sec.key || '');
				const $secBlock = $(`
					<div class="dash-dept-section-block" data-section="${frappe.utils.escape_html(sec.key || '')}">
						<div class="dept-section-title">
							<div class="dept-title-left">
								<span class="dept-icon-pill">${secIcon}</span>
								<span class="dept-title-text">${frappe.utils.escape_html(sec.title || '')}</span>
							</div>
							<span class="dept-count-badge">${matchingCards.length} ${__('metrics')}</span>
						</div>
						<div class="dash-dept-cards-grid"></div>
					</div>
				`);
				const $grid = $secBlock.find('.dash-dept-cards-grid');

				matchingCards.forEach(c => {
					const toneClass = 'card-tone-' + (c.tone || 'blue');
					const displayVal = (c.value === null || c.value === undefined) ? '0' : String(c.value);

					// Determine if the value is zero/blank or active count
					const cleanVal = displayVal.trim();
					const isZero = cleanVal === '0' || cleanVal === '0.00' || cleanVal === '0 UGX' || cleanVal === '';
					const stateClass = isZero ? 'is-zero' : 'has-count';

					const $card = $(`
						<div class="dash-summary-card ${toneClass} ${stateClass}" role="button" tabindex="0" title="${__('Click to view details and records')}">
							<div class="card-inner">
								<div class="card-top-row">
									<div class="card-val">${frappe.utils.escape_html(displayVal)}</div>
									<div class="card-tone-indicator"></div>
								</div>
								<div class="card-lbl-row">
									<div class="card-lbl">${frappe.utils.escape_html(c.label || '')}</div>
									<span class="card-nav-arrow">→</span>
								</div>
							</div>
						</div>
					`);

					$card.on('click', () => {
						me.openCard(c);
					});

					$grid.append($card);
				});

				$container.append($secBlock);
			});

			if (query && totalVisibleCards === 0) {
				$container.html(`
					<div class="dash-empty-search-state">
						<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="1.5">
							<circle cx="11" cy="11" r="8"></circle>
							<line x1="21" y1="21" x2="16.65" y2="16.65"></line>
						</svg>
						<h4>${__('No metrics found matching "{0}"', [frappe.utils.escape_html(query)])}</h4>
						<p>${__('Try searching by another term or clear the filter.')}</p>
						<button class="btn btn-sm btn-outline-secondary" id="btn-empty-clear">${__('Clear Search')}</button>
					</div>
				`);
				$container.find('#btn-empty-clear').on('click', () => {
					$('#dash-card-search').val('').trigger('input');
				});
			}
		},

		bindDashboardEvents: function ($wrapper, data) {
			const me = this;

			// Refresh action with animation feedback
			$wrapper.find('#btn-dash-refresh').off('click').on('click', function () {
				const $btn = $(this);
				$btn.addClass('is-refreshing');
				me.fetchData(true, function (freshData) {
					me.cachedData = freshData;
					me.renderSectionCards($wrapper.find('.dash-section-cards-container'), freshData.sections || []);
					$btn.removeClass('is-refreshing');
					frappe.show_alert({ message: __('Dashboard refreshed with live data'), indicator: 'green' });
				});
			});

			// Print/Export
			$wrapper.find('#btn-dash-export').off('click').on('click', () => {
				window.print();
			});

			// Filter tabs
			$wrapper.find('.dash-filter-tab').off('click').on('click', function () {
				$wrapper.find('.dash-filter-tab').removeClass('active');
				$(this).addClass('active');
				me.currentFilter = $(this).attr('data-filter');
				me.renderSectionCards($wrapper.find('.dash-section-cards-container'), (me.cachedData || data).sections || []);
			});

			// Search input with clear button
			const $searchInput = $wrapper.find('#dash-card-search');
			const $clearBtn = $wrapper.find('#btn-clear-search');

			$searchInput.off('input').on('input', function () {
				me.searchQuery = $(this).val();
				if (me.searchQuery) {
					$clearBtn.show();
				} else {
					$clearBtn.hide();
				}
				me.renderSectionCards($wrapper.find('.dash-section-cards-container'), (me.cachedData || data).sections || []);
			});

			$clearBtn.off('click').on('click', function () {
				$searchInput.val('').trigger('input');
			});
		},

		openCard: function (c) {
			if (!c) return;
			if (c.route) {
				if (typeof c.route === 'string' || Array.isArray(c.route)) {
					return this.handleRoute(c.route);
				}
				if (typeof c.route === 'object') {
					if (c.route.report) {
						frappe.route_options = c.filters || {};
						return frappe.set_route('query-report', c.route.report);
					}
					if (c.route.doctype && c.route.name) {
						return frappe.set_route('Form', c.route.doctype, c.route.name);
					}
					if (c.route.page) {
						return frappe.set_route(c.route.page);
					}
					if (c.route.doctype) {
						frappe.route_options = c.filters || {};
						return frappe.set_route('List', c.route.doctype);
					}
				}
			}
			frappe.route_options = c.filters || {};
			if (c.doctype) {
				frappe.set_route('List', c.doctype);
			}
		},

		handleRoute: function (route) {
			if (!route) return;
			if (typeof route === 'string') {
				let r = route.trim();
				if (r.startsWith('/app/')) {
					r = r.slice(5);
				}
				const parts = r.split('/').filter(Boolean);
				return frappe.set_route.apply(frappe, parts);
			}
			if (Array.isArray(route)) {
				const last = route[route.length - 1];
				if (last && typeof last === 'object' && !Array.isArray(last)) {
					frappe.route_options = last;
					const slugs = route.slice(0, route.length - 1);
					return frappe.set_route.apply(frappe, slugs);
				}
				return frappe.set_route.apply(frappe, route);
			}
			if (typeof route === 'object') {
				if (route.report) {
					frappe.route_options = route.filters || {};
					return frappe.set_route('query-report', route.report);
				}
				if (route.doctype && route.name) {
					return frappe.set_route('Form', route.doctype, route.name);
				}
				if (route.page) {
					return frappe.set_route(route.page);
				}
				if (route.doctype) {
					frappe.route_options = route.filters || {};
					return frappe.set_route('List', route.doctype);
				}
			}
		},

		getGreeting: function () {
			const hr = new Date().getHours();
			if (hr < 12) return __('Good morning');
			if (hr < 17) return __('Good afternoon');
			return __('Good evening');
		},

		getSectionIcon: function (key) {
			const k = (key || '').toLowerCase();
			if (k === 'management' || k === 'delegation') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
			}
			if (k === 'sales' || k === 'tenders') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 6l-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/></svg>';
			}
			if (k === 'quality') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>';
			}
			if (k === 'field_lab') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="18" r="3"/><circle cx="18" cy="6" r="3"/><line x1="8.5" y1="15.5" x2="15.5" y2="8.5"/></svg>';
			}
			if (k === 'production') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
			}
			if (k === 'stores') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>';
			}
			if (k === 'procurement') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>';
			}
			if (k === 'hse') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>';
			}
			if (k === 'accounts') {
				return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>';
			}
			return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
		}
	};

	BraveDashboard.init();
})();
