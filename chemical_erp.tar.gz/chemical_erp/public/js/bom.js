frappe.ui.form.on("BOM", {
	refresh(frm) {
		if (frm.is_new()) return;
		frm.add_custom_button(__("Make Standard Cost Sheet"), () =>
			frappe.call("chemical_erp.chemical_core.costing.make_standard_cost_sheet", { bom: frm.doc.name }).then((r) => {
				frappe.show_alert({ message: __("Cost sheet {0} created", [r.message]), indicator: "green" });
				frm.reload_doc();
			}), __("Product Costing"));
		frm.add_custom_button(__("Add Missing Cost Items"), () => {
			frappe.db.get_list("Cost Element", { filters: { active: 1 }, fields: ["name", "default_rate", "default_quantity"], limit: 100 }).then((rows) => {
				const have = new Set((frm.doc.costing_lines || []).map((l) => l.cost_element));
				rows.filter((r) => !have.has(r.name)).forEach((r) => frm.add_child("costing_lines", { cost_element: r.name, rate: r.default_rate, quantity: r.default_quantity || 1 }));
				frm.refresh_field("costing_lines");
				frm.dirty();
				frappe.show_alert({ message: __("Save to recalculate the cost"), indicator: "blue" });
			});
		}, __("Product Costing"));
		if (frm.doc.cost_per_kg) {
			frm.dashboard.add_comment(__("Product cost {0} per kg; suggested price {1} per kg at {2}% margin",
				[format_currency(frm.doc.cost_per_kg), format_currency(frm.doc.cost_suggested_price_kg), frm.doc.cost_target_margin || 30]), "blue", true);
		}
	},
});
