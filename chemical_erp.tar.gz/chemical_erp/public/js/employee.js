frappe.ui.form.on("Employee", {
	refresh(frm) {
		if (frm.is_new()) return;
		const group = __("HR");
		frm.add_custom_button(__("New Contract"), () => {
			frappe.new_doc("Employment Contract", { employee: frm.doc.name });
		}, group);
		if (frm.doc.current_contract) {
			frm.add_custom_button(__("Current Contract"), () => frappe.set_route("Form", "Employment Contract", frm.doc.current_contract), group);
		}
		frm.add_custom_button(__("Assign Shift"), () => {
			frappe.new_doc("Shift Assignment", { employee: frm.doc.name, shift_type: frm.doc.default_shift, start_date: frappe.datetime.get_today() });
		}, group);
		if (!frm.doc.user_id && (frappe.user.has_role("System Manager") || frappe.user.has_role("Managing Director") || frappe.user.has_role("HR Manager"))) {
			frm.add_custom_button(__("Create System Account"), () => {
				frappe.prompt([
					{ fieldname: "email", fieldtype: "Data", options: "Email", label: __("Login Email"), reqd: 1,
					  default: frm.doc.company_email || frm.doc.personal_email || "" },
					{ fieldname: "send_welcome_email", fieldtype: "Check", label: __("Send welcome email to set a password"), default: 1 },
				], (v) => frappe.call("chemical_erp.people_management.accounts.create_employee_account", Object.assign({ employee: frm.doc.name }, v))
					.then((r) => { frappe.show_alert({ message: __("Account {0} created", [r.message]), indicator: "green" }); frm.reload_doc(); }),
				__("Create System Account"), __("Create"));
			}).addClass("btn-primary");
		}
		frm.add_custom_button(__("Raise Training Need"), () => {
			frappe.prompt([
				{ fieldname: "title", fieldtype: "Data", label: __("Training Needed"), reqd: 1 },
				{ fieldname: "need_type", fieldtype: "Select", label: __("Reason"), default: "Manager Request",
				  options: "Manager Request\nAppraisal Development\nCAPA Action\nInduction" },
				{ fieldname: "due_date", fieldtype: "Date", label: __("Needed By") },
				{ fieldname: "notes", fieldtype: "Small Text", label: __("Notes") },
			], (v) => frappe.call("chemical_erp.learning.needs.raise_from_form", Object.assign({ employee: frm.doc.name,
				source_doctype: "Employee", source_name: frm.doc.name }, v))
				.then((r) => frappe.set_route("Form", "Training Need", r.message)), __("Raise Training Need"), __("Raise"));
		}, group);
		frm.add_custom_button(__("Training Needs"), () => {
			frappe.route_options = { employee: frm.doc.name };
			frappe.set_route("List", "Training Need");
		}, group);
		frm.add_custom_button(__("Payslips"), () => {
			frappe.route_options = { employee: frm.doc.name };
			frappe.set_route("List", "Staff Payslip");
		}, group);

		const kin = frm.doc.next_of_kin || [];
		if (frm.fields_dict.next_of_kin && !kin.length) {
			frm.dashboard.add_comment(__("No next of kin recorded. Add at least one in the Staff Details tab."), "orange", true);
		}
	},
});
