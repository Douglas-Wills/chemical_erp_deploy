frappe.ui.form.on("Sales Invoice", {
	refresh(frm) {
		if (frm.doc.docstatus !== 1) return;
		const s = frm.doc.efris_status;
		if (s === "Fiscalised") {
			frm.dashboard.set_headline_alert(__("EFRIS fiscal number {0}", [frm.doc.efris_fdn]), "green");
		} else {
			frm.dashboard.set_headline_alert(
				s === "Failed" ? __("EFRIS submission failed; it will retry. Not yet a valid tax invoice.")
					: __("Awaiting EFRIS fiscal number. In manual mode, key in the number from the URA Desktop App."), "orange");
		}
	},
});
