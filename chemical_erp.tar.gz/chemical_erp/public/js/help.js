// ❓ Help: the user manual, searched by keyword(s). On every desk page (top bar), on My Dashboard,
// and with Ctrl+Shift+H. Opened on a document, it starts with the help for that document.
frappe.provide("frappe.chem_help");

(function () {
	const API = "chemical_erp.help.search.";
	const esc = (s) => frappe.utils.escape_html(s || "");
	const rx = (words) => (words && words.length)
		? new RegExp("(" + words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|") + ")", "gi") : null;

	function mark_text(text, words) {
		const r = rx(words);
		return r ? esc(text).replace(r, "<mark>$1</mark>") : esc(text);
	}

	function mark_dom(el, words) {
		const r = rx(words);
		if (!r) return;
		const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
		const nodes = [];
		while (walker.nextNode()) if (walker.currentNode.nodeValue.trim()) nodes.push(walker.currentNode);
		nodes.forEach((n) => {
			r.lastIndex = 0;
			if (!r.test(n.nodeValue)) return;
			const span = document.createElement("span");
			span.innerHTML = esc(n.nodeValue).replace(rx(words), "<mark>$1</mark>");
			n.parentNode.replaceChild(span, n);
		});
	}

	function page_doctype() {
		const r = frappe.get_route() || [];
		if (["Form", "List", "Tree", "Report"].includes(r[0]) && r[1]) return r[1];
		if (r[0] === "query-report" && r[1]) return r[1];
		return null;
	}

	frappe.chem_help.open = function (query) {
		const doctype = page_doctype();
		const d = new frappe.ui.Dialog({
			title: __("❓ Help"),
			size: "large",
			fields: [
				{ fieldname: "q", fieldtype: "Data", label: __("What do you need help with?"),
				  placeholder: __("Type keyword(s), e.g. delete, LPO, waste, password, commission") },
				{ fieldname: "out", fieldtype: "HTML" },
			],
			secondary_action_label: __("Whole Manual"),
			secondary_action: () => show_contents(),
		});
		d.$wrapper.find(".modal-body").css({ "min-height": "420px" });
		const $out = d.fields_dict.out.$wrapper;
		const $q = d.fields_dict.q.$input;
		let last = null, timer = null, words = [];
		$(`<style>
			.ch-res { list-style: none; padding: 0; margin: 6px 0 0; }
			.ch-res li { padding: 9px 10px; border: 1px solid var(--border-color); border-radius: 8px; margin-bottom: 7px; cursor: pointer; }
			.ch-res li:hover, .ch-res li.on { background: var(--control-bg); border-color: var(--primary); }
			.ch-res .t { font-weight: 600; } .ch-res .s { font-size: 11px; color: var(--text-muted); margin-left: 6px; }
			.ch-res .p { font-size: 12.5px; color: var(--text-muted); margin-top: 3px; }
			.ch-head { font-size: 12px; color: var(--text-muted); margin: 4px 0; }
			.ch-topic h3 { margin: 6px 0 2px; } .ch-topic .s { font-size: 12px; color: var(--text-muted); }
			.ch-topic .b { margin-top: 10px; font-size: 13.5px; line-height: 1.55; }
			.ch-topic table { width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 12.5px; }
			.ch-topic th, .ch-topic td { border: 1px solid var(--border-color); padding: 4px 7px; vertical-align: top; }
			.ch-topic th { background: var(--control-bg); }
			.ch-modal mark { background: #fff3a3; padding: 0 1px; border-radius: 2px; color: inherit; }
			.ch-chips button { margin: 0 6px 6px 0; }
			.ch-sec { margin: 10px 0 4px; font-weight: 600; } .ch-toc a { display: block; padding: 2px 0 2px 10px; }
		</style>`).appendTo(d.$wrapper);
		d.$wrapper.addClass("ch-modal");

		function run(q) {
			last = q;
			frappe.call({ method: API + "search", args: { query: q, doctype }, type: "GET" }).then(({ message: m }) => {
				if (q !== last) return;  // an older answer arriving late
				words = m.highlight || [];
				show_results(m, q);
			});
		}

		function show_results(m, q) {
			$out.empty();
			const rows = m.results || [];
			if (!q) {
				$out.append(`<div class="ch-head">${doctype && rows.length ? __("Help for {0}", [esc(__(doctype))]) : __("Start here")}</div>`);
			} else if (!rows.length) {
				frappe.call({ method: API + "not_found", args: { query: q, doctype } });
				$out.append(`<div class="ch-head">${__("Nothing in the manual matches “{0}”. Try a different word, or one of these:", [esc(q)])}</div>`);
				const $c = $(`<div class="ch-chips"></div>`).appendTo($out);
				["approval", "delete", "password", "quotation", "purchase order", "production", "waste", "SDS", "payroll", "commission", "field lab"]
					.forEach((w) => $(`<button class="btn btn-xs btn-default">${esc(w)}</button>`).appendTo($c).on("click", () => { $q.val(w); run(w); }));
				$out.append(`<div class="ch-head">${__("Your search has been passed on so the manual can cover it.")}</div>`);
				return;
			} else {
				$out.append(`<div class="ch-head">${__("{0} topic(s) for “{1}”", [rows.length, esc(q)])}</div>`);
			}
			const $ul = $(`<ul class="ch-res"></ul>`).appendTo($out);
			rows.forEach((r, i) => {
				$(`<li class="${i === 0 && q ? "on" : ""}"><span class="t">${mark_text(r.title, words)}</span><span class="s">${esc(r.section)}</span>
					<div class="p">${mark_text(r.snippet, words)}</div></li>`).appendTo($ul).on("click", () => show_topic(r.name, () => show_results(m, q)));
			});
		}

		function show_topic(name, back) {
			frappe.call({ method: API + "topic", args: { name } }).then(({ message: t }) => {
				$out.empty();
				const $t = $(`<div class="ch-topic">
					<button class="btn btn-xs btn-default ch-back">← ${__("Back")}</button>
					<h3>${esc(t.title)}</h3><div class="s">${__("Manual section")}: ${esc(t.section)}</div>
					<div class="b">${frappe.markdown(t.body || "")}</div></div>`).appendTo($out);
				mark_dom($t.find(".b")[0], words);
				const $links = $(`<div class="ch-chips" style="margin-top:12px"></div>`).appendTo($t);
				(t.related_doctypes || []).slice(0, 6).forEach((dt) =>
					$(`<button class="btn btn-xs btn-default">${__("Open {0}", [esc(__(dt))])}</button>`).appendTo($links)
						.on("click", () => { d.hide(); frappe.set_route("List", dt); }));
				if (t.can_edit) $(`<button class="btn btn-xs btn-default">✎ ${__("Edit this topic")}</button>`).appendTo($links)
					.on("click", () => { d.hide(); frappe.set_route("Form", "Help Topic", t.name); });
				$t.find(".ch-back").on("click", back);
				$t.find(".b a[href^='#']").attr("target", "_self");
			});
		}

		function show_contents() {
			frappe.call({ method: API + "contents", type: "GET" }).then(({ message: secs }) => {
				$out.empty();
				const $toc = $(`<div class="ch-toc"><button class="btn btn-xs btn-default ch-back">← ${__("Back")}</button></div>`).appendTo($out);
				$toc.find(".ch-back").on("click", () => run($q.val() || ""));
				secs.forEach((s, i) => {
					$(`<div class="ch-sec">${i + 1}. ${esc(s.section)}</div>`).appendTo($toc);
					s.topics.forEach((t) => $(`<a href="#">${esc(t.title)}</a>`).appendTo($toc)
						.on("click", (e) => { e.preventDefault(); words = []; show_topic(t.name, show_contents); }));
				});
			});
		}

		$q.on("input", () => { clearTimeout(timer); timer = setTimeout(() => run(($q.val() || "").trim()), 250); });
		$q.on("keydown", (e) => {
			if (e.key === "Enter") { e.preventDefault(); const $on = $out.find(".ch-res li.on"); if ($on.length) $on.trigger("click"); }
			if (e.key === "ArrowDown" || e.key === "ArrowUp") {
				e.preventDefault();
				const $li = $out.find(".ch-res li"); if (!$li.length) return;
				let i = $li.index($li.filter(".on")); $li.removeClass("on");
				i = e.key === "ArrowDown" ? Math.min(i + 1, $li.length - 1) : Math.max(i - 1, 0);
				$li.eq(i).addClass("on")[0].scrollIntoView({ block: "nearest" });
			}
		});
		d.show();
		$q.val(query || "");
		run((query || "").trim());
		setTimeout(() => $q.trigger("focus"), 200);
		return d;
	};

	function add_navbar_button(tries) {
		if (!frappe.session || frappe.session.user === "Guest" || $(".chem-help-btn").length) return;
		const $nav = $("header.navbar .navbar-collapse ul.navbar-nav").first();
		if (!$nav.length) { if ((tries || 0) < 40) setTimeout(() => add_navbar_button((tries || 0) + 1), 250); return; }
		$(`<li class="nav-item chem-help-btn"><a class="nav-link" href="#" title="${__("Help (Ctrl+Shift+H)")}"
			style="font-weight:600; white-space:nowrap">❓ ${__("Help")}</a></li>`)
			.prependTo($nav).find("a").on("click", (e) => { e.preventDefault(); frappe.chem_help.open(); });
	}

	$(document).ready(() => {
		add_navbar_button();
		if (frappe.ui && frappe.ui.keys) frappe.ui.keys.add_shortcut({
			shortcut: "ctrl+shift+h", action: () => frappe.chem_help.open(), description: __("Help: search the user manual"), ignore_inputs: true,
		});
	});
})();
