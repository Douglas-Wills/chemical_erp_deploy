// PDF button on documents that leave the company: the house-style PDF, named like QUO-000367-26_MERU_QUOTATION.pdf.
(function () {
	const HOUSE = ["Quotation", "Sales Order", "Delivery Note", "Sales Invoice", "Purchase Order", "Request for Quotation", "Payment Entry"];
	$(document).on("form-refresh", (e, frm) => {
		if (!frm || !HOUSE.includes(frm.doctype) || frm.is_new()) return;
		frm.add_custom_button(__("⬇ PDF"), () => {
			if (frm.is_dirty()) { frappe.msgprint(__("Save first, so the PDF shows your changes.")); return; }
			const url = "/api/method/chemical_erp.print_pdf.download?" + new URLSearchParams({ doctype: frm.doctype, name: frm.doc.name });
			window.open(url, "_blank");
		});
	});
})();
