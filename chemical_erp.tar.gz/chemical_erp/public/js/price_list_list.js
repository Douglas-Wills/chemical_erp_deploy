frappe.listview_settings["Price List"] = Object.assign(frappe.listview_settings["Price List"] || {}, {
	onload(list) {
		list.page.add_inner_button(__("One List per Customer Group"), () =>
			frappe.call("chemical_erp.chemical_core.pricing.create_group_price_lists").then(({ message }) => {
				frappe.msgprint((message || []).length ? __("Price lists made for: {0}", [message.join(", ")]) : __("Every customer group already has a price list."));
				list.refresh();
			}));
	},
});
