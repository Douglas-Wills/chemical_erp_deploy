frappe.ui.form.on("Batch", {
	refresh(frm) {
		const colours = { Released: "green", Quarantine: "orange", "Retest Due": "orange", Rejected: "red", Expired: "red" };
		if (frm.doc.qc_status) frm.dashboard.set_headline_alert(__("QC status: {0}", [frm.doc.qc_status]), colours[frm.doc.qc_status] || "blue");
		frm.add_custom_button(__("Trace"), () => frappe.set_route("query-report", "Batch Trace", { batch: frm.doc.name }));
		if (!frm.doc.is_waste_batch) {
			frm.add_custom_button(__("Status Override"), () => frappe.new_doc("Batch Status Override", { batch: frm.doc.name }), __("Actions"));
		} else {
			frm.add_custom_button(__("Disposal Order"), () => frappe.new_doc("Disposal Order", { waste_batch: frm.doc.name }), __("Actions"));
		}
	},
});
