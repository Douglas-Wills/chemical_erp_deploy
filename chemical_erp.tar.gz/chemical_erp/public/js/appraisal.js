frappe.ui.form.on("Appraisal", {
	refresh(frm) {
		if (frm.is_new() || !frm.doc.employee) return;
		frm.add_custom_button(__("Raise Training Need"), () => {
			frappe.prompt([
				{ fieldname: "title", fieldtype: "Data", label: __("Training Needed"), reqd: 1 },
				{ fieldname: "due_date", fieldtype: "Date", label: __("Needed By") },
				{ fieldname: "notes", fieldtype: "Small Text", label: __("Development need from this appraisal") },
			], (v) => frappe.call("chemical_erp.learning.needs.raise_from_form", Object.assign({ employee: frm.doc.employee,
				need_type: "Appraisal Development", source_doctype: "Appraisal", source_name: frm.doc.name }, v))
				.then((r) => frappe.show_alert({ message: __("Training need {0} raised", [r.message]), indicator: "green" })),
				__("Raise Training Need"), __("Raise"));
		});
	},
});
