frappe.ui.form.on("Training Event", {
	refresh(frm) {
		if (!frm.is_new() && ["Online", "Hybrid"].includes(frm.doc.delivery_mode) && frm.doc.docstatus === 1) {
			frm.add_custom_button(__("Join Training"), () => {
				frappe.route_options = { event: frm.doc.name };
				frappe.set_route("training-room");
			}).addClass("btn-primary");
		}
		if (!frm.is_new()) {
			frm.add_custom_button(__("Attendance Log"), () => {
				frappe.route_options = { training_event: frm.doc.name };
				frappe.set_route("List", "Training Attendance Log");
			}, __("View"));
		}
	},
	training_program(frm) {
		if (!frm.doc.training_program || (frm.doc.employees || []).length) return;
		frappe.db.get_list("Training Need", { filters: { training_program: frm.doc.training_program, status: "Open" },
			fields: ["employee"], limit: 100 }).then((rows) => {
			if (!rows.length) return;
			frappe.confirm(__("{0} employee(s) have an open need for this program. Add them to the session?", [rows.length]), () => {
				rows.forEach((r) => frm.add_child("employees", { employee: r.employee }));
				frm.refresh_field("employees");
			});
		});
	},
});
