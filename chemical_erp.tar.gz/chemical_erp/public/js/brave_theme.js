/* ==========================================================================
   BRAVE CHEMICALS - BENCHMARK DOM RESTRUCTURER & THEME ENHANCER
   ========================================================================== */

(function () {
	// 1. LOGIN PAGE BENCHMARK RESTRUCTURING
	function restructureLoginPage() {
		if (window.location.pathname !== '/login' && $('body').attr('data-route') !== 'login') return;

		// 1. Remove duplicate Frappe page-card-head replica above the card
		$('.page-card-head').remove();

		const $pageCard = $('.page-card, .login-content .page-card');
		if (!$pageCard.length) return;

		// Ensure outer container exists for centered benchmark layout
		if (!$('.brave-login-wrapper').length) {
			$pageCard.wrap('<div class="brave-login-wrapper" style="display:flex; flex-direction:column; align-items:center; width:100%; max-width:480px; margin: 40px auto 20px auto;"></div>');
		}

		const $wrapper = $('.brave-login-wrapper');

		// A. Inject Official Logo ABOVE the login card
		if (!$wrapper.find('.brave-login-header-logo').length) {
			$wrapper.prepend('<img class="brave-login-header-logo" src="/assets/chemical_erp/images/brave_logo_wide.png" alt="Brave Chemicals" />');
		}

		// B. Inject Heading ABOVE the login card
		if (!$wrapper.find('.brave-login-heading').length) {
			$('<div class="brave-login-heading">' +
				'<h1>Login to Brave ERP</h1>' +
				'<p>Welcome, please sign in to your dashboard</p>' +
			'</div>').insertAfter($wrapper.find('.brave-login-header-logo'));
		} else {
			$wrapper.find('.brave-login-heading h1').text('Login to Brave ERP');
		}

		document.title = "Login to Brave ERP";

		// C. Clean any remaining duplicate heads
		$('.page-card-head').remove();

		// D. Restructure Password row to include "Forgot Password?" on right side of label
		const $pwdGroup = $pageCard.find('input[type="password"]').closest('.form-group');
		if ($pwdGroup.length && !$pwdGroup.find('.password-label-row').length) {
			const $lbl = $pwdGroup.find('label');
			const labelText = 'Password';
			const forgotHtml = '<a href="#forgot" class="forgot-password-link">Forgot Password?</a>';

			const $row = $(`<div class="password-label-row">
				<label>${labelText}</label>
				${forgotHtml}
			</div>`);

			$lbl.replaceWith($row);
		}

		// Hide duplicate lower "Forgot Password?" message below input
		$pageCard.find('.forgot-password-message, p.forgot-password-message, a.for-forgot').hide();

		// E. Customize Login Button
		const $btn = $pageCard.find('button[type="submit"], .btn-login');
		if ($btn.length) {
			$btn.text('Login');
		}

		// F. Format Email label
		const $usrGroup = $pageCard.find('input[type="text"], input[type="email"]').first().closest('.form-group');
		if ($usrGroup.length) {
			const $uLbl = $usrGroup.find('label');
			if ($uLbl.length && !$uLbl.hasClass('brave-formatted')) {
				$uLbl.text('Email Address').addClass('brave-formatted');
			}
		}
	}

	// 2. DESK SIDEBAR & NAVBAR BENCHMARK ENHANCEMENTS
	function purgeDuplicateNavbarLogos() {
		const nav = document.querySelector('.navbar');
		if (!nav) return;

		// 1. Remove extra logo elements inside navbar-left or navbar-breadcrumbs
		const navLeftExtra = nav.querySelectorAll(
			'.navbar-left img, #navbar-breadcrumbs img, #navbar-breadcrumbs .app-logo, .navbar-left .navbar-brand, .brave-nav-logo'
		);
		navLeftExtra.forEach(el => el.remove());

		// 2. Keep only the first navbar-brand link
		const brandLinks = Array.from(nav.querySelectorAll('.navbar-brand'));
		if (brandLinks.length > 1) {
			for (let i = 1; i < brandLinks.length; i++) {
				brandLinks[i].remove();
			}
		}

		// 3. Keep only the first logo image inside the first navbar-brand
		if (brandLinks[0]) {
			const brandImgs = Array.from(brandLinks[0].querySelectorAll('img'));
			if (brandImgs.length > 1) {
				for (let i = 1; i < brandImgs.length; i++) {
					brandImgs[i].remove();
				}
			}
			if (brandImgs[0]) {
				brandImgs[0].style.height = '34px';
				brandImgs[0].style.maxHeight = '34px';
				brandImgs[0].style.width = 'auto';
				brandImgs[0].style.objectFit = 'contain';
				brandImgs[0].style.display = 'inline-block';
			}
		}

		// 4. Any extra logo images outside navbar-brand and outside user avatar
		const otherLogos = nav.querySelectorAll('img:not(.navbar-brand img):not(.avatar-img):not(.avatar img)');
		otherLogos.forEach(el => {
			if (!el.closest('.dropdown-navbar-user')) {
				el.remove();
			}
		});
	}

	function purgeRightBreadcrumbLogos() {
		// Target and remove any logo images inside breadcrumb or page-head title areas
		const breadcrumbLogos = document.querySelectorAll(
			'#navbar-breadcrumbs img, #navbar-breadcrumbs .app-logo, .breadcrumb img, .page-head .app-logo, .page-head img:not(.avatar-img), .title-area img, .page-breadcrumbs img, .frappe-breadcrumbs img'
		);
		breadcrumbLogos.forEach(el => el.remove());
	}

	function purgeAllDuplicateLogos() {
		purgeDuplicateNavbarLogos();
		purgeRightBreadcrumbLogos();
	}


	function enhanceDeskUI() {
		purgeDuplicateNavbarLogos();

		// Attach MutationObserver to navbar if not already attached
		const targetNode = document.querySelector('.navbar');
		if (targetNode && !window._braveNavObserver) {
			window._braveNavObserver = new MutationObserver(function () {
				purgeDuplicateNavbarLogos();
			});
			window._braveNavObserver.observe(targetNode, { childList: true, subtree: true });
		}

		// Purge any sidebar user box
		$('.sidebar-user-box').remove();

		// Ensure Dashboard is above Management in the left sidebar
		ensureDashboardSidebarItem();
	}

	function ensureDashboardSidebarItem() {
		const $sidebar = $('.layout-side-section, .desk-sidebar');
		if (!$sidebar.length) return;

		// Ensure left sidebar is ALWAYS visible and never hidden
		$sidebar.show().removeClass('hidden hide-sidebar');
		$sidebar.find('.standard-sidebar-section, .sidebar-item-container').show().removeClass('hidden');

		const $dashItems = $sidebar.find('[item-name="Dashboard"], [item-name="Operations Dashboard"]');
		const $mgmtItem = $sidebar.find('[item-name="Management Systems"], [item-name="Management"]').first();

		// Deduplicate if more than one exists
		if ($dashItems.length > 1) {
			$dashItems.slice(1).remove();
		}

		let $dashItem = $sidebar.find('[item-name="Dashboard"], [item-name="Operations Dashboard"]').first();

		if ($dashItem.length) {
			$dashItem.find('.sidebar-item-label').text(__('Dashboard'));
			$dashItem.find('a.item-anchor').attr('href', '/app/dashboard').attr('title', __('Dashboard'));
			if ($mgmtItem.length && $dashItem.index() > $mgmtItem.index()) {
				$dashItem.insertBefore($mgmtItem);
			}
		} else if ($mgmtItem.length) {
			// If not yet present in DOM, clone from $mgmtItem to ensure identical Frappe structure & classes
			const $cloned = $mgmtItem.clone();
			$cloned.attr('item-name', 'Dashboard');
			$cloned.find('.sidebar-item-label').text(__('Dashboard'));
			$cloned.find('a.item-anchor').attr('href', '/app/dashboard').attr('title', __('Dashboard'));
			$cloned.find('.sidebar-item-icon').html('<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>');
			$cloned.insertBefore($mgmtItem);
		}
	}

	// Handle click on sidebar Dashboard item
	$(document).on('click', '.sidebar-item-container[item-name="Dashboard"] a, .sidebar-item-container[item-name="Operations Dashboard"] a', function (e) {
		e.preventDefault();
		frappe.set_route('dashboard');
		if (window.BraveDashboard) {
			window.BraveDashboard.render();
		}
	});

	$(document).ready(function () {
		restructureLoginPage();
		enhanceDeskUI();
		setTimeout(restructureLoginPage, 300);
		setTimeout(enhanceDeskUI, 300);
		setTimeout(enhanceDeskUI, 1000);
	});

	$(document).on('app_ready page_change', function () {
		enhanceDeskUI();
	});

	$(document).ajaxComplete(function () {
		enhanceDeskUI();
		restructureLoginPage();
	});
})();

