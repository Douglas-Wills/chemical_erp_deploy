frappe.ui.form.on("Stock Entry", {
	refresh(frm) {
		if (frm.doc.docstatus === 0 && !frm.is_new() && frm.doc.purpose === "Manufacture" && !frm.doc.excess_waste_approved_by
			&& (frappe.user.has_role("Plant Manager") || frappe.user.has_role("Managing Director"))) {
			frm.add_custom_button(__("Approve Excess Waste"), () => {
				frappe.call("chemical_erp.controls.manufacturing.approve_excess_waste", { stock_entry: frm.doc.name })
					.then(() => frm.reload_doc());
			});
		}
		if (frm.doc.is_confidential) frm.dashboard.set_headline_alert(__("Confidential premix entry"), "orange");
	},
});
