// Every saved document:
// - a line manager looking at a document raised by someone in their team gets "Delete (as line manager)";
// - everyone else (except the MD, who has Delete) gets "Request Deletion", sent to their line manager or the MD.
$(document).on("form-refresh", (e, frm) => {
	if (!frm || frm.is_new() || frm.meta.istable || frm.meta.issingle) return;
	if (frappe.user.has_role("Managing Director") || frappe.session.user === "Administrator") return;
	const add = (key, label, fn) => {
		frm.__chem_menu = frm.__chem_menu || {};
		if (frm.__chem_menu[key] && frm.__chem_menu[key].remove) frm.__chem_menu[key].remove();
		frm.__chem_menu[key] = frm.page.add_menu_item(label, fn);
	};
	add("request", __("Request Deletion"), () => {
		frappe.prompt({ fieldname: "reason", fieldtype: "Small Text", label: __("Why should it be deleted?"), reqd: 1 }, (v) =>
			frappe.call("chemical_erp.controls.deletion.request_deletion", { doctype: frm.doctype, name: frm.doc.name, reason: v.reason })
				.then(({ message }) => frappe.show_alert({ message: __("Sent to {0}.", [message]), indicator: "green" })),
		__("Request Deletion"), __("Send"));
	});
	if (frm.__chem_menu.manager) { if (frm.__chem_menu.manager.remove) frm.__chem_menu.manager.remove(); delete frm.__chem_menu.manager; }
	if (!frappe.boot.chem_manages_staff) return;
	frappe.call({ method: "chemical_erp.controls.deletion.can_delete", args: { doctype: frm.doctype, name: frm.doc.name }, async: true })
		.then(({ message }) => {
			if (!message || !message.line_manager) return;
			add("manager", __("Delete (as line manager)"), () =>
				frappe.confirm(__("Delete {0} {1}? The Managing Director is told, and a copy is kept.", [__(frm.doctype), frm.doc.name]), () =>
					frappe.call("chemical_erp.controls.deletion.manager_delete", { doctype: frm.doctype, name: frm.doc.name })
						.then(() => { frappe.show_alert({ message: __("Deleted"), indicator: "green" }); frappe.set_route("List", frm.doctype); })));
		});
});
