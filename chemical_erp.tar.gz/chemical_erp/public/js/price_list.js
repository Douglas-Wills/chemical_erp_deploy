frappe.ui.form.on("Price List", {
	refresh(frm) {
		if (frm.is_new() || !frm.doc.selling) return;
		frm.add_custom_button(__("Fill From Another List"), () => {
			const d = new frappe.ui.Dialog({
				title: __("Fill {0}", [frm.doc.name]),
				fields: [
					{ fieldname: "source", fieldtype: "Link", options: "Price List", label: __("Copy prices from"), reqd: 1,
					  get_query: () => ({ filters: { selling: 1, name: ["!=", frm.doc.name] } }) },
					{ fieldname: "adjust_percent", fieldtype: "Float", label: __("Adjust by %"), default: 0,
					  description: __("-5 = 5% below the source; 10 = 10% above") },
					{ fieldname: "item_group", fieldtype: "Link", options: "Item Group", label: __("Only this item group (optional)") },
					{ fieldname: "round_to", fieldtype: "Currency", label: __("Round up to the nearest"), default: 100 },
					{ fieldname: "respect_floor", fieldtype: "Check", label: __("Never below the item's price floor"), default: 1 },
					{ fieldname: "overwrite", fieldtype: "Check", label: __("Replace prices already in this list"), default: 0 },
				],
				primary_action_label: __("Fill"),
				primary_action(v) {
					frappe.call({ method: "chemical_erp.chemical_core.pricing.build", args: Object.assign({ target: frm.doc.name }, v), freeze: true })
						.then(({ message: r }) => {
							d.hide();
							frappe.msgprint(__("{0} added, {1} replaced, {2} kept as they were, {3} raised to the price floor.",
								[r.created, r.updated, r.skipped, r.raised_to_floor]), __("Prices filled"));
						});
				},
			});
			d.show();
		});
		frm.add_custom_button(__("Compare Price Lists"), () => frappe.set_route("query-report", "Price List Comparison"));
	},
});
