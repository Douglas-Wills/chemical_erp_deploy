"""Our modules were called HR and Maintenance, names that Frappe HR and ERPNext already use, so Frappe looked for our
code in their apps. They are now People Management and Plant Maintenance; move any of our records still filed under
the old names (e.g. left behind by an install that stopped part-way). Records belonging to HRMS/ERPNext are not touched."""
import glob
import json
import os

import frappe

MOVES = {"HR": "People Management", "Maintenance": "Plant Maintenance"}
KINDS = ("DocType", "Report", "Page", "Print Format", "Workspace", "Number Card", "Dashboard Chart")


def ours():
	"""(kind, name, module) for every record our app ships in the renamed modules."""
	root = frappe.get_app_path("chemical_erp")
	for folder in ("people_management", "plant_maintenance"):
		for path in glob.glob(os.path.join(root, folder, "*", "*", "*.json")):
			if os.path.basename(path)[:-5] != os.path.basename(os.path.dirname(path)):
				continue
			try:
				d = json.load(open(path))
			except Exception:
				continue
			if isinstance(d, dict) and d.get("doctype") in KINDS and d.get("module") in MOVES.values():
				yield d["doctype"], d.get("name"), d["module"]


def execute():
	for module in MOVES.values():
		if not frappe.db.exists("Module Def", module):
			frappe.get_doc({"doctype": "Module Def", "module_name": module, "app_name": "chemical_erp"}).insert(
				ignore_permissions=True, ignore_if_duplicate=True)
	for kind, name, module in ours():
		if name and frappe.db.exists(kind, name) and frappe.db.get_value(kind, name, "module") in MOVES:
			frappe.db.set_value(kind, name, "module", module, update_modified=False)
	frappe.clear_cache()
