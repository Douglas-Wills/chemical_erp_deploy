"""Remove repetition: Tender Scan Settings is now the Tender Scanning section of Tender Settings (its values and scope
keywords move across), and the Missing Current SDS report is covered by Document Gaps."""
import frappe

MOVE = {"enabled": "scan_enabled", "email_account": "scan_email_account", "min_score": "min_score", "alert_score": "alert_score",
        "notify_role": "notify_role", "digest_recipients": "digest_recipients", "country_terms": "country_terms"}


def execute():
	old = {r.field: r.value for r in frappe.db.sql(
		"select field, value from `tabSingles` where doctype = 'Tender Scan Settings'", as_dict=True)}
	if old and frappe.get_meta("Tender Settings").has_field("scan_enabled"):
		for src, dst in MOVE.items():
			if old.get(src) not in (None, ""):
				frappe.db.set_single_value("Tender Settings", dst, old[src])
		frappe.db.sql("""update `tabTender Scope Keyword` set parenttype = 'Tender Settings', parent = 'Tender Settings',
			parentfield = 'scope_keywords' where parenttype = 'Tender Scan Settings'""")
		frappe.db.sql("delete from `tabSingles` where doctype = 'Tender Scan Settings'")
	for kind, name in (("DocType", "Tender Scan Settings"), ("Report", "Missing Current SDS")):
		if frappe.db.exists(kind, name):
			frappe.delete_doc(kind, name, ignore_permissions=True, force=True, ignore_missing=True)
	# Events: our own Location field repeated Event's standard one
	if frappe.db.exists("Custom Field", "Event-visit_location"):
		if frappe.db.has_column("Event", "visit_location"):
			frappe.db.sql("update `tabEvent` set location = visit_location where ifnull(location, '') = '' and ifnull(visit_location, '') != ''")
		frappe.delete_doc("Custom Field", "Event-visit_location", ignore_permissions=True, force=True)
	frappe.clear_cache()
