"""Laboratory staff move from ERPNext's broad "Quality Manager" role to Chemical ERP's own roles: the QC Analyst post keeps
QC Analyst only; the Laboratory Assistant access profile (and the grants made from it) gives Laboratory Technician."""
import frappe

OLD, NEW = "Quality Manager", "Laboratory Technician"


def execute():
	if not frappe.db.exists("Role", NEW):
		frappe.get_doc({"doctype": "Role", "role_name": NEW, "desk_access": 1}).insert(ignore_permissions=True)
	if frappe.db.exists("Company Position", "QC Analyst"):
		post = frappe.get_doc("Company Position", "QC Analyst")
		post.set("roles", [r for r in post.roles if r.role != OLD])
		if not any(r.role == NEW for r in post.roles):
			post.append("roles", {"role": NEW})
		post.flags.ignore_permissions = True
		post.save()
	# inspection drafts are edited by Laboratory Technicians (QC Analysts hold that role too)
	frappe.db.set_value("Workflow Document State", {"parent": "Chem Batch Release", "state": "Draft"}, "allow_edit", NEW)
	if frappe.db.exists("Access Profile", "Laboratory Assistant"):
		profile = frappe.get_doc("Access Profile", "Laboratory Assistant")
		if any(r.role == OLD for r in profile.roles):
			profile.set("roles", [r for r in profile.roles if r.role != OLD])
			if not any(r.role == NEW for r in profile.roles):
				profile.append("roles", {"role": NEW})
			profile.flags.ignore_permissions = True
			profile.save()
	# grants already made from that profile: swap the role, keeping the grant
	if frappe.db.has_column("Position Role Grant", "access_grant"):
		for g in frappe.get_all("Position Role Grant", filters={"role": OLD, "reason": "Access Grant"}, fields=["name", "user", "access_grant"]):
			if g.access_grant and frappe.db.get_value("Access Grant", g.access_grant, "access_profile") == "Laboratory Assistant":
				user = frappe.get_doc("User", g.user)
				user.add_roles(NEW)
				user.remove_roles(OLD)
				frappe.db.set_value("Position Role Grant", g.name, "role", NEW)
	from chemical_erp.people_management.positions import sync_positions

	sync_positions()  # takes back Quality Manager from QC Analyst holders (only where this system granted it)
