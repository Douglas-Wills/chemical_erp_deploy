"""Reference numbers: prefixes, number length, year placement and starting numbers per document.

A pattern is ERPNext's naming series: parts separated by dots, #### for the number (one # per digit),
YY / YYYY / MM / DD for dates, e.g. QUO-.######.-.YY gives QUO-000368-26.
ERPNext counts per prefix (everything before the ####): a date placed before the number therefore starts a new
count each year; a date after it keeps one running count."""

import frappe
from frappe import _
from frappe.utils import getdate, today

# Rows that are not document types of their own:
#   Waste Manifest      numbers given to Disposal Orders on approval
#   Customer Receipt    Payment Entries receiving money; Supplier Payment: Payment Entries paying money out
DOCTYPE_OF = {"Customer Receipt (money received)": "Payment Entry", "Supplier Payment (money paid)": "Payment Entry",
              "Purchase Receipt (goods received)": "Purchase Receipt", "Waste Manifest": None}
PAYMENT_ROW = {"Receive": "Customer Receipt (money received)", "Pay": "Supplier Payment (money paid)"}
SUGGESTED = [("Quotation", "QTN-.YY.-.#####"), ("Sales Invoice", "INV-.YY.-.#####"), ("Delivery Note", "DN-.YY.-.#####"),
             ("Customer Receipt (money received)", "RCT-.YY.-.#####"), ("Supplier Payment (money paid)", "PAY-.YY.-.#####"),
             ("Purchase Receipt (goods received)", "GRN-.YY.-.#####"),
             ("Expense Claim", "EXP-.YY.-.#####"), ("Disposal Order", "DO-.YY.-.###"), ("Waste Manifest", "WM-.YY.-.####")]
BRAVE = [("Quotation", "QUO-.######.-.YY"), ("Sales Invoice", "INV-.######.-.YY"), ("Delivery Note", "DN-.######.-.YY"),
         ("Customer Receipt (money received)", "RCT-.######.-.YY"), ("Supplier Payment (money paid)", "PAY-.######.-.YY"),
         ("Purchase Receipt (goods received)", "GRN-.######.-.YY"),
         ("Expense Claim", "EXP-.######.-.YY"), ("Disposal Order", "DO-.######.-.YY"), ("Waste Manifest", "WM-.######.-.YY")]


def _parts(pattern):
	"""Split a pattern into its parts. Like ERPNext, a pattern without # gets a 5-digit number at the end."""
	if not (pattern or "").strip():
		frappe.throw(_("Enter a pattern, e.g. QUO-.######.-.YY"))
	parts = [p for p in pattern.split(".") if p != ""]
	if not any(p.startswith("#") for p in parts):
		parts.append("#####")
	return parts


def _date_part(p, d):
	return {"YY": d.strftime("%y"), "YYYY": d.strftime("%Y"), "MM": d.strftime("%m"), "DD": d.strftime("%d")}.get(p)


def preview(pattern, number, on=None):
	d = getdate(on or today())
	out = []
	for p in _parts(pattern):
		if p.startswith("#"):
			out.append(str(number).zfill(len(p)))
		else:
			out.append(_date_part(p, d) or p)
	return "".join(out)


def counter_key(pattern, on=None):
	"""What ERPNext counts against: the resolved text before the number."""
	d = getdate(on or today())
	before = []
	for p in _parts(pattern):
		if p.startswith("#"):
			break
		before.append(_date_part(p, d) or p)
	return "".join(before)


def current_value(pattern):
	return frappe.db.get_value("Series", counter_key(pattern), "current", order_by=None) or 0


def next_for(row):
	if row.document == "Waste Manifest" and not frappe.db.exists("Series", counter_key(row.pattern)):
		return int(row.next_number or 1)
	return int(row.next_number) if row.next_number else int(current_value(row.pattern)) + 1


def set_options(doctype, pattern):
	"""Make the pattern available and the default for new documents of this type."""
	from frappe.custom.doctype.property_setter.property_setter import make_property_setter

	meta = frappe.get_meta(doctype)
	field = meta.get_field("naming_series")
	if not field:
		frappe.throw(_("{0} does not use a numbering series.").format(_(doctype)))
	options = [o for o in (field.options or "").split("\n") if o.strip()]
	options = [pattern] + [o for o in options if o != pattern]
	make_property_setter(doctype, "naming_series", "options", "\n".join(options), "Text", validate_fields_for_doctype=False)
	make_property_setter(doctype, "naming_series", "default", pattern, "Text", validate_fields_for_doctype=False)


def set_counter(pattern, next_number):
	key = counter_key(pattern)
	current = int(frappe.db.get_value("Series", key, "current") or 0)
	wanted = int(next_number) - 1
	if wanted < current:
		frappe.throw(_("{0} has already reached {1}. Starting at {2} would reuse numbers already issued; choose {3} or higher.").format(
			key, current, next_number, current + 1), title=_("Number already used"))
	if frappe.db.exists("Series", key):
		frappe.db.sql("update `tabSeries` set current = %s where name = %s", (wanted, key))
	else:
		frappe.db.sql("insert into `tabSeries` (name, current) values (%s, %s)", (key, wanted))


def apply(profile):
	frappe.only_for(("System Manager", "Managing Director"))
	done = []
	for row in profile.numbering:
		doctype = DOCTYPE_OF.get(row.document, row.document)
		if doctype:
			set_options(doctype, row.pattern)
		if row.next_number:
			set_counter(row.pattern, row.next_number)
		row.example = preview(row.pattern, next_for(row))
		row.next_number = None  # applied; from now on the counter carries on by itself
		row.applied_on = frappe.utils.now_datetime()
		done.append(f"{row.document}: {row.example}")
	return done


def payment_series(doc, method=None):
	"""Receipts and payments each keep their own count: pick the series from the direction of the money."""
	from chemical_erp.company import get_profile

	wanted = PAYMENT_ROW.get(doc.get("payment_type"))
	if not wanted:
		return
	pattern = next((r.pattern for r in get_profile(doc.get("company")).get("numbering") or [] if r.document == wanted), None)
	if pattern:
		doc.naming_series = pattern


def add_missing_rows(profile_name):
	"""Profiles created before receipts were numbered get the new rows (pattern only; nothing is applied)."""
	p = frappe.get_doc("Company Profile", profile_name)
	have = {r.document for r in p.numbering}
	have |= {"Purchase Receipt (goods received)" for r in p.numbering if r.document == "Purchase Receipt"}
	defaults = BRAVE if "brave" in (p.company or "").lower() else SUGGESTED
	added = False
	for r in p.numbering:
		if r.document == "Purchase Receipt":
			r.document, added = "Purchase Receipt (goods received)", True
	for doc, pattern in defaults:
		if doc not in have:
			p.append("numbering", {"document": doc, "pattern": pattern})
			added = True
	if added:
		p.flags.ignore_permissions = True
		p.save()


def manifest_number(disposal_order):
	"""Given when a disposal order is approved."""
	from frappe.model.naming import make_autoname

	from chemical_erp.company import get_profile

	pattern = next((r.pattern for r in get_profile(disposal_order.company).get("numbering") or [] if r.document == "Waste Manifest"),
	               "WM-.YY.-.####")
	return make_autoname(pattern, doc=disposal_order)
