"""Scheduled jobs. Each is idempotent and logs failures instead of stopping the scheduler."""

import frappe
from frappe import _
from frappe.utils import add_days, cint, date_diff, getdate, today

from chemical_erp.utils import approver_role, get_settings, notify, users_with_role


def _safe(fn):
	try:
		fn()
		frappe.db.commit()
	except Exception:
		frappe.db.rollback()
		frappe.log_error(title=f"chemical_erp job failed: {fn.__name__}", message=frappe.get_traceback())


def daily():
	for fn in (batch_expiry_and_retest, calibration_and_pm, waste_hold_ageing, sds_review, vendor_licences,
	           permit_expiry, batch_link_check):
		_safe(fn)


def hourly():
	from chemical_erp.chemical_core.doctype.formula_delegation.formula_delegation import expire_delegations

	_safe(expire_delegations)


def every_five_minutes():
	from chemical_erp.integrations.efris import retry_due

	_safe(retry_due)


def weekly():
	_safe(approval_aging)
	_safe(exchange_rate_reminder)


def batch_expiry_and_retest():
	now = today()
	qc = users_with_role("QC Analyst") + users_with_role(approver_role("quality"))
	for b in frappe.get_all("Batch", filters={"qc_status": "Released", "expiry_date": ["<", now]}, pluck="name"):
		frappe.db.set_value("Batch", b, "qc_status", "Expired")
		notify(qc, "Batch", b, _("Batch {0} has expired").format(b))
	for b in frappe.get_all("Batch", filters={"qc_status": "Released", "retest_date": ["<", now]}, pluck="name"):
		frappe.db.set_value("Batch", b, "qc_status", "Retest Due")
		notify(qc, "Batch", b, _("Batch {0} is due for retest").format(b))


def calibration_and_pm():
	from chemical_erp.plant_maintenance.doctype.equipment.equipment import compute_status

	for eq in frappe.get_all("Equipment", filters={"status": ["not in", ["Retired"]]}, fields=["*"]):
		status = compute_status(eq)
		if status != eq.status:
			frappe.db.set_value("Equipment", eq.name, "status", status)
			if status == "Out of Calibration":
				notify(users_with_role("QC Analyst") + users_with_role("Manufacturing Manager") + users_with_role(approver_role()), "Equipment", eq.name,
				       _("{0} is now out of calibration and cannot be used").format(eq.name), priority="High")
	lead_default = cint(get_settings().pm_lead_days or 7)
	for sched in frappe.get_all("PM Schedule", filters={"active": 1}, pluck="name"):
		s = frappe.get_doc("PM Schedule", sched)
		lead = cint(s.lead_days) or lead_default
		for t in s.tasks:
			due = t.next_due if t.frequency_type == "Days" else (today() if cint(t.batches_since) >= cint(t.interval) else None)
			if not due or date_diff(due, today()) > lead:
				continue
			if frappe.db.exists("Maintenance Job", {"pm_schedule": s.name, "pm_task": t.task, "status": ["!=", "Done"]}):
				continue
			job = frappe.get_doc({"doctype": "Maintenance Job", "job_type": "Preventive", "equipment": s.equipment,
			                      "pm_schedule": s.name, "pm_task": t.task, "due_date": due, "assigned_to": s.assigned_to,
			                      "checklist": [{"task": line.strip()} for line in (t.checklist or t.task).splitlines() if line.strip()]})
			job.insert(ignore_permissions=True)
			if s.assigned_to:
				notify(s.assigned_to, "Maintenance Job", job.name, _("PM due {0}: {1} on {2}").format(due, t.task, s.equipment))


def count_batches_for_pm(doc, method=None):
	"""Batch-based PM intervals: count manufacture entries per workstation."""
	if doc.purpose != "Manufacture" or not doc.get("work_order"):
		return
	stations = {r.workstation for r in frappe.get_all("Work Order Operation", filters={"parent": doc.work_order}, fields=["workstation"]) if r.workstation}
	for eq in frappe.get_all("Equipment", filters={"workstation": ["in", list(stations) or [""]]}, pluck="name"):
		for t in frappe.get_all("PM Task", filters={"parenttype": "PM Schedule", "frequency_type": "Batches Made",
		                                           "parent": ["in", frappe.get_all("PM Schedule", filters={"equipment": eq}, pluck="name") or [""]]},
		                       fields=["name", "batches_since"]):
			frappe.db.set_value("PM Task", t.name, "batches_since", cint(t.batches_since) + 1, update_modified=False)


def waste_hold_ageing():
	limit = cint(get_settings().waste_hold_days or 30)
	who = users_with_role("Waste Officer") + users_with_role("HSE Officer") + users_with_role("Managing Director")
	for b in frappe.get_all("Batch", filters={"is_waste_batch": 1, "creation": ["<", add_days(today(), -limit)]}, pluck="name"):
		if frappe.db.exists("Disposal Order", {"waste_batch": b, "status": "Closed"}):
			continue
		notify(who, "Batch", b, _("Waste batch {0} has been in Waste Hold for more than {1} days").format(b, limit))


def sds_review():
	soon = add_days(today(), cint(get_settings().expiry_warning_days or 30))
	who = users_with_role("HSE Officer") + users_with_role("Managing Director")
	for f in frappe.get_all("SDS File", filters={"sds_status": "Current", "review_due": ["<=", soon]}, fields=["name", "item_code"]):
		notify(who, "SDS File", f.name, _("SDS for {0} is due for review").format(f.item_code))


def vendor_licences():
	soon = add_days(today(), cint(get_settings().expiry_warning_days or 30))
	for v in frappe.get_all("Supplier", filters={"is_disposal_vendor": 1, "disposal_licence_expiry": ["<=", soon]}, pluck="name"):
		notify(users_with_role("HSE Officer"), "Supplier", v, _("Disposal licence for {0} expires soon or has expired").format(v))


def permit_expiry():
	"""Licences and permits in the Management Systems legal register nearing or past expiry."""
	soon = add_days(today(), cint(get_settings().expiry_warning_days or 30))
	who = users_with_role("HSE Officer") + users_with_role("Managing Director")
	for r in frappe.get_all("Legal Requirement", filters={"expiry_date": ["<=", soon], "compliance_status": ["!=", "Not Applicable"]},
	                        fields=["name", "law_name", "licence_permit_filing", "expiry_date", "enforced_on", "enforcement"]):
		what = r.licence_permit_filing or r.law_name
		gate = _(" It will {0} {1}.").format("block" if r.enforcement == "Block" else "warn on", r.enforced_on.lower()) if r.enforced_on else ""
		notify(who, "Legal Requirement", r.name, _("{0} expires on {1}.{2}").format(what, r.expiry_date, gate),
		       priority="High" if getdate(r.expiry_date) < getdate(today()) else "Medium")


def batch_link_check():
	"""Every submitted manufacture entry must have genealogy rows."""
	missing = frappe.db.sql("""select se.name from `tabStock Entry` se
		where se.docstatus=1 and se.purpose in ('Manufacture','Repack') and se.posting_date >= %s
		and not exists (select 1 from `tabBatch Link` bl where bl.voucher_no = se.name)""", add_days(today(), -7))
	if missing:
		notify(users_with_role("Managing Director"), "Stock Entry", missing[0][0],
		       _("{0} manufacture entries have no genealogy rows; traceability needs checking").format(len(missing)), priority="High")


def foreign_currencies():
	"""Currencies other than the company's that Brave actually uses: price lists, customers, suppliers, open tenders."""
	from chemical_erp.utils import company_currency

	base = company_currency()
	used = set(frappe.get_all("Price List", filters={"enabled": 1}, pluck="currency"))
	used |= set(frappe.get_all("Customer", filters={"disabled": 0, "default_currency": ["is", "set"]}, pluck="default_currency"))
	used |= set(frappe.get_all("Supplier", filters={"disabled": 0, "default_currency": ["is", "set"]}, pluck="default_currency"))
	if frappe.db.exists("DocType", "Tender"):
		used |= set(frappe.get_all("Tender", filters={"currency": ["is", "set"]}, pluck="currency"))
	return sorted(c for c in used if c and c != base), base


def stale_rates(days=7):
	"""Foreign currencies with no exchange rate to the company currency entered in the last `days` days."""
	currencies, base = foreign_currencies()
	since = add_days(today(), -days)
	return [c for c in currencies
	        if not frappe.db.exists("Currency Exchange", {"from_currency": c, "to_currency": base, "date": [">=", since]})
	        and not frappe.db.exists("Currency Exchange", {"from_currency": base, "to_currency": c, "date": [">=", since]})], base


def exchange_rate_reminder():
	"""ERPNext's automatic rate service does not cover the Uganda shilling, so Accounts enters rates by hand."""
	stale, base = stale_rates()
	if stale:
		notify(users_with_role("Accounts Manager") + users_with_role("Accounts User"), "Currency Exchange", None,
		       _("Enter this week's exchange rates to {0} (e.g. Bank of Uganda) for: {1}").format(base, ", ".join(stale)))


def approval_aging():
	from chemical_erp.utils import pending_approvals

	by_user = {}
	for user in frappe.get_all("User", filters={"enabled": 1, "user_type": "System User", "name": ["not in", ["Administrator", "Guest"]]}, pluck="name"):
		items = pending_approvals(user)
		if items:
			by_user[user] = items
	for user, items in by_user.items():
		oldest = min(items, key=lambda x: x.creation)
		notify(user, oldest.reference_doctype, oldest.reference_name,
		       _("{0} document(s) waiting for your approval; the oldest since {1}. On your phone: {2}/approvals").format(
			       len(items), getdate(oldest.creation), frappe.utils.get_url()))
