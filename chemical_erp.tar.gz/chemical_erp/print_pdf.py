"""House-style PDFs for documents that leave the company: quotations, sales orders, delivery notes, invoices and credit
notes, purchase orders, requests for quotation, receipts and payment vouchers.

- When a document is approved (submitted) its PDF is made in the house style and saved on it, named like
  QUO-000367-26_MERU_QUOTATION.pdf, so the exact copy sent is on record. Invoices wait for the URA EFRIS fiscal number,
  so the saved copy is the valid tax invoice. Cancelling re-makes it, marked CANCELLED.
- The PDF button on each of these documents downloads the same PDF at any time (drafts show DRAFT and are not signed).
- E-mails sent from these documents attach the same house-style PDF (it is their default print format).
"""
import re

import frappe
from frappe import _

# doctype -> (print format, word used in the file name)
HOUSE = {
	"Quotation": ("Quotation (House Style)", "QUOTATION"),
	"Sales Order": ("Sales Order (House Style)", "SALES_ORDER"),
	"Delivery Note": ("Delivery Note (House Style)", "DELIVERY_NOTE"),
	"Sales Invoice": ("Tax Invoice (EFRIS)", "INVOICE"),
	"Purchase Order": ("Purchase Order (House Style)", "PO"),
	"Request for Quotation": ("Request for Quotation (House Style)", "RFQ"),
	"Payment Entry": ("Receipt (House Style)", "RECEIPT"),
}
SKIP_WORDS = {"THE", "MOUNT", "MT", "ST", "SAINT", "OF", "AND", "M/S", "MESSRS", "MS"}


def party_name(doc):
	if doc.doctype == "Quotation":
		return doc.get("customer_name") or doc.get("party_name")
	if doc.doctype in ("Sales Order", "Delivery Note", "Sales Invoice"):
		return doc.get("customer_name") or doc.get("customer")
	if doc.doctype == "Purchase Order":
		return doc.get("supplier_name") or doc.get("supplier")
	if doc.doctype == "Payment Entry":
		return doc.get("party_name") or doc.get("party")
	if doc.doctype == "Request for Quotation" and doc.get("supplier"):
		return frappe.db.get_value("Supplier", doc.supplier, "supplier_name") or doc.supplier
	return None


def party_short(doc):
	"""The customer's or supplier's short name for file names: MOUNT MERU MILLERS LIMITED -> MERU."""
	words = [re.sub(r"[^A-Z0-9]", "", w) for w in (party_name(doc) or "").upper().split()]
	words = [w for w in words if w and w not in SKIP_WORDS]
	return words[0][:20] if words else ""


def type_word(doc):
	if doc.doctype == "Sales Invoice" and doc.get("is_return"):
		return "CREDIT_NOTE"
	if doc.doctype == "Delivery Note" and doc.get("is_return"):
		return "GOODS_RETURN"
	if doc.doctype == "Payment Entry" and doc.get("payment_type") != "Receive":
		return "PAYMENT_VOUCHER"
	return HOUSE[doc.doctype][1]


def file_name(doc):
	parts = [re.sub(r"[^A-Za-z0-9\-]", "-", doc.name), party_short(doc), type_word(doc)]
	return "_".join(p for p in parts if p) + ".pdf"


def print_format(doctype):
	fmt = HOUSE[doctype][0]
	return fmt if frappe.db.exists("Print Format", fmt) else None


def make(doc):
	return frappe.get_print(doc.doctype, doc.name, print_format=print_format(doc.doctype), doc=doc, as_pdf=True,
	                        no_letterhead=1)


def save(doctype, name):
	"""Make the PDF and keep it on the document, replacing the copy saved earlier (one current copy)."""
	doc = frappe.get_doc(doctype, name)
	pdf = make(doc)
	fname = file_name(doc)
	for f in frappe.get_all("File", filters={"attached_to_doctype": doctype, "attached_to_name": name},
	                        fields=["name", "file_name"]):
		if (f.file_name or "").startswith(re.sub(r"[^A-Za-z0-9\-]", "-", name) + "_") and f.file_name.endswith(".pdf"):
			frappe.delete_doc("File", f.name, ignore_permissions=True, force=True)
	frappe.get_doc({"doctype": "File", "file_name": fname, "attached_to_doctype": doctype, "attached_to_name": name,
	                "is_private": 1, "content": pdf}).insert(ignore_permissions=True)
	return fname


def queue(doc, method=None):
	"""doc_events: on_submit / on_cancel. Made in the background, after the save is committed."""
	if doc.doctype not in HOUSE or not print_format(doc.doctype):
		return
	if doc.doctype == "Sales Invoice" and doc.docstatus == 1 and not doc.get("efris_fdn"):
		return  # made when the EFRIS fiscal number arrives (see efris_done)
	frappe.enqueue("chemical_erp.print_pdf.save_quietly", doctype=doc.doctype, name=doc.name, queue="short",
	               enqueue_after_commit=True)


def efris_done(doc, method=None):
	"""Sales Invoice on_update_after_submit: the fiscal number is in, so the saved copy is now the tax invoice."""
	if doc.get("efris_fdn") and doc.has_value_changed("efris_fdn"):
		queue(doc)


def save_quietly(doctype, name):
	try:
		save(doctype, name)
	except Exception:
		frappe.log_error(title=f"House-style PDF not saved: {doctype} {name}", message=frappe.get_traceback())


@frappe.whitelist()
def download(doctype, name):
	"""PDF button: the house-style PDF, with the house file name."""
	if doctype not in HOUSE:
		frappe.throw(_("No house-style PDF for {0}.").format(doctype))
	frappe.has_permission(doctype, "print", name, throw=True)
	doc = frappe.get_doc(doctype, name)
	frappe.local.response.filename = file_name(doc)
	frappe.local.response.filecontent = make(doc)
	frappe.local.response.type = "pdf"


def ensure_print_settings():
	"""Setup step: e-mails carry PDFs, A4 pages, and the house formats are the defaults."""
	from frappe.custom.doctype.property_setter.property_setter import make_property_setter

	frappe.db.set_single_value("Print Settings", "send_print_as_pdf", 1)
	if not frappe.db.get_single_value("Print Settings", "pdf_page_size"):
		frappe.db.set_single_value("Print Settings", "pdf_page_size", "A4")
	for dt, (fmt, _word) in HOUSE.items():
		if frappe.db.exists("Print Format", fmt) and frappe.db.exists("DocType", dt):
			make_property_setter(dt, None, "default_print_format", fmt, "Data", for_doctype=True,
			                     validate_fields_for_doctype=False)
