"""Fleet and dangerous-goods delivery (Chemical Core > Sales; vehicles also under Maintenance).

Builds on ERPNext's Delivery Trip, Vehicle and Driver:
- before a trip leaves: the vehicle's permits and inspection are current; a load with dangerous goods needs a driver
  with current dangerous-goods training and a vehicle with a current dangerous-goods permit; chemicals that must be
  kept apart are not loaded together; the load is within the vehicle's limit;
- the driver's phone page /driver shows today's stops and records proof of delivery (receiver, photo, GPS);
- each trip carries its costs (fuel, allowances, other), cost per kg and per stop.
"""

import base64

import frappe
from frappe import _
from frappe.utils import flt, getdate, now_datetime, today

VEHICLE_DATES = (("dg_permit_expiry", "dangerous-goods permit"), ("inspection_expiry", "inspection"), ("fire_extinguisher_expiry", "fire extinguisher"))


def load_of(trip):
	"""(kg, dangerous goods?, {storage class: item}) of the delivery notes on the trip."""
	from chemical_erp.controls.manufacturing import to_kg
	from chemical_erp.regulatory_compliance.storage import storage_class

	kg, dg, classes = 0.0, False, {}
	for stop in trip.get("delivery_stops") or []:
		if not stop.get("delivery_note"):
			continue
		for r in frappe.get_all("Delivery Note Item", filters={"parent": stop.delivery_note}, fields=["item_code", "stock_qty"]):
			kg += to_kg(r.item_code, r.stock_qty)
			sub = frappe.get_cached_value("Item", r.item_code, "substance")
			if sub and frappe.get_cached_value("Substance Register", sub, "un_number"):
				dg = True
			c = storage_class(r.item_code)
			if c and c != "Non-hazardous":
				classes.setdefault(c, r.item_code)
	return kg, dg, classes


def trip_problems(trip):
	from chemical_erp.regulatory_compliance.storage import INCOMPATIBLE, REASONS

	problems = []
	kg, dg, classes = load_of(trip)
	now = getdate(today())
	if trip.get("vehicle"):
		v = frappe.get_doc("Vehicle", trip.vehicle)
		for field, label in VEHICLE_DATES:
			if field == "dg_permit_expiry" and not dg:
				continue
			if v.meta.has_field(field):
				d = v.get(field)
				if not d:
					problems.append(_("Vehicle {0}: no {1} date recorded.").format(trip.vehicle, label))
				elif getdate(d) < now:
					problems.append(_("Vehicle {0}: {1} expired on {2}.").format(trip.vehicle, label, d))
		if v.meta.has_field("max_load_kg") and flt(v.max_load_kg) and kg > flt(v.max_load_kg):
			problems.append(_("Load {0:.0f} kg is above the vehicle's limit of {1:.0f} kg.").format(kg, flt(v.max_load_kg)))
		if dg and v.meta.has_field("spill_kit") and not v.spill_kit:
			problems.append(_("Vehicle {0} carries no spill kit: required for dangerous goods.").format(trip.vehicle))
	if trip.get("driver"):
		d = frappe.get_doc("Driver", trip.driver)
		for field in ("expiry_date", "license_expiry"):
			if d.meta.has_field(field) and d.get(field) and getdate(d.get(field)) < now:
				problems.append(_("Driver {0}: driving licence expired on {1}.").format(d.full_name, d.get(field)))
		if dg and d.meta.has_field("dg_training_expiry") and (not d.dg_training_expiry or getdate(d.dg_training_expiry) < now):
			problems.append(_("Driver {0} has no current dangerous-goods training, and this load has dangerous goods.").format(d.full_name))
	names = list(classes)
	for i, a in enumerate(names):
		for b in names[i + 1:]:
			if frozenset((a, b)) in INCOMPATIBLE:
				problems.append(_("{0} ({1}) and {2} ({3}) must not travel together: {4}.").format(
					classes[a], a, classes[b], b, REASONS.get(frozenset((a, b)), _("they must be kept apart"))))
	return problems, kg, dg


def trip_validate(doc, method=None):
	problems, kg, dg = trip_problems(doc)
	if doc.meta.has_field("load_kg"):
		doc.load_kg = round(kg, 1)
		doc.dangerous_goods = 1 if dg else 0
	if doc.meta.has_field("total_cost"):
		doc.total_cost = flt(doc.fuel_cost) + flt(doc.driver_allowance) + flt(doc.other_cost)
		doc.cost_per_kg = flt(doc.total_cost) / kg if kg else 0
	if problems and doc.docstatus == 0:
		frappe.msgprint("<br>".join(problems), title=_("Before this trip leaves"), indicator="orange")


def trip_before_submit(doc, method=None):
	problems, _kg, _dg = trip_problems(doc)
	if problems:
		frappe.throw("<br>".join(problems), title=_("Trip cannot leave"))


# ---------------------------------------------------------------- the driver's phone
def driver_of(user):
	emp = frappe.db.get_value("Employee", {"user_id": user}, "name")
	return frappe.db.get_value("Driver", {"employee": emp}, "name") if emp else None


@frappe.whitelist()
def my_trips():
	driver = driver_of(frappe.session.user)
	if not driver and not set(("Stock Manager", "Managing Director", "System Manager")) & set(frappe.get_roles()):
		frappe.throw(_("Your login is not linked to a driver."), frappe.PermissionError)
	filters = {"docstatus": 1, "status": ["not in", ["Completed", "Cancelled"]]}
	if driver:
		filters["driver"] = driver
	out = []
	for t in frappe.get_all("Delivery Trip", filters=filters, fields=["name", "vehicle", "departure_time"], order_by="departure_time asc", limit=10):
		trip = frappe.get_doc("Delivery Trip", t.name)
		stops = []
		for i, s in enumerate(trip.delivery_stops):
			dn = frappe.db.get_value("Delivery Note", s.delivery_note, ["pod_received_by", "pod_time"], as_dict=True) if s.delivery_note else {}
			stops.append({"idx": i, "customer": s.customer, "address": frappe.utils.strip_html(s.get("customer_address") or s.get("address_display") or ""),
			              "contact": s.get("contact") or "", "delivery_note": s.delivery_note, "done": bool(s.visited or (dn or {}).get("pod_time")),
			              "items": [f"{r.item_name} × {flt(r.qty):g} {r.uom}" for r in frappe.get_all("Delivery Note Item", filters={"parent": s.delivery_note},
			                                                                                         fields=["item_name", "qty", "uom"])] if s.delivery_note else []})
		out.append({"name": t.name, "vehicle": t.vehicle, "departure": str(t.departure_time or ""), "stops": stops})
	return out


@frappe.whitelist(methods=["POST"])
def proof_of_delivery(trip, idx, received_by, latitude=None, longitude=None, photo=None, notes=None):
	t = frappe.get_doc("Delivery Trip", trip)
	driver = driver_of(frappe.session.user)
	if driver and t.driver != driver:
		frappe.throw(_("This is not your trip."), frappe.PermissionError)
	stop = t.delivery_stops[int(idx)]
	if not (received_by or "").strip():
		frappe.throw(_("Write the name of the person who received the goods."))
	values = {"pod_received_by": received_by.strip()[:140], "pod_time": now_datetime(),
	          "pod_gps": f"{flt(latitude):.6f},{flt(longitude):.6f}" if latitude and longitude else None, "pod_notes": (notes or "")[:500]}
	if photo and stop.delivery_note:
		header, _sep, data = photo.partition(",")
		if len(data) > 8_000_000:
			frappe.throw(_("Photo too large."))
		f = frappe.get_doc({"doctype": "File", "file_name": f"POD-{stop.delivery_note}.jpg", "attached_to_doctype": "Delivery Note",
		                    "attached_to_name": stop.delivery_note, "is_private": 1, "content": base64.b64decode(data)})
		f.save(ignore_permissions=True)
		values["pod_photo"] = f.file_url
	if stop.delivery_note:
		frappe.db.set_value("Delivery Note", stop.delivery_note, values)
	frappe.db.set_value("Delivery Stop", stop.name, "visited", 1)
	if all(s.visited or s.name == stop.name for s in t.delivery_stops) and t.meta.has_field("status"):
		frappe.db.set_value("Delivery Trip", t.name, "status", "Completed")
	return True
