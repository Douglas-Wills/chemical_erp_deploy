"""Business Diagnostics: one button that reads every module and says where the business can do better.

Each check measures one thing from the company's own records, compares it with good practice for a chemicals
manufacturer and distributor, and returns Good / Watch / Act Now with a recommendation, the role that should act and a
link to the evidence. A check that has no data yet says so instead of guessing. Every run is kept, so progress can be
compared run to run (and taken into the Management Review).
"""

import json

import frappe
from frappe import _
from frappe.utils import add_days, add_months, cint, date_diff, flt, getdate, now_datetime, today

from chemical_erp.utils import MD_ROLE

GOOD, WATCH, ACT, NODATA = "Good", "Watch", "Act Now", "No Data"
POINTS = {GOOD: 100, WATCH: 55, ACT: 15}
AREAS = ["Sales and Customers", "Finance and Cash", "Stock", "Production and Quality", "Purchasing and Suppliers",
         "Compliance and HSE", "People and Control", "Field Laboratory", "Tenders", "Security"]
CHECKS = []


def check(area, name, owner):
	def wrap(fn):
		CHECKS.append((area, name, owner, fn))
		return fn
	return wrap


def grade(value, good, watch, higher_is_better=True):
	if value is None:
		return NODATA
	if higher_is_better:
		return GOOD if value >= good else (WATCH if value >= watch else ACT)
	return GOOD if value <= good else (WATCH if value <= watch else ACT)


def R(status, value, target, finding, recommendation, evidence=None):
	return {"status": status, "value": value, "target": target, "finding": finding, "recommendation": recommendation, "evidence": evidence}


def money(v):
	return frappe.format_value(flt(v), {"fieldtype": "Currency"})


def pct(v):
	return f"{flt(v):.0f}%"


def scalar(sql, values=None):
	r = frappe.db.sql(sql, values or {})
	return flt(r[0][0]) if r and r[0][0] is not None else 0.0


def company():
	from chemical_erp.company import default_company

	return default_company()


def _sales(start, end, customer=False):
	return frappe.db.sql(f"""select {'customer,' if customer else ''} sum(base_net_total) from `tabSales Invoice`
		where docstatus=1 and is_return=0 and posting_date between %s and %s {'group by customer order by 2 desc' if customer else ''}""",
	                     (start, end))


# ================================================================== Sales and Customers
@check("Sales and Customers", "Sales trend (last 90 days vs the 90 before)", "Sales Manager")
def sales_trend():
	now = flt(_sales(add_days(today(), -90), today())[0][0])
	before = flt(_sales(add_days(today(), -180), add_days(today(), -91))[0][0])
	if not before:
		return R(NODATA, money(now), "Growing", "Not enough sales history yet.", "")
	change = (now - before) / before * 100
	return R(grade(change, 0, -10), f"{change:+.0f}%", "≥ 0%",
	         _("Net sales {0} in the last 90 days against {1} before.").format(money(now), money(before)),
	         _("Find which customers and products fell (Sales Analytics), revisit dormant customers and push quotations still open.")
	         if change < 0 else _("Keep it up: check margins hold as volume grows."), "/app/query-report/Sales Analytics")


@check("Sales and Customers", "Dependence on the largest customer (12 months)", "Managing Director")
def concentration():
	rows = _sales(add_months(today(), -12), today(), customer=True)
	total = sum(flt(r[1]) for r in rows)
	if not total:
		return R(NODATA, "-", "< 25%", "No sales in the last 12 months.", "")
	share = flt(rows[0][1]) / total * 100
	return R(grade(share, 25, 40, False), pct(share), "< 25%",
	         _("{0} accounts for {1} of sales.").format(rows[0][0], pct(share)),
	         _("Losing this customer would hurt badly: widen the base (utilities, manufacturers, Brave Home channels, tenders) and secure "
	           "a supply agreement with this customer.") if share >= 25 else _("A healthy spread of customers."),
	         "/app/query-report/Customer Acquisition and Loyalty")


@check("Sales and Customers", "Quotations won (quoted 1 to 4 months ago)", "Sales Manager")
def conversion():
	rows = frappe.get_all("Quotation", filters={"docstatus": 1, "transaction_date": ["between", [add_days(today(), -120), add_days(today(), -30)]]},
	                      fields=["status"])
	if len(rows) < 5:
		return R(NODATA, str(len(rows)), "≥ 40%", "Too few quotations to judge.", "")
	won = sum(1 for r in rows if r.status in ("Ordered", "Partially Ordered"))
	rate = won / len(rows) * 100
	return R(grade(rate, 40, 20), pct(rate), "≥ 40%", _("{0} of {1} quotations became orders.").format(won, len(rows)),
	         _("Follow up every quotation within 7 days; record why quotations are lost (price, lead time, specification) and act on the "
	           "commonest reason."), "/app/quotation?status=Lost")


@check("Sales and Customers", "Customers who stopped buying", "Sales Manager")
def dormant():
	recent = set(r[0] for r in frappe.db.sql("select distinct customer from `tabSales Invoice` where docstatus=1 and posting_date >= %s",
	                                         add_days(today(), -90)))
	year = set(r[0] for r in frappe.db.sql("select distinct customer from `tabSales Invoice` where docstatus=1 and posting_date between %s and %s",
	                                       (add_months(today(), -12), add_days(today(), -91))))
	if not year:
		return R(NODATA, "-", "< 10%", "Not enough history.", "")
	lost = year - recent
	share = len(lost) / len(year | recent) * 100
	return R(grade(share, 10, 25, False), f"{len(lost)} ({pct(share)})", "< 10%",
	         _("{0} customers bought in the past year but not in the last 90 days.").format(len(lost)),
	         _("Call each one this month: ask why, offer a site visit or water test. Examples: {0}.").format(", ".join(sorted(lost)[:5]))
	         if lost else _("No customers lost."), "/app/customer")


@check("Sales and Customers", "Gross margin (last 90 days)", "Managing Director")
def margin():
	co = company()
	income = scalar("""select sum(gle.credit - gle.debit) from `tabGL Entry` gle join `tabAccount` a on a.name = gle.account
		where gle.is_cancelled=0 and gle.company=%s and gle.posting_date >= %s and a.root_type='Income'""", (co, add_days(today(), -90)))
	cogs = scalar("""select sum(gle.debit - gle.credit) from `tabGL Entry` gle join `tabAccount` a on a.name = gle.account
		where gle.is_cancelled=0 and gle.company=%s and gle.posting_date >= %s and a.account_type='Cost of Goods Sold'""", (co, add_days(today(), -90)))
	if not income:
		return R(NODATA, "-", "≥ 30%", "No income posted in the period.", "")
	m = (income - cogs) / income * 100
	return R(grade(m, 30, 20), pct(m), "≥ 30%", _("Income {0}, cost of goods {1}.").format(money(income), money(cogs)),
	         _("Review the lowest-margin products (Batch Margin, Product Cost Summary): raise prices toward the floor, cut raw-material "
	           "cost, or improve yield.") if m < 30 else _("Margins are healthy."), "/app/query-report/Batch Margin")


# ================================================================== Finance and Cash
def _receivables():
	return frappe.get_all("Sales Invoice", filters={"docstatus": 1, "outstanding_amount": [">", 0]},
	                      fields=["outstanding_amount", "conversion_rate", "due_date"])


@check("Finance and Cash", "Days to collect from customers (DSO)", "Accounts Manager")
def dso():
	sales = flt(_sales(add_months(today(), -12), today())[0][0])
	if not sales:
		return R(NODATA, "-", "≤ 45 days", "No sales in 12 months.", "")
	owed = sum(flt(r.outstanding_amount) * (flt(r.conversion_rate) or 1) for r in _receivables())
	days = owed / (sales / 365)
	return R(grade(days, 45, 75, False), f"{days:.0f} days", "≤ 45 days", _("Customers owe {0}.").format(money(owed)),
	         _("Send statements monthly, chase at 7, 30 and 60 days overdue, and put customers past 60 days on credit hold. You pay "
	           "suppliers in advance, so every day of DSO is cash you finance."), "/app/query-report/Accounts Receivable")


@check("Finance and Cash", "Receivables more than 60 days overdue", "Accounts Manager")
def overdue60():
	rows = _receivables()
	total = sum(flt(r.outstanding_amount) * (flt(r.conversion_rate) or 1) for r in rows)
	if not total:
		return R(GOOD, "0%", "< 10%", "Nothing owed.", "")
	old = sum(flt(r.outstanding_amount) * (flt(r.conversion_rate) or 1) for r in rows if r.due_date and date_diff(today(), r.due_date) > 60)
	share = old / total * 100
	return R(grade(share, 10, 25, False), f"{money(old)} ({pct(share)})", "< 10%", _("{0} of receivables is over 60 days late.").format(pct(share)),
	         _("Agree payment plans in writing, stop supply to the worst accounts, and provide for doubtful debts."),
	         "/app/query-report/Accounts Receivable")


@check("Finance and Cash", "Weeks below minimum cash (next 13)", "Managing Director")
def cash_weeks():
	if not frappe.db.exists("Report", "Cash Flow Forecast"):
		return None
	from chemical_erp.chemical_core.report.cash_flow_forecast.cash_flow_forecast import execute

	data = execute({"company": company()})[1]
	weeks = sum(1 for w in data if w.get("flag"))
	low = min(data, key=lambda w: w["closing"]) if data else None
	return R(grade(weeks, 0, 2, False), str(weeks), "0",
	         _("Lowest balance {0} in {1}.").format(money(low["closing"]), low["label"]) if low else "",
	         _("Bring collections forward, phase advance payments to suppliers, or arrange an overdraft before the low weeks.")
	         if weeks else _("Cash covers the next 13 weeks."), "/app/query-report/Cash Flow Forecast")


@check("Finance and Cash", "Expense claims flagged as repeated small amounts (90 days)", "Accounts Manager")
def expense_flags():
	if not frappe.get_meta("Expense Claim").has_field("pattern_flag"):
		return None
	n = frappe.db.count("Expense Claim", {"pattern_flag": 1, "posting_date": [">=", add_days(today(), -90)]})
	return R(grade(n, 0, 3, False), str(n), "0", _("{0} claims were flagged for splitting or repetition.").format(n),
	         _("Review the pattern with the claimants' managers; consider a petty-cash float or a monthly allowance instead.")
	         if n else _("No suspicious patterns."), "/app/query-report/Expense Pattern Review")


@check("Finance and Cash", "Withholding-tax certificates not received (over 90 days)", "Accounts Manager")
def wht():
	if not frappe.db.exists("DocType", "WHT Certificate"):
		return None
	n = frappe.db.count("WHT Certificate", {"status": "Expected", "creation": ["<", add_days(today(), -90)]})
	return R(grade(n, 0, 5, False), str(n), "0", _("{0} certificates older than 90 days are still expected.").format(n),
	         _("Without the certificate the tax credit is lost at year end: ask each customer for it with the statement."),
	         "/app/wht-certificate?status=Expected")


# ================================================================== Stock
@check("Stock", "Stock that has not moved in 6 months", "Stores / Plant Manager")
def slow_stock():
	total = scalar("select sum(stock_value) from `tabBin`")
	if not total:
		return R(NODATA, "-", "< 10%", "No stock value.", "")
	moving = set(r[0] for r in frappe.db.sql("""select distinct item_code from `tabStock Ledger Entry`
		where is_cancelled=0 and actual_qty < 0 and posting_date >= %s""", add_days(today(), -180)))
	slow = frappe.db.sql("select item_code, sum(stock_value) v from `tabBin` where actual_qty > 0 group by item_code", as_dict=True)
	value = sum(flt(r.v) for r in slow if r.item_code not in moving)
	share = value / total * 100
	worst = sorted([r for r in slow if r.item_code not in moving], key=lambda r: -flt(r.v))[:4]
	return R(grade(share, 10, 25, False), f"{money(value)} ({pct(share)})", "< 10%",
	         _("Slow stock includes: {0}.").format(", ".join(r.item_code for r in worst)) if worst else "",
	         _("Sell it at a discount, use it in production, return it to the supplier, or dispose of it before it expires; buy smaller "
	           "lots next time."), "/app/query-report/Stock Ageing")


@check("Stock", "Batches waiting in quarantine more than 14 days", "QC Manager")
def quarantine():
	n = frappe.db.count("Batch", {"qc_status": "Quarantine", "creation": ["<", add_days(today(), -14)], "batch_qty": [">", 0]})
	return R(grade(n, 0, 3, False), str(n), "0", _("{0} batches have waited over two weeks for a release decision.").format(n),
	         _("Clear the testing backlog: stock waiting in quarantine is cash that cannot be sold."),
	         "/app/query-report/Quarantine and Rejected Stock")


@check("Stock", "Expired batches still in stock", "QC Manager")
def expired():
	n = frappe.db.count("Batch", {"expiry_date": ["<", today()], "batch_qty": [">", 0]})
	return R(GOOD if not n else ACT, str(n), "0", _("{0} batches are past their expiry date.").format(n),
	         _("Retest and re-date if the specification allows, otherwise move to waste hold and dispose; review order quantities."),
	         "/app/batch")


# ================================================================== Production and Quality
def _runs():
	if not frappe.get_meta("Stock Entry").has_field("actual_yield_percent"):
		return []
	return frappe.get_all("Stock Entry", filters={"purpose": "Manufacture", "docstatus": 1, "posting_date": [">=", add_days(today(), -90)]},
	                      fields=["actual_yield_percent", "expected_yield_percent", "total_batch_kg", "waste_unaccounted_kg"])


@check("Production and Quality", "Actual yield against formula yield (90 days)", "Plant Manager")
def yield_gap():
	runs = [r for r in _runs() if flt(r.total_batch_kg)]
	if not runs:
		return R(NODATA, "-", "≤ 1 point", "No production runs with yield recorded.", "")
	batch = sum(flt(r.total_batch_kg) for r in runs)
	actual = sum(flt(r.actual_yield_percent) * flt(r.total_batch_kg) for r in runs) / batch
	expected = sum(flt(r.expected_yield_percent) * flt(r.total_batch_kg) for r in runs) / batch
	gap = expected - actual
	return R(grade(gap, 1, 3, False), f"{actual:.1f}% vs {expected:.1f}%", "≤ 1 point below",
	         _("Over {0} runs ({1:,.0f} kg charged).").format(len(runs), batch),
	         _("Each point of yield on {0:,.0f} kg is {1:,.0f} kg of product lost: check charging accuracy, transfer losses and filling "
	           "overfill.").format(batch, batch / 100) if gap > 1 else _("Yield is on target."), "/app/query-report/Production Waste Variance")


@check("Production and Quality", "Losses not recorded as waste (90 days)", "Plant Manager")
def unrecorded():
	runs = [r for r in _runs() if flt(r.total_batch_kg)]
	if not runs:
		return None
	share = sum(flt(r.waste_unaccounted_kg) for r in runs) / sum(flt(r.total_batch_kg) for r in runs) * 100
	return R(grade(share, 1, 2, False), pct(share) if share >= 1 else f"{share:.1f}%", "< 1% of batch",
	         _("Material charged that left as neither product nor recorded waste."),
	         _("Find where it goes: evaporation, spills, unweighed rinses or charging errors. Weigh all waste."),
	         "/app/query-report/Production Waste Variance")


@check("Production and Quality", "Batches passing quality first time (90 days)", "QC Manager")
def first_pass():
	rows = frappe.get_all("Quality Inspection", filters={"docstatus": 1, "report_date": [">=", add_days(today(), -90)]}, fields=["status"])
	if len(rows) < 5:
		return R(NODATA, str(len(rows)), "≥ 98%", "Too few inspections to judge.", "")
	ok = sum(1 for r in rows if r.status == "Accepted")
	rate = ok / len(rows) * 100
	return R(grade(rate, 98, 95), pct(rate), "≥ 98%", _("{0} of {1} inspections accepted.").format(ok, len(rows)),
	         _("Study the rejected batches (OOS Investigations) for a common cause: raw material, weighing, mixing time or method."),
	         "/app/oos-investigation")


@check("Production and Quality", "Quality investigations open more than 30 days", "QC Manager")
def open_quality():
	old = add_days(today(), -30)
	n = sum(frappe.db.count(dt, {"status": ["!=", "Closed"], "creation": ["<", old]}) for dt in ("OOS Investigation", "Deviation")
	        if frappe.db.exists("DocType", dt))
	return R(grade(n, 0, 2, False), str(n), "0", _("{0} OOS investigations or deviations are over a month old.").format(n),
	         _("Close them with a root cause and corrective action; open investigations hide repeat problems."), "/app/deviation")


@check("Production and Quality", "Production orders past their end date", "Plant Manager")
def late_orders():
	n = frappe.db.count("Work Order", {"docstatus": 1, "status": ["not in", ["Completed", "Stopped", "Closed"]], "planned_end_date": ["<", today()]})
	return R(grade(n, 0, 3, False), str(n), "0", _("{0} production orders are late.").format(n),
	         _("Check material shortages (Material Check on each order) and capacity; plan the week ahead rather than day by day."),
	         "/app/work-order?status=In%20Process")


# ================================================================== Purchasing and Suppliers
@check("Purchasing and Suppliers", "Supplier lateness (90 days)", "Procurement Officer")
def supplier_delay():
	rows = frappe.db.sql("""select datediff(pr.posting_date, po.schedule_date) from `tabPurchase Receipt Item` pri
		join `tabPurchase Receipt` pr on pr.name = pri.parent join `tabPurchase Order` po on po.name = pri.purchase_order
		where pr.docstatus=1 and pr.posting_date >= %s and po.schedule_date is not null""", add_days(today(), -90))
	if len(rows) < 3:
		return R(NODATA, str(len(rows)), "≤ 2 days", "Too few receipts linked to orders.", "")
	avg = sum(max(flt(r[0]), 0) for r in rows) / len(rows)
	return R(grade(avg, 2, 7, False), f"{avg:.1f} days", "≤ 2 days late", _("Average across {0} received lines.").format(len(rows)),
	         _("Raise lateness in Supplier Evaluations, keep safety stock of critical raw materials, and qualify a second supplier."),
	         "/app/supplier-evaluation")


@check("Purchasing and Suppliers", "Raw materials with only one supplier", "Procurement Officer")
def single_source():
	materials = set(r[0] for r in frappe.db.sql("""select distinct bi.item_code from `tabBOM Item` bi join `tabBOM` b on b.name = bi.parent
		where b.docstatus=1 and b.is_active=1"""))
	if not materials:
		return R(NODATA, "-", "< 30%", "No active formulas.", "")
	counts = dict(frappe.db.sql("""select poi.item_code, count(distinct po.supplier) from `tabPurchase Order Item` poi
		join `tabPurchase Order` po on po.name = poi.parent where po.docstatus=1 and po.transaction_date >= %s group by poi.item_code""",
	                            add_months(today(), -12)))
	bought = [m for m in materials if counts.get(m)]
	if not bought:
		return R(NODATA, "-", "< 30%", "No purchases of formula materials in 12 months.", "")
	single = [m for m in bought if counts[m] == 1]
	share = len(single) / len(bought) * 100
	return R(grade(share, 30, 60, False), f"{len(single)} of {len(bought)}", "< 30%",
	         _("Single-supplier materials include {0}.").format(", ".join(single[:5])) if single else "",
	         _("Qualify a second source for the critical ones (approved supplier evaluation, test a sample lot)."), "/app/supplier")


# ================================================================== Compliance and HSE
@check("Compliance and HSE", "Products blocked from delivery: no SDS", "HSE Officer")
def documents():
	from chemical_erp.regulatory_compliance.documents import blocking_count

	n = blocking_count()
	return R(GOOD if not n else ACT, str(n), "0", _("{0} products in stock or selling have no current SDS.").format(n),
	         _("Get supplier SDSs or write your own (Document Gaps report)."), "/app/query-report/Document Gaps")


@check("Compliance and HSE", "Expired permits and licences", "HSE Officer")
def permits():
	if not frappe.db.exists("DocType", "Legal Requirement"):
		return None
	n = frappe.db.count("Legal Requirement", {"expiry_date": ["<", today()], "compliance_status": ["!=", "Not Applicable"]})
	soon = frappe.db.count("Legal Requirement", {"expiry_date": ["between", [today(), add_days(today(), 60)]]})
	return R(GOOD if not n else ACT, f"{n} expired, {soon} due in 60 days", "0 expired",
	         _("Operating with expired permits risks closure and fines."),
	         _("Renew now and set reminders 90 days ahead (NEMA, UNBS, OSH, trading licences)."), "/app/legal-requirement")


@check("Compliance and HSE", "Equipment out of calibration", "Plant Manager")
def calibration():
	n = frappe.db.count("Equipment", {"requires_calibration": 1, "status": "Out of Calibration"})
	return R(GOOD if not n else ACT, str(n), "0", _("{0} instruments or scales cannot be relied on.").format(n),
	         _("Calibrate them: results and weights from them are not valid evidence."), "/app/equipment?status=Out%20of%20Calibration")


@check("Compliance and HSE", "Incidents open more than 30 days", "HSE Officer")
def incidents():
	n = frappe.db.count("HSE Incident", {"status": ["!=", "Closed"], "occurred_on": ["<", add_days(today(), -30)]})
	return R(grade(n, 0, 2, False), str(n), "0", _("{0} incidents are still open after a month.").format(n),
	         _("Close each with a root cause and a completed corrective action."), "/app/hse-incident")


@check("Compliance and HSE", "High and critical risks open", "Managing Director")
def risks():
	if not frappe.db.exists("DocType", "IMS Risk"):
		return None
	n = frappe.db.count("IMS Risk", {"status": ["!=", "Closed"], "level": ["in", ["High", "Critical"]]})
	return R(grade(n, 0, 2, False), str(n), "0", _("{0} high or critical risks without closure.").format(n),
	         _("Give each an owner, a control and a date; review them at the Management Review."), "/app/ims-risk")


@check("Compliance and HSE", "Customer complaints open more than 30 days", "QC Manager")
def complaints():
	n = frappe.db.count("Customer Complaint", {"status": ["!=", "Closed"], "received_on": ["<", add_days(today(), -30)]})
	return R(grade(n, 0, 2, False), str(n), "0", _("{0} complaints over a month old.").format(n),
	         _("Answer within 30 days with the cause and the fix; slow answers lose customers."), "/app/customer-complaint")


# ================================================================== People and Control
@check("People and Control", "Approvals waiting more than 3 days", "Managing Director")
def approvals_waiting():
	from chemical_erp.utils import all_pending_approvals

	rows = all_pending_approvals()
	n = sum(1 for r in rows if date_diff(today(), r.creation) > 3)
	return R(grade(n, 2, 10, False), str(n), "≤ 2", _("{0} documents have waited more than 3 days for a signature.").format(n),
	         _("Set realistic approval limits (Settings > Suggest Limits), approve on the phone (/approvals), and delegate when away."),
	         "/app/query-report/Approval Aging")


@check("People and Control", "Share of approvals signed by the MD (90 days)", "Managing Director")
def md_share():
	from chemical_erp.people_management.positions import md_users

	rows = frappe.db.sql("""select user, count(*) from `tabApproval Log` where `on` >= %s and action in ('Approve', 'Approve Report', 'Approve Release',
		'Review') group by user""", add_days(today(), -90))
	total = sum(r[1] for r in rows)
	if total < 10:
		return R(NODATA, str(total), "< 40%", "Too few approvals to judge.", "")
	mds = set(md_users())
	share = sum(r[1] for r in rows if r[0] in mds) / total * 100
	return R(grade(share, 40, 70, False), pct(share), "< 40%", _("The MD signed {0} of {1} approvals.").format(pct(share), total),
	         _("The MD is the bottleneck: raise approval limits so routine items are signed lower down, and fill vacant positions.")
	         if share >= 40 else _("Approvals are spread across managers."), "/app/chemical-erp-settings")


@check("People and Control", "Training overdue", "HR Manager")
def training():
	n = frappe.db.count("Training Need", {"status": ["in", ["Open", "Scheduled"]], "due_date": ["<", today()]})
	return R(grade(n, 0, 5, False), str(n), "0", _("{0} training needs are past their due date.").format(n),
	         _("Schedule the sessions; untrained staff on hazardous tasks are both a safety and a legal risk."), "/app/training-need")


@check("People and Control", "Approved expenses still without receipts", "Accounts Manager")
def receipts():
	if not frappe.get_meta("Expense Claim").has_field("receipts_status"):
		return None
	n = frappe.db.count("Expense Claim", {"docstatus": 1, "receipts_status": "Awaiting Receipts", "modified": ["<", add_days(today(), -3)]})
	return R(grade(n, 0, 3, False), str(n), "0", _("{0} approved claims have waited over 72 hours for receipts.").format(n),
	         _("The 72-hour rule blocks new requests; remind the claimants."), "/app/expense-claim?receipts_status=Awaiting%20Receipts")


# ================================================================== Field Laboratory
@check("Field Laboratory", "Client equipment overdue for sampling", "QC Manager")
def sampling():
	n = frappe.db.count("Client Water System", {"active": 1, "next_due": ["<", today()]})
	return R(grade(n, 0, 3, False), str(n), "0", _("{0} boilers, towers or chillers are overdue for a visit.").format(n),
	         _("Each overdue visit is a missed invoice and a risk to the client's plant: plan visits weekly."), "/app/client-water-system")


@check("Field Laboratory", "Water reports out of specification (90 days)", "Sales Manager")
def noncompliant():
	rows = frappe.get_all("Water Analysis", filters={"docstatus": 1, "analysed_on": [">=", add_days(today(), -90)]}, fields=["compliance", "customer"])
	if len(rows) < 3:
		return R(NODATA, str(len(rows)), "< 30%", "Too few reports.", "")
	bad = [r for r in rows if r.compliance == "Non-compliant"]
	share = len(bad) / len(rows) * 100
	return R(grade(share, 30, 50, False), pct(share), "< 30%", _("{0} of {1} reports were out of specification.").format(len(bad), len(rows)),
	         _("Each is a sales opportunity and a risk: propose dosing changes or a treatment programme to {0}.").format(
		         ", ".join(sorted({r.customer for r in bad})[:4])) if bad else "", "/app/water-analysis?compliance=Non-compliant")


# ================================================================== Tenders
@check("Tenders", "Tender win rate (12 months)", "Tender Manager")
def tenders():
	if not frappe.db.exists("DocType", "Tender"):
		return None
	rows = frappe.get_all("Tender", filters={"status": ["in", ["Awarded", "Lost"]], "modified": [">=", add_months(today(), -12)]}, fields=["status"])
	if len(rows) < 4:
		return R(NODATA, str(len(rows)), "≥ 30%", "Too few decided tenders.", "")
	won = sum(1 for r in rows if r.status == "Awarded")
	rate = won / len(rows) * 100
	return R(grade(rate, 30, 15), pct(rate), "≥ 30%", _("{0} won of {1} decided.").format(won, len(rows)),
	         _("Record competitors' prices on lost tenders, bid only where you fit (Go/No-Go), and teach the bid library from winning bids."),
	         "/app/tender?status=Lost")


# ================================================================== Security
@check("Security", "Security items needing attention", "System Manager")
def security():
	from chemical_erp.controls.security import status

	rows = status()
	bad = [r["check"] for r in rows if r["state"] == "attention"]
	return R(GOOD if not bad else (WATCH if len(bad) <= 1 else ACT), str(len(bad)), "0", "; ".join(bad),
	         _("Open Chemical ERP Settings > Security Check and fix each item."), "/app/chemical-erp-settings")


# ================================================================== running it
def run_checks():
	out = []
	for area, name, owner, fn in CHECKS:
		try:
			r = fn()
		except Exception:
			frappe.log_error(title=f"Business diagnostic check failed: {name}", message=frappe.get_traceback())
			r = R(NODATA, "-", "", _("This check could not run (see Error Log)."), "")
		if r is None:
			continue
		r.update({"area": area, "check_name": name, "owner_role": owner})
		out.append(r)
	return out


def score(findings):
	areas = {}
	for f in findings:
		if f["status"] in POINTS:
			areas.setdefault(f["area"], []).append(POINTS[f["status"]])
	by_area = {a: round(sum(v) / len(v)) for a, v in areas.items()}
	overall = round(sum(by_area.values()) / len(by_area)) if by_area else 0
	return overall, by_area


@frappe.whitelist()
def run(notify=0):
	if not (set((MD_ROLE, "System Manager")) & set(frappe.get_roles()) or frappe.session.user == "Administrator"):
		frappe.throw(_("The Business Diagnostics is for the Managing Director."), frappe.PermissionError)
	findings = run_checks()
	overall, by_area = score(findings)
	order = {ACT: 0, WATCH: 1, GOOD: 2, NODATA: 3}
	findings.sort(key=lambda f: (AREAS.index(f["area"]) if f["area"] in AREAS else 99, order[f["status"]]))
	previous = frappe.db.get_value("Business Diagnostics", {}, "name", order_by="run_on desc")
	doc = frappe.get_doc({"doctype": "Business Diagnostics", "run_on": now_datetime(), "run_by": frappe.session.user, "company": company(),
	                      "overall_score": overall, "previous": previous, "area_scores": json.dumps(by_area),
	                      "act_now": sum(1 for f in findings if f["status"] == ACT), "watch": sum(1 for f in findings if f["status"] == WATCH),
	                      "good": sum(1 for f in findings if f["status"] == GOOD),
	                      "findings": [{k: (str(v)[:140] if k in ("value", "target", "evidence", "check_name", "area", "owner_role") else v)
	                                    for k, v in f.items()} for f in findings]})
	doc.insert(ignore_permissions=True)
	if cint(notify):
		from chemical_erp.people_management.positions import md_users
		from chemical_erp.utils import notify as tell

		tell(md_users(), "Business Diagnostics", doc.name, _("Monthly business diagnostic: score {0}%, {1} items to act on now.").format(
			overall, doc.act_now), priority="High")
	return doc.name


def monthly():
	frappe.set_user("Administrator")
	run(notify=1)
