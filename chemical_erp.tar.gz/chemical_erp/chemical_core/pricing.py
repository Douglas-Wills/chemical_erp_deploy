"""Price lists by customer group.

ERPNext picks a customer's prices from the customer's own price list, else the customer group's default price list.
This module gives each customer group its own selling list, and builds a list from another one (for example,
Utilities = Standard Selling less 5%, rounded to 100 shillings) without letting any price fall below the item's floor.
"""

import math

import frappe
from frappe import _
from frappe.utils import cint, flt

from chemical_erp.utils import MD_ROLE, company_currency

# Brave Chemicals: customer group → its price list
BRAVE_GROUP_PRICE_LISTS = {
	"Major Projects and Remote Sites": "Projects Selling",
	"Manufacturing": "Manufacturers Selling",
	"Water and Utilities": "Utilities Selling",
	"Healthcare and Laboratories": "Healthcare and Laboratories Selling",
	"Government and NGOs": "Government and NGOs Selling",
	"Brave Home: Retailers": "Brave Home Retailer",
	"Brave Home: Distributors": "Brave Home Distributor",
	"Brave Home: Institutions": "Brave Home Institutional",
	"Brave Home: Households": "Brave Home Consumer",
}
PRICE_ROLES = (MD_ROLE, "Sales Manager", "Accounts Manager", "System Manager")


def _check():
	if not set(PRICE_ROLES) & set(frappe.get_roles()):
		frappe.throw(_("Only the Managing Director, Sales Manager or Accounts Manager set prices."), frappe.PermissionError)


def ensure_price_list(name, currency=None):
	if not frappe.db.exists("Price List", name):
		frappe.get_doc({"doctype": "Price List", "price_list_name": name, "selling": 1, "buying": 0, "enabled": 1,
		                "currency": currency or company_currency() or "UGX"}).insert(ignore_permissions=True)
	return name


def link_groups(mapping):
	"""Create each list and make it the group's default, unless the group already has one."""
	done = []
	for group, pl in mapping.items():
		if not frappe.db.exists("Customer Group", group):
			continue
		ensure_price_list(pl)
		if not frappe.db.get_value("Customer Group", group, "default_price_list"):
			frappe.db.set_value("Customer Group", group, "default_price_list", pl)
			done.append(group)
	return done


def apply_brave():
	link_groups(BRAVE_GROUP_PRICE_LISTS)
	from chemical_erp.utils import get_settings

	s = get_settings()
	values = {}
	if not s.get("quick_order_item_group") and frappe.db.exists("Item Group", "Brave Home"):
		values["quick_order_item_group"] = "Brave Home"
	if not s.get("quick_order_price_list"):
		values["quick_order_price_list"] = "Brave Home Consumer"
	if not s.get("quick_order_customer_group") and frappe.db.exists("Customer Group", "Brave Home: Households"):
		values["quick_order_customer_group"] = "Brave Home: Households"
	for k, v in values.items():
		frappe.db.set_single_value("Chemical ERP Settings", k, v)


@frappe.whitelist()
def create_group_price_lists():
	"""Any company: one selling list per customer group that has none ('<group> Selling')."""
	_check()
	groups = frappe.get_all("Customer Group", filters={"is_group": 0, "default_price_list": ["in", ["", None]]}, pluck="name")
	return link_groups({g: f"{g} Selling" for g in groups})


def round_up(value, step):
	step = flt(step)
	return math.ceil(flt(value) / step) * step if step > 0 else round(flt(value), 2)


@frappe.whitelist()
def build(target, source, adjust_percent=0, item_group=None, round_to=0, respect_floor=1, overwrite=0):
	"""Fill `target` from `source`: rate × (1 + adjust%), rounded up, never below the floor. Returns a summary."""
	_check()
	if target == source:
		frappe.throw(_("Choose a different source list."))
	filters = {"price_list": source, "selling": 1}
	if item_group:
		lft, rgt = frappe.db.get_value("Item Group", item_group, ["lft", "rgt"])
		groups = frappe.get_all("Item Group", filters={"lft": [">=", lft], "rgt": ["<=", rgt]}, pluck="name")
		filters["item_code"] = ["in", frappe.get_all("Item", filters={"item_group": ["in", groups]}, pluck="name") or [""]]
	created = updated = skipped = raised = 0
	for p in frappe.get_all("Item Price", filters=filters, fields=["item_code", "uom", "price_list_rate", "valid_from"]):
		rate = round_up(flt(p.price_list_rate) * (1 + flt(adjust_percent) / 100), round_to)
		if cint(respect_floor):
			floor = flt(frappe.get_cached_value("Item", p.item_code, "price_floor")) if frappe.get_meta("Item").has_field("price_floor") else 0
			stock = frappe.get_cached_value("Item", p.item_code, "stock_uom")
			factor = 1 if (p.uom or stock) == stock else flt(frappe.db.get_value("UOM Conversion Detail", {"parent": p.item_code, "uom": p.uom},
			                                                                         "conversion_factor")) or 1
			if floor and rate < floor * factor:
				rate = round_up(floor * factor, round_to)
				raised += 1
		existing = frappe.db.get_value("Item Price", {"price_list": target, "item_code": p.item_code, "uom": p.uom}, "name")
		if existing:
			if not cint(overwrite):
				skipped += 1
				continue
			frappe.db.set_value("Item Price", existing, "price_list_rate", rate)
			updated += 1
		else:
			frappe.get_doc({"doctype": "Item Price", "price_list": target, "item_code": p.item_code, "uom": p.uom,
			                "price_list_rate": rate, "selling": 1}).insert()
			created += 1
	return {"created": created, "updated": updated, "skipped": skipped, "raised_to_floor": raised}
