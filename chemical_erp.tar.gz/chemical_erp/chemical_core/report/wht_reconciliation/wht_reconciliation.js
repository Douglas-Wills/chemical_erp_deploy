frappe.query_reports["WHT Reconciliation"] = {
	filters: [
		{ fieldname: "year", label: __("Calendar Year"), fieldtype: "Int", default: new Date().getFullYear() },
		{ fieldname: "customer", label: __("Customer"), fieldtype: "Link", options: "Customer" },
		{ fieldname: "only_outstanding", label: __("Only Outstanding"), fieldtype: "Check" },
	],
};
