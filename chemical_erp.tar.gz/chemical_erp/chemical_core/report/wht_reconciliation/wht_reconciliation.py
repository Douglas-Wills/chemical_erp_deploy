"""WHT withheld from Brave in a year, invoice by invoice, with the certificates received and still outstanding.
Run it before the tax return: only WHT backed by a certificate can be claimed."""

import frappe
from frappe import _
from frappe.utils import flt


def execute(filters=None):
	f = frappe._dict(filters or {})
	year = int(f.year or frappe.utils.getdate().year)
	date_from, date_to = (f.from_date, f.to_date) if f.from_date and f.to_date else (f"{year}-01-01", f"{year}-12-31")
	rows = frappe.db.sql("""select si.name invoice, si.posting_date, si.customer, si.base_net_total net, si.wht_amount,
		si.wht_status, si.wht_certificate, c.certificate_no, c.received_on, c.claimed_in_period, c.status cert_status
		from `tabSales Invoice` si left join `tabWHT Certificate` c on c.name = si.wht_certificate
		where si.docstatus = 1 and si.is_return = 0 and si.wht_applicable = 1 and si.posting_date between %s and %s
		{customer} order by si.customer, si.posting_date""".format(customer="and si.customer = %s" if f.customer else ""),
		(date_from, date_to, f.customer) if f.customer else (date_from, date_to), as_dict=True)
	if f.only_outstanding:
		rows = [r for r in rows if (r.cert_status or "Expected") == "Expected"]
	expected = sum(flt(r.wht_amount) for r in rows)
	received = sum(flt(r.wht_amount) for r in rows if r.cert_status in ("Received", "Claimed"))
	summary = [{"label": _("WHT withheld"), "value": frappe.utils.fmt_money(expected, precision=0), "indicator": "Blue"},
	           {"label": _("Backed by certificates"), "value": frappe.utils.fmt_money(received, precision=0), "indicator": "Green"},
	           {"label": _("Certificates outstanding"), "value": frappe.utils.fmt_money(expected - received, precision=0),
	            "indicator": "Red" if expected - received else "Green"}]
	return [
		{"fieldname": "customer", "label": _("Customer"), "fieldtype": "Link", "options": "Customer", "width": 170},
		{"fieldname": "invoice", "label": _("Invoice"), "fieldtype": "Link", "options": "Sales Invoice", "width": 140},
		{"fieldname": "posting_date", "label": _("Date"), "fieldtype": "Date", "width": 95},
		{"fieldname": "net", "label": _("Value excl. VAT"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "wht_amount", "label": _("WHT"), "fieldtype": "Currency", "width": 110},
		{"fieldname": "wht_status", "label": _("Status"), "fieldtype": "Data", "width": 150},
		{"fieldname": "certificate_no", "label": _("Certificate No."), "fieldtype": "Data", "width": 130},
		{"fieldname": "received_on", "label": _("Received"), "fieldtype": "Date", "width": 95},
		{"fieldname": "claimed_in_period", "label": _("Claimed In"), "fieldtype": "Data", "width": 100},
		{"fieldname": "wht_certificate", "label": _("Certificate Record"), "fieldtype": "Link", "options": "WHT Certificate", "width": 130},
	], rows, None, None, summary
