from frappe import _
from frappe.utils import date_diff, today

from chemical_erp.utils import all_pending_approvals


def execute(filters=None):
	data = [{"doctype_": r.reference_doctype, "document": r.reference_name, "state": r.workflow_state, "approver": r.user,
	         "days": date_diff(today(), r.creation)} for r in all_pending_approvals()]
	data.sort(key=lambda r: -r["days"])
	return [
		{"fieldname": "approver", "label": _("Waiting On"), "fieldtype": "Data", "width": 200},
		{"fieldname": "doctype_", "label": _("Document Type"), "fieldtype": "Data", "width": 150},
		{"fieldname": "document", "label": _("Document"), "fieldtype": "Dynamic Link", "options": "doctype_", "width": 160},
		{"fieldname": "state", "label": _("State"), "fieldtype": "Data", "width": 140},
		{"fieldname": "days", "label": _("Days Waiting"), "fieldtype": "Int", "width": 100},
	], data
