"""Batch margin with material, operations and disposal kept separate. MD only, because it reveals consumption."""

import frappe
from frappe import _
from frappe.utils import flt

from chemical_erp.utils import MD_ROLE, has_role


def execute(filters=None):
	if not has_role(MD_ROLE) and frappe.session.user != "Administrator":
		frappe.throw(_("Batch Margin is restricted to the Managing Director."), frappe.PermissionError)
	f = frappe._dict(filters or {})
	cond = {"purpose": "Manufacture", "docstatus": 1}
	if f.from_date:
		cond["posting_date"] = [">=", f.from_date]
	data = []
	for se in frappe.get_all("Stock Entry", filters=cond, fields=["name", "work_order", "bom_no", "fg_completed_qty", "posting_date",
	                                                            "total_outgoing_value", "total_additional_costs"]):
		fg = frappe.get_all("Stock Entry Detail", filters={"parent": se.name, "is_finished_item": 1}, fields=["batch_no"])
		batch = fg[0].batch_no if fg else None
		bom = frappe.db.get_value("BOM", se.bom_no, ["total_cost", "quantity"], as_dict=True) or frappe._dict()
		bom_cost = flt(bom.total_cost) * flt(se.fg_completed_qty) / (flt(bom.quantity) or 1)
		disposal = flt(frappe.db.sql("""select sum(total_debit) from `tabJournal Entry` where docstatus=1
			and waste_batch in (select name from `tabBatch` where waste_from_batch=%s)""", batch)[0][0]) if batch else 0
		sales = flt(frappe.db.sql("""select sum(base_net_amount) from `tabDelivery Note Item` where docstatus=1 and batch_no=%s""",
		                          batch)[0][0]) if batch else 0
		material, ops = flt(se.total_outgoing_value), flt(se.total_additional_costs)
		item = frappe.db.get_value("BOM", se.bom_no, "item")
		std_per_kg = flt(frappe.db.get_value("Product Cost Sheet", {"item_code": item, "status": "Current"}, "cost_per_kg"))
		standard_cost = std_per_kg * flt(se.fg_completed_qty)
		data.append({"batch": batch, "work_order": se.work_order, "date": se.posting_date, "bom_cost": bom_cost,
		             "material": material, "operations": ops, "yield_variance": material + ops - bom_cost,
		             "disposal": disposal, "sales": sales, "margin": sales - material - ops - disposal,
		             "standard_cost": standard_cost, "cost_variance": (material + ops + disposal - standard_cost) if standard_cost else 0})
	cur = lambda fn, lab: {"fieldname": fn, "label": lab, "fieldtype": "Currency", "width": 120}
	return [
		{"fieldname": "batch", "label": _("Batch"), "fieldtype": "Link", "options": "Batch", "width": 140},
		{"fieldname": "work_order", "label": _("Work Order"), "fieldtype": "Link", "options": "Work Order", "width": 130},
		{"fieldname": "date", "label": _("Date"), "fieldtype": "Date", "width": 95},
		cur("bom_cost", _("Formula Cost")), cur("material", _("Actual Material")), cur("operations", _("Operations")),
		cur("yield_variance", _("Yield Variance")), cur("standard_cost", _("Standard Cost")), cur("cost_variance", _("Actual vs Standard")), cur("disposal", _("Disposal")), cur("sales", _("Sales")), cur("margin", _("Margin")),
	], data
