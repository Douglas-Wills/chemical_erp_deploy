import frappe
from frappe import _
from frappe.utils import date_diff, today

from chemical_erp.utils import batch_balances


def execute(filters=None):
	f = frappe._dict(filters or {})
	statuses = [f.status] if f.status else ["Quarantine", "Rejected", "Retest Due", "Expired"]
	data = []
	for b in frappe.get_all("Batch", filters={"qc_status": ["in", statuses], "is_waste_batch": 0},
	                        fields=["name", "item", "qc_status", "creation", "expiry_date", "supplier_batch"]):
		for wh, qty in batch_balances(b.name):
			data.append({"batch": b.name, "item": b.item, "qc_status": b.qc_status, "warehouse": wh, "qty": qty,
			             "days_held": date_diff(today(), b.creation), "expiry_date": b.expiry_date, "supplier_batch": b.supplier_batch})
	data.sort(key=lambda r: -r["days_held"])
	return [
		{"fieldname": "batch", "label": _("Batch"), "fieldtype": "Link", "options": "Batch", "width": 150},
		{"fieldname": "item", "label": _("Item"), "fieldtype": "Link", "options": "Item", "width": 160},
		{"fieldname": "qc_status", "label": _("Status"), "fieldtype": "Data", "width": 100},
		{"fieldname": "warehouse", "label": _("Warehouse"), "fieldtype": "Link", "options": "Warehouse", "width": 160},
		{"fieldname": "qty", "label": _("Qty"), "fieldtype": "Float", "width": 90},
		{"fieldname": "days_held", "label": _("Days Held"), "fieldtype": "Int", "width": 90},
		{"fieldname": "expiry_date", "label": _("Expiry"), "fieldtype": "Date", "width": 100},
		{"fieldname": "supplier_batch", "label": _("Supplier Batch"), "fieldtype": "Data", "width": 120},
	], data
