frappe.query_reports["Quarantine and Rejected Stock"] = { filters: [{ fieldname: "status", label: __("Status"), fieldtype: "Select", options: "\nQuarantine\nRetest Due\nRejected\nExpired" }] };
