"""What each delivery trip cost: per trip, per kg and per stop."""

import frappe
from frappe import _
from frappe.utils import add_months, flt, today


def execute(filters=None):
	f = frappe._dict(filters or {})
	cond = {"docstatus": 1, "departure_time": [">=", f.get("from_date") or add_months(today(), -1)]}
	if f.get("vehicle"):
		cond["vehicle"] = f.vehicle
	data = []
	for t in frappe.get_all("Delivery Trip", filters=cond, fields=["name", "departure_time", "vehicle", "driver_name", "load_kg", "dangerous_goods",
	                                                                 "fuel_cost", "driver_allowance", "other_cost", "total_cost", "cost_per_kg"],
	                        order_by="departure_time desc"):
		stops = frappe.db.count("Delivery Stop", {"parent": t.name})
		value = flt(frappe.db.sql("""select sum(dn.base_net_total) from `tabDelivery Stop` s join `tabDelivery Note` dn on dn.name = s.delivery_note
			where s.parent=%s""", t.name)[0][0])
		t.update({"stops": stops, "per_stop": flt(t.total_cost) / stops if stops else 0, "goods_value": value,
		          "cost_share": flt(t.total_cost) / value * 100 if value else 0})
		data.append(t)
	c = lambda n, l, t="Currency", w=110, o=None: {"fieldname": n, "label": l, "fieldtype": t, "width": w, **({"options": o} if o else {})}
	return [c("name", _("Trip"), "Link", 140, "Delivery Trip"), c("departure_time", _("Left"), "Datetime", 140), c("vehicle", _("Vehicle"), "Link", 110, "Vehicle"),
	        c("driver_name", _("Driver"), "Data", 130), c("stops", _("Stops"), "Int", 60), c("load_kg", _("Load (kg)"), "Float", 90),
	        c("dangerous_goods", _("DG"), "Check", 50), c("fuel_cost", _("Fuel")), c("driver_allowance", _("Allowances")), c("other_cost", _("Other")),
	        c("total_cost", _("Total")), c("cost_per_kg", _("Per kg")), c("per_stop", _("Per Stop")), c("goods_value", _("Goods Delivered")),
	        c("cost_share", _("Cost % of Goods"), "Percent", 100)], data
