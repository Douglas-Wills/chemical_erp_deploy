frappe.query_reports["Price List Comparison"] = {
	filters: [
		{ fieldname: "item_group", label: __("Item Group"), fieldtype: "Link", options: "Item Group" },
		{ fieldname: "price_lists", label: __("Price Lists"), fieldtype: "MultiSelectList",
		  get_data: (txt) => frappe.db.get_link_options("Price List", txt, { selling: 1, enabled: 1 }) },
		{ fieldname: "only_problems", label: __("Only below floor or missing"), fieldtype: "Check" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (data && column.fieldname === "below_floor" && data.below_floor) value = `<span style="color:#b42318;font-weight:700">${value}</span>`;
		return value;
	},
};
