"""Every selling price list side by side, per item and unit, with the item's floor. Prices below the floor are flagged."""

import frappe
from frappe import _
from frappe.utils import flt


def execute(filters=None):
	filters = frappe._dict(filters or {})
	lists = frappe.get_all("Price List", filters={"selling": 1, "enabled": 1}, pluck="name", order_by="name")
	if filters.get("price_lists"):
		wanted = [x.strip() for x in filters.price_lists.split(",") if x.strip()] if isinstance(filters.price_lists, str) else filters.price_lists
		lists = [x for x in lists if x in wanted]
	item_filters = {"disabled": 0, "is_sales_item": 1}
	if filters.get("item_group"):
		lft, rgt = frappe.db.get_value("Item Group", filters.item_group, ["lft", "rgt"])
		item_filters["item_group"] = ["in", frappe.get_all("Item Group", filters={"lft": [">=", lft], "rgt": ["<=", rgt]}, pluck="name")]
	has_floor = frappe.get_meta("Item").has_field("price_floor")
	items = {i.name: i for i in frappe.get_all("Item", filters=item_filters,
	                                           fields=["name", "item_name", "item_group", "stock_uom"] + (["price_floor"] if has_floor else []))}
	prices = {}
	for p in frappe.get_all("Item Price", filters={"price_list": ["in", lists or [""]], "item_code": ["in", list(items) or [""]]},
	                        fields=["item_code", "uom", "price_list", "price_list_rate"]):
		prices.setdefault((p.item_code, p.uom), {})[p.price_list] = flt(p.price_list_rate)
	columns = [{"fieldname": "item_code", "label": _("Item"), "fieldtype": "Link", "options": "Item", "width": 140},
	           {"fieldname": "item_name", "label": _("Name"), "fieldtype": "Data", "width": 220},
	           {"fieldname": "uom", "label": _("Unit"), "fieldtype": "Data", "width": 90},
	           {"fieldname": "floor", "label": _("Floor"), "fieldtype": "Currency", "width": 110}]
	columns += [{"fieldname": frappe.scrub(pl), "label": pl, "fieldtype": "Currency", "width": 130} for pl in lists]
	columns += [{"fieldname": "below_floor", "label": _("Below Floor In"), "fieldtype": "Data", "width": 220},
	            {"fieldname": "missing", "label": _("Not Priced In"), "fieldtype": "Int", "width": 100}]
	data = []
	for (code, uom), by_list in sorted(prices.items(), key=lambda x: (items[x[0][0]].item_name, x[0][1] or "")):
		it = items[code]
		factor = 1 if (uom or it.stock_uom) == it.stock_uom else flt(frappe.db.get_value("UOM Conversion Detail", {"parent": code, "uom": uom},
		                                                                                    "conversion_factor")) or 1
		floor = flt(it.get("price_floor")) * factor
		row = {"item_code": code, "item_name": it.item_name, "uom": uom or it.stock_uom, "floor": floor or None}
		low = []
		for pl in lists:
			rate = by_list.get(pl)
			row[frappe.scrub(pl)] = rate
			if rate is not None and floor and rate < floor:
				low.append(pl)
		row["below_floor"] = ", ".join(low)
		row["missing"] = sum(1 for pl in lists if pl not in by_list)
		if filters.get("only_problems") and not (low or row["missing"]):
			continue
		data.append(row)
	return columns, data
