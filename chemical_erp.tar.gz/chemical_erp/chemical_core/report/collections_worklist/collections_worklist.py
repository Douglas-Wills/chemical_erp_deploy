"""The collector's daily list: who owes what, how late, last reminder, open promise, hold."""

import frappe
from frappe import _
from frappe.utils import date_diff, flt, today


def execute(filters=None):
	f = frappe._dict(filters or {})
	rows = {}
	for inv in frappe.get_all("Sales Invoice", filters={"docstatus": 1, "outstanding_amount": [">", 0], "is_return": 0},
	                          fields=["customer", "customer_name", "due_date", "base_grand_total", "grand_total", "outstanding_amount", "reminder_stage"]):
		rate = flt(inv.base_grand_total) / flt(inv.grand_total) if flt(inv.grand_total) else 1
		amt = flt(inv.outstanding_amount) * rate
		r = rows.setdefault(inv.customer, frappe._dict(customer=inv.customer, customer_name=inv.customer_name, total=0, current=0, d30=0, d60=0,
		                                              d90=0, d90p=0, oldest=0, stage=0))
		days = date_diff(today(), inv.due_date)
		r.total += amt
		key = "current" if days <= 0 else "d30" if days <= 30 else "d60" if days <= 60 else "d90" if days <= 90 else "d90p"
		r[key] += amt
		r.oldest = max(r.oldest, days)
		r.stage = max(r.stage, inv.reminder_stage or 0)
	data = []
	has_hold = frappe.get_meta("Customer").has_field("credit_hold")
	for r in rows.values():
		if has_hold:
			c = frappe.db.get_value("Customer", r.customer, ["credit_hold", "collector"], as_dict=True) or {}
			r.hold, r.collector = c.get("credit_hold"), c.get("collector")
		if f.get("collector") and r.get("collector") != f.collector:
			continue
		p = frappe.get_all("Payment Promise", filters={"customer": r.customer, "status": "Open"}, fields=["promised_date", "amount"],
		                   order_by="promised_date asc", limit=1)
		r.promise = f"{frappe.format_value(p[0].amount, {'fieldtype': 'Currency'})} by {frappe.format_value(p[0].promised_date, {'fieldtype': 'Date'})}" if p else ""
		r.broken = frappe.db.count("Payment Promise", {"customer": r.customer, "status": "Broken"})
		data.append(r)
	data.sort(key=lambda r: (-r.oldest, -r.total))
	c = lambda n, l, t="Currency", w=115, o=None: {"fieldname": n, "label": l, "fieldtype": t, "width": w, **({"options": o} if o else {})}
	cols = [c("customer", _("Customer"), "Link", 150, "Customer"), c("customer_name", _("Name"), "Data", 180), c("total", _("Owed")),
	        c("current", _("Not Yet Due")), c("d30", _("1-30 Days")), c("d60", _("31-60")), c("d90", _("61-90")), c("d90p", _("Over 90")),
	        c("oldest", _("Oldest (days)"), "Int", 90), c("stage", _("Reminders Sent"), "Int", 90), c("promise", _("Open Promise"), "Data", 170),
	        c("broken", _("Broken Promises"), "Int", 90)]
	if has_hold:
		cols += [c("hold", _("On Hold"), "Check", 70), c("collector", _("Collector"), "Link", 130, "User")]
	return cols, data
