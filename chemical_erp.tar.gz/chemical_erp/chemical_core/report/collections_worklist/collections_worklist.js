frappe.query_reports["Collections Worklist"] = {
	filters: [{ fieldname: "collector", label: __("Collector"), fieldtype: "Link", options: "User" }],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (data && ["d90p", "oldest"].includes(column.fieldname) && data.oldest > 90) value = `<span style="color:#b42318;font-weight:700">${value}</span>`;
		return value;
	},
	onload(report) {
		report.page.add_inner_button(__("Record a Payment Promise"), () => frappe.new_doc("Payment Promise"));
	},
};
