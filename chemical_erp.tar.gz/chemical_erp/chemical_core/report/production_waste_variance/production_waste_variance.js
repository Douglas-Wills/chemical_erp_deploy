frappe.query_reports["Production Waste Variance"] = {
	filters: [
		{ fieldname: "from_date", label: __("From"), fieldtype: "Date", default: frappe.datetime.add_months(frappe.datetime.get_today(), -3) },
		{ fieldname: "item_code", label: __("Product"), fieldtype: "Link", options: "Item" },
		{ fieldname: "only_flagged", label: __("Only flagged runs"), fieldtype: "Check" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (data && column.fieldname === "flag" && data.flag) value = `<span style="color:#b42318;font-weight:700">${value}</span>`;
		return value;
	},
};
