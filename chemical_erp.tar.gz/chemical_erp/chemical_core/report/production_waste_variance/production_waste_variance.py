"""Every production run: Waste = (1 − Yield %) × Total Batch Size, against the waste recorded, with the mass balance."""

import frappe
from frappe import _
from frappe.utils import add_months, flt, today

from chemical_erp.controls.manufacturing import run_balance


def execute(filters=None):
	f = frappe._dict(filters or {})
	cond = {"purpose": "Manufacture", "docstatus": 1, "posting_date": [">=", f.get("from_date") or add_months(today(), -3)]}
	if f.get("item_code"):
		cond["bom_no"] = ["in", frappe.get_all("BOM", filters={"item": f.item_code}, pluck="name") or [""]]
	from chemical_erp.controls.manufacturing import waste_thresholds

	tol, low = waste_thresholds()  # the same thresholds production entries are checked against
	data = []
	for name in frappe.get_all("Stock Entry", filters=cond, pluck="name", order_by="posting_date desc", limit=1000):
		se = frappe.get_doc("Stock Entry", name)
		if not se.bom_no:
			continue
		b = run_balance(se)
		var = (b.recorded_kg - b.expected_kg) / b.expected_kg * 100 if b.expected_kg else (100.0 if b.recorded_kg else 0.0)
		flag = ""
		if b.expected_kg and b.recorded_kg > b.expected_kg * (1 + tol / 100):
			flag = _("Above estimate")
		elif b.expected_kg and b.recorded_kg < b.expected_kg * low / 100:
			flag = _("Below estimate")
		elif b.batch_kg and b.unaccounted_kg > b.batch_kg * 0.02:
			flag = _("Loss not recorded (>2% of batch)")
		elif not se.get("waste_weighed") and b.recorded_kg:
			flag = _("Not marked weighed")
		data.append({"stock_entry": se.name, "posting_date": se.posting_date, "work_order": se.work_order,
		             "product": frappe.db.get_value("BOM", se.bom_no, "item"), "batch_kg": b.batch_kg, "output_kg": b.output_kg,
		             "yield_expected": b.yield_expected, "yield_actual": b.yield_actual, "expected_kg": b.expected_kg,
		             "recorded_kg": b.recorded_kg, "variance": var, "unaccounted_kg": b.unaccounted_kg, "flag": flag,
		             "reason": se.get("waste_reason"), "approved_by": se.get("excess_waste_approved_by"), "weighed": se.get("waste_weighed")})
	if f.get("only_flagged"):
		data = [d for d in data if d["flag"]]
	c = lambda n, l, t="Float", w=110, o=None: {"fieldname": n, "label": l, "fieldtype": t, "width": w, **({"options": o} if o else {})}
	columns = [c("posting_date", _("Date"), "Date", 95), c("stock_entry", _("Production Entry"), "Link", 150, "Stock Entry"),
	           c("product", _("Product"), "Link", 140, "Item"), c("batch_kg", _("Total Batch (kg)")), c("output_kg", _("Product Out (kg)")),
	           c("yield_expected", _("Formula Yield %"), "Percent", 100), c("yield_actual", _("Actual Yield %"), "Percent", 100),
	           c("expected_kg", _("Expected Waste (kg)"), "Float", 120), c("recorded_kg", _("Recorded Waste (kg)"), "Float", 120),
	           c("variance", _("Variance %"), "Percent", 90), c("unaccounted_kg", _("Loss Not Recorded (kg)"), "Float", 120),
	           c("flag", _("Flag"), "Data", 190), c("weighed", _("Weighed"), "Check", 70), c("reason", _("Reason Given"), "Data", 200),
	           c("approved_by", _("Approved By"), "Link", 130, "User"), c("work_order", _("Work Order"), "Link", 130, "Work Order")]
	te, tr = sum(d["expected_kg"] for d in data), sum(d["recorded_kg"] for d in data)
	tb, to = sum(d["batch_kg"] for d in data), sum(d["output_kg"] for d in data)
	summary = [{"label": _("Average actual yield"), "value": f"{(to / tb * 100):.1f}%" if tb else "-", "datatype": "Data", "indicator": "Blue"},
	           {"label": _("Expected waste (kg)"), "value": round(te, 1), "datatype": "Float", "indicator": "Blue"},
	           {"label": _("Recorded waste (kg)"), "value": round(tr, 1), "datatype": "Float", "indicator": "Blue"},
	           {"label": _("Overall variance"), "value": f"{((tr - te) / te * 100):+.1f}%" if te else "-", "datatype": "Data",
	            "indicator": "Orange" if te and abs(tr - te) / te > tol / 100 else "Green"},
	           {"label": _("Runs flagged"), "value": sum(1 for d in data if d["flag"]), "datatype": "Int", "indicator": "Red"}]
	return columns, data, None, None, summary
