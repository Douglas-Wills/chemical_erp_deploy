frappe.query_reports["Batch Trace"] = {
	filters: [
		{ fieldname: "batch", label: __("Batch"), fieldtype: "Link", options: "Batch", reqd: 1 },
		{ fieldname: "direction", label: __("Direction"), fieldtype: "Select", options: "Forward (to customers)\nBackward (to suppliers)", default: "Forward (to customers)" },
	],
};
