"""Forward and backward trace through Batch Link. Premix steps are opaque to anyone without Formula Owner."""

import frappe
from frappe import _

from chemical_erp.utils import is_formula_owner


def execute(filters=None):
	f = frappe._dict(filters or {})
	if not f.batch:
		return _columns(), []
	direction = f.direction or "Forward (to customers)"
	owner = is_formula_owner()
	rows, seen, frontier, depth = [], {f.batch}, [f.batch], 0
	field, other = ("from_batch", "to_batch") if direction.startswith("Forward") else ("to_batch", "from_batch")
	while frontier and depth < 12:
		depth += 1
		links = frappe.get_all("Batch Link", filters={field: ["in", frontier]}, ignore_permissions=True,
		                       fields=["from_batch", "to_batch", "from_party", "to_party", "voucher_type", "voucher_no",
		                               "qty_kg", "link_type", "posting_date", "is_confidential"])
		frontier = []
		for l in links:
			hidden = l.is_confidential and not owner
			rows.append({"level": depth, "link_type": l.link_type, "from_batch": l.from_batch, "to_batch": l.to_batch,
			             "party": l.to_party or l.from_party, "voucher_type": None if hidden else l.voucher_type,
			             "voucher_no": None if hidden else l.voucher_no, "qty_kg": None if hidden else l.qty_kg,
			             "posting_date": l.posting_date})
			nxt = l.get(other)
			if nxt and nxt not in seen:
				seen.add(nxt)
				frontier.append(nxt)
	customers = {r["party"] for r in rows if r["link_type"] == "Delivery" and r["party"]}
	summary = [{"label": _("Customers reached"), "value": len(customers), "indicator": "Red" if customers else "Green"},
	           {"label": _("Disposal Orders"), "value": len({r["party"] for r in rows if r["link_type"] == "Disposal"}), "indicator": "Blue"}]
	return _columns(), rows, None, None, summary


def _columns():
	return [
		{"fieldname": "level", "label": _("Step"), "fieldtype": "Int", "width": 60},
		{"fieldname": "link_type", "label": _("Movement"), "fieldtype": "Data", "width": 110},
		{"fieldname": "from_batch", "label": _("From Batch"), "fieldtype": "Link", "options": "Batch", "width": 150},
		{"fieldname": "to_batch", "label": _("To Batch"), "fieldtype": "Link", "options": "Batch", "width": 150},
		{"fieldname": "party", "label": _("Customer / Supplier / Disposal"), "fieldtype": "Data", "width": 200},
		{"fieldname": "voucher_type", "label": _("Document Type"), "fieldtype": "Data", "width": 130},
		{"fieldname": "voucher_no", "label": _("Document"), "fieldtype": "Dynamic Link", "options": "voucher_type", "width": 150},
		{"fieldname": "qty_kg", "label": _("Qty (kg)"), "fieldtype": "Float", "width": 100},
		{"fieldname": "posting_date", "label": _("Date"), "fieldtype": "Date", "width": 100},
	]
