"""13-week cash-flow forecast.

Starts from today's bank and cash balances and adds, week by week:
  money in  - unpaid customer invoices on their due date, moved by how late each customer usually pays;
              confirmed sales orders not yet invoiced, at delivery date + credit days + that delay;
  money out - purchase orders not yet paid, on the order date when suppliers are paid in advance (Settings),
              otherwise 30 days after the expected date; unpaid supplier invoices on their due date;
              approved expense claims not yet reimbursed; salaries and statutory deductions (from the last payroll);
              planned items (rent, loans, taxes) from Planned Cash Item.
Anything already overdue lands in the first week. Weeks that close below the minimum balance are flagged.
"""

import frappe
from frappe import _
from frappe.utils import add_days, add_months, cint, date_diff, flt, get_first_day, get_last_day, getdate, today

from chemical_erp.utils import get_settings

IN_COLS = ("receipts", "orders_in", "other_in")
OUT_COLS = ("supplier_orders", "supplier_invoices", "expenses", "salaries", "statutory", "other_out")


def execute(filters=None):
	f = frappe._dict(filters or {})
	company = f.get("company") or frappe.defaults.get_user_default("Company") or frappe.db.get_single_value("Global Defaults", "default_company")
	weeks = min(max(cint(f.get("weeks")) or 13, 4), 52)
	start = getdate(f.get("from_date") or today())
	s = get_settings()
	minimum = flt(f.get("minimum_balance")) if f.get("minimum_balance") not in (None, "") else flt(s.get("minimum_cash_balance"))
	buckets = [{"week": i + 1, "from_date": add_days(start, 7 * i), "to_date": add_days(start, 7 * i + 6),
	            **{c: 0.0 for c in IN_COLS + OUT_COLS}} for i in range(weeks)]
	end = buckets[-1]["to_date"]
	notes = []

	def put(col, date, amount):
		amount = flt(amount)
		if not amount:
			return
		date = getdate(date) if date else start
		if date > end:
			return
		i = 0 if date <= start else min(date_diff(date, start) // 7, weeks - 1)
		buckets[i][col] += amount

	opening = opening_balance(company)
	delays = customer_delays(company)
	credit_days = cint(s.get("default_credit_days")) or 30

	for inv in frappe.get_all("Sales Invoice", filters={"company": company, "docstatus": 1, "outstanding_amount": [">", 0]},
	                          fields=["customer", "due_date", "outstanding_amount", "conversion_rate", "currency", "party_account_currency"]):
		foreign = (inv.party_account_currency or inv.currency) != company_currency(company)
		rate = (flt(inv.conversion_rate) or 1) if foreign else 1
		put("receipts", add_days(inv.due_date, delays.get(inv.customer, 0)), flt(inv.outstanding_amount) * rate)

	for so in frappe.get_all("Sales Order", filters={"company": company, "docstatus": 1, "per_billed": ["<", 100],
	                                                  "status": ["not in", ["Closed", "Completed", "On Hold"]]},
	                         fields=["customer", "delivery_date", "base_grand_total", "per_billed", "advance_paid", "conversion_rate"]):
		left = flt(so.base_grand_total) * (1 - flt(so.per_billed) / 100) - flt(so.advance_paid) * (flt(so.conversion_rate) or 1)
		if left > 0:
			put("orders_in", add_days(so.delivery_date or start, credit_days + delays.get(so.customer, 0)), left)

	advance = (s.get("supplier_payment_timing") or "In advance").startswith("In advance")
	for po in frappe.get_all("Purchase Order", filters={"company": company, "docstatus": 1, "per_billed": ["<", 100],
	                                                     "status": ["not in", ["Closed", "Completed", "On Hold", "Delivered"]]},
	                         fields=["transaction_date", "schedule_date", "base_grand_total", "per_billed", "advance_paid", "conversion_rate"]):
		left = flt(po.base_grand_total) * (1 - flt(po.per_billed) / 100) - flt(po.advance_paid) * (flt(po.conversion_rate) or 1)
		if left > 0:
			put("supplier_orders", po.transaction_date if advance else add_days(po.schedule_date or po.transaction_date, 30), left)

	for pi in frappe.get_all("Purchase Invoice", filters={"company": company, "docstatus": 1, "outstanding_amount": [">", 0]},
	                         fields=["due_date", "outstanding_amount", "conversion_rate", "currency", "party_account_currency"]):
		foreign = (pi.party_account_currency or pi.currency) != company_currency(company)
		rate = (flt(pi.conversion_rate) or 1) if foreign else 1
		put("supplier_invoices", pi.due_date, flt(pi.outstanding_amount) * rate)

	if frappe.db.exists("DocType", "Expense Claim"):
		for ec in frappe.get_all("Expense Claim", filters={"company": company, "docstatus": 1, "status": "Unpaid"},
		                         fields=["grand_total", "total_amount_reimbursed", "posting_date"]):
			put("expenses", add_days(start, 3), flt(ec.grand_total) - flt(ec.total_amount_reimbursed))

	payroll = last_payroll(company)
	if payroll:
		day = min(max(cint(s.get("payroll_day")) or 28, 1), 28)
		month = get_first_day(start)
		while month <= end:
			put("salaries", month.replace(day=day), payroll["net"])
			put("statutory", month.replace(day=15), payroll["statutory"])  # last month's PAYE and NSSF, due by the 15th
			month = get_first_day(add_months(month, 1))
		notes.append(_("Salaries {0} a month and PAYE/NSSF {1} (incl. employer NSSF 10%), from the {2} payroll.").format(
			fmt(payroll["net"]), fmt(payroll["statutory"]), payroll["month"]))
	else:
		notes.append(_("No payroll on record: add salaries as a Planned Cash Item."))

	for p in frappe.get_all("Planned Cash Item", filters={"active": 1},
	                        fields=["description", "direction", "amount", "frequency", "start_date", "end_date", "company"]):
		if p.company and p.company != company:
			continue
		for d in occurrences(p, start, end):
			put("other_in" if p.direction == "Money In" else "other_out", d, p.amount)

	data, balance, lowest = [], opening, None
	for b in buckets:
		b["opening"] = balance
		b["money_in"] = sum(b[c] for c in IN_COLS)
		b["money_out"] = sum(b[c] for c in OUT_COLS)
		b["net"] = b["money_in"] - b["money_out"]
		balance = b["closing"] = balance + b["net"]
		b["flag"] = _("Below minimum") if minimum and balance < minimum else (_("Overdraft") if balance < 0 else "")
		b["label"] = f"W{b['week']} · {frappe.format_value(b['from_date'], {'fieldtype': 'Date'})}"
		if lowest is None or balance < lowest["closing"]:
			lowest = b
		data.append(b)

	summary = [
		{"label": _("Cash and bank today"), "value": opening, "datatype": "Currency", "indicator": "Blue"},
		{"label": _("Money in ({0} weeks)").format(weeks), "value": sum(b["money_in"] for b in data), "datatype": "Currency", "indicator": "Green"},
		{"label": _("Money out ({0} weeks)").format(weeks), "value": sum(b["money_out"] for b in data), "datatype": "Currency", "indicator": "Red"},
		{"label": _("Lowest point: {0}").format(lowest["label"]), "value": lowest["closing"], "datatype": "Currency",
		 "indicator": "Red" if (lowest["closing"] < 0 or (minimum and lowest["closing"] < minimum)) else "Green"},
	]
	chart = {"data": {"labels": [b["label"] for b in data],
	                  "datasets": [{"name": _("Closing balance"), "chartType": "line", "values": [round(b["closing"]) for b in data]},
	                               {"name": _("Money in"), "chartType": "bar", "values": [round(b["money_in"]) for b in data]},
	                               {"name": _("Money out"), "chartType": "bar", "values": [round(b["money_out"]) for b in data]}]},
	         "type": "axis-mixed", "colors": ["#1f3864", "#1f7a3d", "#b42318"]}
	if minimum:
		notes.append(_("Minimum balance {0}.").format(fmt(minimum)))
	notes.append(_("Customer payments are moved by how late each customer paid over the last 12 months; overdue items are in week 1."))
	notes.append(_("Suppliers: {0}.").format(_("paid when the order is placed") if advance else _("paid 30 days after the expected date")))
	return columns(), data, "<br>".join(notes), chart, summary


def columns():
	c = lambda name, label, width=120, ft="Currency": {"fieldname": name, "label": label, "fieldtype": ft, "width": width}
	return [c("label", _("Week"), 130, "Data"), c("opening", _("Opening")),
	        c("receipts", _("Customer Invoices")), c("orders_in", _("Sales Orders")), c("other_in", _("Other In")),
	        c("money_in", _("Money In")),
	        c("supplier_orders", _("Supplier Orders")), c("supplier_invoices", _("Supplier Invoices")), c("expenses", _("Expense Claims")),
	        c("salaries", _("Salaries")), c("statutory", _("PAYE / NSSF")), c("other_out", _("Other Out")), c("money_out", _("Money Out")),
	        c("net", _("Net")), c("closing", _("Closing")), c("flag", _("Flag"), 120, "Data")]


def fmt(v):
	return frappe.format_value(v, {"fieldtype": "Currency"})


def company_currency(company):
	return frappe.get_cached_value("Company", company, "default_currency")


def opening_balance(company):
	accounts = frappe.get_all("Account", filters={"company": company, "account_type": ["in", ["Bank", "Cash"]], "is_group": 0}, pluck="name")
	if not accounts:
		return 0.0
	row = frappe.db.sql("""select sum(debit) - sum(credit) from `tabGL Entry`
		where account in %(a)s and company = %(c)s and is_cancelled = 0 and posting_date <= %(d)s""",
	                    {"a": tuple(accounts), "c": company, "d": today()})
	return flt(row[0][0]) if row else 0.0


def customer_delays(company):
	"""Average days each customer paid after the due date over the last 12 months (0 to 120)."""
	if not frappe.db.exists("DocType", "Payment Ledger Entry"):
		return {}
	rows = frappe.db.sql("""
		select si.customer, avg(datediff(ple.paid_on, si.due_date))
		from `tabSales Invoice` si
		join (select against_voucher_no, max(posting_date) as paid_on from `tabPayment Ledger Entry`
		      where against_voucher_type = 'Sales Invoice' and voucher_type != 'Sales Invoice' and delinked = 0
		      group by against_voucher_no) ple on ple.against_voucher_no = si.name
		where si.docstatus = 1 and si.company = %(c)s and si.outstanding_amount <= 0 and si.posting_date >= %(since)s
		group by si.customer""", {"c": company, "since": add_months(today(), -12)})
	return {customer: int(min(max(flt(days), 0), 120)) for customer, days in rows}


def last_payroll(company):
	if not frappe.db.exists("DocType", "Salary Slip"):
		return None
	last = frappe.get_all("Salary Slip", filters={"company": company, "docstatus": 1}, fields=["max(end_date) as end_date"])
	if not last or not last[0].end_date:
		return None
	month_start, month_end = get_first_day(last[0].end_date), get_last_day(last[0].end_date)
	slips = frappe.get_all("Salary Slip", filters={"company": company, "docstatus": 1, "end_date": ["between", [month_start, month_end]]},
	                       fields=["base_gross_pay", "base_net_pay", "gross_pay", "net_pay"])
	gross = sum(flt(x.base_gross_pay or x.gross_pay) for x in slips)
	net = sum(flt(x.base_net_pay or x.net_pay) for x in slips)
	statutory = max(gross - net, 0) + 0.10 * gross  # employee deductions plus the employer's 10% NSSF
	return {"net": net, "statutory": statutory, "month": frappe.utils.formatdate(month_end, "MMMM yyyy")}


def occurrences(p, start, end):
	d = getdate(p.start_date)
	stop = min(getdate(p.end_date), end) if p.end_date else end
	step = {"Weekly": ("days", 7), "Monthly": ("months", 1), "Quarterly": ("months", 3), "Yearly": ("months", 12)}.get(p.frequency)
	out, n = [], 0
	while d <= stop and n < 400:
		if d >= start:
			out.append(d)
		if not step:
			break
		n += 1
		d = add_days(getdate(p.start_date), step[1] * n) if step[0] == "days" else add_months(getdate(p.start_date), step[1] * n)
	return out
