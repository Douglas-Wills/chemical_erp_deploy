frappe.query_reports["Cash Flow Forecast"] = {
	filters: [
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company", reqd: 1,
		  default: frappe.defaults.get_user_default("Company") },
		{ fieldname: "from_date", label: __("From"), fieldtype: "Date", default: frappe.datetime.get_today() },
		{ fieldname: "weeks", label: __("Weeks"), fieldtype: "Int", default: 13 },
		{ fieldname: "minimum_balance", label: __("Minimum balance (blank = Settings)"), fieldtype: "Currency" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (!data) return value;
		if (column.fieldname === "closing" && (data.flag || data.closing < 0)) value = `<span style="color:#b42318;font-weight:700">${value}</span>`;
		if (column.fieldname === "flag" && data.flag) value = `<span style="color:#b42318;font-weight:700">⚠ ${value}</span>`;
		return value;
	},
	onload(report) {
		report.page.add_inner_button(__("Planned Items (rent, loans, taxes)"), () => frappe.set_route("List", "Planned Cash Item"));
	},
};
