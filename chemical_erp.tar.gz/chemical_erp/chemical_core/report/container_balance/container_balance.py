"""Returnable containers held by each customer (only customers and deliveries that track containers)."""

import frappe
from frappe import _
from frappe.utils import date_diff, flt, today


def execute(filters=None):
	rows = frappe.db.sql("""select customer, container_item,
		sum(case when direction = 'Out' then qty else 0 end) as sent,
		sum(case when direction = 'Returned' then qty else 0 end) as returned,
		sum(case when direction = 'Written Off' then qty else 0 end) as written_off,
		max(case when direction = 'Out' then movement_date end) as last_out,
		max(deposit_per_container) as deposit
		from `tabContainer Movement` group by customer, container_item""", as_dict=True)
	data = []
	for r in rows:
		held = flt(r.sent) - flt(r.returned) - flt(r.written_off)
		if held <= 0:
			continue
		data.append({**r, "held": held, "deposit_value": held * flt(r.deposit), "days": date_diff(today(), r.last_out) if r.last_out else None})
	data.sort(key=lambda d: -(d["days"] or 0))
	return [
		{"fieldname": "customer", "label": _("Customer"), "fieldtype": "Link", "options": "Customer", "width": 180},
		{"fieldname": "container_item", "label": _("Container"), "fieldtype": "Link", "options": "Item", "width": 160},
		{"fieldname": "sent", "label": _("Sent"), "fieldtype": "Int", "width": 70},
		{"fieldname": "returned", "label": _("Returned"), "fieldtype": "Int", "width": 80},
		{"fieldname": "written_off", "label": _("Written Off"), "fieldtype": "Int", "width": 90},
		{"fieldname": "held", "label": _("Still Held"), "fieldtype": "Int", "width": 90},
		{"fieldname": "deposit_value", "label": _("Deposit Value"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "days", "label": _("Days Since Last Sent"), "fieldtype": "Int", "width": 130},
	], data
