"""Monthly management accounts by business line: sales, cost of goods, gross profit against budget, then overheads.

Business lines are groups of item groups (Business Line). Sales and cost of goods come from submitted sales invoices
(cost at the stock value of what was delivered); overheads are every other expense posted in the month.
"""

import frappe
from frappe import _
from frappe.utils import add_months, flt, get_first_day, get_last_day, getdate, today


def groups_of(line):
	out = set()
	for g in frappe.get_all("Business Line Group", filters={"parent": line}, pluck="item_group"):
		lft, rgt = frappe.db.get_value("Item Group", g, ["lft", "rgt"]) or (None, None)
		if lft:
			out |= set(frappe.get_all("Item Group", filters={"lft": [">=", lft], "rgt": ["<=", rgt]}, pluck="name"))
	return out


def line_of_group():
	m = {}
	for line in frappe.get_all("Business Line", order_by="sort_order asc, name asc", pluck="name"):
		for g in groups_of(line):
			m.setdefault(g, line)
	return m


def month_figures(company, start, end):
	mapping = line_of_group()
	lines = {}
	rows = frappe.db.sql("""select sii.item_group, sum(sii.base_net_amount) sales, sum(sii.stock_qty * ifnull(sii.incoming_rate, 0)) cost_si,
			sum(case when ifnull(sii.incoming_rate,0)=0 and sii.dn_detail is not null then sii.stock_qty * ifnull((select dni.incoming_rate from
			`tabDelivery Note Item` dni where dni.name = sii.dn_detail), 0) else 0 end) cost_dn
		from `tabSales Invoice Item` sii join `tabSales Invoice` si on si.name = sii.parent
		where si.docstatus = 1 and si.company = %s and si.posting_date between %s and %s group by sii.item_group""", (company, start, end), as_dict=True)
	for r in rows:
		line = mapping.get(r.item_group, _("Other"))
		x = lines.setdefault(line, {"sales": 0.0, "cost": 0.0})
		x["sales"] += flt(r.sales)
		x["cost"] += flt(r.cost_si) + flt(r.cost_dn)
	overheads = flt(frappe.db.sql("""select sum(gle.debit - gle.credit) from `tabGL Entry` gle join `tabAccount` a on a.name = gle.account
		where gle.is_cancelled = 0 and gle.company = %s and gle.posting_date between %s and %s and a.root_type = 'Expense'
		and ifnull(a.account_type, '') not in ('Cost of Goods Sold', 'Stock Adjustment')""", (company, start, end))[0][0])
	return lines, overheads


def execute(filters=None):
	f = frappe._dict(filters or {})
	company = f.get("company") or frappe.defaults.get_user_default("Company")
	month = getdate(f.get("month") or add_months(today(), -1))
	start, end = get_first_day(month), get_last_day(month)
	ytd_start = getdate(f"{start.year}-01-01")
	lines, overheads = month_figures(company, start, end)
	ytd_lines, ytd_over = month_figures(company, ytd_start, end)
	months = start.month
	budgets = {b.name: b for b in frappe.get_all("Business Line", fields=["name", "monthly_revenue_budget", "gross_margin_budget", "sort_order"])}
	order = sorted(set(lines) | set(ytd_lines), key=lambda n: (flt((budgets.get(n) or {}).get("sort_order")) or 99, n))
	data, tot = [], {"sales": 0, "gp": 0, "ytd_sales": 0, "ytd_gp": 0, "budget": 0, "ytd_budget": 0}
	for n in order:
		m, y, b = lines.get(n, {"sales": 0, "cost": 0}), ytd_lines.get(n, {"sales": 0, "cost": 0}), budgets.get(n) or frappe._dict()
		gp, ygp = m["sales"] - m["cost"], y["sales"] - y["cost"]
		budget = flt(b.get("monthly_revenue_budget"))
		row = {"line": n, "sales": m["sales"], "budget": budget, "vs_budget": (m["sales"] - budget) / budget * 100 if budget else None,
		       "cost": m["cost"], "gp": gp, "gm": gp / m["sales"] * 100 if m["sales"] else 0, "gm_budget": b.get("gross_margin_budget"),
		       "ytd_sales": y["sales"], "ytd_budget": budget * months, "ytd_gp": ygp, "ytd_gm": ygp / y["sales"] * 100 if y["sales"] else 0}
		for k in tot:
			tot[k] += flt(row.get(k))
		data.append(row)
	data.append({"line": _("Total gross profit"), "sales": tot["sales"], "budget": tot["budget"], "gp": tot["gp"],
	             "gm": tot["gp"] / tot["sales"] * 100 if tot["sales"] else 0, "ytd_sales": tot["ytd_sales"], "ytd_budget": tot["ytd_budget"],
	             "ytd_gp": tot["ytd_gp"], "bold": 1})
	data.append({"line": _("Overheads (all other expenses)"), "gp": -overheads, "ytd_gp": -ytd_over})
	data.append({"line": _("Net profit before tax"), "gp": tot["gp"] - overheads, "ytd_gp": tot["ytd_gp"] - ytd_over, "bold": 1})
	c = lambda n, l, t="Currency", w=120: {"fieldname": n, "label": l, "fieldtype": t, "width": w}
	columns = [c("line", _("Business Line"), "Data", 200), c("sales", _("Sales")), c("budget", _("Budget")), c("vs_budget", _("vs Budget %"), "Percent", 95),
	           c("cost", _("Cost of Goods")), c("gp", _("Gross Profit")), c("gm", _("Margin %"), "Percent", 85), c("gm_budget", _("Budget Margin %"), "Percent", 95),
	           c("ytd_sales", _("Sales YTD")), c("ytd_budget", _("Budget YTD")), c("ytd_gp", _("Profit YTD")), c("ytd_gm", _("Margin YTD %"), "Percent", 95)]
	chart = {"data": {"labels": [r["line"] for r in data[:-3]], "datasets": [{"name": _("Sales"), "values": [round(r["sales"]) for r in data[:-3]]},
	                                                                           {"name": _("Budget"), "values": [round(r["budget"]) for r in data[:-3]]},
	                                                                           {"name": _("Gross profit"), "values": [round(r["gp"]) for r in data[:-3]]}]},
	         "type": "bar", "colors": ["#1f3864", "#9aa5b1", "#1f7a3d"]}
	summary = [{"label": _("Sales"), "value": tot["sales"], "datatype": "Currency", "indicator": "Blue"},
	           {"label": _("Gross margin"), "value": f"{(tot['gp'] / tot['sales'] * 100):.1f}%" if tot["sales"] else "-", "datatype": "Data", "indicator": "Blue"},
	           {"label": _("Net profit"), "value": tot["gp"] - overheads, "datatype": "Currency", "indicator": "Green" if tot["gp"] >= overheads else "Red"}]
	return columns, data, _("{0}. Cost of goods is the stock value of what was delivered.").format(frappe.utils.formatdate(start, "MMMM yyyy")), chart, summary
