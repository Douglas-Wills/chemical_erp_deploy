frappe.query_reports["Business Line Profit and Loss"] = {
	filters: [
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company", reqd: 1, default: frappe.defaults.get_user_default("Company") },
		{ fieldname: "month", label: __("Month (any date in it)"), fieldtype: "Date", default: frappe.datetime.add_months(frappe.datetime.get_today(), -1) },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		return data && data.bold ? `<b>${value}</b>` : value;
	},
};
