"""One screen that says whether the site is set up well enough for the controls to work.

Fail: a control will not work, or will stop the business. Warning: worth fixing before go-live.
"""

import frappe
from frappe import _
from frappe.utils import flt, today

from chemical_erp.utils import current_sds, get_settings, users_with_role


def execute(filters=None):
	rows = []

	def add(area, check, ok, detail="", warn=False):
		rows.append({"area": area, "check": check, "result": "Pass" if ok else ("Warning" if warn else "Fail"), "detail": detail})

	s = get_settings()
	# ---------------------------------------------------------------- currency
	from chemical_erp.tasks import foreign_currencies, stale_rates
	from chemical_erp.utils import company_currency

	base = company_currency()
	add("Currency", _("Company currency is UGX"), base == "UGX", base or _("No default company"))
	foreign, _base = foreign_currencies()
	disabled = [c for c in foreign if not frappe.db.get_value("Currency", c, "enabled")]
	add("Currency", _("Foreign currencies in use are enabled"), not disabled, ", ".join(disabled))
	add("Currency", _("USD enabled (imports, exports and joint-venture tenders)"), bool(frappe.db.get_value("Currency", "USD", "enabled")), "", warn=True)
	stale, _b = stale_rates()
	add("Currency", _("Exchange rates entered in the last 7 days"), not stale,
	    _("Missing for: {0}. ERPNext's automatic rates do not cover UGX; enter the Bank of Uganda rate under Currency Exchange.").format(", ".join(stale))
	    if stale else _("Currencies in use: {0}").format(", ".join(foreign) or _("none besides {0}").format(base)))
	auto = frappe.db.get_single_value("Accounts Settings", "allow_stale") if frappe.get_meta("Accounts Settings").has_field("allow_stale") else None
	if auto is not None:
		add("Currency", _("Stale exchange rates are not silently reused"), not auto,
		    _("Turn off 'Allow Stale Exchange Rates' in Accounts Settings so an old rate is never applied unnoticed"), warn=True)
	no_cur = frappe.db.count("Price List", {"enabled": 1, "currency": ["is", "not set"]})
	add("Currency", _("Every price list has a currency"), not no_cur, _("{0} without").format(no_cur))

	# ---------------------------------------------------------------- settings and warehouses
	for f in ("quarantine_raw_warehouse", "quarantine_production_warehouse", "released_raw_warehouse",
	          "released_finished_warehouse", "rejected_warehouse", "waste_hold_warehouse", "spares_warehouse"):
		wh = s.get(f)
		add("Settings", s.meta.get_label(f), bool(wh), wh or _("Not set"))
	for f in ("disposal_expense_account", "disposal_accrual_account", "maintenance_expense_account"):
		add("Settings", s.meta.get_label(f), bool(s.get(f)), s.get(f) or _("Not set"))
	for zone in ("Quarantine", "Released", "Rejected", "Waste Hold", "WIP"):
		n = frappe.db.count("Warehouse", {"qc_zone": zone, "disabled": 0})
		add("Warehouses", _("At least one {0} warehouse").format(zone), n > 0, _("{0} found").format(n))
	limits = [s.get(f) for f in ("po_limit", "po_md_limit", "expense_limit", "payment_limit", "disposal_limit", "estimate_limit")]
	add("Approvals", _("Approval limits set by the MD"), any(flt(x) for x in limits),
	    _("All zero: every document routes for approval until the MD sets limits"), warn=True)

	# ---------------------------------------------------------------- people and segregation
	for role in ("Managing Director", "QC Analyst", "HSE Officer", "Waste Officer", "Stock User", "Accounts User",
	             "Manufacturing Manager", "Sales User"):
		users = users_with_role(role)
		add("People", _("Someone holds {0}").format(role), bool(users), ", ".join(users) or _("Nobody"))
	from chemical_erp.utils import approver_role

	pm = users_with_role("Plant Manager")
	add("Positions", _("Someone holds Plant Manager (approves production documents)"), bool(pm),
	    ", ".join(pm) or _("Nobody: give the Managing Director the Plant Manager role until one is appointed"))
	qrole = approver_role("quality")
	qa = users_with_role(qrole)
	add("Positions", _("Someone holds {0} (approves quality documents)").format(qrole), bool(qa), ", ".join(qa) or _("Nobody"))
	from chemical_erp.people_management.positions import covering

	both = [u for u in set(users_with_role("QC Analyst")) & set(qa) if not covering(u, "QC Analyst") and not covering(u, qrole)]
	add("Segregation", _("No appointed person is both QC Analyst and {0}").format(qrole), not both, ", ".join(both))
	vacant = frappe.get_all("Company Position", filters={"active": 1, "status": ["like", "Vacant%"]}, pluck="name")
	add("Positions", _("Posts filled (vacant posts are covered by the Managing Director)"), not vacant,
	    _("Covered by the MD: {0}. Two-person checks on these posts are signed by the MD alone and logged as such.").format(", ".join(vacant))
	    if vacant else "", warn=True)
	admins = set(users_with_role("System Manager")) & set(users_with_role("Managing Director") + users_with_role("Accounts Manager"))
	add("Segregation", _("System Managers hold no approval role"), not admins, ", ".join(admins), warn=True)
	fo = set(users_with_role("Formula Owner")) - set(users_with_role("Managing Director"))
	add("Formulas", _("At most one formula delegate"), len(fo) <= 1, ", ".join(fo))

	# ---------------------------------------------------------------- expenses
	fb = s.get("expense_fallback_approver")
	add("Expenses", _("Fallback Expense Approver set (signs first when the manager is the MD)"), bool(fb), fb or _("Not set"))
	if fb:
		add("Expenses", _("Fallback Expense Approver holds the Expense Approver role"), "Expense Approver" in frappe.get_roles(fb), fb)
	no_approver = frappe.db.count("Employee", {"status": "Active", "expense_approver": ["is", "not set"]}) \
		if frappe.get_meta("Employee").has_field("expense_approver") else 0
	add("Expenses", _("Employees have an Expense Approver"), not no_approver,
	    _("{0} without; their claims go to the Fallback Expense Approver").format(no_approver), warn=True)

	# ---------------------------------------------------------------- staff documents
	emp_meta = frappe.get_meta("Employee")
	if emp_meta.has_field("appointment_letter"):
		no_letter = frappe.get_all("Employee", filters={"status": "Active", "appointment_letter": ["is", "not set"]}, pluck="employee_name")
		add("Documents", _("Every active employee has a signed appointment letter on file"), not no_letter, ", ".join(no_letter[:15]))
	if emp_meta.has_field("nin_card_copy"):
		no_id = frappe.get_all("Employee", filters={"status": "Active", "nin": ["is", "set"], "nin_card_copy": ["is", "not set"]}, pluck="employee_name")
		add("Documents", _("Every NIN has a National ID copy attached"), not no_id, ", ".join(no_id[:15]))
		no_nin = frappe.db.count("Employee", {"status": "Active", "nin": ["is", "not set"]})
		add("Documents", _("Every active employee's NIN recorded"), not no_nin, _("{0} without a NIN").format(no_nin), warn=True)
	awaiting = frappe.db.count("Staff Certification", {"parenttype": "Employee", "awaiting_certificate": 1})
	add("Documents", _("Training certificates issued by the system have their copy attached"), not awaiting,
	    _("{0} awaiting a certificate copy").format(awaiting), warn=True)
	no_po = frappe.db.count("Customer", {"disabled": 0, "po_required": 1})
	add("Documents", _("Customers marked as sending purchase orders"), True,
	    _("{0} customer(s) need a PO before invoicing; untick 'Sends a Purchase Order' for cash and walk-in customers").format(no_po))
	waiting = frappe.db.count("Purchase Order", {"docstatus": 1, "supplier_receipt_status": "Awaiting Supplier Receipt"})
	add("Documents", _("Received purchases have the supplier's receipt attached"), not waiting,
	    _("{0} purchase order(s) cannot close until it is attached").format(waiting), warn=True)

	# ---------------------------------------------------------------- items
	chem = frappe.get_all("Item", filters={"disabled": 0, "substance": ["is", "set"]},
	                      fields=["name", "has_batch_no", "inspection_required_before_purchase", "shelf_life_in_days",
	                              "is_sales_item", "efris_commodity_code", "is_hazardous", "requires_current_sds"])
	add("Items", _("Chemical items exist (Item has a Substance)"), bool(chem), _("{0} found").format(len(chem)))
	bad = [i.name for i in chem if not i.has_batch_no]
	add("Items", _("Every chemical item is batch-tracked"), not bad, ", ".join(bad[:15]))
	bad = [i.name for i in chem if i.get("inspection_required_before_purchase")]
	add("Items", _("'Inspection Required before Purchase' is off"), not bad,
	    _("Receipts must post to Quarantine before inspection: ") + ", ".join(bad[:15]) if bad else "")
	bad = [i.name for i in chem if not i.shelf_life_in_days]
	add("Items", _("Shelf life set"), not bad, ", ".join(bad[:15]), warn=True)
	sales = [i for i in chem if i.is_sales_item]
	bad = [i.name for i in sales if (i.is_hazardous or i.requires_current_sds) and not current_sds(i.name)]
	add("Items", _("Every saleable chemical has a current English SDS"), not bad, ", ".join(bad[:15]))
	bad = [i.name for i in sales if not i.efris_commodity_code]
	add("EFRIS", _("Every saleable item has an EFRIS commodity code"), not bad, ", ".join(bad[:15]))
	waste = frappe.get_all("Item", filters={"is_waste_item": 1, "disabled": 0}, pluck="name")
	add("Waste", _("Waste items defined"), bool(waste), ", ".join(waste[:10]), warn=True)
	add("Waste", _("A disposal vendor with an in-date licence"),
	    bool(frappe.db.exists("Supplier", {"is_disposal_vendor": 1, "disposal_licence_expiry": [">=", today()]})), "")

	# ---------------------------------------------------------------- formulas
	unapproved = frappe.get_all("BOM", filters={"is_active": 1, "is_default": 1, "formula_status": ["!=", "Approved"]}, pluck="name",
	                            ignore_permissions=True)
	add("Formulas", _("Every default formula is approved"), not unapproved, _("{0} not approved").format(len(unapproved)))

	# ---------------------------------------------------------------- costing
	zero = frappe.get_all("Cost Element", filters={"active": 1, "default_rate": 0}, pluck="name")
	add("Costing", _("Cost element rates set"), not zero, _("Still at zero: {0}").format(", ".join(zero)) if zero else "", warn=True)
	made = frappe.get_all("BOM", filters={"is_default": 1, "is_active": 1, "docstatus": 1, "formula_level": ["!=", "Master premix"]},
	                      pluck="item", ignore_permissions=True)
	uncosted = [i for i in set(made) if not frappe.db.exists("Product Cost Sheet", {"item_code": i, "status": "Current"})]
	add("Costing", _("Every manufactured product has a standard cost sheet"), not uncosted, ", ".join(uncosted[:15]), warn=True)
	no_acct = frappe.get_all("Cost Element", filters={"absorb_into_stock": 1, "absorbed_account": ["is", "not set"]}, pluck="name")
	add("Costing", _("Costs added to stock value have an account"), not no_acct, ", ".join(no_acct))

	# ---------------------------------------------------------------- equipment
	lab = frappe.db.count("Equipment", {"category": "Laboratory Instrument", "status": ["!=", "Retired"]})
	add("Equipment", _("Laboratory instruments registered"), lab > 0, _("{0} found").format(lab))
	nodue = frappe.get_all("Equipment", filters={"requires_calibration": 1, "next_calibration_due": ["is", "not set"],
	                                            "status": ["!=", "Retired"]}, pluck="name")
	add("Equipment", _("Calibrated equipment has a first calibration on record"), not nodue, ", ".join(nodue[:15]))
	ooc = frappe.get_all("Equipment", filters={"status": "Out of Calibration"}, pluck="name")
	add("Equipment", _("No equipment out of calibration"), not ooc, ", ".join(ooc[:15]), warn=True)

	# ---------------------------------------------------------------- compliance (Management Systems)
	expired = frappe.get_all("Legal Requirement", filters={"expiry_date": ["<", today()], "compliance_status": ["!=", "Not Applicable"]},
	                         fields=["name", "licence_permit_filing", "law_name"])
	add("Compliance", _("No expired permits or licences"), not expired,
	    ", ".join((e.licence_permit_filing or e.law_name) for e in expired[:10]))
	last_issued = frappe.db.get_value("Internal Audit", {"docstatus": 1}, "max(period_to)")
	from frappe.utils import add_days as _ad
	add("Compliance", _("Internal audit issued for the last quarter"),
	    bool(last_issued and frappe.utils.getdate(last_issued) >= frappe.utils.getdate(_ad(today(), -120))),
	    _("Last issued audit covers up to {0}").format(last_issued) if last_issued else _("No internal audit issued yet"), warn=True)
	overdue = frappe.db.count("IMS Document", {"status": "Active", "review_status": "Overdue"})
	add("Compliance", _("No IMS documents overdue for review"), not overdue, _("{0} overdue").format(overdue), warn=True)
	unassessed = frappe.db.count("Legal Requirement", {"compliance_status": "Not yet assessed"})
	add("Compliance", _("Legal register assessed"), not unassessed, _("{0} not yet assessed").format(unassessed), warn=True)

	# ---------------------------------------------------------------- EFRIS and payroll
	add("EFRIS", _("Company TIN entered for EFRIS"), bool(s.efris_tin), s.efris_tin or "")
	add("EFRIS", _("Mode"), True, s.efris_mode or "")
	no_tin = frappe.db.count("Customer", {"disabled": 0, "efris_buyer_type": ["in", ["Business", "Government"]], "tax_id": ["is", "not set"]})
	add("EFRIS", _("Business and government customers have a TIN"), not no_tin, _("{0} without").format(no_tin), warn=True)
	if frappe.db.exists("DocType", "PAYE Band Set"):
		add("Payroll", _("A PAYE band set is in force"), bool(frappe.db.exists("PAYE Band Set", {"effective_from": ["<=", today()]})), "")

	from chemical_erp.tenders_desk.scanner import scope_ready

	ready, missing = scope_ready()
	add("Setup", _("Tender scanning set up (company profile, scope, switched on)"), ready, "; ".join(missing), warn=True)

	# ---------------------------------------------------------------- access
	creators = frappe.db.sql("""select distinct role from `tabCustom DocPerm` where parent = 'User' and `create` = 1
		and role not in ('System Manager', 'Administrator', 'HR Manager')""", pluck=True) if frappe.db.table_exists("Custom DocPerm") else []
	add("Access", _("Only the system administrator, MD and HR Manager create staff accounts"), not creators,
	    _("These roles can also open new users (the system still refuses staff accounts from them): {0}").format(", ".join(creators)), warn=True)
	no_login = frappe.db.count("Employee", {"status": "Active", "user_id": ["is", "not set"]})
	add("Access", _("Every active employee has a login"), not no_login, _("{0} without a login").format(no_login), warn=True)
	no_mgr = frappe.db.count("Employee", {"status": "Active", "reports_to": ["is", "not set"]})
	add("Access", _("Every employee has a line manager (Reports To)"), no_mgr <= 1,
	    _("{0} without; only the MD should have none. Line managers can only grant access to people who report to them").format(no_mgr), warn=True)
	manual = frappe.db.sql("""select count(*) from `tabHas Role` hr join `tabUser` u on u.name = hr.parent
		where hr.parenttype = 'User' and u.enabled = 1 and u.name not in ('Administrator', 'Guest')
		and hr.role not in ('All', 'Guest', 'Desk User', 'Employee', 'System Manager')
		and not exists (select 1 from `tabPosition Role Grant` g where g.user = hr.parent and g.role = hr.role)""")[0][0]
	add("Access", _("Roles come from posts or access grants, not given by hand"), not manual,
	    _("{0} role(s) given by hand: see the User Access Review report").format(manual), warn=True)

	# ---------------------------------------------------------------- learning
	ls = frappe.get_cached_doc("Learning Settings")
	platform = ls.video_platform or ""
	if platform.startswith("JaaS"):
		ok = bool(ls.jaas_app_id and ls.jaas_key_id and frappe.conf.get("jaas_private_key"))
	elif platform == "Self-hosted Jitsi":
		ok = bool(ls.jitsi_domain)
	else:
		ok = True
	add("Learning", _("Online training room configured ({0})").format(platform), ok,
	    "" if ok else _("Add the platform details in Learning Settings (and the key in site_config)"), warn=True)
	unmapped = frappe.get_all("Training Requirement", filters={"active": 1, "training_program": ["is", "not set"]}, pluck="required_record")
	add("Learning", _("Every training requirement names the program that issues it"), not unmapped, ", ".join(unmapped[:10]), warn=True)
	nouser = frappe.db.count("Employee", {"status": "Active", "user_id": ["is", "not set"]})
	add("Learning", _("Employees have ERPNext logins (to join online training)"), not nouser,
	    _("{0} without a login; they can still attend in person").format(nouser), warn=True)

	# ---------------------------------------------------------------- operations
	from chemical_erp.company import emergency_phone, get_profile

	add("Setup", _("Company Profile completed (name, address, phones, email, bank, logo)"),
	    bool(frappe.db.exists("Company Profile", get_profile().get("company") or "")), _("Open Company Profile to fill it in"))
	add("Operations", _("24-hour emergency phone set (transport emergency card)"), bool(emergency_phone()),
	    _("Add an 'Emergency (24 hours)' number in the Company Profile"))
	add("Operations", _("WHT receivable account set"), bool(s.get("wht_receivable_account")), "", warn=True)
	tbc = frappe.get_all("Product Certification", filters={"in_scope": "To Be Confirmed"}, pluck="item_code")
	sold = frappe.get_all("Item", filters={"disabled": 0, "is_sales_item": 1, "substance": ["is", "set"]}, pluck="name")
	unreviewed = [i for i in sold if not frappe.db.exists("Product Certification", {"item_code": i}) or i in tbc]
	add("Operations", _("Certification scope confirmed for every product"), not unreviewed, ", ".join(unreviewed[:15]), warn=True)
	add("Operations", _("An emergency drill in the last 12 months"),
	    bool(frappe.db.exists("Emergency Drill", {"drill_date": [">=", frappe.utils.add_months(today(), -12)]})), "", warn=True)
	add("Operations", _("Quality, environmental and safety objectives set"), bool(frappe.db.count("Quality Objective")), "", warn=True)
	add("Operations", _("Risk register started"), bool(frappe.db.count("IMS Risk")), "", warn=True)
	add("Operations", _("Approved suppliers evaluated"), not frappe.db.count("Supplier", {"is_approved_vendor": 1, "last_evaluated_on": ["is", "not set"]}),
	    _("{0} approved supplier(s) never evaluated").format(frappe.db.count("Supplier", {"is_approved_vendor": 1, "last_evaluated_on": ["is", "not set"]})), warn=True)

	# ---------------------------------------------------------------- ERPNext features to set up
	fy = frappe.db.get_value("Fiscal Year", {"year_start_date": ["<=", today()], "year_end_date": [">=", today()]}, "name")
	add("Setup", _("A budget for the current financial year"), bool(fy and frappe.db.exists("Budget", {"fiscal_year": fy, "docstatus": 1})),
	    fy or _("No fiscal year covers today"), warn=True)
	unreconciled = frappe.db.count("Payment Entry", {"docstatus": 1, "clearance_date": ["is", "not set"],
	                                                 "posting_date": ["<", frappe.utils.add_days(today(), -45)]})
	add("Setup", _("Bank reconciled (no payments older than 45 days uncleared)"), not unreconciled, _("{0} uncleared").format(unreconciled), warn=True)
	add("Setup", _("Collection reminder levels set (Dunning Types)"), bool(frappe.db.count("Dunning Type")), "", warn=True)
	add("Setup", _("Asset categories with accounts"), bool(frappe.db.count("Asset Category")), "", warn=True)
	portal = frappe.db.sql("""select count(distinct c.user) from `tabContact` c join `tabDynamic Link` dl on dl.parent = c.name
		where dl.link_doctype = 'Customer' and ifnull(c.user, '') != ''""")[0][0]
	add("Setup", _("Customers invited to the document portal (/my-documents)"), bool(portal), _("{0} customer login(s)").format(portal), warn=True)

	# ---------------------------------------------------------------- documents
	add("Documents", _("Print font is Arial"), frappe.db.get_single_value("Print Settings", "font") == "Arial",
	    frappe.db.get_single_value("Print Settings", "font") or "Default")
	add("Documents", _("House print style active (11pt, 1.15 spacing for lengthy text)"),
	    frappe.db.get_single_value("Print Settings", "print_style") in ("House Style", "Brave"),
	    frappe.db.get_single_value("Print Settings", "print_style") or "")
	try:
		import subprocess

		arial = subprocess.run(["fc-list", ":family=Arial"], capture_output=True, text=True, timeout=10).stdout.strip()
	except Exception:
		arial = ""
	add("Documents", _("Arial font installed on the server (for PDFs)"), bool(arial),
	    "" if arial else _("PDFs will fall back to Liberation Sans. Install: sudo apt install ttf-mscorefonts-installer && fc-cache -f"),
	    warn=True)

	try:
		from chemical_erp.chemical_core.report.missing_attachments.missing_attachments import execute as _missing

		gaps = len(_missing()[1])
	except Exception:
		gaps = 0
	add("Documents", _("Required attachments on file (see the Missing Attachments report)"), not gaps,
	    _("{0} missing").format(gaps) if gaps else "", warn=True)

	order = {"Fail": 0, "Warning": 1, "Pass": 2}
	rows.sort(key=lambda r: order[r["result"]])
	fails = sum(r["result"] == "Fail" for r in rows)
	summary = [{"label": _("Fail"), "value": fails, "indicator": "Red" if fails else "Green"},
	           {"label": _("Warning"), "value": sum(r["result"] == "Warning" for r in rows), "indicator": "Orange"},
	           {"label": _("Pass"), "value": sum(r["result"] == "Pass" for r in rows), "indicator": "Green"}]
	msg = _("Ready for go-live: no failures.") if not fails else _("{0} item(s) must be fixed before go-live.").format(fails)
	return [
		{"fieldname": "result", "label": _("Result"), "fieldtype": "Data", "width": 90},
		{"fieldname": "area", "label": _("Area"), "fieldtype": "Data", "width": 110},
		{"fieldname": "check", "label": _("Check"), "fieldtype": "Data", "width": 340},
		{"fieldname": "detail", "label": _("Detail"), "fieldtype": "Data", "width": 420},
	], rows, msg, None, summary
