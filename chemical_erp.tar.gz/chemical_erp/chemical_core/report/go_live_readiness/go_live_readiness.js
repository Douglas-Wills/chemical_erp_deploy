frappe.query_reports["Go-Live Readiness"] = {
	filters: [],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "result" && data) {
			const c = { Fail: "var(--red-600)", Warning: "var(--orange-600)", Pass: "var(--green-600)" }[data.result];
			value = `<b style="color:${c}">${value}</b>`;
		}
		return value;
	},
};
