import frappe
from frappe import _
from frappe.utils import date_diff, flt, today

from chemical_erp.utils import batch_balances, get_settings, warehouse_zone


def execute(filters=None):
	s = get_settings()
	limit = s.waste_hold_days or 30
	data = []
	for b in frappe.get_all("Batch", filters={"is_waste_batch": 1}, fields=["name", "item", "source_work_order", "waste_from_batch", "creation"]):
		from chemical_erp.controls.manufacturing import to_kg

		held = to_kg(b.item, sum(q for wh, q in batch_balances(b.name) if warehouse_zone(wh) == "Waste Hold"))  # stock unit to kg
		orders = frappe.get_all("Disposal Order", filters={"waste_batch": b.name, "docstatus": 1}, fields=["name", "expected_cost"])
		posted = flt(frappe.db.sql("""select sum(gle.debit) from `tabGL Entry` gle
			where gle.is_cancelled=0 and gle.account=%s and gle.voucher_type='Journal Entry'
			and gle.voucher_no in (select name from `tabJournal Entry` where waste_batch=%s)""",
		                           (s.disposal_expense_account, b.name))[0][0])
		age = date_diff(today(), b.creation)
		data.append({"batch": b.name, "item": b.item, "work_order": b.source_work_order, "from_batch": b.waste_from_batch,
		             "held_kg": held, "days": age, "overdue": 1 if held and age > limit else 0,
		             "disposal_order": orders[0].name if orders else None,
		             "expected_cost": sum(flt(o.expected_cost) for o in orders), "posted_cost": posted})
	data.sort(key=lambda r: (-r["overdue"], -r["days"]))
	return [
		{"fieldname": "batch", "label": _("Waste Batch"), "fieldtype": "Link", "options": "Batch", "width": 140},
		{"fieldname": "item", "label": _("Waste Item"), "fieldtype": "Link", "options": "Item", "width": 140},
		{"fieldname": "work_order", "label": _("Work Order"), "fieldtype": "Link", "options": "Work Order", "width": 130},
		{"fieldname": "from_batch", "label": _("From Batch"), "fieldtype": "Link", "options": "Batch", "width": 130},
		{"fieldname": "held_kg", "label": _("In Waste Hold (kg)"), "fieldtype": "Float", "width": 120},
		{"fieldname": "days", "label": _("Days"), "fieldtype": "Int", "width": 70},
		{"fieldname": "overdue", "label": _("Over Limit"), "fieldtype": "Check", "width": 80},
		{"fieldname": "disposal_order", "label": _("Disposal Order"), "fieldtype": "Link", "options": "Disposal Order", "width": 130},
		{"fieldname": "expected_cost", "label": _("Expected Cost"), "fieldtype": "Currency", "width": 120},
		{"fieldname": "posted_cost", "label": _("Posted Cost"), "fieldtype": "Currency", "width": 120},
	], data
