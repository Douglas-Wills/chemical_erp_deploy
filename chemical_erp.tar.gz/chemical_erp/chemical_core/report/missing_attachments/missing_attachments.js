frappe.query_reports["Missing Attachments"] = { filters: [{ fieldname: "area", label: __("Area"), fieldtype: "Select", options: "\nStaff\nPurchasing\nMaintenance" }] };
