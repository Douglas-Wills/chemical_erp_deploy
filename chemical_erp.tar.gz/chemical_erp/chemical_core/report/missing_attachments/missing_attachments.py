"""Every required attachment that is still missing, in one list."""

import frappe
from frappe import _


def execute(filters=None):
	f = frappe._dict(filters or {})
	rows = []

	def add(area, doctype, name, label, missing):
		rows.append({"area": area, "doctype_": doctype, "document": name, "label": label, "missing": missing})

	emp_meta = frappe.get_meta("Employee")
	fields = ["name", "employee_name"] + [x for x in ("nin", "nin_card_copy", "appointment_letter") if emp_meta.has_field(x)]
	for e in frappe.get_all("Employee", filters={"status": "Active"}, fields=fields):
		if e.get("nin") and not e.get("nin_card_copy"):
			add("Staff", "Employee", e.name, e.employee_name, _("National ID copy"))
		if "appointment_letter" in e and not e.get("appointment_letter"):
			add("Staff", "Employee", e.name, e.employee_name, _("Signed appointment letter"))
	for q in frappe.get_all("Staff Qualification", filters={"parenttype": "Employee", "certificate": ["is", "not set"]},
	                        fields=["parent", "qualification"]):
		add("Staff", "Employee", q.parent, frappe.db.get_value("Employee", q.parent, "employee_name"), _("Certificate: {0}").format(q.qualification))
	for c in frappe.get_all("Staff Certification", filters={"parenttype": "Employee", "record_type": ["in", ["Training", "Certification", "Medical"]],
	                                                       "attachment": ["is", "not set"]}, fields=["parent", "title", "record_type"]):
		add("Staff", "Employee", c.parent, frappe.db.get_value("Employee", c.parent, "employee_name"), _("{0} certificate: {1}").format(c.record_type, c.title))
	for c in frappe.get_all("Employment Contract", filters={"is_signed": 1, "signed_copy": ["is", "not set"]}, fields=["name", "employee_name"]):
		add("Staff", "Employment Contract", c.name, c.employee_name, _("Signed contract copy"))
	for po in frappe.get_all("Purchase Order", filters={"docstatus": 1, "status": ["not in", ["Closed", "Completed"]], "signed_lpo": ["is", "not set"]},
	                         fields=["name", "supplier_name"]):
		add("Purchasing", "Purchase Order", po.name, po.supplier_name, _("Signed and stamped LPO"))
	# Purchased batches: the same rules as receiving and delivery (Document Profile). A certificate is missing only when
	# there is neither the supplier's CoA nor our own accepted inspection; an SDS only when the product needs one and
	# no current SDS File is held (one SDS File covers every batch).
	from chemical_erp.regulatory_compliance.documents import certificate_available, sds_required, sds_state

	for b in frappe.get_all("Batch", filters={"reference_doctype": "Purchase Receipt", "is_waste_batch": 0, "batch_qty": [">", 0]},
	                        fields=["name", "item"]):
		gaps = []
		if not certificate_available(b.name):
			gaps.append(_("Certificate (supplier CoA or our inspection)"))
		if sds_required(b.item) and sds_state(b.item)[0] == "Missing":
			gaps.append(_("Current SDS"))
		if gaps:
			add("Purchasing", "Batch", b.name, b.item, ", ".join(gaps))
	for c in frappe.get_all("Calibration Record", filters={"docstatus": 1, "certificate": ["is", "not set"]}, fields=["name", "equipment"]):
		add("Maintenance", "Calibration Record", c.name, c.equipment, _("Calibration certificate"))
	if f.area:
		rows = [r for r in rows if r["area"] == f.area]
	return [
		{"fieldname": "area", "label": _("Area"), "fieldtype": "Data", "width": 110},
		{"fieldname": "doctype_", "label": _("Record Type"), "fieldtype": "Data", "width": 150},
		{"fieldname": "document", "label": _("Record"), "fieldtype": "Dynamic Link", "options": "doctype_", "width": 160},
		{"fieldname": "label", "label": _("Who / What"), "fieldtype": "Data", "width": 200},
		{"fieldname": "missing", "label": _("Missing Attachment"), "fieldtype": "Data", "width": 300},
	], rows, (_("{0} attachment(s) missing.").format(len(rows)) if rows else _("Nothing missing."))
