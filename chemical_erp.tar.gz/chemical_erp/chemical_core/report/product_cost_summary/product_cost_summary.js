frappe.query_reports["Product Cost Summary"] = {
	filters: [],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (data && (column.fieldname === "flag" || column.fieldname === "floor_note")) {
			const c = { "Selling below cost": "var(--red-600)", "Below cost": "var(--red-600)", "No selling price": "var(--orange-600)",
				"Below target margin": "var(--orange-600)", "On target": "var(--green-600)" }[data[column.fieldname]];
			if (c) value = `<b style="color:${c}">${value}</b>`;
		}
		return value;
	},
};
