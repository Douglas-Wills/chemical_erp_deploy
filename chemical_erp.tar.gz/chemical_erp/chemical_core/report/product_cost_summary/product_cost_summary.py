"""Every product's standard cost against its selling price: who is below cost, who is below target margin."""

import frappe
from frappe import _
from frappe.utils import flt


def execute(filters=None):
	data = []
	for s in frappe.get_all("Product Cost Sheet", filters={"status": "Current"},
	                        fields=["name", "item_code", "item_name", "valid_from", "cost_per_kg", "cost_per_pack", "pack_size",
	                                "material_cost", "labour_cost", "packaging_cost", "overhead_cost", "other_cost", "total_batch_cost",
	                                "current_price_per_kg", "current_margin", "target_margin", "suggested_price_per_kg"]):
		total = flt(s.total_batch_cost) or 1
		if not s.current_price_per_kg:
			flag = _("No selling price")
		elif s.current_price_per_kg < s.cost_per_kg:
			flag = _("Selling below cost")
		elif s.current_margin < s.target_margin:
			flag = _("Below target margin")
		else:
			flag = _("On target")
		floor = flt(frappe.db.get_value("Item", s.item_code, "price_floor"))
		data.append({**s, "material_share": flt(s.material_cost / total * 100, 1), "price_floor": floor, "flag": flag,
		             "floor_note": _("Below cost") if floor and floor < s.cost_per_kg else ""})
	order = {_("Selling below cost"): 0, _("No selling price"): 1, _("Below target margin"): 2, _("On target"): 3}
	data.sort(key=lambda d: (order.get(d["flag"], 9), d["current_margin"]))
	cur = lambda f, l, w=110: {"fieldname": f, "label": l, "fieldtype": "Currency", "width": w}
	return [
		{"fieldname": "name", "label": _("Cost Sheet"), "fieldtype": "Link", "options": "Product Cost Sheet", "width": 150},
		{"fieldname": "item_name", "label": _("Product"), "fieldtype": "Data", "width": 170},
		{"fieldname": "flag", "label": _("Status"), "fieldtype": "Data", "width": 140},
		cur("cost_per_kg", _("Cost / kg")), cur("current_price_per_kg", _("Price / kg")),
		{"fieldname": "current_margin", "label": _("Margin %"), "fieldtype": "Percent", "width": 90},
		{"fieldname": "target_margin", "label": _("Target %"), "fieldtype": "Percent", "width": 80},
		cur("suggested_price_per_kg", _("Suggested / kg")), cur("cost_per_pack", _("Cost / pack")),
		{"fieldname": "material_share", "label": _("Materials % of Cost"), "fieldtype": "Percent", "width": 120},
		cur("price_floor", _("Price Floor")), {"fieldname": "floor_note", "label": _("Floor Check"), "fieldtype": "Data", "width": 100},
		{"fieldname": "valid_from", "label": _("Valid From"), "fieldtype": "Date", "width": 100},
	], data
