"""Credit control (Chemical Core > Customer Accounts).

Daily:
- reminders by email at 7, 30 and 60 days overdue (Settings), one per invoice per stage, copied to the collector;
- credit hold: a customer with an invoice overdue 60+ days, or owing more than their credit limit, is put on hold;
  sales orders and deliveries then stop until paid (paid-in-advance orders still go). The hold lifts itself when
  cleared, unless the MD or Accounts Manager set it by hand;
- payment promises past their date are marked kept, part kept or broken, and the collector is told.
Monthly (Settings day): a statement of open invoices to every customer who owes money.
"""

import frappe
from frappe import _
from frappe.utils import cint, date_diff, flt, fmt_money, formatdate, getdate, today

from chemical_erp.utils import MD_ROLE, get_settings, has_role, notify

MANAGERS = (MD_ROLE, "Accounts Manager", "System Manager")


def stages():
	raw = get_settings().get("reminder_days") or "7,30,60"
	return sorted({cint(x) for x in str(raw).replace(" ", "").split(",") if cint(x) > 0})


def customer_email(customer):
	email = frappe.db.get_value("Customer", customer, "email_id")
	if email:
		return email
	contact = frappe.db.get_value("Customer", customer, "customer_primary_contact")
	return frappe.db.get_value("Contact", contact, "email_id") if contact else None


def collector_of(customer):
	return frappe.db.get_value("Customer", customer, "collector") if frappe.get_meta("Customer").has_field("collector") else None


def open_invoices(customer):
	return frappe.get_all("Sales Invoice", filters={"customer": customer, "docstatus": 1, "outstanding_amount": [">", 0]},
	                      fields=["name", "posting_date", "due_date", "grand_total", "outstanding_amount", "currency", "po_no"],
	                      order_by="due_date asc")


def statement_html(customer):
	from chemical_erp.company import company_name

	rows = open_invoices(customer)
	total = sum(flt(r.outstanding_amount) for r in rows)
	body = "".join(f"<tr><td>{r.name}</td><td>{formatdate(r.posting_date)}</td><td>{formatdate(r.due_date)}</td>"
	               f"<td>{frappe.utils.escape_html(r.po_no or '')}</td><td style='text-align:right'>{fmt_money(r.outstanding_amount, currency=r.currency)}</td>"
	               f"<td style='text-align:right'>{max(date_diff(today(), r.due_date), 0)}</td></tr>" for r in rows)
	return (f"<p>Dear {frappe.utils.escape_html(frappe.db.get_value('Customer', customer, 'customer_name'))},</p>"
	        f"<p>Below are the invoices from {frappe.utils.escape_html(company_name(short=True))} still open on {formatdate(today())}.</p>"
	        "<table border='1' cellpadding='5' style='border-collapse:collapse;font-family:Arial;font-size:11pt'>"
	        "<tr><th>Invoice</th><th>Date</th><th>Due</th><th>Your PO</th><th>Outstanding</th><th>Days overdue</th></tr>"
	        f"{body}<tr><td colspan='4'><b>Total</b></td><td style='text-align:right'><b>{fmt_money(total)}</b></td><td></td></tr></table>"
	        "<p>If you have already paid, please send us the remittance details. Thank you.</p>"), total


def _send(customer, subject, message):
	to = customer_email(customer)
	if not to:
		return False
	cc = [frappe.db.get_value("User", c, "email") for c in [collector_of(customer)] if c]
	frappe.sendmail(recipients=[to], cc=[c for c in cc if c], subject=subject, message=message,
	                reference_doctype="Customer", reference_name=customer)
	return True


# ---------------------------------------------------------------- daily
def daily():
	for fn in (reminders, credit_holds, promises):
		try:
			fn()
			frappe.db.commit()
		except Exception:
			frappe.db.rollback()
			frappe.log_error(title=f"Credit control failed: {fn.__name__}", message=frappe.get_traceback())
	if getdate(today()).day == (cint(get_settings().get("statement_day")) or 1):
		statements()


def reminders():
	steps = stages()
	if not steps or not frappe.get_meta("Sales Invoice").has_field("reminder_stage"):
		return
	by_customer = {}
	for inv in frappe.get_all("Sales Invoice", filters={"docstatus": 1, "outstanding_amount": [">", 0], "due_date": ["<", today()],
	                                                    "is_return": 0}, fields=["name", "customer", "due_date", "reminder_stage"]):
		days = date_diff(today(), inv.due_date)
		stage = sum(1 for s in steps if days >= s)
		if stage > cint(inv.reminder_stage):
			by_customer.setdefault(inv.customer, []).append((inv.name, stage))
	for customer, items in by_customer.items():
		top = max(s for _n, s in items)
		html, total = statement_html(customer)
		tone = {1: _("Friendly reminder"), 2: _("Second reminder"), 3: _("Final reminder: account on hold")}.get(top, _("Reminder"))
		if _send(customer, _("{0}: overdue invoices, {1}").format(tone, fmt_money(total)), html):
			for name, stage in items:
				frappe.db.set_value("Sales Invoice", name, "reminder_stage", stage, update_modified=False)
		if top >= len(steps) and collector_of(customer):
			notify(collector_of(customer), "Customer", customer, _("{0}: final reminder sent; {1} outstanding. Call them today.").format(
				customer, fmt_money(total)), priority="High")


def hold_reason(customer):
	days = cint(get_settings().get("credit_hold_days")) or 60
	oldest = frappe.db.sql("""select min(due_date) from `tabSales Invoice` where customer=%s and docstatus=1 and outstanding_amount>0
		and is_return=0""", customer)[0][0]
	if oldest and date_diff(today(), oldest) >= days:
		return _("Invoice overdue {0} days").format(date_diff(today(), oldest))
	limit = flt(frappe.db.get_value("Customer Credit Limit", {"parent": customer}, "credit_limit"))
	if limit:
		owed = flt(frappe.db.sql("select sum(outstanding_amount) from `tabSales Invoice` where customer=%s and docstatus=1", customer)[0][0])
		if owed > limit:
			return _("Owes {0}, above the credit limit {1}").format(fmt_money(owed), fmt_money(limit))
	return None


def credit_holds():
	if not frappe.get_meta("Customer").has_field("credit_hold"):
		return
	owing = set(frappe.get_all("Sales Invoice", filters={"docstatus": 1, "outstanding_amount": [">", 0]}, pluck="customer", distinct=True))
	held = set(frappe.get_all("Customer", filters={"credit_hold": 1}, pluck="name"))
	for customer in owing | held:
		reason = hold_reason(customer)
		c = frappe.db.get_value("Customer", customer, ["credit_hold", "credit_hold_manual"], as_dict=True)
		if reason and not c.credit_hold:
			frappe.db.set_value("Customer", customer, {"credit_hold": 1, "credit_hold_reason": reason})
			notify([collector_of(customer)] + _sales_people(customer), "Customer", customer,
			       _("{0} is on credit hold: {1}. No new orders or deliveries until paid.").format(customer, reason), priority="High")
		elif not reason and c.credit_hold and not c.credit_hold_manual:
			frappe.db.set_value("Customer", customer, {"credit_hold": 0, "credit_hold_reason": None})
			notify([collector_of(customer)] + _sales_people(customer), "Customer", customer, _("{0}'s credit hold has lifted.").format(customer))


def _sales_people(customer):
	from chemical_erp.utils import users_with_role

	return users_with_role("Sales Manager")


def promises():
	for p in frappe.get_all("Payment Promise", filters={"status": "Open", "promised_date": ["<", today()]},
	                        fields=["name", "customer", "amount", "creation"]):
		received = flt(frappe.db.sql("""select sum(base_received_amount) from `tabPayment Entry` where docstatus=1 and party_type='Customer'
			and party=%s and payment_type='Receive' and posting_date >= %s""", (p.customer, getdate(p.creation)))[0][0])
		status = "Kept" if received >= flt(p.amount) else ("Part Kept" if received > 0 else "Broken")
		frappe.db.set_value("Payment Promise", p.name, {"status": status, "received": received})
		if status != "Kept":
			notify([collector_of(p.customer)] + list(_sales_people(p.customer)), "Payment Promise", p.name,
			       _("{0} promised {1} by now; received {2}.").format(p.customer, fmt_money(p.amount), fmt_money(received)), priority="High")


def statements():
	for customer in frappe.get_all("Sales Invoice", filters={"docstatus": 1, "outstanding_amount": [">", 0]}, pluck="customer", distinct=True):
		html, total = statement_html(customer)
		if total > 0:
			_send(customer, _("Statement of account: {0}").format(fmt_money(total)), html)
	frappe.db.commit()


@frappe.whitelist()
def send_statement(customer):
	if not set(MANAGERS + ("Accounts User",)) & set(frappe.get_roles()):
		frappe.throw(_("Not permitted"), frappe.PermissionError)
	html, total = statement_html(customer)
	if not _send(customer, _("Statement of account: {0}").format(fmt_money(total)), html):
		frappe.throw(_("{0} has no email address.").format(customer))
	return total


# ---------------------------------------------------------------- enforcement
def guard_customer(doc, method=None):
	"""Only the MD or Accounts Manager may put a customer on, or take them off, credit hold by hand."""
	if not doc.meta.has_field("credit_hold") or doc.is_new():
		return
	before = doc.get_doc_before_save()
	if before and (before.get("credit_hold") != doc.get("credit_hold")) and not set(MANAGERS) & set(frappe.get_roles()):
		frappe.throw(_("Only the Managing Director or Accounts Manager can change a credit hold."), frappe.PermissionError)
	if before and before.get("credit_hold") != doc.get("credit_hold"):
		doc.credit_hold_manual = 1 if doc.credit_hold else 0


def stop_on_hold(doc, method=None):
	"""Sales Order and Delivery Note: not for a customer on credit hold, unless the order is paid in advance."""
	if doc.get("is_return") or not frappe.get_meta("Customer").has_field("credit_hold"):
		return
	hold = frappe.db.get_value("Customer", doc.customer, ["credit_hold", "credit_hold_reason"], as_dict=True)
	if not hold or not hold.credit_hold:
		return
	paid = flt(doc.get("advance_paid")) >= flt(doc.get("grand_total")) > 0 if doc.doctype == "Sales Order" else False
	if doc.doctype == "Delivery Note":
		orders = {r.against_sales_order for r in doc.items if r.get("against_sales_order")}
		paid = bool(orders) and all(flt(frappe.db.get_value("Sales Order", so, "advance_paid")) >= flt(frappe.db.get_value("Sales Order", so, "grand_total"))
		                             for so in orders)
	if not paid:
		frappe.throw(_("{0} is on credit hold ({1}). Collect payment first, or take the order paid in advance.").format(
			doc.customer, hold.credit_hold_reason or _("set by Accounts")), title=_("Credit hold"))


def promise_validate(doc, method=None):
	if doc.is_new():
		doc.outstanding_then = flt(frappe.db.sql("select sum(outstanding_amount) from `tabSales Invoice` where customer=%s and docstatus=1",
		                                         doc.customer)[0][0])
	if getdate(doc.promised_date) < getdate(today()) and doc.is_new():
		frappe.throw(_("The promised date is in the past."))
