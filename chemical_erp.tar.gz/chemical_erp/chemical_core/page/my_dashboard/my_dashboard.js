frappe.pages["my-dashboard"].on_page_load = function (wrapper) {
	const page = frappe.ui.make_app_page({ parent: wrapper, title: __("My Dashboard"), single_column: true });
	page.set_primary_action(__("New Meeting"), () => new_event("Meeting"), "add");
	page.add_menu_item(__("New Appointment"), () => new_event("Appointment"));
	page.add_menu_item(__("New Field Visit"), () => new_event("Field Visit"));
	page.add_menu_item(__("Open Full Calendar"), () => frappe.set_route("List", "Event", "Calendar", "default"));
	page.add_inner_button(__("Refresh"), () => load(wrapper));
	$(`<style>
		.md-wrap { display: grid; gap: 16px; }
		.md-row { display: grid; grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr); gap: 16px; }
		@media (max-width: 900px) { .md-row { grid-template-columns: 1fr; } }
		.md-box { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 10px; padding: 14px 16px; }
		.md-box h5 { margin: 0 0 10px; font-weight: 600; }
		.md-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 10px; }
		.md-card { border: 1px solid var(--border-color); border-radius: 8px; padding: 10px 12px; cursor: pointer; background: var(--fg-color); }
		.md-card:hover { border-color: var(--primary); }
		.md-card .v { font-size: 22px; font-weight: 600; line-height: 1.2; }
		.md-card .l { color: var(--text-muted); font-size: 12px; margin-top: 2px; }
		.md-card.red .v { color: var(--red-600); } .md-card.orange .v { color: var(--orange-600); }
		.md-card.green .v { color: var(--green-600); } .md-card.blue .v { color: var(--text-color); }
		.md-cal { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; text-align: center; font-size: 12px; }
		.md-cal .h { color: var(--text-muted); font-weight: 600; }
		.md-cal .d { padding: 6px 0; border-radius: 6px; cursor: pointer; position: relative; }
		.md-cal .d.today { outline: 2px solid var(--primary); }
		.md-cal .d.has::after { content: ""; position: absolute; left: 50%; bottom: 2px; width: 5px; height: 5px; margin-left: -2.5px; border-radius: 50%; background: var(--primary); }
		.md-cal .d.sel { background: var(--control-bg); font-weight: 600; }
		.md-cal .d.out { color: var(--text-light); }
		.md-ag { list-style: none; padding: 0; margin: 10px 0 0; max-height: 280px; overflow: auto; }
		.md-ag li { padding: 7px 0; border-top: 1px solid var(--border-color); cursor: pointer; display: flex; gap: 10px; }
		.md-ag .t { color: var(--text-muted); font-size: 12px; min-width: 92px; }
		.md-ag .k { font-size: 11px; padding: 1px 6px; border-radius: 10px; background: var(--control-bg); margin-left: 6px; }
		.md-appr li { padding: 6px 0; border-top: 1px solid var(--border-color); cursor: pointer; }
	</style>`).appendTo(page.body);
	wrapper.$body = $(`<div class="md-wrap"></div>`).appendTo(page.body);
	wrapper.page_obj = page;
	frappe.pages["my-dashboard"].wrapper_el = wrapper;
	load(wrapper);
};

frappe.pages["my-dashboard"].on_page_show = function (wrapper) { if (wrapper.loaded) load(wrapper); };

function load(wrapper) {
	frappe.call("chemical_erp.dashboard.data.get_dashboard").then(({ message: d }) => {
		wrapper.loaded = true;
		wrapper.data = d;
		if (d.is_md && !wrapper.diag_button) {
			wrapper.diag_button = wrapper.page_obj.add_inner_button(__("🩺 Business Diagnostics"), () =>
				frappe.call({ method: "chemical_erp.chemical_core.diagnostics.run", freeze: true, freeze_message: __("Scanning all modules…") })
					.then(({ message }) => frappe.set_route("Form", "Business Diagnostics", message)));
		}
		if (!wrapper.help_button) wrapper.help_button = wrapper.page_obj.add_inner_button(__("❓ Help"), () => frappe.chem_help.open());
		wrapper.selected = frappe.datetime.get_today();
		render(wrapper);
	});
}

function render(wrapper) {
	const d = wrapper.data, $b = wrapper.$body.empty(), esc = frappe.utils.escape_html;
	wrapper.page_obj.set_title(__("Good {0}, {1}", [greeting(), d.user.split(" ")[0]]));
	const $row = $(`<div class="md-row"></div>`).appendTo($b);

	// Calendar
	const $cal = $(`<div class="md-box"><h5>📅 ${__("My Calendar")}</h5><div class="md-cal"></div><ul class="md-ag"></ul></div>`).appendTo($row);
	draw_month(wrapper, $cal);

	// Approvals
	const $ap = $(`<div class="md-box"><h5>${__("Waiting for my approval")} (${d.approval_count}) <a class="small" href="/approvals" title="${__("Phone-friendly approvals")}">📱 ${__("Approve on phone")}</a></h5><ul class="md-appr list-unstyled mb-0"></ul></div>`).appendTo($row);
	if (!d.approvals.length) $ap.find("ul").append(`<li class="text-muted">${__("Nothing waiting for you.")}</li>`);
	d.approvals.forEach((a) => $(`<li><b>${esc(__(a.doctype))}</b> ${esc(a.name)} <span class="text-muted">· ${esc(a.state || "")} · ${__("since")} ${frappe.datetime.str_to_user(a.since)}</span></li>`)
		.on("click", () => frappe.set_route("Form", a.doctype, a.name)).appendTo($ap.find("ul")));

	// My commission
	if (d.commission) {
		const c = d.commission, money = (v) => format_currency(v || 0, frappe.defaults.get_default("currency"), 0);
		const $c = $(`<div class="md-box"><h5>💰 ${__("My Commission")}${c.rate ? ` <span class="text-muted small">· ${c.rate}% ${__("of profit on sales I originate")}</span>` : ""}</h5>
			<div class="md-cards"></div><div class="md-com"></div></div>`).appendTo($b);
		[[__("Payable now"), c.payable, "green", __("customers have paid; not yet paid to me")],
		 [__("Waiting for customers to pay"), c.accrued, "orange", __("becomes payable as they pay")],
		 [__("Earned this month"), c.this_month, "blue", ""], [__("Paid to me so far"), c.paid, "blue", __("through payroll or payments")]]
			.concat(c.owed ? [[__("To be recovered"), c.owed, "red", __("a paid sale was returned or cancelled: taken from future commission")]] : [])
			.forEach(([l, v, tone, hint]) => $(`<div class="md-card ${tone}"><div class="v">${money(v)}</div><div class="l">${esc(l)}${hint ? `<br><span style="font-size:11px">${esc(hint)}</span>` : ""}</div></div>`)
				.on("click", () => frappe.set_route("query-report", "Commission Statement", { employee: c.employee })).appendTo($c.find(".md-cards")));
		if ((c.sales || []).length) {
			$c.find(".md-com").html(`<table class="table table-sm mt-3 mb-0"><tr><th>${__("Invoice")}</th><th>${__("Customer")}</th>
				<th class="text-right">${__("Net sale")}</th><th class="text-right">${__("Profit")}</th><th class="text-right">${__("Commission")}</th><th class="text-right">${__("Customer paid")}</th></tr>` +
				c.sales.map((s) => `<tr><td><a href="/app/sales-invoice/${encodeURIComponent(s.sales_invoice)}">${esc(s.sales_invoice)}</a></td><td>${esc(s.customer_name)}</td>
				<td class="text-right">${money(s.net_sales)}</td><td class="text-right">${money(s.profit)}</td><td class="text-right"><b>${money(s.commission)}</b></td>
				<td class="text-right">${s.paid_share}%</td></tr>`).join("") + "</table>");
		} else {
			$c.find(".md-com").html(`<p class="text-muted mt-2 mb-0">${__("No commissioned sales yet. Sales you originate appear here once invoiced.")}</p>`);
		}
	}

	// Sections
	d.sections.forEach((s) => {
		const $s = $(`<div class="md-box"><h5>${esc(s.title)}</h5><div class="md-cards"></div></div>`).appendTo($b);
		s.cards.forEach((c) => $(`<div class="md-card ${c.tone || "blue"}"><div class="v">${esc(String(c.value))}</div><div class="l">${esc(c.label)}</div></div>`)
			.on("click", () => open_card(c)).appendTo($s.find(".md-cards")));
	});
}

function draw_month(wrapper, $cal) {
	const d = wrapper.data, sel = wrapper.selected, esc = frappe.utils.escape_html;
	const base = frappe.datetime.str_to_obj(sel), first = new Date(base.getFullYear(), base.getMonth(), 1);
	const start = new Date(first); start.setDate(1 - ((first.getDay() + 6) % 7));
	const days = new Set(d.agenda.map((i) => i.when.slice(0, 10)));
	const $g = $cal.find(".md-cal").empty();
	[__("Mo"), __("Tu"), __("We"), __("Th"), __("Fr"), __("Sa"), __("Su")].forEach((h) => $g.append(`<div class="h">${h}</div>`));
	for (let i = 0; i < 42; i++) {
		const day = new Date(start); day.setDate(start.getDate() + i);
		const iso = frappe.datetime.obj_to_str(day).slice(0, 10);
		const cls = ["d", day.getMonth() !== base.getMonth() ? "out" : "", iso === frappe.datetime.get_today() ? "today" : "",
			days.has(iso) ? "has" : "", iso === sel ? "sel" : ""].join(" ");
		$(`<div class="${cls}">${day.getDate()}</div>`).on("click", () => { wrapper.selected = iso; draw_month(wrapper, $cal); }).appendTo($g);
	}
	const $ag = $cal.find(".md-ag").empty();
	const list = d.agenda.filter((i) => i.when.slice(0, 10) >= sel);
	if (!list.length) $ag.append(`<li class="text-muted">${__("Nothing scheduled in the next two weeks.")}</li>`);
	list.forEach((i) => $(`<li><span class="t">${frappe.datetime.str_to_user(i.when.slice(0, 16))}</span>
		<span>${esc(i.title)}<span class="k">${esc(__(i.kind))}</span>${i.detail ? `<br><span class="text-muted small">${esc(i.detail)}</span>` : ""}</span></li>`)
		.on("click", () => frappe.set_route("Form", i.doctype, i.name)).appendTo($ag));
}

function open_card(c) {
	if (c.route && c.route.report) return frappe.set_route("query-report", c.route.report);
	if (c.route && c.route.name) return frappe.set_route("Form", c.route.doctype, c.route.name);
	frappe.route_options = c.filters || {};
	frappe.set_route("List", c.doctype);
}

function new_event(kind) {
	const d = new frappe.ui.Dialog({
		title: __("New {0}", [__(kind)]),
		fields: [
			{ fieldname: "subject", fieldtype: "Data", label: __("Subject"), reqd: 1 },
			{ fieldname: "starts_on", fieldtype: "Datetime", label: __("Starts"), reqd: 1 },
			{ fieldname: "ends_on", fieldtype: "Datetime", label: __("Ends") },
			{ fieldname: "party_type", fieldtype: "Select", label: __("With"), options: "\nCustomer\nSupplier\nLead\nEmployee", default: kind === "Field Visit" ? "Customer" : "" },
			{ fieldname: "party", fieldtype: "Dynamic Link", label: __("Name"), options: "party_type" },
			{ fieldname: "location", fieldtype: "Data", label: __("Location") },
			{ fieldname: "attendees", fieldtype: "MultiSelectList", label: __("Attendees"),
			  get_data: (txt) => frappe.db.get_link_options("User", txt, { user_type: "System User", enabled: 1 }) },
			{ fieldname: "description", fieldtype: "Small Text", label: __("Notes") },
		],
		primary_action_label: __("Save"),
		primary_action(v) {
			frappe.call("chemical_erp.dashboard.calendar.create_event", Object.assign({ event_kind: kind }, v, { attendees: JSON.stringify(v.attendees || []) }))
				.then(() => { d.hide(); frappe.show_alert({ message: __("{0} added to your calendar", [__(kind)]), indicator: "green" }); load(frappe.pages["my-dashboard"].wrapper_el); });
		},
	});
	d.show();
}

function greeting() {
	const h = new Date().getHours();
	return h < 12 ? __("morning") : h < 17 ? __("afternoon") : __("evening");
}
