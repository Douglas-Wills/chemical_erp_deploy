import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt

from chemical_erp.chemical_core.costing import calculate, element_rate, load_materials
from chemical_erp.utils import MD_ROLE, company_currency, exchange_rate, has_role


class ProductCostSheet(Document):
	def validate(self):
		bom = frappe.db.get_value("BOM", self.bom, ["item", "quantity", "docstatus", "formula_status"], as_dict=True)
		if not bom or bom.item != self.item_code:
			frappe.throw(_("Formula {0} is not for {1}.").format(self.bom, self.item_code))
		if not flt(self.batch_size):
			self.batch_size = bom.quantity
		if not self.materials:
			load_materials(self)
		if self.is_new() and not self.cost_lines:
			for e in frappe.get_all("Cost Element", filters={"active": 1}, fields=["name", "default_quantity"], order_by="category, name"):
				self.append("cost_lines", {"cost_element": e.name, "rate": element_rate(e.name), "quantity": e.default_quantity or 1})
		for line in self.cost_lines:
			if not line.basis or not line.category:
				line.basis, line.category = frappe.db.get_value("Cost Element", line.cost_element, ["basis", "category"])
		self.currency = company_currency()
		price = frappe.db.get_value("Item Price", {"item_code": self.item_code, "price_list": self.selling_price_list, "selling": 1},
		                            ["price_list_rate", "uom"], as_dict=True)
		self.current_price_per_kg = 0
		if price:
			pl_currency = frappe.db.get_value("Price List", self.selling_price_list, "currency")
			stock_uom = frappe.get_cached_value("Item", self.item_code, "stock_uom")
			factor = 1.0
			if price.uom and price.uom != stock_uom:
				factor = flt(frappe.db.get_value("UOM Conversion Detail", {"parent": self.item_code, "uom": price.uom}, "conversion_factor")) or 1.0
			# compare like with like: company currency, per stock unit (kg)
			self.current_price_per_kg = flt(price.price_list_rate) / factor * exchange_rate(pl_currency)
		calculate(self)

	@frappe.whitelist()
	def refresh_prices(self):
		"""Reload the formula and today's prices and element rates (keeps the elements chosen)."""
		load_materials(self)
		for line in self.cost_lines:
			line.rate = element_rate(line.cost_element)
		self.save()
		return self.cost_per_kg

	@frappe.whitelist()
	def make_current(self):
		if not (has_role(MD_ROLE) or has_role("Accounts Manager")):
			frappe.throw(_("Only the Managing Director or the Accounts Manager can set the standard cost."), frappe.PermissionError)
		for other in frappe.get_all("Product Cost Sheet", filters={"item_code": self.item_code, "status": "Current", "name": ["!=", self.name]}, pluck="name"):
			frappe.db.set_value("Product Cost Sheet", other, "status", "Superseded")
		self.db_set("status", "Current")
		return self.status

	@frappe.whitelist()
	def set_price_floor(self):
		"""Selling below cost then needs Sales Manager approval on quotations and sales orders."""
		if not has_role(MD_ROLE):
			frappe.throw(_("Only the Managing Director can set the price floor."), frappe.PermissionError)
		frappe.db.set_value("Item", self.item_code, "price_floor", self.cost_per_kg)
		frappe.get_doc("Item", self.item_code).add_comment("Info", _("Price floor set to {0} per kg from {1}").format(self.cost_per_kg, self.name))
		return self.cost_per_kg


def current_sheet(item_code):
	return frappe.db.get_value("Product Cost Sheet", {"item_code": item_code, "status": "Current"}, "name")
