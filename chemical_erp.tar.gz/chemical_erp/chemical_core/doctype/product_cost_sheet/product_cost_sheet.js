frappe.ui.form.on("Product Cost Sheet", {
	item_code(frm) {
		if (!frm.doc.item_code) return;
		frappe.db.get_value("BOM", { item: frm.doc.item_code, is_default: 1, is_active: 1, docstatus: 1 }, ["name", "quantity"])
			.then(({ message: b }) => { if (b && b.name) frm.set_value({ bom: b.name, batch_size: b.quantity }); });
	},
	refresh(frm) {
		if (frm.is_new()) return;
		frm.add_custom_button(__("Refresh Prices"), () => frm.call({ doc: frm.doc, method: "refresh_prices", freeze: true }).then(() => frm.reload_doc()));
		if (frm.doc.status !== "Current" && (frappe.user.has_role("Managing Director") || frappe.user.has_role("Accounts Manager"))) {
			frm.add_custom_button(__("Make Standard Cost"), () => frm.call({ doc: frm.doc, method: "make_current" }).then(() => frm.reload_doc()), __("Actions"));
		}
		if (frappe.user.has_role("Managing Director")) {
			frm.add_custom_button(__("Set Price Floor to Cost"), () =>
				frappe.confirm(__("Quotes and orders below {0} per kg will then need Sales Manager approval. Continue?", [format_currency(frm.doc.cost_per_kg)]),
					() => frm.call({ doc: frm.doc, method: "set_price_floor" }).then(() => frappe.show_alert({ message: __("Price floor updated"), indicator: "green" }))),
				__("Actions"));
		}
		const m = frm.doc.current_margin, t = frm.doc.target_margin;
		if (frm.doc.current_price_per_kg) {
			frm.dashboard.set_headline_alert(__("Cost {0}/kg, selling {1}/kg: margin {2}% (target {3}%)",
				[format_currency(frm.doc.cost_per_kg), format_currency(frm.doc.current_price_per_kg), m, t]), m >= t ? "green" : (m > 0 ? "orange" : "red"));
		}
	},
});
