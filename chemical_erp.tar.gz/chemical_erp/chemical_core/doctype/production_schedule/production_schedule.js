frappe.ui.form.on("Production Schedule", {
	setup(frm) {
		frm.set_query("vessel", "lines", () => ({ filters: { category: ["in", ["Mixer or Reactor", "Tank"]] } }));
	},
	refresh(frm) {
		if (frm.doc.warnings) frm.dashboard.set_headline_alert(frappe.utils.escape_html(frm.doc.warnings).replace(/\n/g, "<br>"), "orange");
		if (frm.is_new()) return;
		frm.add_custom_button(__("Fill from Sales Orders"), () => frm.call("fill_from_sales_orders").then(({ message }) => {
			frm.reload_doc(); frappe.show_alert(__("{0} run(s) added", [message]));
		}));
		frm.add_custom_button(__("Create Work Orders"), () => frm.call("make_work_orders").then(({ message }) => {
			frm.reload_doc(); frappe.show_alert(__("{0} work order(s) created with their material check", [message]));
		})).addClass("btn-primary");
	},
});
