"""Weekly production plan (Chemical Core > Production Planning).

- 'Fill from Sales Orders': open orders due within two weeks, for products we make, less released stock.
- Each run is placed on a tank or reactor (Equipment) and a day. The plan works out the cleaning needed before each
  run: none for the same product again, a rinse for a compatible product, a full clean when the previous product in
  that vessel must be kept apart from this one (storage classes) or was a different formula level.
- 'Create Work Orders': a draft Work Order per run; its material check (stock, QC, open purchases, suggested purchase
  orders) shows on the plan line.
"""

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, flt, getdate

from chemical_erp.regulatory_compliance.storage import INCOMPATIBLE, storage_class


class ProductionSchedule(Document):
	def validate(self):
		warnings = []
		for l in self.lines:
			if not l.bom:
				l.bom = frappe.db.get_value("Item", l.item_code, "default_bom")
			if not l.bom:
				warnings.append(_("{0}: no approved formula").format(l.item_code))
			if getdate(l.planned_date) < getdate(self.week_start) or getdate(l.planned_date) > getdate(add_days(self.week_start, 6)):
				warnings.append(_("{0} on {1} is outside this week").format(l.item_code, l.planned_date))
			if l.work_order:
				l.material_status = frappe.db.get_value("Work Order", l.work_order, "material_status") or ""
		by_vessel = {}
		for l in sorted(self.lines, key=lambda x: (str(x.planned_date), x.idx)):
			if not l.vessel:
				l.cleaning = ""
				continue
			prev = by_vessel.get(l.vessel)
			l.cleaning = cleaning_between(prev.item_code if prev else last_product_in(l.vessel, l.planned_date), l.item_code)
			if prev and prev.planned_date == l.planned_date:
				warnings.append(_("{0} has two runs on {1}: {2} and {3}. Check the time allows the {4}.").format(
					l.vessel, l.planned_date, prev.item_code, l.item_code, (l.cleaning or _("changeover")).lower()))
			by_vessel[l.vessel] = l
		self.warnings = "\n".join(dict.fromkeys(warnings))

	@frappe.whitelist()
	def fill_from_sales_orders(self):
		have = {(l.sales_order, l.item_code) for l in self.lines}
		until = add_days(self.week_start, 13)
		rows = frappe.db.sql("""select so.name, soi.item_code, sum(soi.stock_qty - soi.delivered_qty * soi.conversion_factor) pending, min(soi.delivery_date) due
			from `tabSales Order Item` soi join `tabSales Order` so on so.name = soi.parent
			where so.docstatus = 1 and so.status not in ('Closed','Completed','On Hold') and so.company = %s and soi.delivery_date <= %s
			group by so.name, soi.item_code having pending > 0 order by due""", (self.company, until), as_dict=True)
		from chemical_erp.chemical_core.material_check import _bin_qty, _zone_warehouses

		released = _zone_warehouses("Released")
		free = {}
		added = 0
		for r in rows:
			if not frappe.db.get_value("Item", r.item_code, "default_bom") or (r.name, r.item_code) in have:
				continue
			if r.item_code not in free:
				free[r.item_code] = _bin_qty(r.item_code, released)
			need = flt(r.pending) - free[r.item_code]
			free[r.item_code] = max(free[r.item_code] - flt(r.pending), 0)
			if need <= 0:
				continue
			day = max(getdate(self.week_start), min(getdate(add_days(r.due, -2)), getdate(add_days(self.week_start, 6))))
			self.append("lines", {"planned_date": day, "item_code": r.item_code, "qty": need, "sales_order": r.name})
			added += 1
		self.save()
		return added

	@frappe.whitelist()
	def make_work_orders(self):
		made = 0
		ms = frappe.get_single("Manufacturing Settings")
		for l in self.lines:
			if l.work_order or not l.bom:
				continue
			wo = frappe.get_doc({"doctype": "Work Order", "production_item": l.item_code, "bom_no": l.bom, "qty": l.qty, "company": self.company,
			                     "planned_start_date": f"{l.planned_date} 08:00:00", "sales_order": l.sales_order,
			                     "wip_warehouse": ms.default_wip_warehouse, "fg_warehouse": ms.default_fg_warehouse})
			wo.insert()
			l.work_order, l.material_status = wo.name, wo.get("material_status") or ""
			made += 1
		self.status = "Released" if made or all(l.work_order for l in self.lines) else self.status
		self.save()
		return made


def last_product_in(vessel, before):
	"""The last product made in this vessel before a date (from earlier plans)."""
	r = frappe.db.sql("""select l.item_code from `tabProduction Schedule Line` l where l.vessel=%s and l.planned_date < %s
		order by l.planned_date desc limit 1""", (vessel, before))
	return r[0][0] if r else None


def cleaning_between(previous, product):
	if not previous:
		return ""
	if previous == product:
		return _("None (same product)")
	a, b = storage_class(previous), storage_class(product)
	if a and b and frozenset((a, b)) in INCOMPATIBLE:
		return _("Full clean and check (after {0})").format(previous)
	conf = frappe.db.get_value("BOM", {"item": previous, "is_default": 1}, "is_confidential")
	return _("Full clean (after premix {0})").format(previous) if conf else _("Rinse (after {0})").format(previous)
