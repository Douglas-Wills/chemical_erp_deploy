frappe.listview_settings["Help Topic"] = {
	onload(list) {
		list.page.add_inner_button(__("❓ Try the Help search"), () => frappe.chem_help.open());
		if (!frappe.model.can_write("Help Topic")) return;
		list.page.add_inner_button(__("Searches With No Answer"), () =>
			frappe.call("chemical_erp.help.search.missed_searches").then(({ message: rows }) => {
				const body = rows.length
					? `<table class="table table-bordered"><tr><th>${__("Searched for")}</th><th>${__("Times")}</th></tr>`
						+ rows.map((r) => `<tr><td>${frappe.utils.escape_html(r.search)}</td><td>${r.times}</td></tr>`).join("") + "</table>"
					: `<p>${__("Every search so far found something.")}</p>`;
				const d = new frappe.ui.Dialog({ title: __("Searches With No Answer"), size: "large",
					fields: [{ fieldtype: "HTML", options: `<p class="text-muted">${__("Add a topic, or put these words in a topic's Extra Keywords.")}</p>` + body }],
					primary_action_label: __("Clear List"),
					primary_action: () => frappe.call("chemical_erp.help.search.clear_missed").then(() => d.hide()) });
				d.show();
			}));
	},
};
