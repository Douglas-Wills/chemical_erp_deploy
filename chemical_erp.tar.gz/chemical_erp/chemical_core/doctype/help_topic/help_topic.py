import frappe
from frappe.model.document import Document


class HelpTopic(Document):
	def validate(self):
		if self.is_new() and not frappe.flags.in_help_seed:
			self.source = "Added Here"
		elif not self.is_new() and self.source == "Manual" and not frappe.flags.in_help_seed:
			if self.has_value_changed("body") or self.has_value_changed("topic_title") or self.has_value_changed("keywords"):
				self.edited_here = 1  # the next manual update will not overwrite this wording
