frappe.ui.form.on("Quick Order", {
	refresh(frm) {
		if (frm.is_new()) return;
		if (frm.doc.message && frm.doc.status === "New") {
			frm.add_custom_button(__("Read Message"), () => frm.call("read_message").then(({ message: r }) => {
				frm.reload_doc();
				frappe.show_alert({ message: __("{0} product line(s) added", [r.added]) +
					(r.unmatched.length ? ". " + __("Check the 'Not Recognised' lines.") : ""), indicator: r.unmatched.length ? "orange" : "green" });
			}));
		}
		if (!frm.doc.sales_order && !["Cancelled"].includes(frm.doc.status) && (frm.doc.items || []).length) {
			frm.add_custom_button(__("Create Sales Order"), () => frm.call("make_sales_order").then(({ message }) =>
				frappe.set_route("Form", "Sales Order", message))).addClass("btn-primary");
		}
		if (frm.doc.phone) {
			const phone = frm.doc.phone.replace(/\D/g, "");
			frm.add_custom_button(__("WhatsApp Customer"), () => window.open(
				`https://wa.me/${phone}?text=${encodeURIComponent(__("Hello {0}, this is about your order {1}.", [frm.doc.customer_name, frm.doc.name]))}`, "_blank"));
		}
	},
});

frappe.ui.form.on("Quick Order Item", {
	qty(frm, cdt, cdn) { const r = locals[cdt][cdn]; frappe.model.set_value(cdt, cdn, "amount", (r.qty || 0) * (r.rate || 0)); },
	rate(frm, cdt, cdn) { const r = locals[cdt][cdn]; frappe.model.set_value(cdt, cdn, "amount", (r.qty || 0) * (r.rate || 0)); },
});
