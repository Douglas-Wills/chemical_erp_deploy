import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, flt, today

from chemical_erp.chemical_core import quick_orders as qo
from chemical_erp.utils import get_settings


class QuickOrder(Document):
	def validate(self):
		self.phone = qo.normalise_phone(self.phone)
		if not self.customer:
			self.customer = qo.customer_by_phone(self.phone)
		if self.customer and not self.customer_group:
			self.customer_group = frappe.db.get_value("Customer", self.customer, "customer_group")
		self.customer_group = self.customer_group or get_settings().get("quick_order_customer_group")
		self.price_list = qo.price_list_for(self.customer, self.customer_group)
		self.total = 0
		for r in self.items:
			stock_uom = frappe.get_cached_value("Item", r.item_code, "stock_uom")
			r.uom = r.uom or stock_uom
			r.item_name = r.item_name or frappe.get_cached_value("Item", r.item_code, "item_name")
			if not flt(r.rate):
				r.rate = qo.price(r.item_code, r.uom, self.price_list)
			r.amount = flt(r.qty) * flt(r.rate)
			self.total += r.amount
		if self.status == "Cancelled" and not (self.cancel_reason or "").strip():
			frappe.throw(_("Say why the order was cancelled."))
		if self.status in ("Confirmed", "Converted") and not self.items:
			frappe.throw(_("Add the products ordered."))

	@frappe.whitelist()
	def read_message(self):
		rows, unmatched = qo.parse(self.message or "")
		have = {(r.item_code, r.uom) for r in self.items}
		added = 0
		for r in rows:
			if (r["item_code"], r["uom"]) in have:
				continue
			self.append("items", {"item_code": r["item_code"], "qty": r["qty"], "uom": r["uom"]})
			added += 1
		self.unmatched = "\n".join(unmatched)
		self.save()
		return {"added": added, "unmatched": unmatched}

	@frappe.whitelist()
	def make_sales_order(self):
		if self.sales_order:
			return self.sales_order
		if not self.items:
			frappe.throw(_("Add the products ordered first."))
		customer = self.customer or self._new_customer()
		so = frappe.get_doc({
			"doctype": "Sales Order", "customer": customer, "transaction_date": today(),
			"delivery_date": self.delivery_date or add_days(today(), 1), "selling_price_list": self.price_list,
			"po_no": self.name, "items": [{"item_code": r.item_code, "qty": r.qty, "uom": r.uom, "rate": r.rate,
			                              "delivery_date": self.delivery_date or add_days(today(), 1)} for r in self.items],
		})
		so.insert()
		so.add_comment("Comment", _("From {0} ({1}). Deliver to: {2}. Payment: {3}").format(
			self.name, self.channel, self.delivery_location or "-", self.payment_method or "-"))
		self.db_set({"sales_order": so.name, "status": "Converted", "customer": customer})
		return so.name

	def _new_customer(self):
		group = self.customer_group or get_settings().get("quick_order_customer_group") or frappe.db.get_single_value(
			"Selling Settings", "customer_group") or "All Customer Groups"
		c = frappe.get_doc({"doctype": "Customer", "customer_name": self.customer_name, "customer_type": "Individual",
		                    "customer_group": group, "territory": frappe.db.get_single_value("Selling Settings", "territory") or "All Territories",
		                    "mobile_no": self.phone})
		if c.meta.has_field("po_required"):
			c.po_required = 0  # households and shops order by phone or WhatsApp: the Quick Order is the basis for the invoice
		c.insert()
		contact = frappe.get_doc({"doctype": "Contact", "first_name": self.customer_name, "phone_nos": [{"phone": self.phone, "is_primary_mobile_no": 1}],
		                          "links": [{"link_doctype": "Customer", "link_name": c.name}]})
		contact.insert(ignore_permissions=True)
		return c.name
