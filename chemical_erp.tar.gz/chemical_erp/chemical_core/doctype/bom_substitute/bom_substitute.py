from frappe.model.document import Document


class BOMSubstitute(Document):
	pass
