from frappe.model.document import Document


class DocumentScan(Document):
	pass
