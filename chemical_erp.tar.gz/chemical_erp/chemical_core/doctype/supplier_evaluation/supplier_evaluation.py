import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import cint, flt


def _score(select_value):
	return cint((select_value or "3").split(" ")[0])


class SupplierEvaluation(Document):
	def validate(self):
		self.measure()
		manual = (_score(self.coa_accuracy) + _score(self.responsiveness) + _score(self.price_competitiveness)) / 15 * 100
		# weights: on-time 30%, QC acceptance 40%, assessed factors 30%
		on_time = flt(self.on_time_percent) if self.receipts else 100
		accepted = flt(self.accepted_percent) if self.inspections else 100
		self.total_score = flt(on_time * 0.3 + accepted * 0.4 + manual * 0.3, 1)
		self.rating = "A - Approved" if self.total_score >= 80 else ("B - Conditional" if self.total_score >= 60 else "C - Not Approved")

	def measure(self):
		rows = frappe.db.sql("""select pr.name, pr.posting_date, max(poi.schedule_date) as due
			from `tabPurchase Receipt` pr join `tabPurchase Receipt Item` pri on pri.parent = pr.name
			left join `tabPurchase Order Item` poi on poi.name = pri.purchase_order_item
			where pr.docstatus = 1 and pr.supplier = %s and pr.posting_date between %s and %s group by pr.name""",
		                     (self.supplier, self.period_from, self.period_to), as_dict=True)
		self.receipts = len(rows)
		on_time = sum(1 for r in rows if not r.due or r.posting_date <= r.due)
		self.on_time_percent = flt(on_time / len(rows) * 100, 1) if rows else 0
		qis = frappe.db.sql("""select qi.status from `tabQuality Inspection` qi join `tabPurchase Receipt` pr
			on qi.reference_type = 'Purchase Receipt' and qi.reference_name = pr.name
			where qi.docstatus = 1 and pr.supplier = %s and qi.report_date between %s and %s""",
		                    (self.supplier, self.period_from, self.period_to), as_dict=True)
		self.inspections = len(qis)
		self.accepted_percent = flt(sum(1 for q in qis if q.status == "Accepted") / len(qis) * 100, 1) if qis else 0

	def on_submit(self):
		frappe.db.set_value("Supplier", self.supplier, {"is_approved_vendor": 0 if self.rating.startswith("C") else 1,
		                                                "supplier_rating": self.rating, "last_evaluated_on": self.period_to})
		frappe.get_doc("Supplier", self.supplier).add_comment("Info", _("Evaluated {0}: {1} ({2}%)").format(self.name, self.rating, self.total_score))
