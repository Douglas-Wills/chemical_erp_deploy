import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import cint, date_diff, getdate, now_datetime, today

from chemical_erp.utils import FORMULA_ROLE, MD_ROLE, get_settings, has_role


class FormulaDelegation(Document):
	def validate(self):
		if not has_role(MD_ROLE):
			frappe.throw(_("Only the Managing Director can delegate access to formulas."), frappe.PermissionError)
		if has_role(MD_ROLE, self.delegate):
			frappe.throw(_("The delegate cannot be the Managing Director."))
		if date_diff(self.valid_to, self.valid_from) > cint(get_settings().max_delegation_days or 90):
			frappe.throw(_("A delegation can last at most {0} days.").format(get_settings().max_delegation_days or 90))
		if self.status == "Active":
			other = frappe.db.exists("Formula Delegation", {"status": "Active", "name": ["!=", self.name]})
			if other:
				frappe.throw(_("{0} is already active. Revoke it first; only one delegate at a time.").format(other))

	def on_update(self):
		sync_role(self)

	@frappe.whitelist()
	def revoke(self):
		if not has_role(MD_ROLE):
			frappe.throw(_("Only the Managing Director can revoke a delegation."), frappe.PermissionError)
		self.status = "Revoked"
		self.revoked_on = now_datetime()
		self.save()


def sync_role(d):
	user = frappe.get_doc("User", d.delegate)
	active = d.status == "Active" and getdate(d.valid_from) <= getdate(today()) <= getdate(d.valid_to)
	roles = [r.role for r in user.roles]
	if active and FORMULA_ROLE not in roles:
		user.add_roles(FORMULA_ROLE)
	elif not active and FORMULA_ROLE in roles:
		user.remove_roles(FORMULA_ROLE)
	frappe.get_doc("Formula Delegation", d.name).add_comment(
		"Info", _("Formula Owner role {0} for {1}").format(_("granted") if active else _("removed"), d.delegate))


def expire_delegations():
	for d in frappe.get_all("Formula Delegation", filters={"status": "Active"}, fields=["name", "valid_to"]):
		doc = frappe.get_doc("Formula Delegation", d.name)
		if getdate(d.valid_to) < getdate(today()):
			doc.db_set("status", "Expired")
			doc.status = "Expired"
		sync_role(doc)
