frappe.ui.form.on("Formula Delegation", {
	refresh(frm) {
		if (!frm.is_new() && frm.doc.status === "Active") {
			frm.add_custom_button(__("Revoke Now"), () =>
				frappe.confirm(__("Remove {0}'s access to formulas now?", [frm.doc.delegate]), () =>
					frm.call("revoke").then(() => frm.reload_doc())));
		}
	},
});
