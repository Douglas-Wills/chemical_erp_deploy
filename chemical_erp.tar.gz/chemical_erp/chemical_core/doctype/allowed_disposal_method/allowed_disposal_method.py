from frappe.model.document import Document


class AllowedDisposalMethod(Document):
	pass
