from frappe.model.document import Document


class EFRISSubmissionLog(Document):
	pass
