frappe.ui.form.on("Disposal Order", {
	refresh(frm) {
		if (frm.doc.docstatus === 1 && frm.doc.status !== "Closed") {
			frm.add_custom_button(__("Close with Certificate"), () =>
				frm.call("close").then(() => frm.reload_doc())).addClass("btn-primary");
		}
	},
});
