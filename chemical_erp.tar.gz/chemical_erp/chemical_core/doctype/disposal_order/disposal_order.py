import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, getdate, now_datetime, today

from chemical_erp.utils import batch_balances, exchange_rate, get_settings, make_stock_entry, warehouse_zone


class DisposalOrder(Document):
	def validate(self):
		from chemical_erp.management_systems.gates import check as permit_gate

		permit_gate("Disposal")
		b = frappe.db.get_value("Batch", self.waste_batch, ["is_waste_batch", "item"], as_dict=True)
		if not b or not b.is_waste_batch:
			frappe.throw(_("Batch {0} is not a waste batch.").format(self.waste_batch))
		held = sum(q for wh, q in batch_balances(self.waste_batch) if warehouse_zone(wh) == "Waste Hold")
		if flt(self.qty_kg) > flt(held) + 0.0001:
			frappe.throw(_("Only {0} kg of this batch is in Waste Hold.").format(held))
		allowed = [r.method for r in frappe.get_all("Allowed Disposal Method", filters={"parent": b.item, "parenttype": "Item"}, fields=["method"])]
		if allowed and self.method not in allowed:
			frappe.throw(_("{0} is not an allowed disposal method for {1}.").format(self.method, b.item))
		v = frappe.db.get_value("Supplier", self.vendor, ["is_disposal_vendor", "disposal_licence_expiry"], as_dict=True)
		if not v or not v.is_disposal_vendor:
			frappe.throw(_("{0} is not a disposal vendor.").format(self.vendor))
		if not v.disposal_licence_expiry or getdate(v.disposal_licence_expiry) < getdate(today()):
			frappe.throw(_("{0}'s disposal licence has expired or is not recorded.").format(self.vendor), title=_("Licence expired"))
		rate = frappe.get_all("Disposal Vendor Price", filters={"supplier": self.vendor, "waste_item": b.item, "method": self.method,
		                                                       "valid_from": ["<=", today()]},
		                      or_filters=[["valid_to", "is", "not set"], ["valid_to", ">=", today()]],
		                      fields=["rate_per_kg", "currency"], order_by="valid_from desc", limit=1)
		if not rate:
			frappe.throw(_("No current price from {0} for {1} by {2}.").format(self.vendor, b.item, self.method))
		# expected cost and the accrual are in company currency, whatever currency the vendor quotes in
		self.expected_cost = flt(rate[0].rate_per_kg) * flt(self.qty_kg) * exchange_rate(rate[0].currency)

	def on_submit(self):
		from chemical_erp.numbering import manifest_number

		self.db_set({"status": "Approved", "manifest_no": self.manifest_no or manifest_number(self)})

	@frappe.whitelist()
	def close(self):
		if self.docstatus != 1 or self.status == "Closed":
			frappe.throw(_("Only an approved, open Disposal Order can be closed."))
		missing = [l for f, l in (("certificate", _("certificate of disposal")),
		                          ("disposal_acknowledgement", _("hazardous waste disposal acknowledgement from the receiving facility")),
		                          ("receiver_signed_by", _("receiver's signature")),
		                          ("generator_signed_by", _("generator's signature")), ("transporter_name", _("transporter")))
		           if not self.get(f)]
		if missing:
			frappe.throw(_("Before closing, record the {0}.").format(", ".join(missing)))
		s = get_settings()
		if not (s.disposal_expense_account and s.disposal_accrual_account):
			frappe.throw(_("Set the disposal expense and accrual accounts in Chemical ERP Settings."))
		item = frappe.db.get_value("Batch", self.waste_batch, "item")
		remaining, rows = flt(self.qty_kg), []
		for wh, q in batch_balances(self.waste_batch):
			if warehouse_zone(wh) != "Waste Hold" or remaining <= 0:
				continue
			take = min(q, remaining)
			rows.append({"item_code": item, "qty": take, "s_warehouse": wh, "batch_no": self.waste_batch,
			             "basic_rate": 0, "allow_zero_valuation_rate": 1})
			remaining -= take
		se = make_stock_entry(self.company, "Material Issue", rows, flags={"disposal_issue": True},
		                      disposal_order=self.name, remarks=_("Disposal {0}").format(self.name))
		je = frappe.get_doc({"doctype": "Journal Entry", "voucher_type": "Journal Entry", "company": self.company,
		                     "posting_date": today(), "user_remark": _("Disposal {0}, waste batch {1}").format(self.name, self.waste_batch),
		                     "disposal_order": self.name, "waste_batch": self.waste_batch,
		                     "accounts": [
			                     {"account": s.disposal_expense_account, "debit_in_account_currency": self.expected_cost,
			                      "cost_center": s.default_cost_center},
			                     {"account": s.disposal_accrual_account, "credit_in_account_currency": self.expected_cost,
			                      "cost_center": s.default_cost_center}]})
		je.insert(ignore_permissions=True)
		je.submit()
		self.db_set({"issue_entry": se.name, "accrual_entry": je.name, "status": "Closed"})
		return self.status
