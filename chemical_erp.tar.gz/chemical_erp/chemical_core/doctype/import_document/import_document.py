from frappe.model.document import Document


class ImportDocument(Document):
	pass
