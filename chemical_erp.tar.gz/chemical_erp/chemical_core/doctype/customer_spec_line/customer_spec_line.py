from frappe.model.document import Document


class CustomerSpecLine(Document):
	pass
