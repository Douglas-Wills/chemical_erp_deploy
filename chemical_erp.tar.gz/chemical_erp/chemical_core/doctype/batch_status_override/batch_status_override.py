import frappe
from frappe import _
from frappe.model.document import Document

from chemical_erp.controls.quality import reject_batch, release_batch


class BatchStatusOverride(Document):
	def validate(self):
		self.from_status = frappe.db.get_value("Batch", self.batch, "qc_status") or "Quarantine"
		if self.from_status == self.to_status:
			frappe.throw(_("The batch is already {0}.").format(self.to_status))

	def on_submit(self):
		if self.to_status == "Released":
			release_batch(self.batch, via=self.name)
		elif self.to_status == "Rejected":
			reject_batch(self.batch, via=self.name)
		else:
			frappe.db.set_value("Batch", self.batch, "qc_status", self.to_status)
		frappe.get_doc("Batch", self.batch).add_comment("Info", _("Status {0} → {1} by override {2}: {3}").format(
			self.from_status, self.to_status, self.name, self.reason))
