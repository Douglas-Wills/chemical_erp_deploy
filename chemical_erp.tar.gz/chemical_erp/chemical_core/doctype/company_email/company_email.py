from frappe.model.document import Document


class CompanyEmail(Document):
	pass
