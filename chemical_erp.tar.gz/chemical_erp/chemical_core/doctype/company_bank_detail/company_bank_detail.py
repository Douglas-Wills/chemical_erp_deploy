from frappe.model.document import Document


class CompanyBankDetail(Document):
	pass
