"""WHT certificates owed to Brave by customers who withhold tax.

A provision, never a gate: an expected certificate is opened for every invoice to a customer who deducts WHT,
and stays open until the certificate is attached, which is often months later, around the end of the calendar year.
One certificate may cover several invoices: adding an invoice here absorbs that invoice's own expected record.
"""

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, today

from chemical_erp.utils import get_settings, notify, users_with_role

STATUS_ON_INVOICE = {"Expected": "Awaiting Certificate", "Received": "Certificate Received", "Claimed": "Claimed"}


def wht_for(base_net_total):
	return flt(flt(base_net_total) * flt(get_settings().get("wht_rate") or 6) / 100, 2)


class WHTCertificate(Document):
	def validate(self):
		seen = set()
		for r in self.invoices:
			if r.sales_invoice in seen:
				frappe.throw(_("Invoice {0} is listed twice.").format(r.sales_invoice))
			seen.add(r.sales_invoice)
			inv = frappe.db.get_value("Sales Invoice", r.sales_invoice, ["base_grand_total", "base_net_total", "wht_amount", "customer"], as_dict=True)
			if inv and inv.customer != self.customer:
				frappe.throw(_("Invoice {0} belongs to {1}, not {2}.").format(r.sales_invoice, inv.customer, self.customer))
			r.invoice_amount = inv.base_grand_total if inv else 0
			if not flt(r.wht_amount):
				r.wht_amount = flt(inv.wht_amount) if inv and flt(inv.wht_amount) else wht_for(inv.base_net_total if inv else 0)
		self.total_wht = sum(flt(r.wht_amount) for r in self.invoices)
		if self.attachment and self.status == "Expected":
			self.status = "Received"
			self.received_on = self.received_on or today()

	def on_update(self):
		for r in self.invoices:
			# absorb the invoice's own expected record if this certificate now covers it
			for other in frappe.get_all("WHT Certificate Invoice", filters={"sales_invoice": r.sales_invoice, "parent": ["!=", self.name]},
			                            pluck="parent"):
				if frappe.db.get_value("WHT Certificate", other, "status") == "Expected":
					rows = frappe.db.count("WHT Certificate Invoice", {"parent": other})
					if rows <= 1:
						frappe.delete_doc("WHT Certificate", other, ignore_permissions=True, force=True)
					else:
						frappe.db.delete("WHT Certificate Invoice", {"parent": other, "sales_invoice": r.sales_invoice})
			frappe.db.set_value("Sales Invoice", r.sales_invoice, {
				"wht_certificate": self.name, "wht_status": STATUS_ON_INVOICE.get(self.status, "Awaiting Certificate"),
				"wht_certificate_no": self.certificate_no or frappe.db.get_value("Sales Invoice", r.sales_invoice, "wht_certificate_no"),
				"wht_certificate_file": self.attachment or frappe.db.get_value("Sales Invoice", r.sales_invoice, "wht_certificate_file")},
				update_modified=False)


# ------------------------------------------------------------------ from the sales invoice
def from_invoice(doc, method=None):
	"""Every invoice to a customer who deducts WHT gets an expected certificate; attaching on the invoice records it."""
	if doc.docstatus != 1 or doc.get("is_return"):
		return
	if not doc.get("wht_applicable"):
		if doc.get("wht_status"):
			doc.db_set({"wht_status": None})
		return
	if not flt(doc.get("wht_amount")):
		doc.db_set("wht_amount", wht_for(doc.base_net_total), update_modified=False)
	cert_name = doc.get("wht_certificate") or frappe.db.get_value("WHT Certificate Invoice", {"sales_invoice": doc.name}, "parent")
	if cert_name:
		cert = frappe.get_doc("WHT Certificate", cert_name)
	else:
		cert = frappe.get_doc({"doctype": "WHT Certificate", "customer": doc.customer, "status": "Expected",
		                       "invoices": [{"sales_invoice": doc.name, "wht_amount": doc.wht_amount}]})
	if doc.get("wht_certificate_file") and not cert.attachment:
		cert.attachment = doc.wht_certificate_file
	if doc.get("wht_certificate_no") and not cert.certificate_no:
		cert.certificate_no = doc.wht_certificate_no
	for r in cert.invoices:
		if r.sales_invoice == doc.name and flt(doc.get("wht_amount")):
			r.wht_amount = doc.wht_amount
	cert.flags.ignore_permissions = True
	cert.save() if not cert.is_new() else cert.insert()


def on_invoice_cancel(doc, method=None):
	"""A cancelled invoice no longer owes a certificate; a received certificate is left untouched for the record."""
	for parent in frappe.get_all("WHT Certificate Invoice", filters={"sales_invoice": doc.name}, pluck="parent"):
		if frappe.db.get_value("WHT Certificate", parent, "status") != "Expected":
			continue
		if frappe.db.count("WHT Certificate Invoice", {"parent": parent}) <= 1:
			frappe.delete_doc("WHT Certificate", parent, ignore_permissions=True, force=True)
		else:
			frappe.db.delete("WHT Certificate Invoice", {"parent": parent, "sales_invoice": doc.name})


def expect_from_payment(doc, method=None):
	"""A payment with a deduction to the WHT receivable account confirms the WHT actually withheld."""
	acct = get_settings().get("wht_receivable_account")
	if not acct or doc.payment_type != "Receive" or doc.party_type != "Customer":
		return
	wht = sum(flt(d.amount) for d in doc.get("deductions") or [] if d.account == acct)
	if not wht:
		return
	invoices = [r.reference_name for r in doc.references if r.reference_doctype == "Sales Invoice"]
	for inv in invoices:
		if not frappe.db.get_value("Sales Invoice", inv, "wht_applicable"):
			frappe.db.set_value("Sales Invoice", inv, "wht_applicable", 1)
		frappe.get_doc("Sales Invoice", inv).run_method("on_update_after_submit")
	certs = {frappe.db.get_value("WHT Certificate Invoice", {"sales_invoice": i}, "parent") for i in invoices} - {None}
	for c in certs:
		frappe.db.set_value("WHT Certificate", c, "payment_entry", doc.name)
	if not invoices:
		cert = frappe.get_doc({"doctype": "WHT Certificate", "customer": doc.party, "payment_entry": doc.name, "status": "Expected"})
		cert.insert(ignore_permissions=True)
		cert.db_set("total_wht", wht)


# ------------------------------------------------------------------ follow-up: monthly, weekly towards year end
def outstanding_summary():
	rows = frappe.db.sql("""select c.customer, count(distinct c.name) certs, sum(i.wht_amount) amount, min(c.creation) oldest
		from `tabWHT Certificate` c join `tabWHT Certificate Invoice` i on i.parent = c.name
		where c.status = 'Expected' group by c.customer order by amount desc""", as_dict=True)
	return rows


def follow_up(force=False):
	months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
	start = months.index(get_settings().get("wht_followup_from_month") or "November") + 1
	now = frappe.utils.getdate(today())
	weekly_season = now.month >= start
	if not force and not weekly_season and now.day != 1:
		return  # outside the year-end season: only on the 1st of the month
	if not force and weekly_season and now.weekday() != 0:
		return  # in season: Mondays
	rows = outstanding_summary()
	if not rows:
		return
	total = sum(flt(r.amount) for r in rows)
	lines = "; ".join(f"{r.customer}: {frappe.utils.fmt_money(r.amount, precision=0)}" for r in rows[:12])
	msg = _("{0} customer(s) still owe WHT certificates worth {1} in total. {2}{3}").format(
		len(rows), frappe.utils.fmt_money(total, precision=0), lines,
		_(" Year-end is close: collect these for the tax return.") if weekly_season else "")
	notify(users_with_role("Accounts User") + users_with_role("Accounts Manager"), "WHT Certificate", None, msg,
	       priority="High" if weekly_season else "Medium")
