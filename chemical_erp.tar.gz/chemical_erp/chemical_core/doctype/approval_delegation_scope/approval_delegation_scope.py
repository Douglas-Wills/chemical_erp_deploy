from frappe.model.document import Document


class ApprovalDelegationScope(Document):
	pass
