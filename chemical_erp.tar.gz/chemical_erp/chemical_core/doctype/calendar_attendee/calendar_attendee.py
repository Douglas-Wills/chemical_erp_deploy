from frappe.model.document import Document


class CalendarAttendee(Document):
	pass
