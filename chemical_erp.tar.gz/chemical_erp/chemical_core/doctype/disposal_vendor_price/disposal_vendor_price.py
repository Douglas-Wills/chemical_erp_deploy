from frappe.model.document import Document

from chemical_erp.utils import company_currency


class DisposalVendorPrice(Document):
	def validate(self):
		if not self.currency:
			self.currency = company_currency()
