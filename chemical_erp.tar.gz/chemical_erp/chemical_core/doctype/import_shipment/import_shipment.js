frappe.ui.form.on("Import Shipment", {
	refresh(frm) {
		if (frm.is_new()) return;
		if (frm.doc.landed_cost_voucher) {
			frm.add_custom_button(__("Landed Cost Voucher"), () => frappe.set_route("Form", "Landed Cost Voucher", frm.doc.landed_cost_voucher), __("View"));
		} else if (frm.doc.purchase_receipt) {
			frm.add_custom_button(__("Make Landed Cost Voucher"), () =>
				frm.call({ doc: frm.doc, method: "make_landed_cost_voucher", freeze: true, freeze_message: __("Adding costs to stock value…") })
					.then(({ message }) => { frm.reload_doc(); if (message) frappe.set_route("Form", "Landed Cost Voucher", message); }));
		}
	},
});
