import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt

from chemical_erp.utils import company_currency, exchange_rate

STANDARD_DOCS = ["Proforma Invoice", "Commercial Invoice", "Packing List", "Bill of Lading / Airway Bill", "Certificate of Origin",
                 "Supplier COA", "Supplier SDS", "UNBS Certificate of Conformity", "Customs Entry", "Tax Assessment"]
RECOVERABLE = ("Import VAT", "Withholding Tax")


class ImportShipment(Document):
	def validate(self):
		if not self.documents:
			for d in STANDARD_DOCS:
				self.append("documents", {"document_type": d, "required": 1})
		base = company_currency(self.company)
		landed = recoverable = 0.0
		for c in self.costs:
			c.currency = c.currency or base
			if c.cost_type in RECOVERABLE and not c.name:  # new line: import VAT and WHT are claimable, not stock cost
				c.recoverable = 1
			c.base_amount = flt(c.amount) * exchange_rate(c.currency, base)
			if c.recoverable:
				recoverable += c.base_amount
			else:
				landed += c.base_amount
		self.total_landed_costs, self.total_recoverable = landed, recoverable
		if self.status in ("Cleared", "Received", "Closed"):
			missing = [d.document_type for d in self.documents if d.required and not d.attachment]
			if missing:
				frappe.msgprint(_("Documents still to attach: {0}").format(", ".join(missing)), indicator="orange",
				                title=_("Import documents"))
		if self.purchase_receipt and self.status not in ("Received", "Closed"):
			self.status = "Received"

	@frappe.whitelist()
	def make_landed_cost_voucher(self):
		"""Carry freight, duty, clearing and other non-recoverable costs into the received stock's value."""
		if not self.purchase_receipt:
			frappe.throw(_("Link the purchase receipt first."))
		if frappe.db.get_value("Purchase Receipt", self.purchase_receipt, "docstatus") != 1:
			frappe.throw(_("The purchase receipt must be approved before costs can be added to it."))
		lines = [c for c in self.costs if not c.recoverable and flt(c.base_amount)]
		if not lines:
			frappe.throw(_("No costs to add to stock value."))
		missing_acct = [c.cost_type for c in lines if not c.expense_account]
		if missing_acct:
			frappe.throw(_("Choose an expense account for: {0}").format(", ".join(missing_acct)))
		lcv = frappe.new_doc("Landed Cost Voucher")
		lcv.company = self.company
		lcv.distribute_charges_based_on = "Amount"
		lcv.append("purchase_receipts", {"receipt_document_type": "Purchase Receipt", "receipt_document": self.purchase_receipt,
		                                 "supplier": self.supplier})
		for c in lines:
			lcv.append("taxes", {"expense_account": c.expense_account, "description": f"{c.cost_type} ({self.name})",
			                     "amount": c.base_amount, "base_amount": c.base_amount, "exchange_rate": 1})
		lcv.get_items_from_purchase_receipts()
		lcv.flags.ignore_permissions = True
		lcv.insert()
		self.db_set("landed_cost_voucher", lcv.name)
		return lcv.name
