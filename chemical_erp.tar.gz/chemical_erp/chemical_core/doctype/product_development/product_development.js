frappe.ui.form.on("Product Development", {
	refresh(frm) {
		if (frm.is_new() || ["Launched", "Dropped"].includes(frm.doc.stage)) return;
		const go = (drop) => frappe.prompt({ fieldname: "note", fieldtype: "Small Text", label: __("Decision note") }, (v) =>
			frm.call("advance", { drop: drop, note: v.note }).then(() => frm.reload_doc()), drop ? __("Drop Project") : __("Next Stage"));
		frm.add_custom_button(__("Next Stage"), () => go(0)).addClass("btn-primary");
		frm.add_custom_button(__("Drop"), () => go(1));
	},
});
