import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, now_datetime

from chemical_erp.utils import MD_ROLE, has_role

STAGES = ["Idea", "Brief Agreed", "Lab Trials", "Stability", "Costing", "Approved for Launch", "Launched"]
GATES = {  # moving into this stage needs:
	"Lab Trials": lambda d: (d.brief or "").strip() or _("a written brief"),
	"Stability": lambda d: any(t.passed for t in d.trials) or _("at least one trial that meets the brief"),
	"Costing": lambda d: d.stability_study or _("a stability study"),
	"Approved for Launch": lambda d: (flt(d.target_price) and flt(d.target_cost)) or _("target cost and price"),
	"Launched": lambda d: (d.item_code and d.bom) or _("the product item and its approved formula"),
}


class ProductDevelopment(Document):
	"""New product development, stage by stage. Formula knowledge stays with the MD and formula owners."""

	def validate(self):
		cost = next((flt(t.cost_per_unit) for t in reversed(self.trials) if t.passed and flt(t.cost_per_unit)), flt(self.target_cost))
		self.expected_margin = (flt(self.target_price) - cost) / flt(self.target_price) * 100 if flt(self.target_price) and cost else 0

	@frappe.whitelist()
	def advance(self, drop=0, note=None):
		if frappe.utils.cint(drop):
			self.stage = "Dropped"
		else:
			if self.stage in ("Launched", "Dropped"):
				frappe.throw(_("This project is closed."))
			nxt = STAGES[STAGES.index(self.stage) + 1]
			ok = GATES.get(nxt, lambda d: True)(self)
			if ok is not True and isinstance(ok, str):
				frappe.throw(_("Before {0}: {1}.").format(nxt, ok), title=_("Stage gate"))
			if nxt in ("Approved for Launch", "Launched") and not has_role(MD_ROLE):
				frappe.throw(_("The Managing Director approves launch."), frappe.PermissionError)
			self.stage = nxt
		self.decision_notes = ((self.decision_notes or "") + f"\n{frappe.utils.format_datetime(now_datetime())} "
		                       f"{frappe.utils.get_fullname()}: {self.stage}" + (f" ({note})" if note else "")).strip()
		self.save()
		return self.stage
