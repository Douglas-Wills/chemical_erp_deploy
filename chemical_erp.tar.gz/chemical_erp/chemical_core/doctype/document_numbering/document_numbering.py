from frappe.model.document import Document


class DocumentNumbering(Document):
	pass
