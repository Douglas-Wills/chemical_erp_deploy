from frappe.model.document import Document


class ProfilePosition(Document):
	pass
