import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt


class CreditLimitRequest(Document):
	def validate(self):
		self.current_limit = self._limit()

	def _limit(self):
		return flt(frappe.db.get_value("Customer Credit Limit", {"parent": self.party, "parenttype": self.party_type,
		                                                         "company": self.company}, "credit_limit"))

	def on_submit(self):
		party = frappe.get_doc(self.party_type, self.party)
		row = next((r for r in party.get("credit_limits") or [] if r.company == self.company), None)
		if row:
			row.credit_limit = self.requested_limit
		else:
			party.append("credit_limits", {"company": self.company, "credit_limit": self.requested_limit})
		party.flags.credit_limit_request = self.name
		party.save(ignore_permissions=True)
		party.add_comment("Info", _("Credit limit set to {0} by {1}").format(self.requested_limit, self.name))


def guard_customer_limit(doc, method=None):
	"""Credit limits change only through an approved Credit Limit Request."""
	if doc.flags.get("credit_limit_request") or doc.is_new():
		return
	before = doc.get_doc_before_save()
	if not before:
		return
	old = {r.company: flt(r.credit_limit) for r in before.get("credit_limits") or []}
	new = {r.company: flt(r.credit_limit) for r in doc.get("credit_limits") or []}
	if old != new:
		frappe.throw(_("Change credit limits through a Credit Limit Request, which the Managing Director approves."))
