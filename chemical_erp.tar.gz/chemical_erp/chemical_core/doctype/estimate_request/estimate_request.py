import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, getdate, today

from chemical_erp.utils import company_currency, exchange_rate


class EstimateRequest(Document):
	def validate(self):
		if not self.currency:
			self.currency = frappe.db.get_value("Customer", self.customer, "default_currency") or company_currency()
		self.base_estimated_value = flt(self.estimated_value) * exchange_rate(self.currency)
		if self.is_new() and self.needed_by and getdate(self.needed_by) < getdate(today()):
			frappe.throw(_("Needed-by date is in the past."))

	@frappe.whitelist()
	def convert(self):
		"""Create an Opportunity and a draft Quotation. Posts no stock and no ledger entry."""
		if self.get("workflow_state") not in (None, "", "Approved"):
			frappe.throw(_("Approve the estimate request first."))
		if self.quotation:
			return self.quotation
		opp = frappe.get_doc({"doctype": "Opportunity", "opportunity_from": "Customer", "party_name": self.customer,
		                      "expected_closing": self.needed_by, "opportunity_amount": self.estimated_value})
		opp.insert()
		q = frappe.get_doc({"doctype": "Quotation", "quotation_to": "Customer", "party_name": self.customer, "currency": self.currency,
		                    "opportunity": opp.name, "items": [{"item_code": self.item_code, "qty": self.qty}]})
		q.run_method("set_missing_values")
		q.insert()
		self.db_set({"opportunity": opp.name, "quotation": q.name, "status": "Converted"})
		return q.name
