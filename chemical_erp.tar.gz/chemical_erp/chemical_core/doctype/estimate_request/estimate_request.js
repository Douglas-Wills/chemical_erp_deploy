frappe.ui.form.on("Estimate Request", {
	refresh(frm) {
		if (!frm.is_new() && frm.doc.workflow_state === "Approved" && !frm.doc.quotation) {
			frm.add_custom_button(__("Create Quotation"), () =>
				frm.call("convert").then((r) => r.message && frappe.set_route("Form", "Quotation", r.message)));
		}
	},
});
