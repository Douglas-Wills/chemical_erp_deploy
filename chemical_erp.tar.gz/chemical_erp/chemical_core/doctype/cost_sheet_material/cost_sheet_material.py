from frappe.model.document import Document


class CostSheetMaterial(Document):
	pass
