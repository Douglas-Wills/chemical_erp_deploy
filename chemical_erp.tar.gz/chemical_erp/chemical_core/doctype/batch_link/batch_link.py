from frappe.model.document import Document


class BatchLink(Document):
	pass
