from frappe.model.document import Document


class DevelopmentTrial(Document):
	pass
