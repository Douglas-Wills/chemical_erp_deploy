from frappe.model.document import Document

from chemical_erp.chemical_core.collections import promise_validate


class PaymentPromise(Document):
	def validate(self):
		promise_validate(self)
