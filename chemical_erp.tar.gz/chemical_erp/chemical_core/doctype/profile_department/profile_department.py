from frappe.model.document import Document


class ProfileDepartment(Document):
	pass
