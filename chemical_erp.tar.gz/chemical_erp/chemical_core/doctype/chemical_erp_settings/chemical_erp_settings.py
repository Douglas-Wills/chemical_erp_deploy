import frappe
from frappe import _
from frappe.model.document import Document

from chemical_erp.utils import MD_ROLE, has_role


class ChemicalERPSettings(Document):
	def validate(self):
		if not has_role(MD_ROLE) and frappe.session.user != "Administrator":
			frappe.throw(_("Only the Managing Director can change Chemical ERP Settings."), frappe.PermissionError)

	def on_update(self):
		before = self.get_doc_before_save()
		if before and before.get("hide_replaced_modules") != self.hide_replaced_modules:
			from chemical_erp.setup.replaced_modules import apply

			apply(self.hide_replaced_modules)
		if not before or before.get("quality_approver") != self.quality_approver:
			from chemical_erp.setup.workflows import sync_quality_approver

			sync_quality_approver(self.quality_approver or "Plant Manager")
			frappe.msgprint(_("Quality documents are now approved by the {0}.").format(self.quality_approver or "Plant Manager"),
			                indicator="green", alert=True)
