frappe.ui.form.on("Chemical ERP Settings", {
	refresh(frm) {
		frm.add_custom_button(__("Suggest Limits"), () => {
			frappe.call("chemical_erp.controls.limits.suggest").then(({ message: rows }) => {
				const fmt = (v) => (v === null || v === undefined ? "" : format_number(v, null, 0));
				const esc = frappe.utils.escape_html;
				const body = rows.map((r) => `<tr><td><b>${esc(r.label)}</b><div class="text-muted small">${esc(r.basis)}</div>` +
					`<div class="text-muted small">${esc(r.below || "")}</div></td>` +
					`<td class="text-right">${fmt(r.current)}</td><td class="text-right"><b>${fmt(r.proposed)}</b></td>` +
					`<td class="text-right">${r.over_now === null ? "" : r.over_now + " → " + r.over_proposed}</td></tr>`).join("");
				const d = new frappe.ui.Dialog({
					title: __("Suggested Approval Limits"),
					size: "extra-large",
					fields: [{ fieldtype: "HTML", fieldname: "t" }],
					primary_action_label: __("Use These (then Save)"),
					primary_action() {
						rows.forEach((r) => frm.set_value(r.field, r.proposed));
						d.hide();
						frappe.show_alert({ message: __("Limits filled in. Review and Save."), indicator: "blue" });
					},
				});
				d.fields_dict.t.$wrapper.html(
					`<p class="text-muted">${__("Worked out from the last 6 months. The last column is how many of those documents would have needed approval at this level: now, and with the suggestion.")}</p>` +
					`<table class="table table-bordered"><tr><th>${__("Limit")}</th><th class="text-right">${__("Now")}</th>` +
					`<th class="text-right">${__("Suggested")}</th><th class="text-right">${__("Approvals (6 months)")}</th></tr>${body}</table>`);
				d.show();
			});
		});
		frm.add_custom_button(__("Delegate My Approvals"), () => frappe.new_doc("Approval Delegation"));
		frm.add_custom_button(__("Security Check"), () => frappe.call("chemical_erp.controls.security.status").then(({ message: rows }) => {
			const esc = frappe.utils.escape_html, icon = { ok: "✅", attention: "⚠️", info: "ℹ️" };
			frappe.msgprint({ title: __("Security Check"), wide: true, message: `<table class="table table-bordered">` +
				rows.map((r) => `<tr><td style="width:32px">${icon[r.state] || ""}</td><td><b>${esc(r.check)}</b><div class="text-muted small">${esc(r.detail || "")}</div></td></tr>`).join("") +
				`</table>` });
		}), __("Security"));
		frm.add_custom_button(__("Turn On Two-Factor Sign-in"), () => frappe.confirm(
			__("People with MD, admin, accounts, HR or formula rights will need an authenticator app (e.g. Google Authenticator) to sign in. " +
			   "Each gets a set-up link by email at their next sign-in. Continue?"),
			() => frappe.call("chemical_erp.controls.security.enable_two_factor").then(({ message }) =>
				frappe.msgprint(__("Two-factor sign-in is on for: {0}", [(message || []).join(", ")])))), __("Security"));
	},
});
