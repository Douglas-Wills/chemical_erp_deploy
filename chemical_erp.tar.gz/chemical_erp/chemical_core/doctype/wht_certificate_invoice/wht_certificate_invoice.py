from frappe.model.document import Document


class WHTCertificateInvoice(Document):
	pass
