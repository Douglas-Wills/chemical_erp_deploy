from frappe.model.document import Document


class ImportCostLine(Document):
	pass
