from frappe.model.document import Document


class ApprovalLog(Document):
	pass
