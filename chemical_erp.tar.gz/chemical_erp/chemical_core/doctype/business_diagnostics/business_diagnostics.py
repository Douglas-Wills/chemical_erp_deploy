from frappe.model.document import Document


class BusinessDiagnostics(Document):
	"""One run of the Business Diagnostics (chemical_core/diagnostics.py). Findings are fixed when run; the MD adds decisions."""
