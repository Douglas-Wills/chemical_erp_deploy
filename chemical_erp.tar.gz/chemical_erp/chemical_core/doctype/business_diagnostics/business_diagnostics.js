frappe.ui.form.on("Business Diagnostics", {
	refresh(frm) {
		frm.add_custom_button(__("Run New Diagnostic"), () =>
			frappe.call({ method: "chemical_erp.chemical_core.diagnostics.run", freeze: true, freeze_message: __("Scanning all modules…") })
				.then(({ message }) => frappe.set_route("Form", "Business Diagnostics", message))).addClass("btn-primary");
		if (frm.is_new()) return;
		render(frm);
	},
});

function render(frm) {
	const esc = frappe.utils.escape_html, d = frm.doc;
	const tone = { "Good": "#1f7a3d", "Watch": "#b45309", "Act Now": "#b42318", "No Data": "#6b7280" };
	const bg = { "Good": "#eaf6ee", "Watch": "#fff4d6", "Act Now": "#fdecea", "No Data": "#f3f4f6" };
	const areas = JSON.parse(d.area_scores || "{}");
	const bar = (v) => `<div style="background:#e5e7eb;border-radius:6px;height:8px;width:100%"><div style="width:${v}%;height:8px;border-radius:6px;background:${v >= 75 ? "#1f7a3d" : v >= 50 ? "#b45309" : "#b42318"}"></div></div>`;
	const scoreColour = d.overall_score >= 75 ? "#1f7a3d" : d.overall_score >= 50 ? "#b45309" : "#b42318";
	let html = `<div style="display:flex;gap:24px;align-items:center;flex-wrap:wrap;margin-bottom:16px">
		<div style="text-align:center"><div style="font-size:42px;font-weight:700;color:${scoreColour}">${Math.round(d.overall_score)}%</div>
		<div class="text-muted small">${__("Overall score")}</div><div class="small" id="diag-prev"></div></div>
		<div style="display:flex;gap:10px">${[["Act Now", d.act_now], ["Watch", d.watch], ["Good", d.good]].map(([k, v]) =>
			`<div style="background:${bg[k]};color:${tone[k]};border-radius:10px;padding:10px 16px;text-align:center"><div style="font-size:24px;font-weight:700">${v || 0}</div><div class="small">${__(k)}</div></div>`).join("")}</div>
		<div style="flex:1;min-width:260px">${Object.entries(areas).map(([a, v]) =>
			`<div style="display:grid;grid-template-columns:170px 1fr 44px;gap:8px;align-items:center;margin:3px 0"><span class="small">${esc(__(a))}</span>${bar(v)}<span class="small text-right">${v}%</span></div>`).join("")}</div></div>`;
	let area = null;
	(d.findings || []).forEach((f) => {
		if (f.area !== area) { html += `<h5 style="margin:18px 0 6px">${esc(__(f.area))}${areas[f.area] !== undefined ? ` <span class="text-muted small">· ${areas[f.area]}%</span>` : ""}</h5>`; area = f.area; }
		html += `<div style="border:1px solid var(--border-color);border-left:5px solid ${tone[f.status]};border-radius:8px;padding:9px 12px;margin:6px 0">
			<div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><b>${esc(f.check_name)}</b>
			<span><span style="background:${bg[f.status]};color:${tone[f.status]};border-radius:99px;padding:2px 9px;font-size:12px;font-weight:600">${esc(__(f.status))}</span>
			<b style="margin-left:8px">${esc(f.value || "")}</b> <span class="text-muted small">${f.target ? __("good practice") + ": " + esc(f.target) : ""}</span></span></div>
			${f.finding ? `<div class="small" style="margin-top:4px">${esc(f.finding)}</div>` : ""}
			${f.recommendation && f.status !== "Good" ? `<div class="small" style="margin-top:4px">➜ ${esc(f.recommendation)} <span class="text-muted">(${esc(f.owner_role || "")})</span></div>` : ""}
			${f.evidence ? `<div class="small" style="margin-top:3px"><a href="${esc(f.evidence)}">${__("See the evidence")}</a></div>` : ""}</div>`;
	});
	frm.get_field("summary_html").$wrapper.html(html);
	if (d.previous) frappe.db.get_value("Business Diagnostics", d.previous, ["overall_score", "run_on"]).then(({ message: p }) => {
		if (!p) return;
		const diff = Math.round(d.overall_score - p.overall_score);
		$("#diag-prev").html(`${diff >= 0 ? "▲" : "▼"} ${Math.abs(diff)} ${__("since")} ${frappe.datetime.str_to_user(p.run_on).slice(0, 10)}`)
			.css("color", diff >= 0 ? "#1f7a3d" : "#b42318");
	});
}
