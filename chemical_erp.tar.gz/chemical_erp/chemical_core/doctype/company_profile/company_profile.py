import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import now_datetime


class CompanyProfile(Document):
	def validate(self):
		from chemical_erp.numbering import BRAVE, SUGGESTED, next_for, preview

		if self.is_new() and not self.numbering:
			for doc, pattern in (BRAVE if "brave" in (self.company or "").lower() else SUGGESTED):
				self.append("numbering", {"document": doc, "pattern": pattern})
		for row in self.numbering:
			row.example = preview(row.pattern, next_for(row))
		if not self.trading_name:
			self.trading_name = frappe.db.get_value("Company", self.company, "company_name")
		posts = {p.position_name for p in self.positions}
		depts = {d.department_name for d in self.departments}
		for d in self.departments:
			if d.parent_department and d.parent_department not in depts:
				frappe.throw(_("Department {0}: parent {1} is not in the list.").format(d.department_name, d.parent_department))
			if d.head_position and d.head_position not in posts:
				frappe.throw(_("Department {0}: post {1} is not in the list of posts.").format(d.department_name, d.head_position))
		for p in self.positions:
			if p.reports_to and p.reports_to not in posts:
				frappe.throw(_("Post {0} reports to {1}, which is not in the list of posts.").format(p.position_name, p.reports_to))
			if p.reports_to == p.position_name:
				frappe.throw(_("Post {0} cannot report to itself.").format(p.position_name))
			if p.department and p.department not in depts:
				frappe.throw(_("Post {0}: department {1} is not in the list.").format(p.position_name, p.department))

	def on_update(self):
		frappe.local._chem_profiles = {}
		if self.tin and frappe.db.get_value("Company", self.company, "tax_id") != self.tin:
			frappe.db.set_value("Company", self.company, "tax_id", self.tin)
		if self.logo_square and not frappe.db.get_value("Company", self.company, "company_logo"):
			frappe.db.set_value("Company", self.company, "company_logo", self.logo_square)

	@frappe.whitelist()
	def apply_organisation(self):
		"""Create or update ERPNext Departments and the company's posts (Company Positions) with their reporting lines."""
		frappe.only_for(("System Manager", "Managing Director"))
		dept_name = {}
		root = frappe.db.get_value("Department", {"is_group": 1, "parent_department": ["in", ["", None]]}, "name") or "All Departments"
		pending = list(self.departments)
		for _round in range(len(pending) + 1):  # parents before children
			for d in list(pending):
				if d.parent_department and d.parent_department not in dept_name:
					continue
				existing = frappe.db.get_value("Department", {"department_name": d.department_name, "company": self.company}, "name")
				parent = dept_name.get(d.parent_department) or root
				if existing:
					frappe.db.set_value("Department", existing, "parent_department", parent)
					dept_name[d.department_name] = existing
				else:
					dep = frappe.get_doc({"doctype": "Department", "department_name": d.department_name, "company": self.company,
					                      "parent_department": parent, "is_group": 1 if any(x.parent_department == d.department_name for x in self.departments) else 0})
					dep.insert(ignore_permissions=True)
					dept_name[d.department_name] = dep.name
				pending.remove(d)
		for p in self.positions:
			roles = frappe.get_all("Position Role", filters={"parent": p.access_profile, "parenttype": "Access Profile"}, pluck="role") if p.access_profile else []
			if frappe.db.exists("Company Position", p.position_name):
				pos = frappe.get_doc("Company Position", p.position_name)
			else:
				pos = frappe.new_doc("Company Position")
				pos.position_name = p.position_name
			pos.company = self.company
			pos.department = dept_name.get(p.department)
			if not pos.roles:
				for r in roles or ["Employee"]:
					pos.append("roles", {"role": r})
			pos.flags.ignore_permissions = True
			pos.save()
		for p in self.positions:  # reporting lines once every post exists
			frappe.db.set_value("Company Position", p.position_name, "reports_to_position", p.reports_to or None)
		self.db_set("organisation_applied_on", now_datetime())
		return {"departments": len(dept_name), "posts": len(self.positions)}

	@frappe.whitelist()
	def apply_numbering(self):
		from chemical_erp.numbering import apply

		done = apply(self)
		self.save()
		return done

	@frappe.whitelist()
	def load_reference_register(self):
		"""Optional starting point: Brave Chemicals' IMS register (procedures, legal requirements, watch items)."""
		frappe.only_for(("System Manager", "Managing Director"))
		from chemical_erp.management_systems.install import ensure_setup

		return ensure_setup(first_install=True)
