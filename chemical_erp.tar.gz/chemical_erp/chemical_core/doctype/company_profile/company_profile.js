frappe.ui.form.on("Company Profile", {
	refresh(frm) {
		if (frm.is_new()) return;
		frm.add_custom_button(__("Apply Numbering"), () =>
			frappe.confirm(__("Set these prefixes and starting numbers? Documents already issued keep their numbers."), () =>
				frm.call({ doc: frm.doc, method: "apply_numbering", freeze: true }).then((r) => {
					frappe.msgprint({ title: __("Numbering applied"), message: __("Next documents:") + "<br>" + (r.message || []).join("<br>"), indicator: "green" });
					frm.reload_doc();
				})), __("Setup"));
		frm.add_custom_button(__("Apply Organisation"), () =>
			frappe.confirm(__("Create or update the departments and posts listed here, with their reporting lines?"), () =>
				frm.call({ doc: frm.doc, method: "apply_organisation", freeze: true }).then((r) => {
					frappe.show_alert({ message: __("{0} departments and {1} posts set up", [r.message.departments, r.message.posts]), indicator: "green" });
					frm.reload_doc();
				})), __("Organisation"));
		frm.add_custom_button(__("Organisation Chart"), () => frappe.set_route("query-report", "Company Organisation", { company: frm.doc.company }), __("Organisation"));
		frm.add_custom_button(__("Apply Brave Chemicals Defaults"), () =>
			frappe.confirm(__("Add Brave Chemicals' website scope, products, sectors and tender scope? Nothing already entered is overwritten."), () =>
				frappe.call({ method: "chemical_erp.setup.brave_defaults.apply_now", freeze: true }).then((r) => {
					frappe.show_alert({ message: r.message, indicator: "green" }); frm.reload_doc(); })), __("Setup"));
		frm.add_custom_button(__("Load Reference IMS Register"), () =>
			frappe.confirm(__("Load a starting IMS register (procedures, legal requirements and watch items) into empty tables? Existing records are never overwritten."), () =>
				frm.call({ doc: frm.doc, method: "load_reference_register", freeze: true }).then(() => frappe.show_alert({ message: __("Loaded"), indicator: "green" }))),
			__("Setup"));
	},
});
