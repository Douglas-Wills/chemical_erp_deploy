from frappe.model.document import Document


class CostElement(Document):
	pass
