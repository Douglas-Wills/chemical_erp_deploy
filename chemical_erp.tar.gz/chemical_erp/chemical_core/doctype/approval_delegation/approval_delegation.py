import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import now_datetime

from chemical_erp.controls import delegation
from chemical_erp.utils import MD_ROLE, has_role


class ApprovalDelegation(Document):
	def validate(self):
		delegation.validate_delegation(self)

	def on_update(self):
		delegation.sync_role(self.delegate)
		before = self.get_doc_before_save()
		if self.status in ("Active", "Scheduled") and (not before or before.status != self.status or before.valid_to != self.valid_to):
			from chemical_erp.utils import notify

			notify(self.delegate, self.doctype, self.name,
			       _("You will sign for the Managing Director from {0} to {1}. Approvals: /approvals").format(self.valid_from, self.valid_to),
			       priority="High")

	def onload(self):
		if not self.is_new() and frappe.get_meta("Approval Log").has_field("delegation"):
			rows = frappe.get_all("Approval Log", filters={"delegation": self.name}, fields=["parenttype", "parent", "action", "state", "on"],
			                      order_by="`on` desc", limit=200)
			self.set_onload("signed", rows)

	@frappe.whitelist()
	def revoke(self):
		if not has_role(MD_ROLE) and frappe.session.user != "Administrator":
			frappe.throw(_("Only the Managing Director can end a delegation."), frappe.PermissionError)
		self.status = "Revoked"
		self.revoked_on = now_datetime()
		self.save()
		return self.status
