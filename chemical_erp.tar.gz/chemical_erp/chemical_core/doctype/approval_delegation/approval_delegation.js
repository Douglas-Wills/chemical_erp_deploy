frappe.ui.form.on("Approval Delegation", {
	refresh(frm) {
		if (!frm.is_new() && ["Active", "Scheduled"].includes(frm.doc.status)) {
			frm.add_custom_button(__("End Now"), () =>
				frappe.confirm(__("Stop {0} signing for you from now?", [frm.doc.delegate_name || frm.doc.delegate]), () =>
					frm.call("revoke").then(() => frm.reload_doc())));
		}
		const rows = (frm.doc.__onload || {}).signed || [];
		const esc = frappe.utils.escape_html;
		const html = rows.length
			? `<table class="table table-sm"><tr><th>${__("Document")}</th><th>${__("Action")}</th><th>${__("New state")}</th><th>${__("When")}</th></tr>` +
			  rows.map((r) => `<tr><td><a href="/app/${frappe.router.slug(r.parenttype)}/${encodeURIComponent(r.parent)}">${esc(r.parenttype)} ${esc(r.parent)}</a></td>` +
				`<td>${esc(r.action)}</td><td>${esc(r.state)}</td><td>${frappe.datetime.str_to_user(r.on)}</td></tr>`).join("") + "</table>"
			: `<p class="text-muted">${__("Nothing signed under this delegation yet.")}</p>`;
		frm.get_field("signed_html").$wrapper.html(html);
	},
});
