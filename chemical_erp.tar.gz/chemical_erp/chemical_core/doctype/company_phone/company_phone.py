from frappe.model.document import Document


class CompanyPhone(Document):
	pass
