from frappe.model.document import Document


class PlannedCashItem(Document):
	pass
