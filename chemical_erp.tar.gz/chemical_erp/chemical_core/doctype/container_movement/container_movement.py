import frappe
from frappe import _
from frappe.model.document import Document


class ContainerMovement(Document):
	def validate(self):
		if not frappe.get_cached_value("Item", self.container_item, "is_returnable_container"):
			frappe.throw(_("{0} is not marked as a returnable container.").format(self.container_item))
		if self.direction in ("Returned", "Written Off"):
			held = balance(self.customer, self.container_item, exclude=self.name)
			if self.qty > held:
				frappe.throw(_("{0} holds only {1} of {2}.").format(self.customer, held, self.container_item))


def balance(customer, item, exclude=None):
	rows = frappe.get_all("Container Movement", filters={"customer": customer, "container_item": item, "name": ["!=", exclude or ""]},
	                      fields=["direction", "qty"])
	return sum(r.qty if r.direction == "Out" else -r.qty for r in rows)


def on_delivery(doc, method=None):
	"""Optional: only when the delivery note says these containers are to come back."""
	if doc.get("is_return") or not doc.get("containers_returnable"):
		return
	for row in doc.items:
		if frappe.get_cached_value("Item", row.item_code, "is_returnable_container"):
			frappe.get_doc({"doctype": "Container Movement", "customer": doc.customer, "container_item": row.item_code,
			                "direction": "Out", "qty": int(row.stock_qty or row.qty), "movement_date": doc.posting_date,
			                "delivery_note": doc.name,
			                "deposit_per_container": frappe.get_cached_value("Item", row.item_code, "container_deposit")}).insert(ignore_permissions=True)


def on_delivery_cancel(doc, method=None):
	frappe.db.delete("Container Movement", {"delivery_note": doc.name, "direction": "Out"})


def default_from_customer(doc, method=None):
	if doc.is_new() and doc.meta.has_field("containers_returnable") and doc.get("customer") and doc.get("containers_returnable") is None:
		doc.containers_returnable = frappe.db.get_value("Customer", doc.customer, "returns_containers") or 0
