from frappe.model.document import Document


class BusinessLine(Document):
	pass
