from frappe.model.document import Document


class WorkOrderMaterialCheck(Document):
	pass
