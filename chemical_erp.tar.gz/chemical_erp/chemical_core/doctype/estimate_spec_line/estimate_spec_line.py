from frappe.model.document import Document


class EstimateSpecLine(Document):
	pass
