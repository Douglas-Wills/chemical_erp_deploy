from frappe.model.document import Document


class BusinessLineGroup(Document):
	pass
