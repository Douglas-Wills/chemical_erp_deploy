from frappe.model.document import Document


class ProductionScheduleLine(Document):
	pass
