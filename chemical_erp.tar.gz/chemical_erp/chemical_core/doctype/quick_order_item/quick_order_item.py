from frappe.model.document import Document


class QuickOrderItem(Document):
	pass
