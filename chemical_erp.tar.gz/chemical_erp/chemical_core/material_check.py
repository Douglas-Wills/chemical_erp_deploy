"""Material availability for a manufacturing order (Work Order), and draft purchase orders for what is short.

Only released stock counts as available: stock in Quarantine has not passed QC (the warehouse QC zones guarantee that
released warehouses hold released batches only). Quarantined stock and open purchase orders are shown separately, so
the planner sees whether a shortage will clear by itself or needs ordering now.
"""

import math

import frappe
from frappe import _
from frappe.utils import add_days, cint, flt, getdate, now_datetime, nowdate

OPEN_WO = ("Not Started", "In Process")
OPEN_PO = ("To Receive and Bill", "To Receive")


def _zone_warehouses(zone):
	return frappe.get_all("Warehouse", filters={"qc_zone": zone, "is_group": 0, "disabled": 0}, pluck="name")


def _bin_qty(item, warehouses):
	if not warehouses:
		return 0.0
	return flt(frappe.db.sql("select sum(actual_qty) from `tabBin` where item_code = %s and warehouse in %s", (item, tuple(warehouses)))[0][0])


def _committed_elsewhere(item, wo_name):
	return flt(frappe.db.sql("""select sum(greatest(woi.required_qty - woi.transferred_qty, 0))
		from `tabWork Order Item` woi join `tabWork Order` wo on wo.name = woi.parent
		where woi.item_code = %s and wo.docstatus = 1 and wo.status in %s and wo.name != %s""", (item, OPEN_WO, wo_name or ""))[0][0])


def _on_order(item):
	row = frappe.db.sql("""select sum(greatest(poi.stock_qty - poi.received_qty * poi.conversion_factor, 0)), min(poi.schedule_date)
		from `tabPurchase Order Item` poi join `tabPurchase Order` po on po.name = poi.parent
		where poi.item_code = %s and po.docstatus = 1 and po.status in %s and poi.stock_qty > poi.received_qty * poi.conversion_factor""",
	                    (item, OPEN_PO))[0]
	return flt(row[0]), row[1]


def _supplier(item, company):
	"""Default supplier for the item, else the last one bought from; must be approved for chemicals."""
	default = frappe.db.get_value("Item Default", {"parent": item, "company": company}, "default_supplier")
	last = frappe.db.sql("""select po.supplier from `tabPurchase Order Item` poi join `tabPurchase Order` po on po.name = poi.parent
		where poi.item_code = %s and po.docstatus = 1 order by po.transaction_date desc limit 1""", item)
	for candidate, how in ((default, _("default supplier")), (last[0][0] if last else None, _("last supplier"))):
		if candidate:
			approved = frappe.db.get_value("Supplier", candidate, "is_approved_vendor")
			if approved or not frappe.get_cached_value("Item", item, "is_hazardous"):
				return candidate, how
			return None, _("{0} {1} is not approved: choose an approved supplier").format(how, candidate)
	return None, _("no supplier on record: choose one")


def round_to_pack(stock_qty, item):
	"""Whole purchase packs, at least the minimum order quantity. Returns (stock qty, purchase uom, purchase qty)."""
	it = frappe.get_cached_doc("Item", item)
	puom = it.purchase_uom or it.stock_uom
	factor = 1.0
	if puom != it.stock_uom:
		factor = flt(next((u.conversion_factor for u in it.uoms if u.uom == puom), 0)) or 1.0
	packs = math.ceil(round(flt(stock_qty) / factor, 6))
	if flt(it.min_order_qty):
		packs = max(packs, math.ceil(flt(it.min_order_qty) / factor))
	return packs * factor, puom, packs


def assess(wo):
	"""Fill wo.material_check and wo.material_status from current stock, other orders and open purchases."""
	needed_by = getdate(wo.planned_start_date) if wo.get("planned_start_date") else getdate(nowdate())
	released_wh, quarantine_wh = _zone_warehouses("Released"), _zone_warehouses("Quarantine")
	keep_po = {r.item_code: r.purchase_order for r in (wo.get("material_check") or []) if r.purchase_order}
	wo.set("material_check", [])
	worst = "All Available"
	rank = {"Available": 0, "Short: Awaiting QC Release": 1, "Short: On Order in Time": 1, "Short: On Order but Late": 2, "Order Now": 3}
	worst_rank = 0
	for req in wo.get("required_items") or []:
		need = max(flt(req.required_qty) - flt(req.transferred_qty), 0)
		if not need:
			continue
		item = req.item_code
		released = _bin_qty(item, released_wh)
		committed = _committed_elsewhere(item, wo.name)
		usable = max(released - committed, 0)
		shortage = max(need - usable, 0)
		quarantine = _bin_qty(item, quarantine_wh)
		on_order, eta = _on_order(item)
		row = {"item_code": item, "required_qty": need, "stock_uom": frappe.get_cached_value("Item", item, "stock_uom"),
		       "released_qty": released, "committed_qty": committed, "quarantine_qty": quarantine, "on_order_qty": on_order,
		       "on_order_eta": eta, "shortage_qty": shortage, "purchase_order": keep_po.get(item)}
		if not shortage:
			row["status"] = "Available"
		elif shortage <= quarantine:
			row["status"] = "Short: Awaiting QC Release"
		elif shortage <= quarantine + on_order:
			row["status"] = "Short: On Order in Time" if not eta or getdate(eta) <= needed_by else "Short: On Order but Late"
		else:
			row["status"] = "Order Now"
			to_buy = shortage - quarantine - on_order
			stock_qty, puom, packs = round_to_pack(to_buy, item)
			supplier, how = _supplier(item, wo.company)
			lead = cint(frappe.get_cached_value("Item", item, "lead_time_days"))
			rate = flt(frappe.get_cached_value("Item", item, "last_purchase_rate"))
			row.update({"suggested_qty": stock_qty, "purchase_uom": puom, "purchase_qty": packs, "supplier": supplier,
			            "supplier_note": how if not supplier or how != _("default supplier") else "",
			            "rate": rate, "amount": rate * stock_qty, "lead_time_days": lead,
			            "expected_arrival": add_days(nowdate(), lead) if lead else None})
			if lead and getdate(row["expected_arrival"]) > needed_by:
				late = _("Even ordered today it arrives {0}, after the planned start {1}: reschedule or find a faster supplier.").format(
					row["expected_arrival"], needed_by)
				row["supplier_note"] = f"{row['supplier_note']}; {late}" if row["supplier_note"] else late
		if rank[row["status"]] > worst_rank:
			worst_rank, worst = rank[row["status"]], {1: "Shortages Covered", 2: "Late Supplies", 3: "Order Needed"}[rank[row["status"]]]
		wo.append("material_check", row)
	wo.material_status = worst if wo.get("required_items") else None
	wo.material_checked_on = now_datetime()
	return wo.material_status


def persist(wo):
	"""Write the check onto a submitted order: replace its rows, keep the header fields."""
	frappe.db.delete("Work Order Material Check", {"parent": wo.name, "parenttype": "Work Order"})
	for i, row in enumerate(wo.material_check, 1):
		row.name = frappe.generate_hash(length=10)
		row.idx = i
		row.parent, row.parenttype, row.parentfield = wo.name, "Work Order", "material_check"
		row.db_insert()
	wo.db_set({"material_status": wo.material_status, "material_checked_on": wo.material_checked_on}, update_modified=False)


def on_validate(doc, method=None):
	if doc.docstatus == 0 and doc.get("required_items"):
		assess(doc)


def on_submit(doc, method=None):
	status = assess(doc)
	persist(doc)
	if status in ("Order Needed", "Late Supplies"):
		from chemical_erp.utils import notify, users_with_role

		short = [r.item_code for r in doc.material_check if r.status in ("Order Now", "Short: On Order but Late")]
		notify(users_with_role("Purchase User") + users_with_role("Purchase Manager") + users_with_role("Manufacturing Manager"),
		       "Work Order", doc.name, _("Manufacturing order {0} ({1}) is short of: {2}").format(doc.name, doc.production_item, ", ".join(short)),
		       priority="High")


@frappe.whitelist()
def check(work_order):
	wo = frappe.get_doc("Work Order", work_order)
	wo.check_permission("read")
	assess(wo)
	if wo.docstatus == 1:
		persist(wo)
	else:
		wo.save()
	return {"status": wo.material_status, "rows": [r.as_dict() for r in wo.material_check]}


@frappe.whitelist()
def create_purchase_orders(work_order):
	"""Draft purchase orders, one per supplier, for every 'Order Now' line not yet ordered. They follow the normal approvals."""
	wo = frappe.get_doc("Work Order", work_order)
	wo.check_permission("read")
	assess(wo)
	lines = [r for r in wo.material_check if r.status == "Order Now" and not r.purchase_order]
	missing = [r.item_code for r in lines if not r.supplier]
	if missing:
		frappe.throw(_("Choose an approved supplier first for: {0}").format(", ".join(missing)), title=_("Supplier needed"))
	if not lines:
		frappe.throw(_("Nothing needs ordering for {0}.").format(wo.name))
	from chemical_erp.utils import get_settings

	warehouse = get_settings().get("quarantine_raw_warehouse")
	needed_by = getdate(wo.planned_start_date) if wo.get("planned_start_date") else add_days(nowdate(), 7)
	made = []
	for supplier in sorted({r.supplier for r in lines}):
		po = frappe.new_doc("Purchase Order")
		po.update({"supplier": supplier, "company": wo.company, "transaction_date": nowdate(),
		           "schedule_date": max(needed_by, getdate(add_days(nowdate(), 1))), "set_warehouse": warehouse,
		           "for_work_order": wo.name})
		for r in [x for x in lines if x.supplier == supplier]:
			po.append("items", {"item_code": r.item_code, "qty": r.purchase_qty, "uom": r.purchase_uom,
			                    "schedule_date": po.schedule_date, "warehouse": warehouse,
			                    "description": _("For manufacturing order {0}").format(wo.name)})
		po.set_missing_values()
		po.insert()  # draft; the 72-hour receipt rule and approved-supplier rule apply as usual
		made.append(po.name)
		for r in wo.material_check:
			if r.supplier == supplier and r.status == "Order Now":
				r.purchase_order = po.name
	if wo.docstatus == 1:
		persist(wo)
	else:
		wo.save()
	return made


def daily_recheck():
	"""Re-check manufacturing orders not yet started; alert procurement when a new shortage appears."""
	from chemical_erp.utils import notify, users_with_role

	for name in frappe.get_all("Work Order", filters={"docstatus": 1, "status": "Not Started"}, pluck="name"):
		wo = frappe.get_doc("Work Order", name)
		before = wo.get("material_status")
		try:
			check(name)
		except Exception:
			frappe.log_error(title=f"Material check failed for {name}", message=frappe.get_traceback())
			continue
		after = frappe.db.get_value("Work Order", name, "material_status")
		if after in ("Order Needed", "Late Supplies") and after != before:
			notify(users_with_role("Purchase User") + users_with_role("Manufacturing Manager"), "Work Order", name,
			       _("Manufacturing order {0}: materials now {1}").format(name, after.lower()))
