"""Quick orders for consumer products (Brave Home): the /quick-order page, WhatsApp messages and phone orders.

- parse(): reads an order written in plain words ("2 x 5L SudsWave, flushforce 3") into product lines.
- place_order(): the public /quick-order page (no login needed; rate-limited).
- whatsapp_webhook(): WhatsApp Business (Cloud API) messages become Quick Orders when the number is connected.
- Every Quick Order is checked by Sales and turned into a Sales Order with one click.
"""

import difflib
import hashlib
import hmac
import json
import re

import frappe
from frappe import _
from frappe.rate_limiter import rate_limit
from frappe.utils import cint, flt, now_datetime

from chemical_erp.utils import get_settings

SIZE = re.compile(r"(\d+(?:[.,]\d+)?)\s*(ml|millilit(?:re|er)s?|l|lt|ltr|ltrs|lit(?:re|er)s?)\b", re.I)
QTY_PATTERNS = [re.compile(p, re.I) for p in (
	r"\bx\s*(\d+)\b", r"\b(\d+)\s*x\b", r"\b(\d+)\s*(?:pcs|pieces|units|bottles|btls?|jerry\s*cans?|jerrycans?|cartons?|boxes|tins?|sachets?|packs?|dozens?)\b",
	r"\bqty\s*[:=]?\s*(\d+)\b", r"\b(\d+)\s*(?:of)\b", r"^\s*(\d+)\b", r"\b(\d+)\s+(?=[a-z])", r"\b(\d+)\s*$")]
SPLIT = re.compile(r"[\n;,+&]|\band\b|\bplus\b", re.I)
WORD = re.compile(r"[a-z0-9]+")
COURTESY = re.compile(r"^(?:hi|hello|hey|dear|good\s+(?:morning|afternoon|evening)|please|pls|kindly|thanks|thank\s+you|"
                      r"i\s+(?:need|want|would\s+like)|we\s+(?:need|want)|send(?:\s+me)?|order|can\s+i\s+get)\b", re.I)
INFO = re.compile(r"^(?:deliver|delivery|location|address|pay|payment|cash|mobile\s+money|momo|name|my\s+name|call|thanks|thank)\b", re.I)


def normalise_phone(phone):
	"""Uganda numbers to 2567XXXXXXXX; others digits only."""
	digits = re.sub(r"\D", "", phone or "")
	if digits.startswith("00"):
		digits = digits[2:]
	if len(digits) == 10 and digits.startswith("0"):
		digits = "256" + digits[1:]
	if len(digits) == 9 and digits[0] in "37":
		digits = "256" + digits
	return digits


def item_group():
	return get_settings().get("quick_order_item_group") or ("Brave Home" if frappe.db.exists("Item Group", "Brave Home") else None)


def catalogue(group=None):
	"""[{item_code, item_name, stock_uom, uoms: {litres: uom}}] for the offered item group (and its sub-groups)."""
	group = group or item_group()
	if not group or not frappe.db.exists("Item Group", group):
		return []
	lft, rgt = frappe.db.get_value("Item Group", group, ["lft", "rgt"])
	groups = frappe.get_all("Item Group", filters={"lft": [">=", lft], "rgt": ["<=", rgt]}, pluck="name")
	items = frappe.get_all("Item", filters={"item_group": ["in", groups], "disabled": 0, "is_sales_item": 1, "has_variants": 0},
	                       fields=["item_code", "item_name", "stock_uom", "description"], order_by="item_name")
	for it in items:
		it.uoms = {flt(r.conversion_factor): r.uom for r in frappe.get_all("UOM Conversion Detail", filters={"parent": it.item_code},
		                                                                     fields=["uom", "conversion_factor"])}
	return items


def aliases(items):
	"""{alias: item_code}. Full name, item code without prefix, and the first word of the brand when it is unique."""
	out, first = {}, {}
	for it in items:
		name = it.item_name.lower()
		out[name] = it.item_code
		out[re.sub(r"\(.*?\)", "", name).strip()] = it.item_code
		code = it.item_code.lower().split("-", 1)[-1]
		if len(code) >= 4:
			out[code] = it.item_code
		w = WORD.findall(name)
		if w and len(w[0]) >= 4:
			first.setdefault(w[0], set()).add(it.item_code)
	for word, codes in first.items():
		if len(codes) == 1:
			out.setdefault(word, next(iter(codes)))
	return out


def _match(segment, alias_map):
	text = " ".join(WORD.findall(segment.lower()))
	best = None
	for alias, code in alias_map.items():
		a = " ".join(WORD.findall(alias))
		if a and re.search(rf"\b{re.escape(a)}\b", text) and (not best or len(a) > len(best[0])):
			best = (a, code)
	if best:
		return best[1]
	words = [w for w in WORD.findall(text) if len(w) >= 5 and not w.isdigit()]
	keys = [k for k in alias_map if " " not in k]
	for w in words:  # typing slips: "sudswav", "flushforse"
		close = difflib.get_close_matches(w, keys, n=1, cutoff=0.8)
		if close:
			return alias_map[close[0]]
	return None


def _litres(segment):
	m = SIZE.search(segment)
	if not m:
		return None, segment
	value = flt(m.group(1).replace(",", "."))
	if m.group(2).lower().startswith("m"):
		value = value / 1000
	return value, segment[:m.start()] + " " + segment[m.end():]


def _qty(segment):
	for p in QTY_PATTERNS:
		m = p.search(segment)
		if m and 0 < cint(m.group(1)) <= 1000:
			return cint(m.group(1))
	return 1


def parse(text, items=None):
	"""Returns (rows, unmatched): rows of {item_code, item_name, qty, uom, note}."""
	items = items if items is not None else catalogue()
	by_code = {it.item_code: it for it in items}
	alias_map = aliases(items)
	rows, unmatched = [], []
	for segment in SPLIT.split(text or ""):
		segment = segment.strip(" .:-\t")
		while True:  # drop courtesy words ("please send", "I want"): the order is what is left
			shorter = COURTESY.sub("", segment, count=1).strip(" ,.:-\t")
			if shorter == segment:
				break
			segment = shorter
		if not segment or len(segment) < 3:
			continue
		code = _match(segment, alias_map)
		if not code:
			if re.search(r"[a-z]{3,}", segment, re.I) and not INFO.match(segment):
				unmatched.append(segment)
			continue
		it = by_code[code]
		litres, rest = _litres(segment)
		count = _qty(rest)
		row = {"item_code": code, "item_name": it.item_name, "qty": count, "uom": it.stock_uom, "note": ""}
		if litres:
			pack = next((u for f, u in (it.uoms or {}).items() if abs(f - litres) < 1e-6), None)
			if pack:
				row["uom"] = pack
			elif (it.stock_uom or "").lower().startswith("l"):
				row["qty"] = count * litres
				row["note"] = f"{count} × {litres:g} L"
		same = next((r for r in rows if r["item_code"] == code and r["uom"] == row["uom"]), None)
		if same:
			same["qty"] += row["qty"]
		else:
			rows.append(row)
	return rows, unmatched


# ---------------------------------------------------------------- prices and customers
def price_list_for(customer=None, customer_group=None):
	if customer:
		pl = frappe.db.get_value("Customer", customer, "default_price_list")
		if pl:
			return pl
		customer_group = customer_group or frappe.db.get_value("Customer", customer, "customer_group")
	if customer_group:
		pl = frappe.db.get_value("Customer Group", customer_group, "default_price_list")
		if pl:
			return pl
	return get_settings().get("quick_order_price_list") or frappe.db.get_single_value("Selling Settings", "selling_price_list") or "Standard Selling"


def price(item_code, uom, price_list):
	rows = frappe.get_all("Item Price", filters={"price_list": price_list, "item_code": item_code, "selling": 1},
	                      fields=["uom", "price_list_rate"], order_by="valid_from desc")
	exact = next((r for r in rows if r.uom == uom), None)
	if exact:
		return flt(exact.price_list_rate)
	stock = frappe.get_cached_value("Item", item_code, "stock_uom")
	base = next((r for r in rows if r.uom in (stock, None, "")), None)
	if base:
		factor = flt(frappe.db.get_value("UOM Conversion Detail", {"parent": item_code, "uom": uom}, "conversion_factor")) or 1
		return flt(base.price_list_rate) * factor
	return 0.0


def customer_by_phone(phone):
	digits = normalise_phone(phone)
	if len(digits) < 9:
		return None
	tail = digits[-9:]
	name = frappe.db.get_value("Customer", {"mobile_no": ["like", f"%{tail}"], "disabled": 0}, "name")
	if name:
		return name
	for parent in frappe.get_all("Contact Phone", filters={"phone": ["like", f"%{tail}"]}, pluck="parent"):
		link = frappe.db.get_value("Dynamic Link", {"parent": parent, "parenttype": "Contact", "link_doctype": "Customer"}, "link_name")
		if link:
			return link
	return None


def notify_sales(order):
	from chemical_erp.utils import notify, users_with_role

	role = get_settings().get("quick_order_notify_role") or "Sales User"
	notify(users_with_role(role), "Quick Order", order.name,
	       _("New {0} order {1} from {2} ({3}): {4}").format(order.channel, order.name, order.customer_name, order.phone,
	                                                     frappe.format_value(order.total, {"fieldtype": "Currency"})), priority="High")


# ---------------------------------------------------------------- the public order page
@frappe.whitelist(allow_guest=True, methods=["POST"])
@rate_limit(limit=6, seconds=60 * 60)
def place_order(customer_name, phone, items, delivery_location=None, payment_method=None, note=None, website=None):
	if website:  # hidden field: only robots fill it
		return {"name": None}
	phone = normalise_phone(phone)
	if len(phone) < 11:
		frappe.throw(_("Please give a phone number we can call, e.g. 0772 123456."))
	customer_name = (customer_name or "").strip()[:140]
	if len(customer_name) < 2:
		frappe.throw(_("Please give your name."))
	if isinstance(items, str):
		items = json.loads(items)
	offered = {it.item_code: it for it in catalogue()}
	lines = []
	for row in (items or [])[:30]:
		code, qty = row.get("item_code"), cint(row.get("qty"))
		if code in offered and 0 < qty <= 500:
			uom = row.get("uom") if row.get("uom") in list(offered[code].uoms.values()) + [offered[code].stock_uom] else offered[code].stock_uom
			lines.append({"item_code": code, "qty": qty, "uom": uom})
	if not lines:
		frappe.throw(_("Choose at least one product."))
	customer = None
	from chemical_erp.portal import customers_for

	if frappe.session.user != "Guest":
		mine = customers_for()
		customer = mine[0] if mine else None
	order = frappe.get_doc({"doctype": "Quick Order", "channel": "Order Page", "received_on": now_datetime(), "customer_name": customer_name,
	                        "phone": phone, "customer": customer, "items": lines, "delivery_location": (delivery_location or "")[:500],
	                        "payment_method": payment_method if payment_method in ("Cash on Delivery", "Mobile Money", "Bank Transfer") else "Cash on Delivery",
	                        "notes": (note or "")[:500]})
	order.insert(ignore_permissions=True)
	notify_sales(order)
	return {"name": order.name, "total": order.total}


@frappe.whitelist(allow_guest=True)
def page_data():
	"""Products and prices for the /quick-order page."""
	pl = price_list_for(customer_group=get_settings().get("quick_order_customer_group"))
	out = []
	for it in catalogue():
		units = [{"uom": it.stock_uom, "rate": price(it.item_code, it.stock_uom, pl)}]
		for factor, uom in sorted((it.uoms or {}).items()):
			if uom != it.stock_uom:
				units.append({"uom": uom, "rate": price(it.item_code, uom, pl)})
		out.append({"item_code": it.item_code, "item_name": it.item_name, "description": frappe.utils.strip_html(it.description or "")[:160],
		            "units": units})
	return {"items": out, "whatsapp": get_settings().get("whatsapp_order_number") or ""}


# ---------------------------------------------------------------- WhatsApp Business (Cloud API)
@frappe.whitelist(allow_guest=True, methods=["GET", "POST"])
def whatsapp_webhook():
	from werkzeug.wrappers import Response

	s = get_settings()
	if frappe.request.method == "GET":  # Meta's one-time verification
		args = frappe.request.args
		token = s.get("whatsapp_verify_token")
		if token and args.get("hub.mode") == "subscribe" and hmac.compare_digest(args.get("hub.verify_token") or "", token):
			return Response(args.get("hub.challenge") or "", mimetype="text/plain")
		return Response("forbidden", status=403, mimetype="text/plain")
	secret = s.get_password("whatsapp_app_secret", raise_exception=False) if s.get("whatsapp_app_secret") else None
	raw = frappe.request.get_data() or b""
	sent = (frappe.request.headers.get("X-Hub-Signature-256") or "").replace("sha256=", "")
	if not secret or not hmac.compare_digest(hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest(), sent):
		return Response("bad signature", status=403, mimetype="text/plain")
	made = from_whatsapp(json.loads(raw or b"{}"))
	frappe.db.commit()
	return Response(json.dumps({"orders": made}), mimetype="application/json")


def from_whatsapp(payload):
	made = []
	items = catalogue()
	for entry in payload.get("entry") or []:
		for change in entry.get("changes") or []:
			value = change.get("value") or {}
			names = {c.get("wa_id"): (c.get("profile") or {}).get("name") for c in value.get("contacts") or []}
			for m in value.get("messages") or []:
				if m.get("type") != "text" or not m.get("id"):
					continue
				if frappe.db.exists("Quick Order", {"whatsapp_message_id": m["id"]}):
					continue
				body = ((m.get("text") or {}).get("body") or "")[:2000]
				rows, unmatched = parse(body, items)
				phone = normalise_phone(m.get("from"))
				order = frappe.get_doc({"doctype": "Quick Order", "channel": "WhatsApp", "received_on": now_datetime(),
				                        "customer_name": names.get(m.get("from")) or phone, "phone": phone, "message": body,
				                        "whatsapp_message_id": m["id"], "unmatched": "\n".join(unmatched),
				                        "items": [{k: r[k] for k in ("item_code", "qty", "uom")} for r in rows]})
				order.insert(ignore_permissions=True)
				notify_sales(order)
				made.append(order.name)
	return made
