"""Product costing.

`calculate(sheet)` is plain arithmetic on the cost sheet. `load_materials` and `default_rate` read
prices from ERPNext. Material cost comes from the approved formula; every other cost is a Cost
Element whose rate and basis can be changed at any time.
"""

import frappe
from frappe.utils import flt

DRIVERS = {
	"Per kg of output": lambda s, mat: flt(s.batch_size),
	"Per batch": lambda s, mat: 1.0,
	"Per pack": lambda s, mat: flt(s.packs_per_batch),
	"Per labour hour": lambda s, mat: 1.0,              # hours are entered as the line quantity
	"% of material cost": lambda s, mat: mat / 100.0,
	"Per month (spread over volume)": lambda s, mat: (flt(s.batch_size) / flt(s.monthly_volume_kg)) if flt(s.monthly_volume_kg) else 0.0,
}
BUCKET = {"Labour": "labour_cost", "Packaging": "packaging_cost", "Utilities": "overhead_cost",
          "Production Overheads": "overhead_cost"}


def calculate(s):
	s.packs_per_batch = flt(s.batch_size) / flt(s.pack_size) if flt(s.pack_size) else 0
	raw = pack = 0.0
	for m in s.materials:
		m.amount = flt(flt(m.qty) * flt(m.rate), 2)
		if m.is_packaging:
			pack += m.amount
		else:
			raw += m.amount
	totals = {"labour_cost": 0.0, "packaging_cost": pack, "overhead_cost": 0.0, "other_cost": 0.0}
	for line in s.cost_lines:
		driver = DRIVERS.get(line.basis, lambda s, mat: 0.0)(s, raw)
		qty = flt(line.quantity) if line.quantity not in (None, "") else 1.0
		line.amount = flt(flt(line.rate) * driver * qty, 2)
		totals[BUCKET.get(line.category, "other_cost")] += line.amount
	s.material_cost = flt(raw, 2)
	for k, v in totals.items():
		setattr(s, k, flt(v, 2))
	s.total_batch_cost = flt(raw + sum(totals.values()) + flt(s.disposal_cost) - flt(s.co_product_credit), 2)
	s.cost_per_kg = flt(s.total_batch_cost / flt(s.batch_size), 4) if flt(s.batch_size) else 0
	s.cost_per_pack = flt(s.cost_per_kg * flt(s.pack_size), 2) if flt(s.pack_size) else 0
	margin = flt(s.target_margin)
	s.suggested_price_per_kg = flt(s.cost_per_kg / (1 - margin / 100.0), 2) if margin < 100 else 0
	s.suggested_price_per_pack = flt(s.suggested_price_per_kg * flt(s.pack_size), 2) if flt(s.pack_size) else 0
	price = flt(s.current_price_per_kg)
	s.current_margin = flt((price - s.cost_per_kg) / price * 100, 2) if price else 0
	return s


# ------------------------------------------------------------------ prices from ERPNext
def is_packaging(item_code):
	import frappe

	group = (frappe.get_cached_value("Item", item_code, "item_group") or "").lower()
	return item_code.upper().startswith("PK-") or "packag" in group


def material_rate(item_code, basis, price_list=None):
	"""Unit cost of a material; a sub-formula (premix, intermediate) is costed at its own formula's cost."""
	import frappe

	sub_bom = frappe.db.get_value("BOM", {"item": item_code, "is_default": 1, "is_active": 1, "docstatus": 1},
	                              ["total_cost", "quantity"], as_dict=True)
	if sub_bom and flt(sub_bom.quantity):
		return flt(sub_bom.total_cost) / flt(sub_bom.quantity), "Sub-formula cost"
	if basis == "Last Purchase Rate":
		rate = flt(frappe.db.get_value("Item", item_code, "last_purchase_rate"))
		if rate:
			return rate, "Last purchase"
	if basis == "Buying Price List" and price_list:
		rate = flt(frappe.db.get_value("Item Price", {"item_code": item_code, "price_list": price_list}, "price_list_rate"))
		if rate:
			from chemical_erp.utils import exchange_rate

			currency = frappe.db.get_value("Price List", price_list, "currency")
			return rate * exchange_rate(currency), f"{price_list} ({currency})"
	rate = flt(frappe.db.get_value("Item", item_code, "valuation_rate"))
	if not rate:
		rows = frappe.db.sql("""select sum(stock_value)/nullif(sum(actual_qty),0) from `tabBin` where item_code=%s""", item_code)
		rate = flt(rows[0][0]) if rows else 0
	return rate, ("Valuation" if rate else "No price found")


def load_materials(s):
	import frappe

	bom = frappe.get_doc("BOM", s.bom)
	scale = flt(s.batch_size) / flt(bom.quantity) if flt(bom.quantity) else 1
	s.set("materials", [])
	for row in bom.items:
		rate, source = material_rate(row.item_code, s.price_basis, s.buying_price_list)
		s.append("materials", {"item_code": row.item_code, "item_name": row.item_name, "qty": flt(row.stock_qty) * scale,
		                       "uom": row.stock_uom, "rate": rate, "rate_source": source, "is_packaging": int(is_packaging(row.item_code))})
	s.disposal_cost = flt(bom.get("expected_disposal_cost")) * scale
	s.co_product_credit = sum(flt(r.stock_qty) * flt(r.rate) for r in bom.get("scrap_items") or [] if r.get("is_co_product")) * scale


def element_rate(element):
	import frappe

	e = frappe.get_cached_doc("Cost Element", element)
	if e.item:
		return flt(frappe.db.get_value("Item", e.item, "valuation_rate")) or flt(e.default_rate)
	return flt(e.default_rate)


# ------------------------------------------------------------------ the BOM's Product Costing tab
def bom_costing(bom, method=None):
	"""Cost per batch, per kg and per pack on the formula itself: materials from the BOM plus every cost item."""
	import frappe

	if bom.is_new() and not bom.get("costing_lines"):
		for e in frappe.get_all("Cost Element", filters={"active": 1}, fields=["name", "default_quantity"], order_by="category, name"):
			bom.append("costing_lines", {"cost_element": e.name, "rate": element_rate(e.name), "quantity": e.default_quantity or 1})
	raw = pack = 0.0
	for r in bom.get("items") or []:
		amount = flt(r.get("base_amount") or r.get("amount"))
		if is_packaging(r.item_code):
			pack += amount
		else:
			raw += amount
	batch = flt(bom.quantity) or 1
	shim = frappe._dict(batch_size=batch, pack_size=flt(bom.get("cost_pack_size")),
	                    monthly_volume_kg=flt(bom.get("cost_monthly_volume")))
	shim.packs_per_batch = batch / shim.pack_size if shim.pack_size else 0
	buckets = {"labour": 0.0, "packaging": pack, "utilities": 0.0, "other": flt(bom.get("operating_cost"))}
	where = {"Labour": "labour", "Packaging": "packaging", "Utilities": "utilities", "Production Overheads": "utilities"}
	for line in bom.get("costing_lines") or []:
		if not line.basis or not line.category:
			line.basis, line.category = frappe.db.get_value("Cost Element", line.cost_element, ["basis", "category"]) or (None, None)
		driver = DRIVERS.get(line.basis, lambda s, m: 0.0)(shim, raw)
		qty = flt(line.quantity) if line.quantity not in (None, "") else 1.0
		line.amount = flt(flt(line.rate) * driver * qty, 2)
		buckets[where.get(line.category, "other")] += line.amount
	credit = sum(flt(r.stock_qty) * flt(r.rate) for r in bom.get("scrap_items") or [] if r.get("is_co_product"))
	disposal = flt(bom.get("expected_disposal_cost"))
	total = raw + sum(buckets.values()) + disposal - credit
	per_kg = total / batch
	margin = flt(bom.get("cost_target_margin") or 30)
	values = {"cost_materials": raw, "cost_packaging": buckets["packaging"], "cost_labour": buckets["labour"],
	          "cost_utilities": buckets["utilities"], "cost_other": buckets["other"], "cost_disposal": disposal,
	          "cost_coproduct_credit": credit, "cost_total_batch": total, "cost_per_kg": per_kg,
	          "cost_per_pack": per_kg * shim.pack_size if shim.pack_size else 0,
	          "cost_suggested_price_kg": per_kg / (1 - margin / 100) if margin < 100 else 0}
	values["cost_suggested_price_pack"] = values["cost_suggested_price_kg"] * shim.pack_size if shim.pack_size else 0
	for k, v in values.items():
		setattr(bom, k, flt(v, 2))
	return values


@frappe.whitelist()
def make_standard_cost_sheet(bom):
	"""Turn the formula's costing tab into the product's standard cost (used for stock value and price floors)."""
	import frappe
	from frappe import _

	b = frappe.get_doc("BOM", bom)
	b.check_permission("read")
	sheet = frappe.get_doc({"doctype": "Product Cost Sheet", "item_code": b.item, "bom": b.name, "batch_size": b.quantity,
	                        "pack_size": b.get("cost_pack_size"), "monthly_volume_kg": b.get("cost_monthly_volume"),
	                        "target_margin": b.get("cost_target_margin") or 30,
	                        "cost_lines": [{"cost_element": l.cost_element, "rate": l.rate, "quantity": l.quantity, "notes": l.notes}
	                                       for l in b.get("costing_lines") or []]})
	sheet.insert()
	try:
		sheet.make_current()
	except frappe.PermissionError:
		frappe.msgprint(_("Cost sheet {0} created. The MD or Accounts Manager makes it the standard cost.").format(sheet.name), indicator="orange")
	b.db_set("cost_standard_sheet", sheet.name)
	return sheet.name
