"""Customer portal: customers download the COA for each batch delivered to them and the current SDS for each product.
Access is checked here against the deliveries themselves, so a customer only ever sees their own batches."""

import frappe
from frappe import _
from frappe.utils import add_months, today


def customers_for(user=None):
	user = user or frappe.session.user
	if user == "Guest":
		return []
	contacts = frappe.get_all("Contact", filters={"user": user}, pluck="name")
	if not contacts:
		return []
	return list(set(frappe.get_all("Dynamic Link", filters={"parenttype": "Contact", "parent": ["in", contacts], "link_doctype": "Customer"},
	                               pluck="link_name")))


def deliveries(customers, months=24):
	if not customers:
		return []
	return frappe.db.sql("""select dn.name, dn.posting_date, dn.customer, dni.item_code, dni.item_name, dni.batch_no, dni.qty, dni.uom, dni.sds_file
		from `tabDelivery Note` dn join `tabDelivery Note Item` dni on dni.parent = dn.name
		where dn.docstatus = 1 and dn.is_return = 0 and dn.customer in %(c)s and dn.posting_date >= %(since)s
		order by dn.posting_date desc, dn.name desc""", {"c": tuple(customers), "since": add_months(today(), -months)}, as_dict=True)


def _check_batch(batch):
	customers = customers_for()
	ok = frappe.db.sql("""select 1 from `tabDelivery Note Item` dni join `tabDelivery Note` dn on dn.name = dni.parent
		where dn.docstatus = 1 and dni.batch_no = %s and dn.customer in %s limit 1""", (batch, tuple(customers or [""])))
	if not ok and "System Manager" not in frappe.get_roles():
		raise frappe.PermissionError(_("This batch was not delivered to you."))


def _send(filename, content, content_type="application/pdf"):
	frappe.local.response.filename = filename
	frappe.local.response.filecontent = content
	frappe.local.response.type = "download"


@frappe.whitelist()
def download_coa(batch):
	_check_batch(batch)
	qi = frappe.db.get_value("Batch", batch, "accepted_inspection")
	if not qi:
		frappe.throw(_("No certificate of analysis has been issued for batch {0} yet.").format(batch))
	user = frappe.session.user
	try:
		frappe.set_user("Administrator")  # access was checked above against the customer's own deliveries
		pdf = frappe.get_print("Quality Inspection", qi, "Certificate of Analysis", as_pdf=True)
	finally:
		frappe.set_user(user)
	_send(f"COA {batch}.pdf", pdf)


@frappe.whitelist()
def download_sds(item_code):
	customers = customers_for()
	bought = frappe.db.sql("""select 1 from `tabDelivery Note Item` dni join `tabDelivery Note` dn on dn.name = dni.parent
		where dn.docstatus = 1 and dni.item_code = %s and dn.customer in %s limit 1""", (item_code, tuple(customers or [""])))
	if not bought and "System Manager" not in frappe.get_roles():
		raise frappe.PermissionError(_("You have not bought this product."))
	from chemical_erp.utils import current_sds

	sds = current_sds(item_code)
	if not sds:
		from chemical_erp.company import company_name

		frappe.throw(_("No current SDS is available for {0}; please contact {1}.").format(item_code, company_name(short=True)))
	url = frappe.db.get_value("SDS File", sds, "file")
	f = frappe.get_doc("File", {"file_url": url})
	_send(f"SDS {item_code}.pdf", f.get_content())
