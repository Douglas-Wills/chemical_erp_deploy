# Web view controller for secure shared document access
import frappe
from frappe import _
from frappe.utils import format_datetime, now_datetime
from chemical_erp.documents.sharing import _log_access_dict

no_cache = 1


def get_context(context):
	context.no_cache = 1
	token = frappe.form_dict.get("token") or context.get("token")
	if not token and hasattr(frappe.local, "request") and frappe.local.request:
		path_parts = frappe.local.request.path.strip("/").split("/")
		if len(path_parts) > 1 and path_parts[0] in ("shared-doc", "doc-preview"):
			token = path_parts[1]

	if not token:
		context.error_title = _("Invalid Request")
		context.error_message = _("No document access token was provided in the URL.")
		return context

	context.token = token
	link = frappe.db.get_value(
		"Document Share Link",
		{"token": token},
		["name", "document", "document_title", "recipient_name", "expires_at", "status", "allow_download", "require_passcode", "passcode", "max_downloads", "download_count", "is_revoked", "view_count"],
		as_dict=True
	)

	if not link:
		context.error_title = _("Document Not Found")
		context.error_message = _("The requested shared document does not exist, or the link is invalid.")
		return context

	# 1. Revocation check
	if link.is_revoked:
		context.error_title = _("Access Revoked")
		context.error_message = _("This document share link has been revoked by an administrator.")
		_log_access_dict(link, "Blocked Revoked", "Blocked", "Revoked link visited")
		return context

	# 2. Expiration check
	now = now_datetime()
	if link.expires_at and now > link.expires_at:
		frappe.db.set_value("Document Share Link", link.name, "status", "Expired")
		frappe.db.commit()
		context.error_title = _("Access Expired")
		context.error_message = _("The set access duration for this document has expired ({0}). You no longer have access to this document.").format(
			format_datetime(link.expires_at, "dd-MM-yyyy HH:mm")
		)
		_log_access_dict(link, "Blocked Expired", "Blocked", "Expired link visited")
		return context

	# 3. Global settings check
	settings = frappe.get_single("Document Sharing Settings")
	if not settings.enable_document_sharing:
		context.error_title = _("Sharing Disabled")
		context.error_message = _("Document sharing is currently disabled by the system administrator.")
		return context

	# 4. Passcode / PIN check
	if link.require_passcode and link.passcode:
		submitted_pass = frappe.form_dict.get("passcode")
		session_key = f"doc_auth_{token}"
		authenticated = frappe.local.session.data.get(session_key) if hasattr(frappe.local, "session") else False

		if not authenticated:
			if submitted_pass:
				if submitted_pass.strip() == link.passcode.strip():
					if hasattr(frappe.local, "session"):
						frappe.local.session.data[session_key] = 1
					_log_access_dict(link, "Passcode Verified", "Allowed", "Passcode correctly entered")
				else:
					context.requires_passcode = True
					context.passcode_error = _("Incorrect passcode / PIN. Please try again.")
					_log_access_dict(link, "Passcode Failed", "Blocked", "Incorrect passcode entered")
					return context
			else:
				context.requires_passcode = True
				return context

	# 5. Load document file
	if not frappe.db.exists("Chemical Document", link.document):
		context.error_title = _("File Missing")
		context.error_message = _("The source document record was not found.")
		return context

	doc = frappe.get_doc("Chemical Document", link.document)
	if not doc.attached_document:
		context.error_title = _("No File Attached")
		context.error_message = _("This document has no uploaded file attachment.")
		return context

	# Increment view count
	frappe.db.sql(
		"update `tabDocument Share Link` set view_count = view_count + 1, last_accessed_at = %s where name = %s",
		(now, link.name)
	)
	frappe.db.commit()

	_log_access_dict(link, "Preview", "Allowed", "Document viewed successfully")

	context.document = doc
	context.link = link
	context.file_url = doc.attached_document
	context.file_type = (doc.file_type or "Document").upper()
	context.file_size = doc.file_size or "N/A"
	context.allow_download = link.allow_download
	context.expires_at_formatted = format_datetime(link.expires_at, "dd MMM yyyy, HH:mm")
	context.time_left_seconds = max(0, int((link.expires_at - now).total_seconds())) if link.expires_at else 0
	context.download_url = f"/api/method/chemical_erp.documents.sharing.download_shared_document?token={token}"

	# Check preview capability
	ft = context.file_type
	if "PDF" in ft:
		context.preview_type = "pdf"
	elif any(img in ft for img in ("PNG", "JPEG", "JPG", "WEBP", "SVG")):
		context.preview_type = "image"
	else:
		context.preview_type = "generic"

	return context
