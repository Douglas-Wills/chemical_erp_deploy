import frappe
from frappe import _

no_cache = 1


def get_context(context):
	if frappe.session.user == "Guest":
		frappe.local.flags.redirect_location = "/login?redirect-to=/approvals"
		raise frappe.Redirect
	from chemical_erp.company import company_name
	from chemical_erp.controls.delegation import active_for

	d = active_for(frappe.session.user)
	context.delegation = d.as_dict() if d else None
	context.company = company_name(short=True)
	context.title = _("Approvals")
	context.no_breadcrumbs = 1
	context.show_sidebar = 0
	return context
