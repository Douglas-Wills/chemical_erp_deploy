import frappe
from frappe import _

no_cache = 1


def get_context(context):
	if frappe.session.user == "Guest":
		frappe.local.flags.redirect_location = "/login?redirect-to=/driver"
		raise frappe.Redirect
	from chemical_erp.company import company_name

	context.company = company_name(short=True)
	context.title = _("Deliveries")
	context.no_breadcrumbs = 1
	context.show_sidebar = 0
	return context
