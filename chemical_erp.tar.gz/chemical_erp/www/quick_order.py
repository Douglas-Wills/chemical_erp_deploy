import frappe
from frappe import _

no_cache = 1


def get_context(context):
	from chemical_erp.company import brand_colour, company_logo, company_name, company_phone

	context.company = company_name(short=True)
	context.logo = company_logo(None, wide=True)
	context.colour = brand_colour(None) or "#1f3864"
	context.phone = company_phone(None)
	context.title = _("Order")
	context.no_breadcrumbs = 1
	context.show_sidebar = 0
	context.last = []
	context.me = {}
	if frappe.session.user != "Guest":
		from chemical_erp.portal import customers_for

		mine = customers_for()
		if mine:
			context.me = {"name": frappe.db.get_value("Customer", mine[0], "customer_name"),
			              "phone": frappe.db.get_value("Customer", mine[0], "mobile_no") or ""}
			last = frappe.get_all("Quick Order", filters={"customer": ["in", mine], "status": ["!=", "Cancelled"]}, pluck="name",
			                      order_by="received_on desc", limit=1)
			if last:
				context.last = [{"item_code": r.item_code, "uom": r.uom, "qty": r.qty}
				                for r in frappe.get_doc("Quick Order", last[0]).items]
	return context
