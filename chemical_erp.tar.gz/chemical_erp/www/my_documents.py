import frappe
from frappe import _

from chemical_erp.portal import customers_for, deliveries

no_cache = 1


def get_context(context):
	if frappe.session.user == "Guest":
		frappe.throw(_("Please log in to see your documents."), frappe.PermissionError)
	customers = customers_for()
	context.customers = customers
	context.rows = deliveries(customers)
	context.products = sorted({(r.item_code, r.item_name) for r in context.rows})
	context.title = _("My Documents")
	from chemical_erp.company import company_name

	context.company = company_name(short=True)
	return context
