"""Product documents (SDS, CoA, conformity certificates) by product type.

Each item has a Document Profile that says what it must have:

  Profile                       SDS                                   Certificate per batch
  Hazardous - Made by Us        required: delivery stops without it   our own CoA from QC release
  Hazardous - Bought In         required: delivery stops; supplier's   supplier CoA checked at receipt, or our
                                SDS needed at receipt if none on file  own test (Certificate of Testing)
  Non-hazardous Industrial      recommended: warning only             as the item says (often on request)
  Consumer (Brave Home)         only for customers who require it     internal batch test record
  Service / Equipment / PPE     not applicable                        manufacturer certificate / datasheet

Customers can be marked 'Requires CoA' and 'Requires SDS' (institutions, hospitals, government tenders): for them
the documents become a hard stop. A one-off Document Exception, approved by the MD, lets a single delivery go.
"""

import frappe
from frappe import _
from frappe.utils import add_days, add_years, cint, flt, getdate, today

from chemical_erp.utils import MD_ROLE, current_sds

HAZ_MADE, HAZ_BOUGHT, INDUSTRIAL, CONSUMER, SERVICE = (
	"Hazardous - Made by Us", "Hazardous - Bought In", "Non-hazardous Industrial", "Consumer (Brave Home)", "Service / Equipment / PPE")
PROFILES = (HAZ_MADE, HAZ_BOUGHT, INDUSTRIAL, CONSUMER, SERVICE)
COA, COT, COC, NONE = "Certificate of Analysis", "Certificate of Testing", "Certificate of Conformity", "Not Applicable"
DEFAULT_BASIS = {HAZ_MADE: COA, HAZ_BOUGHT: COA, INDUSTRIAL: COC, CONSUMER: COA, SERVICE: NONE}
SDS_RULE = {HAZ_MADE: "Required", HAZ_BOUGHT: "Required", INDUSTRIAL: "Recommended", CONSUMER: "If the customer requires it",
            SERVICE: "Not applicable"}
def sds_review_years():
	"""How old an SDS may be before review: Chemical ERP Settings > SDS Review (years), default 3. One rule everywhere."""
	from chemical_erp.utils import get_settings

	return cint(get_settings().get("sds_review_years")) or 3
STATEMENTS = {
	COA: "The batch was tested against the specification below and released by the Quality department.",
	COT: "Only the parameters listed below were tested by us on this batch; other properties are as stated by the manufacturer.",
	COC: "This batch conforms to the manufacturer's specification as stated in the manufacturer's certificate. It was not "
	     "re-tested by us; checks made on receipt are listed below.",
}


def profile(item_code):
	v = frappe.get_cached_value("Item", item_code, ["doc_profile", "is_hazardous", "is_stock_item"], as_dict=True) or frappe._dict()
	if v.get("doc_profile"):
		return v.doc_profile
	if not v.get("is_stock_item"):
		return SERVICE
	return HAZ_MADE if v.get("is_hazardous") else INDUSTRIAL  # until classified: hazardous treated strictly


def sds_required(item_code, customer=None):
	p = profile(item_code)
	if p in (HAZ_MADE, HAZ_BOUGHT):
		return True
	if p == SERVICE:
		return False
	return bool(customer and frappe.db.get_value("Customer", customer, "requires_sds"))


def sds_state(item_code):
	"""'Current', 'Old' (older than the SDS review period in Chemical ERP Settings, or past its review date), or 'Missing'."""
	name = current_sds(item_code)
	if not name:
		return "Missing", None
	s = frappe.db.get_value("SDS File", name, ["effective_from", "review_due"], as_dict=True)
	if (s.review_due and getdate(s.review_due) < getdate(today())) or \
			(s.effective_from and getdate(add_years(s.effective_from, sds_review_years())) < getdate(today())):
		return "Old", name
	return "Current", name


# ---------------------------------------------------------------- exceptions approved by the MD
def exception_for(item_code, customer, document):
	for e in frappe.get_all("Document Exception", filters={"item_code": item_code, "document": document, "status": "Approved",
	                                                         "valid_until": [">=", today()]},
	                        fields=["name", "customer"]):
		if not e.customer or e.customer == customer:
			return e.name
	return None


def use_exceptions(doc, method=None):
	"""Delivery Note / Sales Invoice submitted: exceptions it relied on are used up."""
	for name in set(doc.flags.get("document_exceptions") or []):
		frappe.db.set_value("Document Exception", name, {"status": "Used", "used_on": f"{doc.doctype} {doc.name}"})


# ---------------------------------------------------------------- the checks
def delivery_problems(doc):
	"""Called by delivery_block.check. Returns (blocking problems, warnings)."""
	blocks, warnings = [], []
	doc.flags.document_exceptions = []
	customer = doc.get("customer")
	needs_coa = customer and frappe.db.get_value("Customer", customer, "requires_coa")
	seen = set()
	for row in doc.items:
		code = row.item_code
		if sds_required(code, customer):
			state, _name = sds_state(code)
			if state == "Missing":
				ex = exception_for(code, customer, "SDS")
				if ex:
					doc.flags.document_exceptions.append(ex)
				else:
					blocks.append(_("Row {0}: {1} has no current SDS. Get the SDS (Document Gaps report), or ask the MD for a one-off "
					                "Document Exception.").format(row.idx, code))
			elif state == "Old" and code not in seen:
				warnings.append(_("{0}: the SDS is due for review (over {1} years old or past its review date).").format(code, sds_review_years()))
		elif profile(code) == INDUSTRIAL and code not in seen and sds_state(code)[0] == "Missing":
			warnings.append(_("{0}: no SDS on file. It is not legally required for this product, but customers often ask for one.").format(code))
		if needs_coa and profile(code) != SERVICE:
			from chemical_erp.utils import row_batches

			batches = [b for b, _q in row_batches(row)]
			if not batches:
				blocks.append(_("Row {0}: {1} requires a certificate for every delivery, but no batch is selected.").format(row.idx, customer))
			for b in batches:
				if not certificate_available(b):
					ex = exception_for(code, customer, "CoA")
					if ex:
						doc.flags.document_exceptions.append(ex)
					else:
						blocks.append(_("Row {0}: batch {1} has no certificate, and {2} requires one with every delivery.").format(
							row.idx, b, customer))
		seen.add(code)
	return blocks, warnings


def certificate_available(batch_no):
	b = frappe.db.get_value("Batch", batch_no, ["accepted_inspection", "supplier_coa", "qc_status"], as_dict=True) or {}
	return bool(b.get("accepted_inspection") or b.get("supplier_coa"))


def receipt_check(doc, method=None):
	"""Purchase Receipt (replaces 'every chemical needs a CoA and SDS'):
	- hazardous products: the supplier's SDS must be attached unless a current SDS is already on file;
	- certificate: the supplier's CoA is asked for; without it the batch is tested by us (Certificate of Testing)."""
	from chemical_erp.controls.attachments import _moving_forward, _stop

	if not _moving_forward(doc):
		return
	missing, notes = [], []
	for row in doc.items:
		p = profile(row.item_code)
		if p in (HAZ_MADE, HAZ_BOUGHT) and not row.get("supplier_sds") and sds_state(row.item_code)[0] == "Missing":
			missing.append(_("Row {0} ({1}): the supplier's Safety Data Sheet (no current SDS is on file for this hazardous product)").format(
				row.idx, row.item_code))
		basis = frappe.get_cached_value("Item", row.item_code, "coa_basis") or DEFAULT_BASIS.get(p)
		if basis in (COA, COC) and p != SERVICE and not row.get("supplier_coa") and frappe.get_cached_value("Item", row.item_code, "has_batch_no"):
			notes.append(_("Row {0} ({1}): no supplier CoA. The batch will be tested by us and certified as a 'Certificate of Testing'. "
			               "Chase the supplier for it.").format(row.idx, row.item_code))
		if p == SERVICE and frappe.get_cached_value("Item", row.item_code, "needs_conformity_document") and not row.get("supplier_coa"):
			notes.append(_("Row {0} ({1}): attach the manufacturer's certificate or datasheet (PPE and equipment).").format(row.idx, row.item_code))
	_stop(missing, _("Supplier's SDS needed"))
	if notes:
		frappe.msgprint("<br>".join(notes), title=_("Certificates"), indicator="orange")


def receipt_submitted(doc, method=None):
	"""After receipt: set each batch's certificate type; turn an attached supplier SDS into a draft SDS File for HSE."""
	from chemical_erp.utils import notify, row_batches, users_with_role

	for row in doc.items:
		p = profile(row.item_code)
		basis = frappe.get_cached_value("Item", row.item_code, "coa_basis") or DEFAULT_BASIS.get(p)
		if basis in (COA, COC) and not row.get("supplier_coa"):
			basis = COT
		for batch_no, _q in row_batches(row):
			if frappe.get_meta("Batch").has_field("certificate_basis"):
				frappe.db.set_value("Batch", batch_no, "certificate_basis", basis, update_modified=False)
		if row.get("supplier_sds") and sds_state(row.item_code)[0] != "Current" and \
				not frappe.db.exists("SDS File", {"item_code": row.item_code, "docstatus": 0}):
			sds = frappe.get_doc({"doctype": "SDS File", "item_code": row.item_code, "language": "English", "effective_from": today(),
			                      "file": row.supplier_sds, "sds_status": "Draft", "review_due": add_years(today(), sds_review_years())})
			sds.flags.ignore_mandatory = True
			sds.insert(ignore_permissions=True)
			notify(users_with_role("HSE Officer"), "SDS File", sds.name,
			       _("Supplier's SDS for {0} received on {1}: check it (English, 16 sections) and send it to the MD.").format(row.item_code, doc.name))


def purchase_order_request(doc, method=None):
	"""Purchase Order: list the documents the supplier must send with the goods (printed on the order)."""
	if not doc.meta.has_field("documents_requested"):
		return
	lines = []
	for row in doc.items:
		p = profile(row.item_code)
		need = []
		if p in (HAZ_MADE, HAZ_BOUGHT) and sds_state(row.item_code)[0] != "Current":
			need.append(_("Safety Data Sheet (English, GHS, 16 sections)"))
		basis = frappe.get_cached_value("Item", row.item_code, "coa_basis") or DEFAULT_BASIS.get(p)
		if basis in (COA, COC) and p not in (SERVICE,):
			need.append(_("Certificate of Analysis for each batch"))
		if p == SERVICE and frappe.get_cached_value("Item", row.item_code, "needs_conformity_document"):
			need.append(_("manufacturer's certificate of conformity or datasheet"))
		if need:
			lines.append(f"{row.item_name or row.item_code}: {', '.join(dict.fromkeys(need))}")
	doc.documents_requested = "\n".join(dict.fromkeys(lines))


def quotation_attention(doc, method=None):
	"""Quotation / Sales Order: say which products are missing documents before delivery is promised. Never blocks."""
	notes, seen = [], set()
	customer = doc.get("customer") or (doc.get("party_name") if doc.get("quotation_to") == "Customer" else None)
	needs_coa = customer and frappe.db.get_value("Customer", customer, "requires_coa")
	for row in doc.get("items") or []:
		if row.item_code in seen:
			continue
		seen.add(row.item_code)
		if sds_required(row.item_code, customer) and sds_state(row.item_code)[0] == "Missing":
			notes.append(_("{0}: no current SDS. It cannot be delivered until one is on file.").format(row.item_code))
	if needs_coa:
		notes.append(_("This customer requires a certificate with every delivery."))
	if notes:
		frappe.msgprint("<br>".join(notes), title=_("Product documents"), indicator="orange")


# ---------------------------------------------------------------- certificate wording (Jinja)
def cert_title(qi):
	batch = qi.get("batch_no")
	basis = frappe.db.get_value("Batch", batch, "certificate_basis") if batch and frappe.get_meta("Batch").has_field("certificate_basis") else None
	return basis if basis in (COA, COT, COC) else COA


def cert_statement(qi):
	return STATEMENTS.get(cert_title(qi), "")


# ---------------------------------------------------------------- classification
BRAVE_HOME_GROUPS = ("Brave Home",)
SERVICE_GROUPS = ("Brave Services", "Industrial Equipment", "PPE", "Services")


@frappe.whitelist()
def classify_products(overwrite=0):
	"""Give every item a Document Profile from what is known about it. Existing profiles are kept unless overwrite."""
	from chemical_erp.utils import approver_role

	quality = approver_role("quality")  # the quality approver set in Chemical ERP Settings (Plant Manager or QC Manager)
	if not set((MD_ROLE, "HSE Officer", "System Manager", quality)) & set(frappe.get_roles()):
		frappe.throw(_("Only the MD, HSE Officer or {0} classify products.").format(quality), frappe.PermissionError)
	return classify(overwrite)


def classify(overwrite=0):
	if not frappe.get_meta("Item").has_field("doc_profile"):
		return {}
	counts = {}
	groups = {}
	for g in BRAVE_HOME_GROUPS + SERVICE_GROUPS:
		if frappe.db.exists("Item Group", g):
			lft, rgt = frappe.db.get_value("Item Group", g, ["lft", "rgt"])
			for sub in frappe.get_all("Item Group", filters={"lft": [">=", lft], "rgt": ["<=", rgt]}, pluck="name"):
				groups[sub] = CONSUMER if g in BRAVE_HOME_GROUPS else SERVICE
	made = set(frappe.get_all("BOM", filters={"docstatus": 1, "is_active": 1}, pluck="item"))
	for it in frappe.get_all("Item", filters={"disabled": 0}, fields=["name", "item_group", "is_stock_item", "is_hazardous", "doc_profile",
	                                                                  "is_purchase_item", "is_waste_item"]):
		if it.doc_profile and not cint(overwrite):
			continue
		if it.is_waste_item:
			continue
		if groups.get(it.item_group):
			p = groups[it.item_group]
		elif not it.is_stock_item:
			p = SERVICE
		elif it.is_hazardous:
			p = HAZ_MADE if it.name in made or not it.is_purchase_item else HAZ_BOUGHT
		else:
			p = INDUSTRIAL
		values = {"doc_profile": p, "coa_basis": DEFAULT_BASIS[p],
		          "requires_current_sds": 1 if p in (HAZ_MADE, HAZ_BOUGHT) else 0}
		if p == SERVICE and it.item_group in ("PPE", "Industrial Equipment"):
			values["needs_conformity_document"] = 1
		frappe.db.set_value("Item", it.name, values, update_modified=False)
		counts[p] = counts.get(p, 0) + 1
	frappe.clear_cache(doctype="Item")
	return counts


def item_validate(doc, method=None):
	"""Keep 'Requires Current SDS' in step with the profile."""
	if doc.get("doc_profile"):
		doc.requires_current_sds = 1 if doc.doc_profile in (HAZ_MADE, HAZ_BOUGHT) else 0
		if not doc.get("coa_basis"):
			doc.coa_basis = DEFAULT_BASIS.get(doc.doc_profile)


# ---------------------------------------------------------------- gaps (report and dashboard)
def gaps(only_problems=True):
	since = add_days(today(), -90)
	sold = {r.item_code: flt(r.qty) for r in frappe.db.sql("""select dni.item_code, sum(dni.stock_qty) qty from `tabDelivery Note Item` dni
		join `tabDelivery Note` dn on dn.name = dni.parent where dn.docstatus=1 and dn.posting_date >= %s group by dni.item_code""", since, as_dict=True)}
	stock = {r.item_code: flt(r.v) for r in frappe.db.sql("select item_code, sum(stock_value) v from `tabBin` group by item_code", as_dict=True)}
	no_coa = {r.item: r.n for r in frappe.db.sql("""select b.item, count(*) n from `tabBatch` b
		where ifnull(b.supplier_coa,'')='' and ifnull(b.accepted_inspection,'')='' and b.batch_qty > 0 and ifnull(b.is_waste_batch,0)=0
		group by b.item""", as_dict=True)} if frappe.get_meta("Batch").has_field("accepted_inspection") else {}
	out = []
	for it in frappe.get_all("Item", filters={"disabled": 0, "is_sales_item": 1}, fields=["name", "item_name", "item_group", "doc_profile",
	                                                                                      "is_stock_item"]):
		p = profile(it.name)
		state, sds = sds_state(it.name) if p != SERVICE else ("n/a", None)
		problems, severity = [], 0
		if p in (HAZ_MADE, HAZ_BOUGHT) and state == "Missing":
			problems.append(_("SDS missing: delivery blocked"))
			severity = 3
		elif state == "Old":
			problems.append(_("SDS due for review"))
			severity = max(severity, 1)
		elif p in (INDUSTRIAL, CONSUMER) and state == "Missing":
			problems.append(_("No SDS (needed for customers who require one)"))
			severity = max(severity, 1)
		if no_coa.get(it.name):
			problems.append(_("{0} batch(es) in stock with no certificate yet").format(no_coa[it.name]))
			severity = max(severity, 2)
		pc = frappe.db.get_value("Product Certification", {"item_code": it.name}, "status") if frappe.db.exists("DocType", "Product Certification") else None
		if pc in ("Expired", "Certificate Missing"):
			problems.append(_("Product certification: {0}").format(pc))
			severity = max(severity, 1)
		if not it.doc_profile:
			problems.append(_("Not classified"))
		if only_problems and not problems:
			continue
		out.append({"item_code": it.name, "item_name": it.item_name, "profile": p, "sds": state, "sds_file": sds,
		            "batches_without_certificate": no_coa.get(it.name, 0), "problems": "; ".join(problems), "severity": severity,
		            "stock_value": stock.get(it.name, 0), "sold_90_days": sold.get(it.name, 0)})
	out.sort(key=lambda r: (-r["severity"], -(r["stock_value"] + r["sold_90_days"])))
	return out


def blocking_count():
	return sum(1 for r in gaps() if r["severity"] >= 3 and (r["stock_value"] or r["sold_90_days"]))
