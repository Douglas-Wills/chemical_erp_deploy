"""Store segregation (Regulatory Compliance > Substances and SDS).

Each substance has a storage class. Stock moving into a warehouse is checked against what is already there:
incompatible classes in the same store are stopped, unless the warehouse is marked as having segregated bays
(then a warning). A warehouse may also carry its permit's maximum quantity, which cannot be exceeded.
"""

import frappe
from frappe import _
from frappe.utils import cint, flt

# Pairs that must not share a store (standard segregation for chemical stores; hypochlorite is an oxidiser,
# so it is kept from acids, which would release chlorine).
INCOMPATIBLE = {
	frozenset(("Flammable liquids", "Oxidisers")),
	frozenset(("Acids (corrosive)", "Alkalis (corrosive)")),
	frozenset(("Acids (corrosive)", "Oxidisers")),
	frozenset(("Oxidisers", "Toxic")),
	frozenset(("Water-reactive", "Acids (corrosive)")),
	frozenset(("Water-reactive", "Alkalis (corrosive)")),
	frozenset(("Water-reactive", "Flammable liquids")),
	frozenset(("Compressed gases", "Flammable liquids")),
	frozenset(("Compressed gases", "Oxidisers")),
}
REASONS = {
	frozenset(("Acids (corrosive)", "Oxidisers")): "acids with hypochlorite or other oxidisers release toxic gas (chlorine)",
	frozenset(("Acids (corrosive)", "Alkalis (corrosive)")): "acids and alkalis react violently and give off heat",
	frozenset(("Flammable liquids", "Oxidisers")): "oxidisers feed a fire",
}


def storage_class(item_code):
	sub = frappe.get_cached_value("Item", item_code, "substance")
	return frappe.get_cached_value("Substance Register", sub, "storage_class") if sub else None


def classes_in(warehouse):
	out = {}
	for b in frappe.get_all("Bin", filters={"warehouse": warehouse, "actual_qty": [">", 0]}, fields=["item_code"]):
		c = storage_class(b.item_code)
		if c and c != "Non-hazardous":
			out.setdefault(c, b.item_code)
	return out


def stock_kg(warehouse):
	from chemical_erp.controls.manufacturing import to_kg

	return sum(to_kg(b.item_code, b.actual_qty) for b in frappe.get_all("Bin", filters={"warehouse": warehouse, "actual_qty": [">", 0]},
	                                                                    fields=["item_code", "actual_qty"]))


def check(doc, method=None):
	"""Stock Entry / Purchase Receipt: incoming stock against what the store already holds."""
	from chemical_erp.controls.manufacturing import to_kg

	incoming = {}
	for row in doc.get("items") or []:
		wh = row.get("t_warehouse") if doc.doctype == "Stock Entry" else row.get("warehouse")
		if not wh:
			continue
		incoming.setdefault(wh, []).append(row)
	blocks, warns = [], []
	for wh, rows in incoming.items():
		present = classes_in(wh)
		segregated = cint(frappe.get_cached_value("Warehouse", wh, "segregated_bays")) if frappe.get_meta("Warehouse").has_field("segregated_bays") else 0
		for row in rows:
			c = storage_class(row.item_code)
			if not c or c == "Non-hazardous":
				continue
			for other, item in list(present.items()) + [(storage_class(r.item_code), r.item_code) for r in rows if r is not row]:
				if other and frozenset((c, other)) in INCOMPATIBLE:
					why = REASONS.get(frozenset((c, other)), _("they must be kept apart"))
					msg = _("Row {0}: {1} ({2}) cannot be stored in {3} with {4} ({5}): {6}.").format(row.idx, row.item_code, c, wh, item, other, why)
					(warns if segregated else blocks).append(msg)
		limit = flt(frappe.get_cached_value("Warehouse", wh, "max_storage_kg")) if frappe.get_meta("Warehouse").has_field("max_storage_kg") else 0
		if limit:
			total = stock_kg(wh) + sum(to_kg(r.item_code, r.get("transfer_qty") or r.get("stock_qty") or r.qty) for r in rows)
			if total > limit:
				blocks.append(_("{0} would hold {1:.0f} kg, above its permitted {2:.0f} kg.").format(wh, total, limit))
	if blocks:
		frappe.throw("<br>".join(dict.fromkeys(blocks)), title=_("Store segregation"))
	if warns:
		frappe.msgprint("<br>".join(dict.fromkeys(warns)) + "<br>" + _("Allowed because the store has segregated bays: use the right bay."),
		                title=_("Store segregation"), indicator="orange")


def conflicts():
	"""Warehouses holding incompatible classes now (for the report and the HSE dashboard)."""
	out = []
	for wh in frappe.get_all("Warehouse", filters={"is_group": 0, "disabled": 0}, pluck="name"):
		present = classes_in(wh)
		names = list(present)
		for i, a in enumerate(names):
			for b in names[i + 1:]:
				if frozenset((a, b)) in INCOMPATIBLE:
					out.append({"warehouse": wh, "class_a": a, "item_a": present[a], "class_b": b, "item_b": present[b],
					            "reason": REASONS.get(frozenset((a, b)), ""),
					            "segregated": frappe.db.get_value("Warehouse", wh, "segregated_bays") if frappe.get_meta("Warehouse").has_field("segregated_bays") else 0})
	return out
