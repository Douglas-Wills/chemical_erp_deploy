frappe.ui.form.on("Work Permit", {
	refresh(frm) {
		if (frm.is_new()) return;
		if (frm.doc.status === "Draft") frm.add_custom_button(__("Issue Permit"), () => frm.call("issue").then(() => frm.reload_doc())).addClass("btn-primary");
		if (frm.doc.status === "Issued") frm.add_custom_button(__("Close Permit"), () => frm.call("close").then(() => frm.reload_doc())).addClass("btn-primary");
		if (frm.doc.status === "Issued") frm.dashboard.set_headline_alert(__("Permit valid until {0}", [frappe.datetime.str_to_user(frm.doc.valid_to)]), "green");
	},
});
