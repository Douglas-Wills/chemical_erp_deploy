import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_to_date, get_datetime, getdate, now_datetime, time_diff_in_hours, today

from chemical_erp.utils import MD_ROLE

ISSUERS = ("HSE Officer", "Plant Manager", MD_ROLE)
CHECKS = {
	"Hot Work": ["Area cleared of flammables within 10 m", "Fire extinguisher at the work point", "Drains and openings covered",
	             "Tanks and lines nearby emptied and gas-free", "Fire watch for 30 minutes after work"],
	"Confined Space Entry": ["Tank emptied, flushed and ventilated", "All lines isolated and blanked (not just valves)",
	                         "Gas test done and within limits", "Standby person and rescue plan at the entry",
	                         "Breathing apparatus or air supply where needed", "Entrant briefed on the chemical last held"],
	"Work at Height": ["Scaffold or platform inspected and tagged", "Harness worn and anchored", "Area below barricaded"],
	"Line Breaking (opening chemical lines)": ["Line drained and depressurised", "Isolation valves locked and tagged",
	                                          "Chemical in the line identified; SDS read", "Face shield, gloves and apron worn",
	                                          "Spill kit and eyewash at the point"],
	"Electrical Isolation": ["Isolated at the source", "Lock and tag applied", "Tested dead before work"],
}
MAX_HOURS = 12


class WorkPermit(Document):
	def validate(self):
		if not self.checks and self.permit_type in CHECKS:
			for c in CHECKS[self.permit_type]:
				self.append("checks", {"check_item": c})
		if time_diff_in_hours(self.valid_to, self.valid_from) > MAX_HOURS or get_datetime(self.valid_to) <= get_datetime(self.valid_from):
			frappe.throw(_("A permit covers at most {0} hours (one shift). Issue a new one for the next shift.").format(MAX_HOURS))
		if self.contractor_induction:
			ind = frappe.db.get_value("Contractor Induction", self.contractor_induction, ["valid_until", "insurance_expiry"], as_dict=True)
			if ind and ind.valid_until and getdate(ind.valid_until) < getdate(today()):
				frappe.throw(_("The contractor's induction expired on {0}. Induct them again first.").format(ind.valid_until))
			if ind and ind.insurance_expiry and getdate(ind.insurance_expiry) < getdate(today()):
				frappe.throw(_("The contractor's insurance expired on {0}.").format(ind.insurance_expiry))

	def ready_to_issue(self):
		missing = [c.check_item for c in self.checks if not c.done]
		if missing:
			frappe.throw(_("Complete these precautions first:") + "<br>• " + "<br>• ".join(missing), title=_("Not ready"))
		if self.permit_type == "Hot Work" and not (self.fire_watch or "").strip():
			frappe.throw(_("Name the fire watch."))
		if self.permit_type == "Confined Space Entry":
			if not (self.standby_person or "").strip():
				frappe.throw(_("Name the standby person at the entry."))
			if self.gas_tested_at is None or get_datetime(self.gas_tested_at) < add_to_date(now_datetime(), hours=-1):
				frappe.throw(_("Test the atmosphere within the hour before entry."))
			bad = []
			if not (19.5 <= (self.oxygen_percent or 0) <= 23.5):
				bad.append(_("oxygen {0}% (19.5-23.5)").format(self.oxygen_percent))
			if (self.lel_percent or 0) >= 10:
				bad.append(_("flammable {0}% LEL (below 10)").format(self.lel_percent))
			if (self.h2s_ppm or 0) >= 10:
				bad.append(_("H2S {0} ppm (below 10)").format(self.h2s_ppm))
			if bad:
				frappe.throw(_("Do not enter: ") + ", ".join(bad), title=_("Gas test failed"))

	@frappe.whitelist()
	def issue(self):
		if not set(ISSUERS) & set(frappe.get_roles()):
			frappe.throw(_("Only the HSE Officer, Plant Manager or MD issue permits."), frappe.PermissionError)
		if self.owner == frappe.session.user:
			frappe.throw(_("You raised this permit, so someone else must issue it."))
		self.ready_to_issue()
		self.status, self.issued_by, self.issued_on = "Issued", frappe.session.user, now_datetime()
		self.save()
		return self.status

	@frappe.whitelist()
	def close(self):
		if not self.area_left_safe:
			frappe.throw(_("Confirm the area was left safe and the isolations removed."))
		self.status, self.closed_by, self.closed_on = "Closed", frappe.session.user, now_datetime()
		self.save()
		return self.status


def expire():
	"""Hourly: permits past their time expire; the issuer is told if the work was not closed."""
	from chemical_erp.utils import notify

	for p in frappe.get_all("Work Permit", filters={"status": "Issued", "valid_to": ["<", now_datetime()]}, fields=["name", "issued_by", "permit_type"]):
		frappe.db.set_value("Work Permit", p.name, "status", "Expired")
		notify(p.issued_by, "Work Permit", p.name, _("{0} permit {1} expired without being closed. Check the area.").format(p.permit_type, p.name),
		       priority="High")


def maintenance_needs_permit(doc, method=None):
	"""A maintenance job on a tank, reactor or chemical line cannot start without a live permit, if one is required."""
	if not doc.get("requires_permit") or doc.get("status") not in ("In Progress", "Done"):
		return
	if not frappe.db.exists("Work Permit", {"maintenance_job": doc.name, "status": ["in", ["Issued", "Closed"]]}):
		frappe.throw(_("This job needs an issued Work Permit (linked to this job) before work starts."), title=_("Permit to work"))
