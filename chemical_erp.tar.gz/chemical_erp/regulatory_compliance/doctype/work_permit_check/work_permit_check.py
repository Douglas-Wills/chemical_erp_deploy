from frappe.model.document import Document


class WorkPermitCheck(Document):
	pass
