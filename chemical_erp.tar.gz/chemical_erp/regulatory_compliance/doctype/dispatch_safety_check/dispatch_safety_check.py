import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import getdate

CHECKS = {"placards_displayed": "placards", "fire_extinguisher": "fire extinguisher", "spill_kit": "spill kit",
          "driver_ppe": "driver PPE", "load_secured": "load secured", "incompatibles_segregated": "segregation",
          "containers_sealed": "containers sealed", "packages_labelled": "labels", "emergency_card": "emergency card",
          "sds_copies": "SDS copies"}


class DispatchSafetyCheck(Document):
	def validate(self):
		failed = [label for f, label in CHECKS.items() if not self.get(f)]
		if not self.driver_trained:
			failed.append("driver training")
		if self.driver_licence_expiry and getdate(self.driver_licence_expiry) < getdate(self.check_date):
			failed.append("driving licence expired")
		self.result = "Fail" if failed else "Pass"
		self.failed_items = ", ".join(failed)


def required(doc, method=None):
	"""A delivery carrying hazardous goods needs a passed dispatch safety check before it leaves (setting, on by default)."""
	from chemical_erp.utils import get_settings

	if doc.get("is_return") or not get_settings().get("require_dispatch_check"):
		return
	hazardous = [r.item_code for r in doc.items if frappe.get_cached_value("Item", r.item_code, "is_hazardous")]
	if hazardous and not frappe.db.exists("Dispatch Safety Check", {"delivery_note": doc.name, "result": "Pass"}):
		frappe.throw(_("This delivery carries hazardous goods ({0}). Record a passed Dispatch Safety Check for it before dispatch.").format(
			", ".join(sorted(set(hazardous)))), title=_("Dispatch safety check required"))
