from frappe.model.document import Document


class RecallBatch(Document):
	pass
