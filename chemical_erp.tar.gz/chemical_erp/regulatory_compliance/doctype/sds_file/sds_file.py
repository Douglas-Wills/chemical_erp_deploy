import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_years, cint

from chemical_erp.utils import get_settings


class SDSFile(Document):
	def validate(self):
		self.language = "English"
		if not (self.file or "").lower().endswith(".pdf"):
			frappe.throw(_("Attach the SDS as a PDF."))
		self.review_due = add_years(self.effective_from, cint(get_settings().sds_review_years) or 3)

	def on_submit(self):
		for other in frappe.get_all("SDS File", filters={"item_code": self.item_code, "sds_status": "Current",
		                                                "name": ["!=", self.name]}, pluck="name"):
			frappe.db.set_value("SDS File", other, {"sds_status": "Superseded", "effective_to": self.effective_from})
		self.db_set("sds_status", "Current")

	def on_cancel(self):
		self.db_set("sds_status", "Superseded")
