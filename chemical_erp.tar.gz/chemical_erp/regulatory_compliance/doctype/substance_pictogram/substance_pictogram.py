from frappe.model.document import Document


class SubstancePictogram(Document):
	pass
