import re

import frappe
from frappe import _
from frappe.model.document import Document


class SubstanceRegister(Document):
	def validate(self):
		if self.cas_number:
			cas = self.cas_number.strip()
			m = re.fullmatch(r"(\d{2,7})-(\d{2})-(\d)", cas)
			if not m:
				frappe.throw(_("CAS number must look like 7732-18-5."))
			digits = (m.group(1) + m.group(2))[::-1]
			if sum((i + 1) * int(d) for i, d in enumerate(digits)) % 10 != int(m.group(3)):
				frappe.throw(_("CAS number {0} fails its check digit.").format(cas))
			self.cas_number = cas
		if self.un_number and not re.fullmatch(r"UN\d{4}", self.un_number.strip().upper()):
			frappe.throw(_("UN number must look like UN1824."))
		if self.un_number:
			self.un_number = self.un_number.strip().upper()
