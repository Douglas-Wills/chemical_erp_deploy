import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_years


class ContractorInduction(Document):
	"""A contractor's site induction, valid one year. Work permits for contractors need a valid one."""

	def validate(self):
		if not (self.site_rules and self.chemical_hazards and self.ppe and self.permit_system):
			frappe.throw(_("Tick every induction topic covered; all four are required."))
		self.valid_until = add_years(self.inducted_on, 1)
