import frappe
from frappe import _
from frappe.model.document import Document


class TrainingRequirement(Document):
	def validate(self):
		if not (self.workstation or self.designation):
			frappe.throw(_("Set a workstation, a designation, or both."))
