frappe.ui.form.on("Product Recall", {
	refresh(frm) {
		if (frm.is_new() || frm.doc.status === "Closed") return;
		frm.add_custom_button(__("Find Customers"), () => frm.call("find_customers").then(({ message }) => {
			frm.reload_doc();
			frappe.show_alert({ message: __("{0} delivery line(s) found; remaining stock held in quarantine.", [message]), indicator: "green" });
		})).addClass("btn-primary");
		if (!frm.doc.mock_recall && (frm.doc.customers || []).length)
			frm.add_custom_button(__("Email Customers"), () => frappe.confirm(__("Email every customer not yet notified?"), () =>
				frm.call("notify_customers").then(({ message }) => { frm.reload_doc(); frappe.show_alert(__("{0} notified", [message])); })));
		frm.add_custom_button(__("Close Recall"), () => frm.call("close_recall").then(() => frm.reload_doc()));
	},
});
