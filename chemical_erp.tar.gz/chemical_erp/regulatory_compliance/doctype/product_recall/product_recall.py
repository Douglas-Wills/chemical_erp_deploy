import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, now_datetime, time_diff_in_seconds


class ProductRecall(Document):
	"""Find every customer who received the recalled batches, notify them, hold remaining stock, record recovery."""

	def validate(self):
		self.qty_delivered = sum(flt(c.qty_delivered) for c in self.customers)
		self.qty_recovered = sum(flt(c.qty_recovered) for c in self.customers)
		self.recovery_percent = (self.qty_recovered / self.qty_delivered * 100) if self.qty_delivered else 0
		from chemical_erp.utils import batch_balances

		self.stock_held_kg = sum(q for b in self.batches for _wh, q in batch_balances(b.batch))
		if self.status == "Closed":
			if not self.disposition and self.qty_recovered:
				frappe.throw(_("Say what happens to the recovered stock."))
			if self.recovery_percent < 100 and not self.mock_recall and not (self.close_justification or "").strip():
				frappe.throw(_("Only {0:.0f}% was recovered: explain why the recall can close.").format(self.recovery_percent))

	@frappe.whitelist()
	def find_customers(self):
		"""Every delivery of the recalled batches (deliveries, and invoices that moved stock)."""
		batches = [b.batch for b in self.batches]
		if not batches:
			frappe.throw(_("List the batches first."))
		found = {}
		for b in batches:
			rows = frappe.db.sql("""select dn.customer, dn.name, dni.stock_qty from `tabDelivery Note Item` dni join `tabDelivery Note` dn on dn.name = dni.parent
				where dn.docstatus=1 and dn.is_return=0 and dni.batch_no=%s""", b, as_dict=True)
			rows += frappe.db.sql("""select dn.customer, dn.name, abs(sbe.qty) as stock_qty from `tabSerial and Batch Entry` sbe
				join `tabSerial and Batch Bundle` sbb on sbb.name = sbe.parent join `tabDelivery Note` dn on dn.name = sbb.voucher_no
				where sbb.voucher_type='Delivery Note' and sbb.docstatus=1 and dn.is_return=0 and sbe.batch_no=%s""", b, as_dict=True) \
				if frappe.db.exists("DocType", "Serial and Batch Bundle") else []
			for r in rows:
				found[(r.customer, r.name, b)] = found.get((r.customer, r.name, b), 0) + flt(r.stock_qty)
		have = {(c.customer, c.delivery_note, c.batch) for c in self.customers}
		for (customer, dn, b), qty in found.items():
			if (customer, dn, b) not in have:
				self.append("customers", {"customer": customer, "delivery_note": dn, "batch": b, "qty_delivered": qty})
		if not self.customers_found_on:
			self.customers_found_on = now_datetime()
			self.minutes_to_trace = int(time_diff_in_seconds(self.customers_found_on, self.initiated_on) // 60)
		if not self.mock_recall:  # stop remaining stock leaving
			for b in batches:
				frappe.db.set_value("Batch", b, "qc_status", "Quarantine", update_modified=False)
		self.save()
		return len(self.customers)

	@frappe.whitelist()
	def close_recall(self):
		from chemical_erp.utils import MD_ROLE

		from chemical_erp.utils import approver_role

		quality = approver_role("quality")  # Plant Manager or QC Manager, as set in Chemical ERP Settings
		if not set((MD_ROLE, quality, "HSE Officer")) & set(frappe.get_roles()):
			frappe.throw(_("Only the MD, {0} or HSE Officer close a recall.").format(quality), frappe.PermissionError)
		self.status, self.closed_by = "Closed", frappe.session.user
		self.save()
		return self.status

	@frappe.whitelist()
	def notify_customers(self):
		if self.mock_recall:
			frappe.throw(_("A mock recall does not contact customers."))
		from chemical_erp.chemical_core.collections import customer_email
		from chemical_erp.company import company_name, company_phone

		sent = 0
		for c in self.customers:
			if c.notified_on:
				continue
			to = customer_email(c.customer)
			if not to:
				continue
			frappe.sendmail(recipients=[to], subject=_("Product recall: {0}, batch {1}").format(self.item_name, c.batch),
			                message=_("<p>Dear customer,</p><p>{0} is recalling <b>{1}</b>, batch <b>{2}</b>, delivered on {3}.</p><p>Reason: {4}</p>"
			                          "<p>Please stop using this batch, keep it apart, and contact us on {5} to arrange collection. "
			                          "We apologise for the inconvenience.</p>").format(
				                company_name(short=True), self.item_name, c.batch, c.delivery_note, frappe.utils.escape_html(self.reason),
				                company_phone(None)), reference_doctype=self.doctype, reference_name=self.name)
			c.notified_on = now_datetime()
			sent += 1
		self.status = "Notifying" if any(not c.notified_on for c in self.customers) else "Recovering"
		self.save()
		return sent
