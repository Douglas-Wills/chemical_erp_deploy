from frappe.model.document import Document


class StaffCertification(Document):
	pass
