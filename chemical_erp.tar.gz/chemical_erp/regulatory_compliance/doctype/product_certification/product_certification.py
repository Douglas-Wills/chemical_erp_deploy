import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, getdate, today


def compute_status(doc, warn_days=60):
	if doc.in_scope == "No":
		return "Not in Scope"
	if doc.in_scope == "To Be Confirmed":
		return "To Be Confirmed"
	if not doc.attachment or not doc.expires_on:
		return "Certificate Missing"
	if getdate(doc.expires_on) < getdate(today()):
		return "Expired"
	if getdate(doc.expires_on) <= getdate(add_days(today(), warn_days)):
		return "Expiring"
	return "Valid"


class ProductCertification(Document):
	def validate(self):
		self.status = compute_status(self)


def attention(doc, method=None):
	"""Sales documents: draw attention to certification gaps. Never blocks."""
	seen, notes = set(), []
	for row in doc.get("items") or []:
		if row.item_code in seen:
			continue
		seen.add(row.item_code)
		pc = frappe.db.get_value("Product Certification", {"item_code": row.item_code}, ["status", "expires_on"], as_dict=True)
		if pc and pc.status in ("Expired", "Certificate Missing", "Expiring"):
			notes.append(_("{0}: certification {1}{2}").format(row.item_code, pc.status.lower(),
			                                                     _(" on {0}").format(pc.expires_on) if pc.expires_on and pc.status != "Certificate Missing" else ""))
	if notes:
		frappe.msgprint("<br>".join(notes), title=_("Product certification needs attention"), indicator="orange")
