from frappe.model.document import Document


class IncidentPerson(Document):
	pass
