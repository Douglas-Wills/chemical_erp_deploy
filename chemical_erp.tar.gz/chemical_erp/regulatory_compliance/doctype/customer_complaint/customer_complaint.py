import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import now_datetime

from chemical_erp.utils import approver_role, has_role, notify, position_title, users_with_role


class CustomerComplaint(Document):
	def validate(self):
		if self.delivery_note and not (self.item_code and self.batch):
			row = frappe.db.get_value("Delivery Note Item", {"parent": self.delivery_note}, ["item_code", "batch_no"], as_dict=True)
			if row:
				self.item_code = self.item_code or row.item_code
				self.batch = self.batch or row.batch_no
		if self.batch and not self.retained_sample:
			self.retained_sample = frappe.db.get_value("Retained Sample", {"batch": self.batch, "status": "Retained"}, "name")
		if self.return_delivery_note:
			dn = frappe.db.get_value("Delivery Note", self.return_delivery_note, ["is_return", "customer"], as_dict=True)
			if not dn or not dn.is_return or dn.customer != self.customer:
				frappe.throw(_("{0} is not a return from {1}.").format(self.return_delivery_note, self.customer))
		if self.status in ("Investigating", "Awaiting Customer", "Closed") and not self.acknowledged_on:
			self.acknowledged_on = now_datetime()
		before = self.get_doc_before_save()
		if self.status == "Closed" and (not before or before.status != "Closed"):
			self.validate_close()

	def validate_close(self):
		quality = approver_role("quality")
		if not has_role(quality):
			frappe.throw(_("Only the {0} can close a complaint.").format(position_title("quality")), frappe.PermissionError)
		missing = []
		if self.justified == "Pending":
			missing.append(_("whether the complaint is justified"))
		if self.justified == "Justified" and not self.root_cause:
			missing.append(_("the root cause"))
		if self.justified == "Justified" and not self.disposition:
			missing.append(_("the disposition (credit note, replacement, rework …)"))
		if self.disposition == "Credit Note" and not self.credit_note:
			missing.append(_("the credit note"))
		if self.return_required and not self.return_delivery_note:
			missing.append(_("the return delivery note for the goods sent back"))
		if not (self.response_to_customer and self.response_sent_on):
			missing.append(_("the response sent to the customer"))
		if any(not a.done for a in self.actions):
			missing.append(_("completion of every corrective action"))
		if missing:
			frappe.throw(_("Before closing, record: {0}.").format("; ".join(missing)), title=_("Complaint not ready to close"))
		self.closed_by, self.closed_on = frappe.session.user, now_datetime()

	def after_insert(self):
		notify(users_with_role(approver_role("quality")) + users_with_role("QC Analyst") + users_with_role("Sales Manager"),
		       self.doctype, self.name, _("{0} complaint from {1}: {2}").format(self.severity, self.customer, self.complaint_type),
		       priority="High" if self.severity != "Minor" else "Medium")
		if self.batch and self.severity in ("Major", "Critical") and self.complaint_type in ("Product Quality", "Safety"):
			dev = frappe.get_doc({"doctype": "Deviation", "title": _("Complaint {0}: {1}").format(self.name, self.complaint_type),
			                      "source_type": "Batch", "source_name": self.batch, "batch": self.batch, "batch_blocked": 0,
			                      "description": self.description}).insert(ignore_permissions=True)
			self.db_set("deviation", dev.name)
		if self.retained_sample:
			frappe.db.set_value("Retained Sample", self.retained_sample, {"used_for_type": "Customer Complaint", "used_for": self.name})
