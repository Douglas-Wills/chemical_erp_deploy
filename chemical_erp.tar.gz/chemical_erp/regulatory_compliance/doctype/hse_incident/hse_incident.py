import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import now_datetime

from chemical_erp.utils import approver_role, has_role, notify, position_title, users_with_role


class HSEIncident(Document):
	def validate(self):
		self.lost_time = 1 if any((p.days_lost or 0) > 0 or p.treatment in ("Hospitalised", "Fatal") for p in self.people) else 0
		if any(p.treatment == "Fatal" for p in self.people):
			self.severity, self.reportable = "Critical", 1
		before = self.get_doc_before_save()
		if self.status == "Closed" and (not before or before.status != "Closed"):
			if not has_role(approver_role()):
				frappe.throw(_("The HSE Officer investigates; only the {0} closes an incident.").format(position_title()), frappe.PermissionError)
			missing = [m for m, ok in ((_("the root cause"), self.root_cause),
			                           (_("completion of every corrective action"), all(a.done for a in self.actions)),
			                           (_("the date it was reported to the authority"), not self.reportable or self.reported_on)) if not ok]
			if missing:
				frappe.throw(_("Before closing, record: {0}.").format("; ".join(missing)))
			self.closed_by, self.closed_on = frappe.session.user, now_datetime()

	def after_insert(self):
		urgent = self.severity in ("High", "Critical") or self.lost_time
		notify(users_with_role("HSE Officer") + users_with_role(approver_role()) + users_with_role("Managing Director"),
		       self.doctype, self.name, _("{0} incident: {1} at {2}").format(self.severity, self.incident_type, self.location),
		       priority="High" if urgent else "Medium")
