from frappe.model.document import Document


class RecallCustomer(Document):
	pass
