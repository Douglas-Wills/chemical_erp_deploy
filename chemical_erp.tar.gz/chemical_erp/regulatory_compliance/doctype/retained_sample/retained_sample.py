import frappe
from frappe.model.document import Document
from frappe.utils import add_months, cint, today

from chemical_erp.utils import get_settings


class RetainedSample(Document):
	def validate(self):
		if not self.retain_until:
			expiry = frappe.db.get_value("Batch", self.batch, "expiry_date")
			self.retain_until = add_months(expiry or today(), cint(get_settings().get("retained_sample_months")) or 12)
		if self.status == "Disposed" and not self.disposed_on:
			self.disposed_on = today()
