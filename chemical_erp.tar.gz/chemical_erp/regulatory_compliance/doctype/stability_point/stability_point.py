from frappe.model.document import Document


class StabilityPoint(Document):
	pass
