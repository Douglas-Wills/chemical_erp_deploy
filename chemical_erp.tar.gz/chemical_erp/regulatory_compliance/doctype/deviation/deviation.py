import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import now_datetime

from chemical_erp.utils import approver_role, has_role, notify, position_title, users_with_role


class Deviation(Document):
	def validate(self):
		if self.status in ("CAPA", "Closed") and not self.root_cause:
			frappe.throw(_("Record the root cause before moving to CAPA."))
		before = self.get_doc_before_save()
		if self.status == "Closed" and (not before or before.status != "Closed"):
			if not has_role(approver_role("quality")):
				frappe.throw(_("Only the {0} can close a deviation.").format(position_title("quality")), frappe.PermissionError)
			if any(not a.done for a in self.capa_actions):
				frappe.throw(_("Complete every CAPA action before closing."))
			self.closed_by, self.closed_on = frappe.session.user, now_datetime()

	def after_insert(self):
		notify(users_with_role(approver_role("quality")), self.doctype, self.name,
		       _("New deviation {0}: {1}").format(self.name, self.title), priority="High" if self.batch_blocked else "Medium")
