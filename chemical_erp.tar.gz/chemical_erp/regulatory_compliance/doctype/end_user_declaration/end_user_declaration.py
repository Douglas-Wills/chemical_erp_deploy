from frappe.model.document import Document

from chemical_erp.regulatory_compliance.controlled import validate_declaration


class EndUserDeclaration(Document):
	def validate(self):
		validate_declaration(self)
