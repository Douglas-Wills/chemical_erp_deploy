frappe.ui.form.on("End-User Declaration", {
	setup(frm) {
		frm.set_query("substance", () => ({ filters: { is_controlled: 1 } }));
	},
	refresh(frm) {
		if (frm.is_new() || frm.doc.status !== "Draft") return;
		if (!(frappe.user.has_role("HSE Officer") || frappe.user.has_role("Managing Director"))) return;
		frm.add_custom_button(__("Approve"), () => frappe.call("chemical_erp.regulatory_compliance.controlled.decide", { name: frm.doc.name, approve: 1 })
			.then(() => frm.reload_doc())).addClass("btn-primary");
		frm.add_custom_button(__("Reject"), () => frappe.call("chemical_erp.regulatory_compliance.controlled.decide", { name: frm.doc.name, approve: 0 })
			.then(() => frm.reload_doc()));
	},
});
