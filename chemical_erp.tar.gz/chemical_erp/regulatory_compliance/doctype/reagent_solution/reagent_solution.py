from frappe.model.document import Document
from frappe.utils import getdate, today


class ReagentSolution(Document):
	def validate(self):
		if self.status != "Discarded":
			self.status = "Expired" if getdate(self.expires_on) < getdate(today()) else "Valid"
