from frappe.model.document import Document
from frappe.utils import add_months, cint

from chemical_erp.utils import get_settings


class EmergencyDrill(Document):
	def validate(self):
		self.next_drill_due = add_months(self.drill_date, cint(get_settings().get("drill_frequency_months")) or 6)
