from frappe.model.document import Document
from frappe.utils import add_months, flt

DEFAULT_MONTHS = (0, 1, 3, 6, 9, 12, 18, 24)


class StabilityStudy(Document):
	def validate(self):
		if not self.points:
			for m in DEFAULT_MONTHS:
				self.append("points", {"month": m})
		for p in self.points:
			p.due_date = add_months(self.start_date, p.month)
			if p.assay not in (None, "") and p.tested_on:
				ok = (not self.spec_min or flt(p.assay) >= flt(self.spec_min)) and (not self.spec_max or flt(p.assay) <= flt(self.spec_max))
				p.within_spec = "Yes" if ok else "No"
		tested = sorted((p for p in self.points if p.within_spec), key=lambda p: p.month)
		supported = 0
		for p in tested:
			if p.within_spec == "Yes":
				supported = p.month
			else:
				break
		self.supported_shelf_life_months = supported
		if all(p.tested_on for p in self.points):
			self.status = "Completed"
