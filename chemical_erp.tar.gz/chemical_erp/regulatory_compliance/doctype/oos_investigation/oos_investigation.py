import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import now_datetime


class OOSInvestigation(Document):
	def validate(self):
		if not self.failed_parameters:
			self.failed_parameters = ", ".join(frappe.get_all("Quality Inspection Reading",
			                                                  filters={"parent": self.quality_inspection, "status": "Rejected"}, pluck="specification"))
		before = self.get_doc_before_save()
		if self.status == "Closed" and (not before or before.status != "Closed"):
			checks = ("calculation_checked", "instrument_checked", "reagents_checked", "sample_checked", "method_followed")
			if not all(self.get(c) for c in checks):
				frappe.throw(_("Complete every Phase 1 laboratory check before closing."))
			if not self.outcome:
				frappe.throw(_("Record the outcome: laboratory error (retest) or confirmed out of specification."))
			if self.outcome == "Laboratory Error: Retest" and not self.retest_inspection:
				frappe.throw(_("Link the retest inspection."))
			self.closed_by, self.closed_on = frappe.session.user, now_datetime()


def open_if_failed(qi, method=None):
	"""A failed reading opens an OOS investigation, so a rejection is never decided on a laboratory error."""
	if qi.docstatus != 0 or not any(r.status == "Rejected" for r in qi.get("readings") or []):
		return
	if qi.is_new() or frappe.db.exists("OOS Investigation", {"quality_inspection": qi.name}):
		return
	frappe.get_doc({"doctype": "OOS Investigation", "quality_inspection": qi.name,
	                "findings": _("Opened automatically: one or more readings are out of specification.")}).insert(ignore_permissions=True)


def confirmed(qi_name):
	return frappe.db.exists("OOS Investigation", {"quality_inspection": qi_name, "status": "Closed",
	                                              "outcome": "Confirmed Out of Specification"})
