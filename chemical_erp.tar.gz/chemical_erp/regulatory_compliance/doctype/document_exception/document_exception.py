import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, date_diff, getdate, now_datetime, today

from chemical_erp.utils import MD_ROLE, has_role

MAX_DAYS = 14


class DocumentException(Document):
	"""A one-off release of a delivery without its SDS or certificate. Only the MD decides; it covers one delivery."""

	def validate(self):
		before = self.get_doc_before_save()
		old = before.status if before else "Requested"
		if self.status != old and self.status in ("Approved", "Rejected") and not (has_role(MD_ROLE) or frappe.session.user == "Administrator"):
			frappe.throw(_("Only the Managing Director can approve or reject a document exception."), frappe.PermissionError)
		# once decided, what the MD approved is fixed: product, customer, document and end date
		if before and old in ("Approved", "Used", "Rejected", "Expired") and not has_role(MD_ROLE) \
				and any(self.has_value_changed(f) for f in ("item_code", "customer", "document", "valid_until")):
			frappe.throw(_("A decided exception cannot be changed. Ask for a new one."))
		self.valid_until = self.valid_until or add_days(today(), 7)
		# at most 14 days, counted from the MD's decision (from today while it is still a request)
		start = getdate(self.decided_on) if self.get("decided_on") else getdate(today())
		if date_diff(self.valid_until, start) > MAX_DAYS and self.status in ("Requested", "Approved"):
			frappe.throw(_("An exception can last at most {0} days.").format(MAX_DAYS))

	def after_insert(self):
		from chemical_erp.people_management.positions import md_users
		from chemical_erp.utils import notify

		if self.status == "Requested":
			notify(md_users(), self.doctype, self.name, _("{0} asks to deliver {1} without its {2}: {3}").format(
				frappe.utils.get_fullname(self.owner), self.item_code, self.document, (self.reason or "")[:150]), priority="High")

	@frappe.whitelist()
	def decide(self, approve):
		if not (has_role(MD_ROLE) or frappe.session.user == "Administrator"):
			frappe.throw(_("Only the Managing Director decides."), frappe.PermissionError)
		self.status = "Approved" if frappe.utils.cint(approve) else "Rejected"
		self.decided_by, self.decided_on = frappe.session.user, now_datetime()
		self.save()
		from chemical_erp.utils import notify

		notify(self.owner, self.doctype, self.name, _("Document exception {0} for {1}: {2}").format(self.name, self.item_code, self.status))
		return self.status


def expire():
	for name in frappe.get_all("Document Exception", filters={"status": ["in", ["Requested", "Approved"]], "valid_until": ["<", today()]}, pluck="name"):
		frappe.db.set_value("Document Exception", name, "status", "Expired")
