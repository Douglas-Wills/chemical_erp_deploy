frappe.ui.form.on("Document Exception", {
	refresh(frm) {
		if (frm.is_new() || frm.doc.status !== "Requested" || !frappe.user.has_role("Managing Director")) return;
		frm.add_custom_button(__("Approve (one delivery)"), () => frm.call("decide", { approve: 1 }).then(() => frm.reload_doc())).addClass("btn-primary");
		frm.add_custom_button(__("Reject"), () => frm.call("decide", { approve: 0 }).then(() => frm.reload_doc()));
	},
});
