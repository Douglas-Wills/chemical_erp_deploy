frappe.query_reports["Controlled Chemicals Register"] = {
	filters: [
		{ fieldname: "from_date", label: __("From"), fieldtype: "Date", default: frappe.datetime.add_months(frappe.datetime.get_today(), -12) },
		{ fieldname: "to_date", label: __("To"), fieldtype: "Date", default: frappe.datetime.get_today() },
		{ fieldname: "substance", label: __("Substance"), fieldtype: "Link", options: "Substance Register",
		  get_query: () => ({ filters: { is_controlled: 1 } }) },
	],
};
