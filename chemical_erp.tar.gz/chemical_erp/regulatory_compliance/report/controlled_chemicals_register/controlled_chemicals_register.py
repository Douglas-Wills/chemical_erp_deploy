"""Every delivery of a controlled chemical: who, what, how much, under which declaration and licence."""

import frappe
from frappe import _
from frappe.utils import add_months, today

from chemical_erp.regulatory_compliance.controlled import declaration, kg, substance_of


def execute(filters=None):
	f = frappe._dict(filters or {})
	since, until = f.get("from_date") or add_months(today(), -12), f.get("to_date") or today()
	data = []
	for dn in frappe.get_all("Delivery Note", filters={"docstatus": 1, "posting_date": ["between", [since, until]]},
	                         fields=["name", "posting_date", "customer", "customer_name", "is_return"], order_by="posting_date asc"):
		for row in frappe.get_all("Delivery Note Item", filters={"parent": dn.name},
		                          fields=["item_code", "item_name", "qty", "stock_qty", "uom", "batch_no"]):
			sub = substance_of(row.item_code)
			if not sub or (f.get("substance") and f.substance != sub):
				continue
			d = declaration(dn.customer, sub, dn.posting_date)
			data.append({"date": dn.posting_date, "delivery_note": dn.name, "customer": dn.customer, "customer_name": dn.customer_name,
			             "substance": sub, "item_code": row.item_code, "batch": row.batch_no, "qty": row.qty, "uom": row.uom,
			             "kg": kg(frappe._dict(row)) * (-1 if dn.is_return else 1), "declaration": d.name if d else None,
			             "licence": d.licence_number if d else None,
			             "use": frappe.db.get_value("End-User Declaration", d.name, "intended_use") if d else _("NO DECLARATION")})
	c = lambda n, l, t="Data", w=120, o=None: {"fieldname": n, "label": l, "fieldtype": t, "width": w, **({"options": o} if o else {})}
	return [c("date", _("Date"), "Date", 95), c("delivery_note", _("Delivery Note"), "Link", 140, "Delivery Note"),
	        c("customer_name", _("Customer"), "Data", 180), c("substance", _("Substance"), "Link", 150, "Substance Register"),
	        c("item_code", _("Product"), "Link", 130, "Item"), c("batch", _("Batch"), "Link", 120, "Batch"), c("qty", _("Qty"), "Float", 80),
	        c("uom", _("Unit"), "Data", 70), c("kg", _("kg"), "Float", 90), c("declaration", _("Declaration"), "Link", 130, "End-User Declaration"),
	        c("licence", _("Licence No."), "Data", 120), c("use", _("Declared Use"), "Data", 220)], data
