"""Products missing their SDS or certificates, worst and most-sold first."""

import frappe
from frappe import _

from chemical_erp.regulatory_compliance.documents import gaps


def execute(filters=None):
	f = frappe._dict(filters or {})
	data = gaps(only_problems=not f.get("show_all"))
	if f.get("profile"):
		data = [r for r in data if r["profile"] == f.profile]
	c = lambda n, l, t="Data", w=140, o=None: {"fieldname": n, "label": l, "fieldtype": t, "width": w, **({"options": o} if o else {})}
	columns = [c("item_code", _("Product"), "Link", 150, "Item"), c("item_name", _("Name"), "Data", 220), c("profile", _("Document Profile"), "Data", 180),
	           c("sds", _("SDS"), "Data", 90), c("sds_file", _("SDS File"), "Link", 120, "SDS File"),
	           c("batches_without_certificate", _("Batches Without Certificate"), "Int", 110), c("problems", _("What Is Missing"), "Data", 340),
	           c("stock_value", _("Stock Value"), "Currency", 120), c("sold_90_days", _("Sold (90 days, stock units)"), "Float", 120)]
	blocking = sum(1 for r in data if r["severity"] >= 3)
	summary = [{"label": _("Products blocked from delivery"), "value": blocking, "indicator": "Red" if blocking else "Green", "datatype": "Int"},
	           {"label": _("Products with gaps"), "value": len([r for r in data if r["problems"]]), "indicator": "Orange", "datatype": "Int"}]
	return columns, data, None, None, summary
