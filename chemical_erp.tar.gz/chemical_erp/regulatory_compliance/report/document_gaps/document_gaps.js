frappe.query_reports["Document Gaps"] = {
	filters: [
		{ fieldname: "profile", label: __("Document Profile"), fieldtype: "Select",
		  options: ["", "Hazardous - Made by Us", "Hazardous - Bought In", "Non-hazardous Industrial", "Consumer (Brave Home)", "Service / Equipment / PPE"] },
		{ fieldname: "show_all", label: __("Show products with no gaps too"), fieldtype: "Check" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (data && column.fieldname === "problems" && data.severity >= 3) value = `<span style="color:#b42318;font-weight:700">${value}</span>`;
		return value;
	},
	onload(report) {
		report.page.add_inner_button(__("Classify Products"), () =>
			frappe.call("chemical_erp.regulatory_compliance.documents.classify_products").then(({ message }) => {
				frappe.msgprint(Object.entries(message || {}).map(([k, v]) => `${frappe.utils.escape_html(k)}: <b>${v}</b>`).join("<br>") || __("All products already classified."),
					__("Products classified"));
				report.refresh();
			}));
	},
};
