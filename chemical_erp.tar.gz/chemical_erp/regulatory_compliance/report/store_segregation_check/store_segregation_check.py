"""Stores holding chemicals that must be kept apart, as of now."""

from frappe import _

from chemical_erp.regulatory_compliance.storage import conflicts


def execute(filters=None):
	c = lambda n, l, t="Data", w=150, o=None: {"fieldname": n, "label": l, "fieldtype": t, "width": w, **({"options": o} if o else {})}
	return [c("warehouse", _("Store"), "Link", 180, "Warehouse"), c("class_a", _("Class")), c("item_a", _("Product"), "Link", 140, "Item"),
	        c("class_b", _("Stored With")), c("item_b", _("Product"), "Link", 140, "Item"), c("segregated", _("Segregated Bays"), "Check", 90),
	        c("reason", _("Why It Matters"), "Data", 320)], conflicts()
