"""GHS product labels (Regulatory Compliance > Substances and SDS).

The label is printed from a Batch ('GHS Label' print format) or, for pre-printed stock labels, from an Item.
Hazard data comes from the item's Substance Register entry: signal word, pictograms, H and P statements, first aid,
UN number. Consumer and non-hazardous products get a plain product label with the general safety line.
"""

import frappe
from frappe.utils import escape_html, formatdate

RED = "#e00000"


def _diamond(glyph):
	return ('<svg viewBox="0 0 100 100" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">'
	        f'<rect x="18" y="18" width="64" height="64" transform="rotate(45 50 50)" fill="#fff" stroke="{RED}" stroke-width="7"/>'
	        f'<g fill="#000" stroke="#000">{glyph}</g></svg>')


# Simplified drawings of the nine GHS symbols, inside the red diamond the regulation requires.
GLYPHS = {
	"GHS01": '<circle cx="50" cy="56" r="10"/><path d="M50 30 L53 44 L64 36 L58 48 L72 50 L58 54 L66 66 L52 60 L50 74 L46 60 L34 68 L42 55 L28 52 L42 48 L34 36 L46 44 Z" stroke-width="1"/>',
	"GHS02": '<path d="M50 26 C61 40 67 49 63 61 C60 71 40 72 37 61 C35 52 42 47 46 38 C47 46 50 48 52 47 C55 40 52 33 50 26 Z" stroke-width="1"/><rect x="32" y="68" width="36" height="4"/>',
	"GHS03": '<circle cx="50" cy="60" r="10" fill="none" stroke-width="4"/><path d="M50 26 C58 36 61 42 58 49 C56 53 44 53 42 49 C40 43 45 38 50 26 Z" stroke-width="1"/><rect x="32" y="71" width="36" height="3"/>',
	"GHS04": '<rect x="30" y="44" width="40" height="18" rx="9" transform="rotate(-20 50 53)" stroke-width="1"/><rect x="66" y="38" width="6" height="8" transform="rotate(-20 50 53)"/>',
	"GHS05": '<rect x="32" y="30" width="7" height="16" transform="rotate(-30 35 38)"/><rect x="56" y="30" width="7" height="16" transform="rotate(30 60 38)"/>'
	         '<circle cx="34" cy="52" r="2"/><circle cx="64" cy="52" r="2"/><rect x="28" y="58" width="16" height="5"/><path d="M54 60 h18 v6 h-18 z" stroke-width="1"/><rect x="26" y="68" width="48" height="5"/>',
	"GHS06": '<circle cx="50" cy="44" r="12"/><circle cx="45" cy="43" r="3" fill="#fff" stroke="none"/><circle cx="55" cy="43" r="3" fill="#fff" stroke="none"/>'
	         '<line x1="32" y1="58" x2="68" y2="72" stroke-width="5"/><line x1="68" y1="58" x2="32" y2="72" stroke-width="5"/>',
	"GHS07": '<rect x="45" y="28" width="10" height="30" rx="3"/><circle cx="50" cy="68" r="6"/>',
	"GHS08": '<circle cx="50" cy="32" r="6"/><path d="M38 72 V48 Q50 40 62 48 V72 Z" stroke-width="1"/><path d="M50 50 L53 58 L61 58 L55 63 L57 70 L50 66 L43 70 L45 63 L39 58 L47 58 Z" fill="#fff" stroke="none"/>',
	"GHS09": '<path d="M36 70 V44 M36 50 L28 42 M36 54 L44 46" stroke-width="3" fill="none"/><ellipse cx="58" cy="64" rx="10" ry="5"/><path d="M68 64 L74 59 V69 Z"/><rect x="26" y="72" width="50" height="3"/>',
}


def pictogram_svg(code):
	code = (code or "").split(" ")[0].strip().upper()
	return _diamond(GLYPHS.get(code, '<text x="50" y="58" font-size="14" text-anchor="middle" font-family="Arial">' + escape_html(code) + "</text>"))


def label_data(doc, net_content=None):
	"""Jinja: everything a label prints, for a Batch or an Item."""
	batch = doc if doc.doctype == "Batch" else None
	item = frappe.get_cached_doc("Item", doc.item if batch else doc.name)
	sub = frappe.get_cached_doc("Substance Register", item.substance) if item.get("substance") else None
	from chemical_erp.company import company_block, company_name, emergency_phone, company_phone

	hazardous = bool(sub and (sub.signal_word or sub.pictograms))
	pictos = [{"code": p.pictogram.split(" ")[0], "name": " ".join(p.pictogram.split(" ")[1:]), "svg": pictogram_svg(p.pictogram)}
	          for p in (sub.pictograms if sub else [])]
	lines = lambda t: [x.strip() for x in (t or "").replace("\r", "").split("\n") if x.strip()]
	p_statements = lines(sub.precautionary_statements) if sub else []
	if not hazardous and not p_statements:
		p_statements = ["Keep out of reach of children.", "Read the label before use."]
	url = frappe.utils.get_url("/my-documents")
	from chemical_erp.doc_qr import qr_text_image

	return frappe._dict(
		product=item.item_name, description=item.get("coa_description") or "", hazardous=hazardous,
		signal_word=(sub.signal_word if sub else "") or "", pictograms=pictos, h_statements=lines(sub.hazard_statements) if sub else [],
		p_statements=p_statements, first_aid=(sub.first_aid if sub else "") or "",
		un_line=(f"{sub.un_number} {sub.proper_shipping_name or ''}, Class {sub.hazard_class or ''}"
		         + (f", PG {sub.packing_group}" if sub.packing_group else "")) if sub and sub.un_number else "",
		batch=batch.name if batch else "", made=formatdate(batch.manufacturing_date) if batch and batch.manufacturing_date else "",
		expiry=formatdate(batch.expiry_date) if batch and batch.expiry_date else "", net_content=net_content or "",
		company=company_name(doc), address=" · ".join(company_block(doc, "letter")),
		phone=company_phone(doc), emergency=emergency_phone(doc), qr=qr_text_image(url, 18), qr_hint="SDS and certificates: " + url)
