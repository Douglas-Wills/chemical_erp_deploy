"""Controlled and sensitive chemicals (explosive and drug precursors, poisons, licensed chemicals).

- A substance is marked 'Controlled' in the Substance Register; every item made of it is controlled.
- Selling it needs an approved End-User Declaration from the customer for that substance: intended use, site,
  annual limit, signed declaration, and a licence copy above the substance's licence threshold.
- Sales orders show warnings and unusual orders are flagged to the MD and HSE (new customer, quantity far above the
  customer's usual, cash or mobile money); delivery stops without a valid declaration or beyond the annual limit.
- 'Controlled Chemicals Register' lists every delivery for the authorities.
"""

import frappe
from frappe import _
from frappe.utils import add_days, add_years, flt, getdate, now_datetime, today

from chemical_erp.utils import MD_ROLE, has_role


def substance_of(item_code):
	sub = frappe.get_cached_value("Item", item_code, "substance")
	if sub and frappe.db.get_value("Substance Register", sub, "is_controlled"):
		return sub
	return None


def kg(row):
	from chemical_erp.controls.manufacturing import to_kg

	return to_kg(row.item_code, row.get("stock_qty") or row.qty)


def declaration(customer, substance, on=None):
	on = getdate(on or today())
	for d in frappe.get_all("End-User Declaration", filters={"customer": customer, "substance": substance, "status": "Approved"},
	                        fields=["name", "valid_from", "valid_to", "annual_limit_kg", "licence_number", "licence_copy", "licence_expiry"],
	                        order_by="valid_to desc"):
		if getdate(d.valid_from) <= on <= getdate(d.valid_to):
			return d
	return None


def delivered_kg(customer, substance, days=365, exclude=None):
	from chemical_erp.controls.manufacturing import to_kg

	items = frappe.get_all("Item", filters={"substance": substance}, pluck="name")
	if not items:
		return 0.0
	rows = frappe.db.sql("""select dni.item_code, dni.stock_qty from `tabDelivery Note Item` dni join `tabDelivery Note` dn on dn.name = dni.parent
		where dn.docstatus = 1 and dn.is_return = 0 and dn.customer = %s and dni.item_code in %s and dn.posting_date >= %s and dn.name != %s""",
	                     (customer, tuple(items), add_days(today(), -days), exclude or ""), as_dict=True)
	return sum(to_kg(r.item_code, r.stock_qty) for r in rows)


def problems(doc):
	"""Blocking problems for a delivery (Delivery Note, or Sales Invoice that moves stock)."""
	out = []
	by_sub = {}
	for row in doc.items:
		sub = substance_of(row.item_code)
		if sub:
			by_sub.setdefault(sub, []).append(row)
	for sub, rows in by_sub.items():
		qty = sum(kg(r) for r in rows)
		d = declaration(doc.customer, sub, doc.get("posting_date"))
		if not d:
			out.append(_("{0} is a controlled chemical: {1} has no approved End-User Declaration for it.").format(sub, doc.customer))
			continue
		threshold = flt(frappe.db.get_value("Substance Register", sub, "licence_above_kg"))
		if qty > threshold and not (d.licence_copy and d.licence_number):
			out.append(_("{0}: {1:.0f} kg needs the customer's licence on declaration {2}.").format(sub, qty, d.name))
		if d.licence_expiry and getdate(d.licence_expiry) < getdate(today()):
			out.append(_("{0}: the customer's licence on {1} expired on {2}.").format(sub, d.name, d.licence_expiry))
		used = delivered_kg(doc.customer, sub, exclude=doc.name)
		if used + qty > flt(d.annual_limit_kg):
			out.append(_("{0}: this delivery ({1:.0f} kg) takes {2} to {3:.0f} kg in 12 months, above the declared {4:.0f} kg.").format(
				sub, qty, doc.customer, used + qty, flt(d.annual_limit_kg)))
	return out


def red_flags(doc):
	"""Signs that an order may be diverted: told to the MD and HSE, and the order goes to the Sales Manager."""
	flags = []
	created = frappe.db.get_value("Customer", doc.customer, "creation")
	for row in doc.items:
		sub = substance_of(row.item_code)
		if not sub:
			continue
		qty = kg(row)
		if created and getdate(created) > getdate(add_days(today(), -30)):
			flags.append(_("{0}: new customer (registered in the last 30 days)").format(sub))
		history = delivered_kg(doc.customer, sub, days=365)
		if history and qty > 3 * history / 12 and qty > 50:
			flags.append(_("{0}: {1:.0f} kg is over three times the customer's usual monthly quantity").format(sub, qty))
		if not history and qty > 200:
			flags.append(_("{0}: first order and a large quantity ({1:.0f} kg)").format(sub, qty))
	terms = (doc.get("payment_terms_template") or "") + " " + (doc.get("mode_of_payment") or "")
	if flags and any(w in terms.lower() for w in ("cash", "mobile")):
		flags.append(_("paid in cash or mobile money"))
	return list(dict.fromkeys(flags))


def sales_order_check(doc, method=None):
	"""Quotation / Sales Order: warn early; flag unusual orders."""
	customer = doc.get("customer") or (doc.get("party_name") if doc.get("quotation_to") == "Customer" else None)
	if not customer:
		return
	notes = []
	for row in doc.get("items") or []:
		sub = substance_of(row.item_code)
		if sub and not declaration(customer, sub):
			notes.append(_("{0} is controlled: an approved End-User Declaration from {1} is needed before delivery.").format(row.item_code, customer))
	if doc.doctype == "Sales Order":
		flags = red_flags(doc)
		if flags:
			if doc.meta.has_field("approval_level") and doc.get("approval_level") in (None, "", "None"):
				doc.approval_level = "Manager"
			notes.append(_("Unusual order for a controlled chemical: {0}. It needs the Sales Manager's approval, and the MD and HSE are told.").format(
				"; ".join(flags)))
			doc.flags.controlled_flags = flags
	if notes:
		frappe.msgprint("<br>".join(dict.fromkeys(notes)), title=_("Controlled chemicals"), indicator="orange")


def sales_order_flagged(doc, method=None):
	if doc.flags.get("controlled_flags"):
		from chemical_erp.people_management.positions import md_users
		from chemical_erp.utils import notify, users_with_role

		notify(md_users() + users_with_role("HSE Officer"), doc.doctype, doc.name,
		       _("Controlled chemical order {0} from {1} flagged: {2}").format(doc.name, doc.customer, "; ".join(doc.flags.controlled_flags)),
		       priority="High")


def validate_declaration(doc, method=None):
	if not frappe.db.get_value("Substance Register", doc.substance, "is_controlled"):
		frappe.throw(_("{0} is not marked as controlled in the Substance Register.").format(doc.substance))
	if getdate(doc.valid_to) > getdate(add_years(doc.valid_from, 1)):
		frappe.throw(_("A declaration lasts at most one year. Renew it yearly."))
	before = doc.get_doc_before_save()
	if before and before.status != doc.status and doc.status in ("Approved", "Rejected", "Suspended") and \
			not (has_role(MD_ROLE) or has_role("HSE Officer") or frappe.session.user == "Administrator"):
		frappe.throw(_("Only the HSE Officer or the MD approve declarations."), frappe.PermissionError)
	doc.used_kg_12m = delivered_kg(doc.customer, doc.substance)


@frappe.whitelist()
def decide(name, approve):
	if not (has_role(MD_ROLE) or has_role("HSE Officer") or frappe.session.user == "Administrator"):
		frappe.throw(_("Only the HSE Officer or the MD approve declarations."), frappe.PermissionError)
	d = frappe.get_doc("End-User Declaration", name)
	if d.owner == frappe.session.user and not has_role(MD_ROLE):
		frappe.throw(_("You entered this declaration, so someone else must approve it."))
	d.status = "Approved" if frappe.utils.cint(approve) else "Rejected"
	d.approved_by, d.approved_on = frappe.session.user, now_datetime()
	d.save()
	return d.status


def daily():
	"""Declarations past their date expire; those ending within 30 days are flagged to Sales and HSE."""
	from chemical_erp.utils import notify, users_with_role

	for d in frappe.get_all("End-User Declaration", filters={"status": "Approved", "valid_to": ["<", today()]}, pluck="name"):
		frappe.db.set_value("End-User Declaration", d, "status", "Expired")
	for d in frappe.get_all("End-User Declaration", filters={"status": "Approved", "valid_to": add_days(today(), 30)},
	                        fields=["name", "customer", "substance"]):
		notify(users_with_role("Sales Manager") + users_with_role("HSE Officer"), "End-User Declaration", d.name,
		       _("End-user declaration for {0} ({1}) expires in 30 days: ask for a renewal.").format(d.customer, d.substance))
