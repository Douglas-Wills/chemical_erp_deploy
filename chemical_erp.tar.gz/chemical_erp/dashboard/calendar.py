"""Personal calendar: meetings, appointments and field visits (ERPNext Events), plus the dates the system
already knows for each person: training sessions, audits they lead, maintenance jobs, import arrivals."""

import frappe
from frappe import _
from frappe.utils import add_days, get_datetime, now_datetime, today


def validate_event(doc, method=None):
	if doc.get("event_kind") == "Field Visit" and doc.get("visit_outcome") == "Follow-up Needed" and not doc.get("follow_up_date"):
		frappe.throw(_("Set the follow-up date."))
	if doc.get("attendees") and doc.event_type == "Public":
		doc.event_type = "Private"  # attendees see it through sharing; others do not


def share_with_attendees(doc, method=None):
	from frappe.share import add as share

	for a in doc.get("attendees") or []:
		if a.user and a.user != doc.owner and not frappe.db.exists("DocShare", {"share_doctype": "Event", "share_name": doc.name, "user": a.user}):
			share("Event", doc.name, a.user, read=1, write=0, notify=1, flags={"ignore_share_permission": True})


@frappe.whitelist()
def create_event(subject, event_kind, starts_on, ends_on=None, party_type=None, party=None, location=None, attendees=None, description=None):
	attendees = frappe.parse_json(attendees) if attendees else []
	ev = frappe.get_doc({"doctype": "Event", "subject": subject, "event_kind": event_kind, "starts_on": starts_on,
	                     "ends_on": ends_on or None, "party_type": party_type or None, "party": party or None,
	                     "location": location, "description": description, "event_type": "Private",
	                     "event_category": "Meeting" if event_kind == "Meeting" else "Event",
	                     "attendees": [{"user": u} for u in attendees if u]})
	ev.insert()
	return ev.name


def agenda(user=None, days=14):
	user = user or frappe.session.user
	start, end = now_datetime().replace(hour=0, minute=0, second=0), get_datetime(add_days(today(), days)).replace(hour=23, minute=59)
	items = []
	shared = frappe.get_all("DocShare", filters={"share_doctype": "Event", "user": user}, pluck="share_name")
	attending = frappe.get_all("Calendar Attendee", filters={"parenttype": "Event", "user": user}, pluck="parent")
	names = set(shared) | set(attending)
	own = frappe.get_all("Event", filters={"owner": user, "starts_on": ["between", [start, end]]}, pluck="name")
	names |= set(own)
	if names:
		for e in frappe.get_all("Event", filters={"name": ["in", list(names)], "starts_on": ["between", [start, end]]},
		                        fields=["name", "subject", "starts_on", "ends_on", "event_kind", "party", "location"]):
			items.append({"when": e.starts_on, "title": e.subject, "kind": e.event_kind or "Meeting",
			              "detail": " · ".join(x for x in (e.party, e.location) if x), "doctype": "Event", "name": e.name})
	emp = frappe.db.get_value("Employee", {"user_id": user}, "name")
	if frappe.db.exists("DocType", "Training Event"):
		events = frappe.get_all("Training Event", filters={"docstatus": 1, "start_time": ["between", [start, end]]},
		                        fields=["name", "event_name", "start_time", "trainer_email"])
		mine = set(frappe.get_all("Training Event Employee", filters={"employee": emp}, pluck="parent")) if emp else set()
		for t in events:
			if t.name in mine or t.trainer_email == user:
				items.append({"when": t.start_time, "title": t.event_name, "kind": "Training", "detail": "", "doctype": "Training Event", "name": t.name})
	for a in frappe.get_all("Internal Audit", filters={"docstatus": 0, "lead_auditor": user, "scheduled_date": ["between", [start.date(), end.date()]]},
	                        fields=["name", "quarter", "scheduled_date"]):
		items.append({"when": get_datetime(a.scheduled_date), "title": _("Internal audit {0}").format(a.quarter), "kind": "Audit", "detail": "",
		              "doctype": "Internal Audit", "name": a.name})
	for j in frappe.get_all("Maintenance Job", filters={"assigned_to": user, "status": ["!=", "Done"], "due_date": ["between", [start.date(), end.date()]]},
	                        fields=["name", "equipment", "due_date", "pm_task"]):
		items.append({"when": get_datetime(j.due_date), "title": _("Maintenance: {0}").format(j.pm_task or j.equipment), "kind": "Maintenance",
		              "detail": j.equipment, "doctype": "Maintenance Job", "name": j.name})
	if "Purchase User" in frappe.get_roles(user) or "Stock User" in frappe.get_roles(user):
		for i in frappe.get_all("Import Shipment", filters={"status": ["in", ["Paid", "Shipped", "At Port"]], "eta": ["between", [start.date(), end.date()]]},
		                        fields=["name", "supplier", "eta"]):
			items.append({"when": get_datetime(i.eta), "title": _("Import arriving: {0}").format(i.supplier), "kind": "Import", "detail": i.name,
			              "doctype": "Import Shipment", "name": i.name})
	items.sort(key=lambda x: get_datetime(x["when"]))
	for i in items:
		i["when"] = str(i["when"])
	return items
