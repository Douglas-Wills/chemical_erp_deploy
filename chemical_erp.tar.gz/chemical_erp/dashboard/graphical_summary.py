"""Graphical Summary API for Chemical ERP:
Provides structured dataset for Charts, Bargraphs, Piecharts, Interactive Calendar,
Live Notice Board, and Section KPI summaries across all operational sections.
All data is dynamically calculated from actual database records.
"""

import datetime
import frappe
from frappe import _
from frappe.utils import add_days, cint, flt, get_first_day, getdate, now_datetime, today
from chemical_erp.dashboard.calendar import agenda
from chemical_erp.dashboard.data import MD, build_sections, card, get_dashboard

CARDS_CACHE_SECONDS = 60


def documents_section():
	"""Document vault and secure-sharing cards (only the record types this user may read)."""
	if not frappe.db.exists("DocType", "Chemical Document"):
		return None
	cards = [
		card(_("Document vault (total files)"), "Chemical Document", {}, None),
		card(_("Active shared links (time-restricted)"), "Document Share Link", {"status": "Active"}, "blue"),
		card(_("Expired access links"), "Document Share Link", {"status": "Expired"}, "orange"),
	]
	if frappe.db.exists("DocType", "Document Access Log"):
		cards.append(card(_("Access audit logs recorded"), "Document Access Log", {}, None))
	cards = [c for c in cards if c]
	return {"key": "documents", "title": _("Documents & Secure Storage"), "cards": cards} if cards else None


@frappe.whitelist()
def get_dashboard_cards(refresh=0):
	"""Cards-only payload for the main dashboard. Cached per user for a minute; refresh=1 recomputes."""
	user = frappe.session.user
	key = f"chemical_erp:dashboard_cards:{user}"
	cache = frappe.cache() if callable(frappe.cache) else frappe.cache
	if not cint(refresh):
		cached = cache.get_value(key)
		if cached:
			return cached

	roles = set(frappe.get_roles(user))
	is_md = MD in roles or user == "Administrator"
	sections = build_sections(user, roles, is_md)
	try:
		docs = documents_section()
		if docs:
			sections.append(docs)
	except Exception:
		frappe.log_error(title="Dashboard documents section failed", message=frappe.get_traceback())

	out = {"user": frappe.utils.get_fullname(user), "is_md": is_md, "sections": sections,
	       "generated_at": str(now_datetime())}
	cache.set_value(key, out, expires_in_sec=CARDS_CACHE_SECONDS)
	return out


def get_monthly_sales_chart():
	"""Last 6 months real sales and revenue trend."""
	months_data = frappe.db.sql("""
		select date_format(posting_date, '%b %Y') as month,
		       date_format(posting_date, '%Y-%m') as yyyymm,
		       sum(base_net_total) as revenue,
		       count(name) as invoices
		from `tabSales Invoice`
		where docstatus = 1 and is_return = 0 and posting_date >= date_sub(curdate(), interval 5 month)
		group by yyyymm
		order by yyyymm asc
	""", as_dict=True)

	currency = frappe.db.get_default("currency") or "UGX"

	# Build a continuous 6-month timeline ending at current month
	today_dt = getdate(today())
	timeline = []
	for i in range(5, -1, -1):
		m = today_dt.month - i
		y = today_dt.year
		while m <= 0:
			m += 12
			y -= 1
		d = datetime.date(y, m, 1)
		timeline.append((d.strftime("%Y-%m"), d.strftime("%b %Y")))

	sales_by_month = {m["yyyymm"]: m for m in (months_data or [])}

	labels = []
	revenue = []
	invoices = []
	target = []

	valid_revs = [flt(m["revenue"]) for m in (months_data or []) if flt(m.get("revenue")) > 0]
	avg_rev = (sum(valid_revs) / len(valid_revs)) if valid_revs else 0.0

	for yyyymm, month_label in timeline:
		labels.append(month_label)
		row = sales_by_month.get(yyyymm)
		rev = flt(row["revenue"]) if row else 0.0
		inv = int(row["invoices"]) if row else 0
		revenue.append(rev)
		invoices.append(inv)
		target_val = round(max(rev * 1.10, avg_rev * 1.05)) if (rev or avg_rev) else 0.0
		target.append(target_val)

	growth_pct = 0.0
	if len(revenue) >= 2 and revenue[-2] > 0:
		growth_pct = round(((revenue[-1] - revenue[-2]) / revenue[-2]) * 100, 1)
	elif len(revenue) >= 2 and revenue[-1] > 0:
		growth_pct = 100.0

	return {
		"title": _("Monthly Sales & Revenue Performance"),
		"labels": labels,
		"currency": currency,
		"series": [
			{"name": _("Actual Revenue"), "type": "bar", "data": revenue, "color": "#008bc6"},
			{"name": _("Target Revenue"), "type": "line", "data": target, "color": "#10b981"},
		],
		"invoices_count": invoices,
		"total_revenue": sum(revenue),
		"growth_pct": growth_pct
	}


def get_production_maintenance_chart():
	"""Production batches, work orders and maintenance status bar graph."""
	wo_completed = frappe.db.count("Work Order", {"status": "Completed"})
	wo_in_process = frappe.db.count("Work Order", {"status": "In Process"})
	wo_draft = frappe.db.count("Work Order", {"status": ["in", ["Draft", "Not Started"]]})
	wo_material_short = frappe.db.count("Work Order", {"material_status": ["in", ["Order Needed", "Late Supplies"]]}) if frappe.db.has_column("Work Order", "material_status") else 0

	maint_done = frappe.db.count("Maintenance Job", {"status": "Done"})
	maint_active = frappe.db.count("Maintenance Job", {"status": ["in", ["Open", "In Progress"]]})
	maint_overdue = frappe.db.count("Maintenance Job", {"status": ["!=", "Done"], "due_date": ["<", today()]})

	return {
		"title": _("Production & Plant Maintenance Operations"),
		"categories": [
			_("Work Orders Completed"),
			_("In Process"),
			_("Planned / Draft"),
			_("Material Shortage"),
			_("PM Jobs Completed"),
			_("PM Active / Open"),
			_("Maintenance Overdue")
		],
		"values": [wo_completed, wo_in_process, wo_draft, wo_material_short, maint_done, maint_active, maint_overdue],
		"colors": ["#10b981", "#0284c7", "#64748b", "#f59e0b", "#059669", "#06b6d4", "#ef4444"]
	}


def get_cash_flow_chart():
	"""Receivables, Payables, Bank balances comparison."""
	overdue_rec = flt(frappe.db.sql("select sum(outstanding_amount) from `tabSales Invoice` where docstatus=1 and outstanding_amount>0 and due_date < %s", today())[0][0])
	total_rec = flt(frappe.db.sql("select sum(outstanding_amount) from `tabSales Invoice` where docstatus=1 and outstanding_amount>0")[0][0])
	total_pay = flt(frappe.db.sql("select sum(outstanding_amount) from `tabPurchase Invoice` where docstatus=1 and outstanding_amount>0")[0][0])
	bank = flt(frappe.db.sql("""select sum(gle.debit - gle.credit) from `tabGL Entry` gle join `tabAccount` a on a.name = gle.account
		where gle.is_cancelled=0 and a.account_type in ('Bank','Cash')""")[0][0])

	return {
		"title": _("Liquidity & Cash Flow Overview"),
		"categories": [_("Cash & Bank Available"), _("Total Receivables"), _("Overdue Receivables"), _("Supplier Payables")],
		"values": [bank, total_rec, overdue_rec, total_pay],
		"colors": ["#10b981", "#0284c7", "#f59e0b", "#8b5cf6"]
	}


def get_pie_charts():
	"""All 4 Pie / Donut charts: QC, HSE, Product Category, Documents."""
	# 1. Quality & QC Inspections
	batches_released = frappe.db.count("Batch", {"qc_status": ["in", ["Released", "Passed"]]})
	batches_quarantine = frappe.db.count("Batch", {"qc_status": "Quarantine"})
	batches_rejected = frappe.db.count("Batch", {"qc_status": "Rejected"})
	inspections_draft = frappe.db.count("Quality Inspection", {"docstatus": 0})
	oos_count = frappe.db.count("OOS Investigation", {"status": "Open"}) if frappe.db.exists("DocType", "OOS Investigation") else 0

	total_qc = batches_released + batches_quarantine + inspections_draft + batches_rejected + oos_count
	qc_pie = {
		"title": _("Quality Control & Batch Status"),
		"labels": [_("Released / Pass"), _("In Quarantine"), _("Pending Sign-off"), _("OOS / Rejected")],
		"values": [batches_released, batches_quarantine, inspections_draft, batches_rejected + oos_count],
		"colors": ["#10b981", "#f59e0b", "#0284c7", "#ef4444"],
		"total_label": _("Total Batches / QC"),
		"total_value": total_qc
	}

	# 2. HSE Incidents & Safety Records
	incidents_closed = frappe.db.count("HSE Incident", {"status": "Closed"}) if frappe.db.exists("DocType", "HSE Incident") else 0
	incidents_open = frappe.db.count("HSE Incident", {"status": ["!=", "Closed"]}) if frappe.db.exists("DocType", "HSE Incident") else 0
	near_misses = frappe.db.count("HSE Incident", {"incident_type": "Near Miss"}) if frappe.db.exists("DocType", "HSE Incident") else 0
	spills_releases = frappe.db.count("HSE Incident", {"incident_type": "Spill or Release"}) if frappe.db.exists("DocType", "HSE Incident") else 0
	other_incidents = frappe.db.count("HSE Incident", {"incident_type": ["not in", ["Near Miss", "Spill or Release"]]}) if frappe.db.exists("DocType", "HSE Incident") else 0

	total_hse = incidents_closed + incidents_open
	if total_hse > 0:
		hse_labels = [_("Near Misses (Resolved)"), _("Spills / Releases (Contained)"), _("Other Incidents"), _("Active Open Incidents")]
		hse_values = [near_misses, spills_releases, other_incidents, incidents_open]
		hse_colors = ["#10b981", "#f59e0b", "#0284c7", "#ef4444"]
	else:
		hse_labels = [_("Zero Incidents (100% Safe)")]
		hse_values = [1]
		hse_colors = ["#10b981"]

	hse_pie = {
		"title": _("HSE Safety & Incident Records"),
		"labels": hse_labels,
		"values": hse_values,
		"colors": hse_colors,
		"total_label": _("Total Incidents"),
		"total_value": total_hse
	}

	# 3. Product Sales Share
	product_sales = frappe.db.sql("""
		select i.item_name, sum(sii.amount) as total_sales
		from `tabSales Invoice Item` sii
		join `tabSales Invoice` si on si.name = sii.parent
		join `tabItem` i on i.item_code = sii.item_code
		where si.docstatus = 1 and si.is_return = 0
		group by sii.item_code
		order by total_sales desc
		limit 5
	""", as_dict=True)

	if product_sales:
		p_labels = [p["item_name"] for p in product_sales]
		p_values = [flt(p["total_sales"]) for p in product_sales]
		p_colors = ["#008bc6", "#06b6d4", "#10b981", "#8b5cf6", "#f59e0b"]
	else:
		top_items = frappe.get_all("Item", filters={"is_stock_item": 1}, fields=["item_name"], limit=5)
		p_labels = [t["item_name"] for t in top_items] or [_("No sales recorded")]
		p_values = [1] * len(p_labels)
		p_colors = ["#64748b"] * len(p_labels)

	product_pie = {
		"title": _("Chemical Revenue by Product"),
		"labels": p_labels,
		"values": p_values,
		"colors": p_colors[:len(p_labels)],
		"total_label": _("Top Products"),
		"total_value": len(p_values)
	}

	# 4. Document Vault & Sharing Security
	total_docs = frappe.db.count("Chemical Document") if frappe.db.exists("DocType", "Chemical Document") else 0
	active_shares = frappe.db.count("Document Share Link", {"status": "Active"}) if frappe.db.exists("DocType", "Document Share Link") else 0
	expired_shares = frappe.db.count("Document Share Link", {"status": "Expired"}) if frappe.db.exists("DocType", "Document Share Link") else 0
	access_logs = frappe.db.count("Document Access Log") if frappe.db.exists("DocType", "Document Access Log") else 0

	doc_pie = {
		"title": _("Documents & Secure Sharing Distribution"),
		"labels": [_("Active Secure Shares"), _("Expiring / Expired"), _("Internal Vault Files"), _("Verified Access Logs")],
		"values": [active_shares, expired_shares, total_docs, access_logs],
		"colors": ["#10b981", "#ef4444", "#0284c7", "#6366f1"],
		"total_label": _("Total Assets"),
		"total_value": active_shares + expired_shares + total_docs + access_logs
	}

	return {
		"qc": qc_pie,
		"hse": hse_pie,
		"product": product_pie,
		"documents": doc_pie
	}


def get_system_notices():
	"""Actionable notice board: SDS gaps, expiring permits, quarantine, EFRIS, overdue invoices, planned audits."""
	notices = []

	# 1. SDS Document gaps
	try:
		from chemical_erp.dashboard.data import documents_card
		dc = documents_card()
		if dc and dc.get("value"):
			notices.append({
				"id": "sds-gaps",
				"priority": "critical",
				"badge": _("URGENT SDS"),
				"title": _("Chemical Deliveries Blocked (Missing SDS)"),
				"message": _("{0} products are currently blocked from dispatch due to missing safety data sheets.").format(dc["value"]),
				"action_label": _("View Document Gaps"),
				"route": ["query-report", "Document Gaps"],
				"time": _("Immediate action required")
			})
	except Exception:
		pass

	# 2. Batches in Quarantine
	q_batches = frappe.db.count("Batch", {"qc_status": "Quarantine", "is_waste_batch": 0})
	if q_batches > 0:
		notices.append({
			"id": "quarantine-batches",
			"priority": "warning",
			"badge": _("QC QUARANTINE"),
			"title": _("Batches in Quarantine Awaiting Release"),
			"message": _("{0} manufactured chemical batches are currently held in quarantine awaiting QA analysis & release.").format(q_batches),
			"action_label": _("Inspect Batches"),
			"route": ["List", "Batch", {"qc_status": "Quarantine"}],
			"time": _("Daily review")
		})

	# 3. Legal & Environmental Permits expiring in next 30 days
	soon_permits = frappe.get_all("Legal Requirement", filters={"expiry_date": ["between", [today(), add_days(today(), 30)]]}, fields=["name", "law_name", "licence_permit_filing", "expiry_date", "regulator"]) if frappe.db.exists("DocType", "Legal Requirement") else []
	for p in soon_permits:
		p_name = p.get("law_name") or p.get("licence_permit_filing") or p.get("name")
		reg = f" ({p.regulator})" if p.get("regulator") else ""
		notices.append({
			"id": f"permit-{p.name}",
			"priority": "warning",
			"badge": _("REGULATORY"),
			"title": _("Statutory Permit Expiring: {0}{1}").format(p_name, reg),
			"message": _("Operating permit {0} expires on {1}. Prepare renewal documentation with regulator.").format(p_name, p.expiry_date),
			"action_label": _("View Permit"),
			"route": ["Form", "Legal Requirement", p.name],
			"time": _("Due {0}").format(p.expiry_date)
		})

	# 4. Overdue Customer Invoices
	overdue_count = frappe.db.count("Sales Invoice", {"docstatus": 1, "outstanding_amount": [">", 0], "due_date": ["<", today()]})
	if overdue_count > 0:
		overdue_sum = flt(frappe.db.sql("select sum(outstanding_amount) from `tabSales Invoice` where docstatus=1 and outstanding_amount>0 and due_date < %s", today())[0][0])
		currency = frappe.db.get_default("currency") or "UGX"
		notices.append({
			"id": "overdue-invoices",
			"priority": "critical",
			"badge": _("RECEIVABLES"),
			"title": _("{0} Overdue Customer Invoices ({1} {2})").format(overdue_count, currency, frappe.utils.fmt_money(overdue_sum, precision=0)),
			"message": _("{0} sales invoices have passed their credit terms. Follow up with debtors team for immediate collection.").format(overdue_count),
			"action_label": _("View Overdue Invoices"),
			"route": ["List", "Sales Invoice", {"outstanding_amount": [">", 0], "due_date": ["<", today()]}],
			"time": _("Credit control")
		})

	# 5. Invoices not fiscalised (EFRIS)
	efris_pending = frappe.db.count("Sales Invoice", {"docstatus": 1, "efris_status": ["in", ["Pending", "Failed"]]}) if frappe.db.has_column("Sales Invoice", "efris_status") else 0
	if efris_pending > 0:
		notices.append({
			"id": "efris-alert",
			"priority": "critical",
			"badge": _("EFRIS TAX"),
			"title": _("Invoices Not Fiscalised on EFRIS"),
			"message": _("{0} posted customer sales invoices have not completed EFRIS fiscalisation.").format(efris_pending),
			"action_label": _("Fiscalise Invoices"),
			"route": ["List", "Sales Invoice", {"efris_status": ["in", ["Pending", "Failed"]]}],
			"time": _("Tax compliance")
		})

	# 6. Document Sharing Expirations in 72 hours
	expiring_links = frappe.db.count("Document Share Link", {"status": "Active", "expires_at": ["between", [now_datetime(), add_days(now_datetime(), 3)]]}) if frappe.db.exists("DocType", "Document Share Link") else 0
	if expiring_links > 0:
		notices.append({
			"id": "doc-shares-expiring",
			"priority": "info",
			"badge": _("DOC SECURITY"),
			"title": _("Document Share Links Expiring (72 Hours)"),
			"message": _("{0} shared document links will automatically lose access within the next 72 hours.").format(expiring_links),
			"action_label": _("Review Share Links"),
			"route": ["List", "Document Share Link", {"status": "Active"}],
			"time": _("72 hours remaining")
		})

	# 7. Upcoming Preventive Maintenance Due (next 14 days)
	upcoming_jobs = frappe.get_all("Maintenance Job", filters={"status": ["in", ["Open", "In Progress"]], "due_date": ["between", [today(), add_days(today(), 14)]]}, fields=["name", "pm_task", "due_date", "equipment"]) if frappe.db.exists("DocType", "Maintenance Job") else []
	for j in upcoming_jobs:
		notices.append({
			"id": f"maint-{j.name}",
			"priority": "info",
			"badge": _("MAINTENANCE"),
			"title": _("Preventive Maintenance Due: {0}").format(j.pm_task or j.equipment or j.name),
			"message": _("Scheduled maintenance task for {0} is due on {1}.").format(j.equipment or j.pm_task, j.due_date),
			"action_label": _("View Job Card"),
			"route": ["Form", "Maintenance Job", j.name],
			"time": _("Due {0}").format(j.due_date)
		})

	# 8. Upcoming Internal Audit Scheduled (next 60 days)
	audits = frappe.get_all("Internal Audit", filters={"scheduled_date": ["between", [today(), add_days(today(), 60)]]}, fields=["name", "title", "quarter", "scheduled_date"]) if frappe.db.exists("DocType", "Internal Audit") else []
	for a in audits:
		notices.append({
			"id": f"audit-{a.name}",
			"priority": "notice",
			"badge": _("IMS AUDIT"),
			"title": _("Internal Audit Scheduled: {0}").format(a.title or a.quarter),
			"message": _("IMS internal audit is scheduled for {0}. Department heads should ensure all checklists and records are ready.").format(a.scheduled_date),
			"action_label": _("View Audit Plan"),
			"route": ["Form", "Internal Audit", a.name],
			"time": _("Scheduled {0}").format(a.scheduled_date)
		})

	return notices


@frappe.whitelist()
def get_graphical_summary():
	"""Comprehensive endpoint for the Graphical Dashboard."""
	base_dash = get_dashboard()

	# Add Document Vault section cards to base_dash sections if not present
	try:
		docs = documents_section()
		if docs:
			base_dash["sections"].append(docs)
	except Exception:
		frappe.log_error("Failed adding documents to dashboard", frappe.get_traceback())

	# Compile Top KPI Strip
	sales_this_month = flt(frappe.db.sql("""select sum(base_net_total) from `tabSales Invoice`
		where docstatus=1 and is_return=0 and posting_date between %s and %s""", (get_first_day(today()), today()))[0][0])
	overdue_rec = flt(frappe.db.sql("select sum(outstanding_amount) from `tabSales Invoice` where docstatus=1 and outstanding_amount>0 and due_date < %s", today())[0][0])
	bank_cash = flt(frappe.db.sql("""select sum(gle.debit - gle.credit) from `tabGL Entry` gle join `tabAccount` a on a.name = gle.account
		where gle.is_cancelled=0 and a.account_type in ('Bank','Cash')""")[0][0])
	batches_quar = frappe.db.count("Batch", {"qc_status": "Quarantine", "is_waste_batch": 0})

	currency = frappe.db.get_default("currency") or "UGX"
	money = lambda v: frappe.utils.fmt_money(v or 0, precision=0)

	last_lti = frappe.db.get_value("HSE Incident", {"lost_time": 1}, "max(occurred_on)") if frappe.db.exists("DocType", "HSE Incident") else None
	if last_lti:
		safe_days = (getdate(today()) - getdate(last_lti)).days
	else:
		earliest_date = frappe.db.get_value("Sales Invoice", None, "min(posting_date)") or getdate("2026-01-01")
		safe_days = (getdate(today()) - getdate(earliest_date)).days

	kpi_strip = [
		{"label": _("Sales This Month"), "value": money(sales_this_month), "icon": "trending-up", "tone": "cyan", "route": ["List", "Sales Invoice"]},
		{"label": _("Overdue Receivables"), "value": money(overdue_rec), "icon": "alert-circle", "tone": "orange", "route": ["List", "Sales Invoice", {"outstanding_amount": [">", 0], "due_date": ["<", today()]}]},
		{"label": _("Cash & Bank"), "value": money(bank_cash), "icon": "dollar-sign", "tone": "emerald", "route": ["query-report", "General Ledger"]},
		{"label": _("Batches in Quarantine"), "value": batches_quar, "icon": "shield-alert", "tone": "amber", "route": ["List", "Batch", {"qc_status": "Quarantine"}]},
		{"label": _("Days Without LTI (Safe)"), "value": safe_days, "icon": "check-circle", "tone": "emerald", "route": ["List", "HSE Incident"]},
		{"label": _("Secure Shared Docs"), "value": frappe.db.count("Document Share Link") if frappe.db.exists("DocType", "Document Share Link") else 0, "icon": "file-text", "tone": "cyan", "route": ["List", "Document Share Link"]}
	]

	# Build final payload
	return {
		"user": base_dash.get("user"),
		"is_md": base_dash.get("is_md"),
		"currency": currency,
		"kpi_strip": kpi_strip,
		"monthly_sales_chart": get_monthly_sales_chart(),
		"production_chart": get_production_maintenance_chart(),
		"cash_flow_chart": get_cash_flow_chart(),
		"pie_charts": get_pie_charts(),
		"notices": get_system_notices(),
		"agenda": base_dash.get("agenda", []),
		"approvals": base_dash.get("approvals", []),
		"approval_count": base_dash.get("approval_count", 0),
		"sections": base_dash.get("sections", [])
	}
