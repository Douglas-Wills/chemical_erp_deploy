"""My Dashboard: every employee sees the sections for their own work; the Managing Director sees every section.

Counts respect each user's permissions (confidential formulas stay hidden). A card links to the list it counts.
"""

import frappe
from frappe import _
from frappe.utils import add_days, flt, get_first_day, getdate, now_datetime, today

MD = "Managing Director"


def _count(doctype, filters):
	"""Count what this user may see: their roles decide the record types, their limits (department,
	warehouse …) decide the records. None when they may not read the record type at all."""
	if not frappe.has_permission(doctype, "read"):
		return None
	try:
		return frappe.get_list(doctype, filters=filters, fields=["count(name) as n"], limit_page_length=0)[0].n or 0
	except frappe.PermissionError:
		return None
	except Exception:
		return 0


def card(label, doctype, filters, tone_if_any="orange", value=None, route=None):
	if not frappe.has_permission(doctype, "read"):
		return None  # not permitted: the card does not appear
	n = _count(doctype, filters) if value is None else value
	if n is None:
		return None
	tone = (tone_if_any if n else "green") if isinstance(n, (int, float)) and tone_if_any else "blue"
	return {"label": label, "value": n, "tone": tone, "doctype": doctype, "filters": filters, "route": route}


def soon(days):
	return ["between", [today(), add_days(today(), days)]]


# ------------------------------------------------------------------ sections
def section_mine(user):
	emp = frappe.db.get_value("Employee", {"user_id": user}, "name")
	cards = [card(_("My tasks"), "ToDo", {"allocated_to": user, "status": "Open"}, "blue")]
	if emp:
		cards += [card(_("My training needs"), "Training Need", {"employee": emp, "status": ["in", ["Open", "Scheduled"]]}),
		          card(_("My expense claims in progress"), "Expense Claim", {"employee": emp, "docstatus": 0}, "blue"),
		          card(_("My certificates expiring (60 days)"), "Employee", {"name": emp}, "orange",
		               value=frappe.db.count("Staff Certification", {"parent": emp, "parenttype": "Employee", "expires_on": soon(60)}),
		               route={"doctype": "Employee", "name": emp})]
	cards.append(card(_("Incidents I reported, open"), "HSE Incident", {"owner": user, "status": ["!=", "Closed"]}, "blue"))
	from chemical_erp.controls.attachments import overdue_receipts

	if emp:
		cards.append(card(_("Expense receipts to attach (72 hours)"), "Expense Claim", {"employee": emp, "docstatus": 1, "receipts_status": "Awaiting Receipts"}, "orange"))
	blocked = overdue_receipts(user=user, employee=emp)
	if blocked:
		cards.insert(0, {"label": _("Receipts overdue: new expense claims or purchase requests are blocked until attached"),
		                 "value": len(blocked), "tone": "red", "doctype": blocked[0][0], "filters": {"name": ["in", [n for _d, n in blocked]]}})
	cards.append(card(_("Supplier receipts to attach (my purchases, 72 hours)"), "Purchase Order",
	                  {"purchase_originator": user, "docstatus": 1, "supplier_receipt_status": "Awaiting Supplier Receipt"}, "red"))
	return cards


def section_sales(user):
	return [
		card(_("Open quotations"), "Quotation", {"docstatus": 1, "status": "Open"}, "blue"),
		card(_("Orders to deliver"), "Sales Order", {"docstatus": 1, "status": ["in", ["To Deliver and Bill", "To Deliver"]]}, "blue"),
		card(_("Overdue invoices"), "Sales Invoice", {"docstatus": 1, "outstanding_amount": [">", 0], "due_date": ["<", today()]}),
		card(_("Open complaints"), "Customer Complaint", {"status": ["!=", "Closed"]}),
		card(_("Sales orders without the customer's PO"), "Sales Order", {"docstatus": 0, "customer_po_file": ["is", "not set"]}),
		card(_("Field visits in the next 7 days"), "Event", {"event_kind": "Field Visit", "starts_on": soon(7)}, "blue"),
		card(_("Visit reports to write"), "Event", {"event_kind": "Field Visit", "owner": user, "ends_on": ["<", now_datetime()], "visit_report": ["is", "not set"]}),
		card(_("Products needing certification attention"), "Product Certification", {"status": ["in", ["Expired", "Expiring", "Certificate Missing"]]}),
		card(_("Quick orders to confirm (WhatsApp, phone, web)"), "Quick Order", {"status": "New"}, "red"),
		card(_("Customers on credit hold"), "Customer", {"credit_hold": 1}, "red"),
		card(_("Controlled-chemical declarations expiring (30 days)"), "End-User Declaration", {"status": "Approved", "valid_to": soon(30)}),
		({"label": _("Customer tanks low (site stock)"), "value": frappe.db.count("Site Chemical Tank", {"days_left": ["between", [1, 7]]}),
		  "tone": "orange", "doctype": "Client Water System", "filters": {}, "route": {"report": "Customer Tank Stock"}}
		 if frappe.has_permission("Client Water System", "read") else None),
	]


def section_stores(user):
	return [
		card(_("Receipts waiting for the MD"), "Purchase Receipt", {"docstatus": 0, "workflow_state": "Pending MD"}, "blue"),
		card(_("Batches in Quarantine"), "Batch", {"qc_status": "Quarantine", "is_waste_batch": 0}, "blue"),
		card(_("Failed dispatch checks (30 days)"), "Dispatch Safety Check", {"result": "Fail", "check_date": [">=", add_days(today(), -30)]}),
		card(_("Imports on the way"), "Import Shipment", {"status": ["in", ["Shipped", "At Port", "Cleared"]]}, "blue"),
		card(_("Waste batches held"), "Batch", {"is_waste_batch": 1}, "blue"),
	]


def section_quality(user):
	return [
		card(_("Inspections to sign"), "Quality Inspection", {"docstatus": 0, "workflow_state": "Draft"}),
		card(_("Awaiting countersignature"), "Quality Inspection", {"docstatus": 0, "workflow_state": "Analyst Signed"}),
		card(_("Open OOS investigations"), "OOS Investigation", {"status": "Open"}),
		card(_("Open deviations"), "Deviation", {"status": ["!=", "Closed"]}),
		card(_("Complaints under investigation"), "Customer Complaint", {"status": ["in", ["Open", "Investigating"]]}),
		card(_("Stability tests due (7 days)"), "Stability Study", {"status": "Running"}, "orange",
		     value=frappe.db.count("Stability Point", {"parenttype": "Stability Study", "tested_on": ["is", "not set"], "due_date": ["<=", add_days(today(), 7)]})),
		card(_("Reagents expiring (7 days)"), "Reagent Solution", {"status": "Valid", "expires_on": soon(7)}),
		card(_("Equipment out of calibration"), "Equipment", {"status": "Out of Calibration"}, "red"),
		card(_("Retained samples due for disposal"), "Retained Sample", {"status": "Retained", "retain_until": ["<=", today()]}, "blue"),
	]


def section_hse(user):
	last_lti = frappe.db.get_value("HSE Incident", {"lost_time": 1}, "max(occurred_on)")
	days = (getdate(today()) - getdate(last_lti)).days if last_lti else None
	return [
		card(_("Open incidents"), "HSE Incident", {"status": ["!=", "Closed"]}),
		card(_("Disposals awaiting the facility's acknowledgement"), "Disposal Order", {"docstatus": 1, "status": ["!=", "Closed"],
		                                                                               "disposal_acknowledgement": ["is", "not set"]}),
		({"label": _("Days since last lost-time injury"), "value": days if days is not None else _("None recorded"), "tone": "green",
		  "doctype": "HSE Incident", "filters": {"lost_time": 1}} if frappe.has_permission("HSE Incident", "read") else None),
		card(_("Permits expiring (30 days)"), "Legal Requirement", {"expiry_date": soon(30)}),
		card(_("Expired permits"), "Legal Requirement", {"expiry_date": ["<", today()], "compliance_status": ["!=", "Not Applicable"]}, "red"),
		card(_("Drills due (14 days)"), "Emergency Drill", {"next_drill_due": ["<=", add_days(today(), 14)]}),
		card(_("IMS documents overdue for review"), "IMS Document", {"status": "Active", "review_status": "Overdue"}),
		card(_("Open audit findings"), "Internal Audit", {"docstatus": 1, "open_findings": [">", 0]}),
		card(_("High and critical risks"), "IMS Risk", {"status": ["!=", "Closed"], "level": ["in", ["High", "Critical"]]}, "red"),
		card(_("Expense claims flagged (90 days)"), "Expense Claim", {"pattern_flag": 1, "posting_date": [">=", add_days(today(), -90)]}),
		documents_card(),
		card(_("Document exceptions waiting for the MD"), "Document Exception", {"status": "Requested"}, "red"),
		card(_("Work permits live now"), "Work Permit", {"status": "Issued"}, "blue"),
		card(_("Open product recalls"), "Product Recall", {"status": ["!=", "Closed"], "mock_recall": 0}, "red"),
		segregation_card(),
		card(_("Environmental limits exceeded (30 days)"), "Environmental Reading", {"within_limit": "Exceeded", "reading_date": [">=", add_days(today(), -30)]}, "red"),
		card(_("Permits to work expired without closing"), "Work Permit", {"status": "Expired"}, "red"),
	]


def segregation_card():
	if not frappe.has_permission("Warehouse", "read"):
		return None
	from chemical_erp.regulatory_compliance.storage import conflicts

	n = len([c for c in conflicts() if not c.get("segregated")])
	return {"label": _("Stores holding chemicals that must be kept apart"), "value": n, "tone": "red" if n else "green",
	        "doctype": "Warehouse", "filters": {}, "route": {"report": "Store Segregation Check"}}


def documents_card():
	"""Products in stock or selling that cannot be delivered for lack of an SDS (worked out at most once an hour)."""
	if not frappe.has_permission("Item", "read") or not frappe.db.exists("Report", "Document Gaps"):
		return None
	cache = frappe.cache() if callable(frappe.cache) else frappe.cache
	n = cache.get_value("chemical_erp:document_gaps")
	if n is None:
		from chemical_erp.regulatory_compliance.documents import blocking_count

		n = blocking_count()
		cache.set_value("chemical_erp:document_gaps", n, expires_in_sec=3600)
	return {"label": _("Products blocked from delivery: no SDS (Document Gaps)"), "value": n, "tone": "red" if n else "green",
	        "doctype": "Item", "filters": {}, "route": {"report": "Document Gaps"}}


def section_production(user):
	return [
		card(_("Work orders in progress"), "Work Order", {"docstatus": ["<", 2], "status": ["in", ["Not Started", "In Process", "Draft"]]}, "blue"),
		card(_("Manufacturing orders short of materials"), "Work Order", {"docstatus": ["<", 2], "status": ["in", ["Draft", "Not Started"]],
		                                                                 "material_status": ["in", ["Order Needed", "Late Supplies"]]}, "red"),
		card(_("Open job cards"), "Job Card", {"docstatus": ["<", 2], "status": ["in", ["Open", "Work In Progress"]]}, "blue"),
		card(_("Overdue preventive maintenance"), "Maintenance Job", {"job_type": "Preventive", "status": ["!=", "Done"], "due_date": ["<", today()]}, "red"),
		card(_("Equipment out of service"), "Equipment", {"status": "Out of Service"}, "red"),
		card(_("Batches awaiting release"), "Batch", {"qc_status": "Quarantine", "is_waste_batch": 0}, "blue"),
	]


def section_procurement(user):
	return [
		card(_("Purchase orders awaiting approval"), "Purchase Order", {"docstatus": 0, "workflow_state": ["in", ["Pending Review", "Pending MD"]]}, "blue"),
		card(_("Purchase orders that cannot close (no supplier's receipt)"), "Purchase Order", {"docstatus": 1, "supplier_receipt_status": "Awaiting Supplier Receipt"}),
		card(_("Imports in transit"), "Import Shipment", {"status": ["in", ["Paid", "Shipped", "At Port"]]}, "blue"),
		card(_("Materials to order for manufacturing"), "Work Order", {"docstatus": ["<", 2], "material_status": "Order Needed"}, "red"),
		card(_("Supplier evaluations due"), "Supplier Evaluation", {"docstatus": 0}),
		card(_("LCs expiring (14 days)"), "Import Shipment", {"lc_expiry": soon(14), "status": ["not in", ["Received", "Closed"]]}, "red"),
	]


def section_accounts(user):
	from chemical_erp.tasks import stale_rates

	stale, base = stale_rates()
	return [
		card(_("Invoices not fiscalised (EFRIS)"), "Sales Invoice", {"docstatus": 1, "efris_status": ["in", ["Pending", "Failed"]]}, "red"),
		card(_("Overdue customer invoices"), "Sales Invoice", {"docstatus": 1, "outstanding_amount": [">", 0], "due_date": ["<", today()]}),
		card(_("Supplier bills due (7 days)"), "Purchase Invoice", {"docstatus": 1, "outstanding_amount": [">", 0], "due_date": ["<=", add_days(today(), 7)]}),
		card(_("WHT certificates outstanding"), "WHT Certificate", {"status": "Expected"}, "blue"),
		card(_("Approved expenses awaiting receipts (not payable)"), "Expense Claim", {"docstatus": 1, "receipts_status": "Awaiting Receipts"}),
		card(_("Expense claims flagged: repeated small amounts"), "Expense Claim", {"docstatus": 0, "pattern_flag": 1, "pattern_reviewed": 0}, "red"),
		card(_("Expenses ready to reimburse"), "Expense Claim", {"docstatus": 1, "receipts_status": "Receipts Attached", "status": "Unpaid"}, "blue"),
		({"label": _("Currencies without this week's rate"), "value": len(stale), "tone": "red" if stale else "green",
		  "doctype": "Currency Exchange", "filters": {}} if frappe.has_permission("Currency Exchange", "read") else None),
		card(_("Expense claims to approve"), "Expense Claim", {"docstatus": 0, "workflow_state": ["in", ["Manager Review", "MD Review"]]}, "blue"),
		cash_card(),
		commission_card(),
		card(_("Customers on credit hold"), "Customer", {"credit_hold": 1}, "red"),
		card(_("Payment promises broken"), "Payment Promise", {"status": "Broken"}, "red"),
	]


def commission_card():
	if not frappe.has_permission("Commission Entry", "read") or not frappe.db.exists("Commission Entry", {}):
		return None
	from chemical_erp.people_management.commission import all_payable

	return {"label": _("Sales commission payable to staff now"), "value": frappe.format_value(all_payable(), {"fieldtype": "Currency"}),
	        "tone": "blue", "doctype": "Commission Entry", "filters": {}, "route": {"report": "Commission Statement"}}


def cash_card():
	"""Weeks in the 13-week cash-flow forecast that close below the minimum (worked out at most once an hour)."""
	if not frappe.has_permission("GL Entry", "read") or not frappe.db.exists("Report", "Cash Flow Forecast"):
		return None
	from chemical_erp.company import default_company

	company = default_company()
	key = f"chemical_erp:cash_weeks:{company}"
	cache = frappe.cache() if callable(frappe.cache) else frappe.cache
	weeks = cache.get_value(key)
	if weeks is None:
		try:
			from chemical_erp.chemical_core.report.cash_flow_forecast.cash_flow_forecast import execute

			data = execute({"company": company})[1]
			weeks = sum(1 for w in data if w.get("flag"))
		except Exception:
			frappe.log_error(title="Dashboard cash forecast failed", message=frappe.get_traceback())
			return None
		cache.set_value(key, weeks, expires_in_sec=3600)
	return {"label": _("Weeks of the next 13 below the minimum cash balance"), "value": weeks, "tone": "red" if weeks else "green",
	        "doctype": "GL Entry", "filters": {}, "route": {"report": "Cash Flow Forecast"}}


def section_hr(user):
	return [
		card(_("Open training needs"), "Training Need", {"status": "Open"}),
		card(_("Contracts ending (60 days)"), "Employment Contract", {"end_date": soon(60)}),
		card(_("Probations ending (30 days)"), "Employment Contract", {"probation_end_date": soon(30)}, "blue"),
		card(_("Staff without a signed appointment letter"), "Employee", {"status": "Active", "appointment_letter": ["is", "not set"]}),
		card(_("Upcoming training sessions"), "Training Event", {"docstatus": 1, "event_status": "Scheduled"}, "blue"),
	]


def section_tenders(user):
	from chemical_erp.tenders_desk.scanner import scope_ready

	ready, missing = scope_ready()
	setup = [] if ready else [{"label": _("Tender scanning not set up: needs {0}").format("; ".join(missing)), "value": "!", "tone": "orange",
	                           "doctype": "Tender Settings", "filters": {}, "route": {"doctype": "Tender Settings", "name": "Tender Settings"}}]
	return setup + [
		card(_("New tender leads to review"), "Tender Lead", {"status": "New"}, "orange"),
		card(_("Bid library sections to review"), "Bid Library Block", {"approved": 0}, "blue"),
		card(_("Shortlisted leads"), "Tender Lead", {"status": "Shortlisted"}, "blue"),
		card(_("Tenders closing (14 days)"), "Tender", {"closing_datetime": ["between", [now_datetime(), add_days(now_datetime(), 14)]],
		                                               "status": ["in", ["Identified", "Go/No-Go Review", "Preparing", "Internal Review"]]}),
		card(_("Bids under evaluation"), "Tender", {"status": ["in", ["Submitted", "Under Evaluation"]]}, "blue"),
	]


def section_team(user):
	"""For line managers: the people who report to them, directly or further down."""
	from chemical_erp.people_management.access import employee_of, team_of

	me = employee_of(user)
	team = list(team_of(me)) if me else []
	if not team:
		return []
	return [
		{"label": _("People in my team"), "value": len(team), "tone": "blue", "doctype": "Employee", "filters": {"name": ["in", team]}},
		card(_("Team access grants active"), "Access Grant", {"employee": ["in", team], "status": "Active"}, "blue"),
		card(_("Team access ending (14 days)"), "Access Grant", {"employee": ["in", team], "status": "Active", "valid_to": soon(14)}),
		card(_("Team training needs open"), "Training Need", {"employee": ["in", team], "status": ["in", ["Open", "Scheduled"]]}),
		card(_("Team expense claims to approve"), "Expense Claim", {"employee": ["in", team], "docstatus": 0,
		                                                           "workflow_state": "Manager Review", "first_approver": user}),
		card(_("Team members without a login"), "Employee", {"name": ["in", team], "user_id": ["is", "not set"]}),
	]


def section_access(user):
	from chemical_erp.controls.security import dashboard_cards

	return dashboard_cards() + [
		card(_("Access grants active"), "Access Grant", {"status": "Active"}, "blue"),
		card(_("Temporary access ending (14 days)"), "Access Grant", {"status": "Active", "valid_to": soon(14)}),
		card(_("Access grants waiting to start"), "Access Grant", {"status": "Draft", "docstatus": 1}, "blue"),
		card(_("Active staff without a login"), "Employee", {"status": "Active", "user_id": ["is", "not set"]}),
		card(_("Posts covered by you (vacant)"), "Company Position", {"status": ["like", "Vacant%"]}, "blue"),
	]


def section_field_lab(user):
	return [
		card(_("Equipment due for sampling"), "Client Water System", {"active": 1, "next_due": ["<=", today()]}),
		card(_("Site visits with results still to issue"), "Water Sample", {"status": ["in", ["Open", "Analysed"]]}, "blue"),
		card(_("Analyses to sign"), "Water Analysis", {"docstatus": 0, "workflow_state": "Draft"}, "blue"),
		card(_("Reports awaiting approval"), "Water Analysis", {"docstatus": 0, "workflow_state": "Analyst Signed"}),
		card(_("Non-compliant reports (30 days)"), "Water Analysis", {"docstatus": 1, "compliance": "Non-compliant",
		                                                             "analysed_on": [">=", add_days(today(), -30)]}, "red"),
		card(_("Issued reports not yet invoiced"), "Water Analysis", {"docstatus": 1, "sales_invoice": ["is", "not set"]}),
	]


def section_management(user):
	month_start = get_first_day(today())
	sales = flt(frappe.db.sql("""select sum(base_net_total) from `tabSales Invoice` where docstatus=1 and is_return=0
		and posting_date between %s and %s""", (month_start, today()))[0][0])
	overdue = flt(frappe.db.sql("""select sum(outstanding_amount) from `tabSales Invoice` where docstatus=1 and outstanding_amount>0
		and due_date < %s""", today())[0][0])
	bank = flt(frappe.db.sql("""select sum(gle.debit - gle.credit) from `tabGL Entry` gle join `tabAccount` a on a.name = gle.account
		where gle.is_cancelled=0 and a.account_type in ('Bank','Cash')""")[0][0])
	stock = flt(frappe.db.sql("select sum(stock_value) from `tabBin`")[0][0])
	money = lambda v: frappe.utils.fmt_money(v, precision=0)
	return [
		{"label": _("Sales this month (net)"), "value": money(sales), "tone": "blue", "doctype": "Sales Invoice",
		 "filters": {"docstatus": 1, "posting_date": [">=", month_start]}},
		{"label": _("Overdue receivables"), "value": money(overdue), "tone": "red" if overdue else "green", "doctype": "Sales Invoice",
		 "filters": {"docstatus": 1, "outstanding_amount": [">", 0], "due_date": ["<", today()]}},
		{"label": _("Cash and bank"), "value": money(bank), "tone": "blue", "doctype": "Account", "filters": {"account_type": ["in", ["Bank", "Cash"]]}},
		{"label": _("Stock value"), "value": money(stock), "tone": "blue", "doctype": "Bin", "filters": {}},
		card(_("Products selling below cost"), "Product Cost Sheet", {"status": "Current", "current_margin": ["<", 0], "current_price_per_kg": [">", 0]}, "red"),
		card(_("Objectives off target"), "Quality Objective", {"on_target": 0, "latest_value": ["is", "set"]}),
		card(_("Open complaints"), "Customer Complaint", {"status": ["!=", "Closed"]}),
		card(_("Open incidents"), "HSE Incident", {"status": ["!=", "Closed"]}),
		card(_("High and critical risks"), "IMS Risk", {"status": ["!=", "Closed"], "level": ["in", ["High", "Critical"]]}, "red"),
		card(_("Expense claims flagged (90 days)"), "Expense Claim", {"pattern_flag": 1, "posting_date": [">=", add_days(today(), -90)]}),
	]


SECTIONS = [
	("management", _("Management"), (MD,), section_management),
	("access", _("People and Access"), (MD, "HR Manager"), section_access),
	("sales", _("Sales and Customers"), ("Sales User", "Sales Manager"), section_sales),
	("quality", _("Quality"), ("QC Analyst", "QC Manager", "Plant Manager"), section_quality),
	("production", _("Production and Maintenance"), ("Manufacturing User", "Manufacturing Manager", "Plant Manager", "Maintenance Technician"), section_production),
	("stores", _("Stores and Dispatch"), ("Stock User", "Stock Manager"), section_stores),
	("procurement", _("Procurement and Imports"), ("Purchase User", "Purchase Manager"), section_procurement),
	("hse", _("Health, Safety, Environment and Compliance"), ("HSE Officer",), section_hse),
	("accounts", _("Accounts"), ("Accounts User", "Accounts Manager"), section_accounts),
	("hr", _("People"), ("HR User", "HR Manager"), section_hr),
	("tenders", _("Tenders"), ("Tender Manager", "Tender User"), section_tenders),
	("field_lab", _("Field Laboratory"), ("Field Technician", "QC Analyst", "QC Manager", "Plant Manager"), section_field_lab),
]


def build_sections(user, roles=None, is_md=None):
	"""The dashboard sections this user may see, each with its permitted cards only."""
	roles = set(roles) if roles is not None else set(frappe.get_roles(user))
	if is_md is None:
		is_md = MD in roles or user == "Administrator"
	sections = []

	def add(key, title, cards):
		cards = [c for c in cards if c]  # only permitted items reach the dashboard
		if cards:
			sections.append({"key": key, "title": title, "cards": cards})

	add("mine", _("My Work"), section_mine(user))
	from chemical_erp.controls.delegation import active_for

	d = active_for(user)
	if d:
		add("delegation", _("Signing for the Managing Director"), [
			{"label": _("Until {0}: open /approvals on your phone").format(frappe.format_value(d.valid_to, {"fieldtype": "Date"})),
			 "value": d.signed_count or 0, "tone": "blue", "doctype": "Approval Delegation", "filters": {"name": d.name},
			 "route": {"doctype": "Approval Delegation", "name": d.name}}])
	try:
		add("team", _("My Team"), section_team(user))
	except Exception:
		frappe.log_error(title="Dashboard section team failed", message=frappe.get_traceback())
	for key, title, needed, fn in SECTIONS:
		if is_md or roles & set(needed):
			try:
				add(key, title, fn(user))
			except Exception:
				frappe.log_error(title=f"Dashboard section {key} failed", message=frappe.get_traceback())
	return sections


@frappe.whitelist()
def get_dashboard():
	from chemical_erp.dashboard.calendar import agenda
	from chemical_erp.utils import pending_approvals

	user = frappe.session.user
	roles = set(frappe.get_roles(user))
	is_md = MD in roles or user == "Administrator"
	approvals = pending_approvals(user)
	out = {"user": frappe.utils.get_fullname(user), "is_md": is_md, "agenda": agenda(user),
	       "approvals": [{"doctype": a.reference_doctype, "name": a.reference_name, "state": a.workflow_state,
	                      "since": str(getdate(a.creation))} for a in approvals[:15]],
	       "approval_count": len(approvals), "sections": []}

	from chemical_erp.people_management.commission import summary as commission_summary

	try:
		out["commission"] = commission_summary(user)
	except Exception:
		frappe.log_error(title="Dashboard commission failed", message=frappe.get_traceback())
	out["sections"] = build_sections(user, roles, is_md)
	return out


@frappe.whitelist()
def get_graphical_dashboard_data():
	from chemical_erp.dashboard.graphical_summary import get_graphical_summary
	return get_graphical_summary()

