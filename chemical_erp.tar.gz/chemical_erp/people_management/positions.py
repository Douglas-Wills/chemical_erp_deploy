"""Company positions and vacancy cover.

Each Company Position carries system roles. Holders get those roles. A position with no holder is
covered by the Managing Director, who then holds its roles. When a recruit is added as holder, the
roles move to them and the MD's cover is withdrawn. Roles assigned by hand are never removed: only
grants this module made (recorded in Position Role Grant) are ever taken back.
"""

import frappe

MD_ROLE = "Managing Director"

# Brave's posts. Created once; edit them freely afterwards.
BRAVE_POSITIONS = [
	("Plant Manager", ["Plant Manager", "Manufacturing Manager"], "Approves production documents"),
	("QC Manager", ["QC Manager"], "Approves quality documents once quality is switched to the QC Manager in Chemical ERP Settings"),
	("QC Analyst", ["QC Analyst", "Laboratory Technician"], "Enters and signs inspection results"),
	("HSE Officer", ["HSE Officer"], "Compliance, SDS files, first signature on overrides, reconciliations and disposals"),
	("Production Supervisor", ["Manufacturing Manager", "Manufacturing User", "Waste Officer"], "Runs production; drafts disposal orders"),
	("Production Assistant", ["Manufacturing User", "Maintenance Technician"], "Job cards and maintenance jobs"),
	("Stores Officer", ["Stock User"], "Receipts, transfers and deliveries"),
	("Procurement Officer", ["Purchase User"], "Purchase orders and requests for quotation"),
	("Accounts Officer", ["Accounts User", "Expense Approver"], "Invoices and payments; signs first on purchase orders and on expenses when the manager is the MD"),
	("Technical Sales Officer", ["Sales User", "Sales Manager", "Tender Manager", "Tender User"], "Quotations, sales orders and tenders"),
	("Sales Representative", ["Sales User"], "Quotations and sales orders"),
	("HR Officer", ["HR User"], "Staff records, contracts and payroll preparation"),
]


def md_users():
	users = frappe.get_all("Has Role", filters={"role": MD_ROLE, "parenttype": "User"}, pluck="parent")
	return [u for u in set(users) if u not in ("Administrator", "Guest") and frappe.db.get_value("User", u, "enabled")]


def seed_positions():
	if frappe.db.count("Company Position"):
		return
	for name, roles, desc in BRAVE_POSITIONS:
		roles = [r for r in roles if frappe.db.exists("Role", r)]
		if roles:
			frappe.get_doc({"doctype": "Company Position", "position_name": name, "description": desc,
			                "roles": [{"role": r} for r in roles]}).insert(ignore_permissions=True)


def desired_grants():
	"""{(user, role): (position, reason)} for every role the positions say someone should hold."""
	want = {}
	mds = md_users()
	for p in frappe.get_all("Company Position", filters={"active": 1}, pluck="name"):
		pos = frappe.get_doc("Company Position", p)
		holders = [h.user for h in pos.holders if h.user and frappe.db.get_value("User", h.user, "enabled")]
		reason = "Holder" if holders else "Vacancy"
		for user in holders or mds:
			for r in pos.roles:
				want.setdefault((user, r.role), (pos.name, reason))
		status = "Filled" if holders else "Vacant (covered by the MD)"
		if pos.status != status:
			frappe.db.set_value("Company Position", pos.name, "status", status, update_modified=False)
	return want


def sync_positions():
	want = desired_grants()
	existing = {(g.user, g.role): g for g in frappe.get_all("Position Role Grant", filters={"reason": ["in", ["Holder", "Vacancy"]]},
	                                                      fields=["name", "user", "role", "position", "reason"])}
	granted_elsewhere = {(g.user, g.role) for g in frappe.get_all("Position Role Grant", filters={"reason": "Access Grant"}, fields=["user", "role"])}
	# Give what is wanted
	for (user, role), (position, reason) in want.items():
		has = frappe.db.exists("Has Role", {"parent": user, "parenttype": "User", "role": role})
		if not has:
			frappe.get_doc("User", user).add_roles(role)
		g = existing.get((user, role))
		if g:
			if g.position != position or g.reason != reason:
				frappe.db.set_value("Position Role Grant", g.name, {"position": position, "reason": reason})
		elif not has or (user, role) in granted_elsewhere:  # never claim a role given by hand
			frappe.get_doc({"doctype": "Position Role Grant", "user": user, "role": role, "position": position,
			                "reason": reason}).insert(ignore_permissions=True)
	# Take back what is no longer wanted (only our own grants)
	for (user, role), g in existing.items():
		if (user, role) not in want:
			if (user, role) not in granted_elsewhere:  # an active access grant still provides it
				frappe.get_doc("User", user).remove_roles(role)
			frappe.delete_doc("Position Role Grant", g.name, ignore_permissions=True, force=True)


def covering(user, role):
	"""True when `user` holds `role` only because they cover a vacant position."""
	return bool(role) and bool(frappe.db.exists("Position Role Grant", {"user": user, "role": role, "reason": "Vacancy"}))


def covering_any(user, roles):
	return any(covering(user, r) for r in roles)


def holder_of(position):
	"""First user holding a position, or the MD covering it."""
	if not frappe.db.exists("Company Position", position):
		return None
	pos = frappe.get_doc("Company Position", position)
	for h in pos.holders:
		if h.user:
			return h.user
	mds = md_users()
	return mds[0] if mds else None
