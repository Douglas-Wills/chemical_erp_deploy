"""Rules for the Staff Details tab added to ERPNext's Employee."""

import frappe
from frappe import _
from frappe.utils import cint, flt


def validate_employee(doc, method=None):
	kin = doc.get("next_of_kin") or []
	if kin:
		primaries = [k for k in kin if cint(k.is_primary)]
		if not primaries:
			kin[0].is_primary = 1
		elif len(primaries) > 1:
			frappe.throw(_("Only one Next of Kin can be marked Primary."), title=_("Next of Kin"))
		beneficiaries = [k for k in kin if cint(k.is_beneficiary)]
		total = sum(flt(k.benefit_share) for k in beneficiaries)
		if beneficiaries and total and abs(total - 100) > 0.01:
			frappe.throw(
				_("Beneficiary shares add up to {0}%. They must total 100%.").format(flt(total, 2)),
				title=_("Beneficiary shares"),
			)

	mode = doc.get("salary_payment_mode")
	if mode == "Mobile Money" and not doc.get("mobile_money_number"):
		frappe.msgprint(_("Payment mode is Mobile Money but no mobile money number is recorded."), indicator="orange", alert=True)
	if mode == "Bank" and doc.meta.has_field("bank_ac_no") and not doc.get("bank_ac_no"):
		frappe.msgprint(_("Payment mode is Bank but no account number is recorded."), indicator="orange", alert=True)

	if doc.get("nin"):
		doc.nin = doc.nin.strip().upper()
	if doc.get("tin"):
		doc.tin = doc.tin.strip()
