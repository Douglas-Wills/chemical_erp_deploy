"""Idempotent setup. Runs after install and every migrate; never overwrites records you have edited."""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

PHONE = {"options": "Phone"}
MARRIED = {"depends_on": "eval:doc.marital_status=='Married'"}

# (fieldname, fieldtype, label, extra). Fields Employee already has are skipped, so nothing is duplicated.
STAFF_FIELDS = [
	("staff_details_tab", "Tab Break", "Staff Details", {}),

	("bh_personal_section", "Section Break", "Personal Details", {}),
	("nin", "Data", "National ID Number (NIN)", {"unique": 0}),
	("nin_card_copy", "Attach", "National ID Copy", {"mandatory_depends_on": "eval:doc.nin",
	                                                  "description": "Required once a NIN is entered"}),
	("nationality", "Link", "Nationality", {"options": "Country"}),
	("place_of_birth", "Data", "Place of Birth", {}),
	("district_of_origin", "Data", "District of Origin", {}),
	("bh_personal_cb1", "Column Break", "", {}),
	("marital_status", "Select", "Marital Status", {"options": "\nSingle\nMarried\nDivorced\nWidowed\nSeparated"}),
	("spouse_name", "Data", "Spouse's Name", MARRIED),
	("spouse_phone", "Data", "Spouse's Telephone", {**PHONE, **MARRIED}),
	("number_of_children", "Int", "Number of Children", {}),
	("bh_personal_cb2", "Column Break", "", {}),
	("blood_group", "Select", "Blood Group", {"options": "\nA+\nA-\nB+\nB-\nAB+\nAB-\nO+\nO-"}),
	("passport_number", "Data", "Passport Number", {}),
	("passport_expiry", "Date", "Passport Expiry", {}),

	("bh_contact_section", "Section Break", "Contact & Residence", {}),
	("cell_number", "Data", "Mobile Telephone", PHONE),
	("alternate_phone", "Data", "Alternate Telephone", PHONE),
	("personal_email", "Data", "Personal Email", {"options": "Email"}),
	("bh_contact_cb1", "Column Break", "", {}),
	("residence_village", "Data", "Village / LC1 / Zone", {}),
	("residence_parish", "Data", "Parish / Ward", {}),
	("residence_subcounty", "Data", "Sub-county / Division", {}),
	("residence_district", "Data", "District / City", {}),
	("lst_local_government", "Data", "LST Local Government",
	 {"description": "The council LST is remitted to, usually where the employee lives or works"}),

	("bh_kin_section", "Section Break", "Next of Kin & Emergency Contacts", {}),
	("next_of_kin", "Table", "Next of Kin", {"options": "Employee Next of Kin"}),

	("bh_dependants_section", "Section Break", "Dependants", {"collapsible": 1}),
	("dependants", "Table", "Dependants", {"options": "Employee Dependant"}),

	("bh_qualifications_section", "Section Break", "Qualifications & Documents", {"collapsible": 1}),
	("staff_qualifications", "Table", "Qualifications", {"options": "Staff Qualification"}),
	("cv_attachment", "Attach", "CV", {}),
	("appointment_letter", "Attach", "Signed Appointment Letter", {"description": "Required for active staff"}),

	("bh_statutory_section", "Section Break", "Statutory: URA, NSSF & LST", {}),
	("tin", "Data", "TIN", {}),
	("nssf_number", "Data", "NSSF Number", {}),
	("paye_residency", "Select", "PAYE Residency", {"options": "Resident\nNon-resident", "default": "Resident"}),
	("bh_statutory_cb1", "Column Break", "", {}),
	("paye_exempt", "Check", "Exempt from PAYE", {}),
	("nssf_exempt", "Check", "Exempt from NSSF", {}),
	("lst_exempt", "Check", "Exempt from LST", {}),

	("bh_bank_section", "Section Break", "Bank & Mobile Money", {}),
	("salary_payment_mode", "Select", "Salary Paid By", {"options": "Bank\nMobile Money\nCash", "default": "Bank"}),
	("bank_name", "Data", "Bank Name", {}),
	("bank_branch", "Data", "Bank Branch", {}),
	("bank_account_name", "Data", "Account Name", {}),
	("bank_ac_no", "Data", "Account Number", {}),
	("bank_swift_code", "Data", "SWIFT / Sort Code", {}),
	("bh_bank_cb1", "Column Break", "", {}),
	("mobile_money_provider", "Select", "Mobile Money Provider", {"options": "\nMTN Mobile Money\nAirtel Money"}),
	("mobile_money_number", "Data", "Mobile Money Number", PHONE),
	("mobile_money_name", "Data", "Registered Mobile Money Name", {}),

	("bh_hr_section", "Section Break", "Contract", {}),
	("current_contract", "Link", "Current Contract", {"options": "Employment Contract", "read_only": 1}),
]

COMPONENTS = [
	# name, type, taxable, nssf, statutory, abbr
	("Basic Salary", "Earning", 1, 1, 0, "BS"),
	("Housing Allowance", "Earning", 1, 1, 0, "HA"),
	("Transport Allowance", "Earning", 1, 1, 0, "TA"),
	("Medical Allowance", "Earning", 1, 1, 0, "MA"),
	("Responsibility Allowance", "Earning", 1, 1, 0, "RA"),
	("Overtime", "Earning", 1, 1, 0, "OT"),
	("Bonus", "Earning", 1, 1, 0, "BON"),
	("Sales Commission", "Earning", 1, 1, 0, "COM"),  # PAYE and NSSF apply to commission like other pay
	("PAYE", "Deduction", 0, 0, 1, "PAYE"),
	("NSSF Employee", "Deduction", 0, 0, 1, "NSSF"),
	("Local Service Tax", "Deduction", 0, 0, 1, "LST"),
	("Staff Insurance Contribution", "Deduction", 0, 0, 0, "INS"),
	("Salary Advance", "Deduction", 0, 0, 0, "ADV"),
	("Loan Repayment", "Deduction", 0, 0, 0, "LOAN"),
	("Other Deduction", "Deduction", 0, 0, 0, "OD"),
]

NO_LIMIT = 0
PAYE_SETS = [
	{
		"title": "Resident from 1 Jul 2026",
		"residency": "Resident",
		"effective_from": "2026-07-01",
		"bands": [(0, 335000, 0), (335000, 410000, 20), (410000, 485000, 25), (485000, NO_LIMIT, 30)],
		"source_notes": "Income Tax (Amendment) Act 2026, assented 20 Aug 2026, effective 1 Jul 2026. "
		"Plus 10% on chargeable income above UGX 10,000,000 a month. Verify against URA's PAYE guidance.",
	},
	{
		"title": "Resident before 1 Jul 2026",
		"residency": "Resident",
		"effective_from": "2012-07-01",
		"bands": [(0, 235000, 0), (235000, 335000, 10), (335000, 410000, 20), (410000, NO_LIMIT, 30)],
		"source_notes": "Income Tax Act bands in force until 30 Jun 2026, plus 10% above UGX 10,000,000 a month.",
	},
	{
		"title": "Non-resident",
		"residency": "Non-resident",
		"effective_from": "2012-07-01",
		"bands": [(0, 335000, 10), (335000, 410000, 20), (410000, NO_LIMIT, 30)],
		"source_notes": "Non-resident bands as published before the 2026 amendment. CHECK whether the 2026 Act "
		"changed them and add a new set dated 1 Jul 2026 if so.",
	},
]

# Annual LST by monthly income (Local Governments Act). Verify with your council.
LST_BANDS = [
	(100000, 200000, 5000), (200000, 300000, 10000), (300000, 400000, 20000), (400000, 500000, 30000),
	(500000, 600000, 40000), (600000, 700000, 60000), (700000, 800000, 70000), (800000, 900000, 80000),
	(900000, 1000000, 90000), (1000000, NO_LIMIT, 100000),
]

def ensure_setup(first_install=False):
	ensure_roles()
	ensure_employee_fields()
	ensure_other_custom_fields()
	ensure_components()
	ensure_paye_sets()
	hide_duplicate_employee_fields()
	if first_install or not frappe.db.get_single_value("HR Management Settings", "basic_component"):
		ensure_settings()
	frappe.db.commit()


def ensure_roles():
	for role in ("HR Manager", "HR User"):
		if not frappe.db.exists("Role", role):
			frappe.get_doc({"doctype": "Role", "role_name": role, "desk_access": 1}).insert(ignore_permissions=True)


def ensure_employee_fields():
	meta = frappe.get_meta("Employee")
	ours = {f[0] for f in STAFF_FIELDS}
	# Our own custom fields count as ours, so re-running places them consistently.
	standard = {df.fieldname for df in meta.fields if not (df.get("is_custom_field") and df.fieldname in ours)}
	others = [df.fieldname for df in meta.fields if df.fieldname not in ours]
	fields, previous = [], (others[-1] if others else None)
	for fieldname, fieldtype, label, extra in STAFF_FIELDS:
		if fieldname in standard:
			continue  # Employee already has it; use the existing field
		df = {"fieldname": fieldname, "fieldtype": fieldtype, "label": label, **extra}
		if previous:
			df["insert_after"] = previous
		fields.append(df)
		previous = fieldname
	create_custom_fields({"Employee": fields}, update=True)


def ensure_other_custom_fields():
	create_custom_fields(
		{"Journal Entry": [{"fieldname": "payroll_run", "label": "Payroll Run", "fieldtype": "Link",
		                     "options": "Payroll Run", "insert_after": "user_remark", "read_only": 1}]},
		update=True,
	)


def ensure_components():
	for name, ctype, taxable, nssf, statutory, abbr in COMPONENTS:
		if frappe.db.exists("Pay Component", name):
			if statutory:
				frappe.db.set_value("Pay Component", name, "is_statutory", 1)
			continue
		frappe.get_doc({
			"doctype": "Pay Component", "component_name": name, "component_type": ctype, "abbr": abbr,
			"is_taxable": taxable, "nssf_applicable": nssf, "is_statutory": statutory,
		}).insert(ignore_permissions=True)


def ensure_paye_sets():
	for s in PAYE_SETS:
		if frappe.db.exists("PAYE Band Set", s["title"]):
			continue
		frappe.get_doc({
			"doctype": "PAYE Band Set", "title": s["title"], "residency": s["residency"],
			"effective_from": s["effective_from"], "surcharge_threshold": 10000000, "surcharge_rate": 10,
			"source_notes": s["source_notes"],
			"bands": [{"from_amount": a, "to_amount": b, "rate": r} for a, b, r in s["bands"]],
		}).insert(ignore_permissions=True)


def hide_duplicate_employee_fields():
	"""One record per fact: hide ERPNext fields that the Staff Details tab replaces."""
	from frappe.custom.doctype.property_setter.property_setter import make_property_setter

	meta = frappe.get_meta("Employee")
	for field in ("person_to_be_contacted", "emergency_phone_number", "relation", "education"):
		if meta.has_field(field):
			make_property_setter("Employee", field, "hidden", 1, "Check", validate_fields_for_doctype=False)


def ensure_settings():
	s = frappe.get_single("HR Management Settings")
	defaults = {
		"basic_component": "Basic Salary", "paye_component": "PAYE", "nssf_component": "NSSF Employee",
		"lst_component": "Local Service Tax", "insurance_component": "Staff Insurance Contribution",
		"currency": "UGX" if frappe.db.exists("Currency", "UGX") else None,
		"nssf_employee_rate": 5, "nssf_employer_rate": 10, "lst_start_month": "July", "lst_installments": 4,
		"lst_base": "Gross pay less PAYE", "working_hours_per_week": 48, "default_probation_months": 6,
		"default_notice_period_days": 30, "contract_reminder_days": "60,30,7", "probation_reminder_days": 14,
		"insurance_reminder_days": "30,7", "email_notifications": 1, "notify_line_manager": 1,
		"payslip_print_format": "Uganda Payslip" if frappe.db.exists("Print Format", "Uganda Payslip") else None,
		"company": frappe.defaults.get_global_default("company"),
	}
	for field, value in defaults.items():
		if value is not None and s.get(field) in (None, "", 0):
			s.set(field, value)
	if not s.lst_bands:
		for a, b, amt in LST_BANDS:
			s.append("lst_bands", {"from_amount": a, "to_amount": b, "annual_lst": amt})
	s.flags.ignore_permissions = True
	s.save()
