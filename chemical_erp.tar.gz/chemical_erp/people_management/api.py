import frappe
from frappe import _
from frappe.utils import now_datetime

from chemical_erp.people_management.utils import get_settings


def _employee_email(employee):
	meta = frappe.get_meta("Employee")
	fields = [f for f in ("prefered_email", "personal_email", "company_email", "user_id") if meta.has_field(f)]
	values = frappe.db.get_value("Employee", employee, fields, as_dict=True) or {}
	for f in fields:
		if values.get(f) and "@" in values.get(f):
			return values.get(f)
	return None


@frappe.whitelist()
def email_payslip(payslip):
	doc = frappe.get_doc("Staff Payslip", payslip)
	doc.check_permission("email")
	if doc.docstatus != 1:
		frappe.throw(_("Submit the payslip before emailing it."))
	email = _employee_email(doc.employee)
	if not email:
		frappe.throw(_("{0} has no email address on their Employee record.").format(doc.employee_name))
	print_format = get_settings().payslip_print_format or "Uganda Payslip"
	frappe.sendmail(
		recipients=[email],
		subject=_("Your payslip for {0}").format(frappe.utils.formatdate(doc.end_date, "MMMM yyyy")),
		message=_("Dear {0},<br><br>Your payslip is attached.<br><br>Human Resources").format(doc.employee_name),
		attachments=[frappe.attach_print("Staff Payslip", doc.name, print_format=print_format, file_name=f"Payslip {doc.name}")],
		reference_doctype="Staff Payslip",
		reference_name=doc.name,
	)
	doc.db_set("emailed_on", now_datetime())
	return email


def email_run_payslips(run):
	sent, missing = 0, []
	for name in frappe.get_all("Staff Payslip", filters={"payroll_run": run, "docstatus": 1}, pluck="name"):
		try:
			email_payslip(name)
			sent += 1
		except Exception:
			missing.append(name)
			frappe.clear_last_message()
	frappe.get_doc("Payroll Run", run).add_comment(
		"Info",
		_("Payslips emailed: {0}.").format(sent) + (_(" Not sent (no email address or error): {0}").format(", ".join(missing)) if missing else ""),
	)


@frappe.whitelist()
def preview_paye(amount, residency="Resident", on_date=None):
	"""Quick check from the PAYE Band Set form."""
	from chemical_erp.people_management.utils import compute_paye

	return compute_paye(float(amount), residency, on_date or frappe.utils.today())
