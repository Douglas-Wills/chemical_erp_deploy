"""Staff system accounts: only the system administrator (System Manager), the Managing Director and the HR Manager create them.

The rule is enforced on the User record itself, so it holds however an account is made (this app's button,
the Users list, or ERPNext's Employee 'Create User'). Website accounts for the customer portal are not affected.
"""

import frappe
from frappe import _

ACCOUNT_CREATORS = ("System Manager", "Managing Director", "HR Manager")


def may_create_accounts(user=None):
	user = user or frappe.session.user
	return user == "Administrator" or bool(set(frappe.get_roles(user)) & set(ACCOUNT_CREATORS))


def guard(doc, method=None):
	if frappe.flags.in_install or frappe.flags.in_migrate or frappe.flags.in_test or frappe.flags.in_setup_wizard:
		return
	if doc.name in ("Administrator", "Guest") or doc.user_type != "System User":
		return
	becoming_staff = doc.is_new() or (doc.get_doc_before_save() and doc.get_doc_before_save().user_type != "System User")
	if becoming_staff and not may_create_accounts():
		frappe.throw(_("Only the system administrator, the Managing Director or the HR Manager can create staff system accounts."),
		             frappe.PermissionError, title=_("Not allowed"))


@frappe.whitelist()
def create_employee_account(employee, email, send_welcome_email=1):
	if not may_create_accounts():
		frappe.throw(_("Only the system administrator, the Managing Director or the HR Manager can create staff system accounts."), frappe.PermissionError)
	emp = frappe.get_doc("Employee", employee)
	if emp.user_id:
		frappe.throw(_("{0} already has an account: {1}").format(emp.employee_name, emp.user_id))
	email = (email or "").strip().lower()
	if not frappe.utils.validate_email_address(email):
		frappe.throw(_("Enter a valid email address."))
	if frappe.db.exists("User", email):
		user = frappe.get_doc("User", email)
		if frappe.db.exists("Employee", {"user_id": email}):
			frappe.throw(_("{0} is already linked to another employee.").format(email))
	else:
		user = frappe.get_doc({"doctype": "User", "email": email, "first_name": emp.first_name, "last_name": emp.last_name,
		                       "user_type": "System User", "enabled": 1, "send_welcome_email": int(send_welcome_email),
		                       "roles": [{"role": "Employee"}]})
		user.flags.ignore_permissions = True
		user.insert()
	emp.user_id = user.name
	if emp.meta.has_field("company_email") and not emp.company_email:
		emp.company_email = user.name
	emp.flags.ignore_permissions = True
	emp.save()
	from chemical_erp.people_management.positions import sync_positions

	sync_positions()  # roles of any post they already hold
	emp.add_comment("Info", _("System account {0} created by {1}").format(user.name, frappe.utils.get_fullname(frappe.session.user)))
	return user.name
