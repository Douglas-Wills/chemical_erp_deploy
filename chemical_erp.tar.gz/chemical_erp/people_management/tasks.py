import frappe
from frappe import _
from frappe.utils import cint, date_diff, formatdate, getdate, today

from chemical_erp.people_management.utils import get_settings, hr_recipients, notify, parse_days


def daily():
	for job in (refresh_contracts, refresh_insurance):
		try:
			job()
			frappe.db.commit()
		except Exception:
			frappe.db.rollback()
			frappe.log_error(title=f"HR Management daily job failed: {job.__name__}", message=frappe.get_traceback())


def _mark(doctype, name, sent, token, also=()):
	sent.add(token)
	sent.update(also)
	frappe.db.set_value(doctype, name, "reminders_sent", ",".join(sorted(sent)), update_modified=False)


def refresh_contracts():
	settings = get_settings()
	thresholds = parse_days(settings.contract_reminder_days)
	probation_days = cint(settings.probation_reminder_days)
	now = getdate(today())

	for name in frappe.get_all("Employment Contract", filters={"status": ["not in", ["Terminated", "Renewed"]]}, pluck="name"):
		doc = frappe.get_doc("Employment Contract", name)
		status = doc.compute_status()
		if status != doc.status:
			frappe.db.set_value("Employment Contract", name, "status", status, update_modified=False)
			doc.status = status
			if status in ("Active", "Expiring Soon"):
				doc.update_employee()
		sent = {s for s in (doc.reminders_sent or "").split(",") if s}
		who = hr_recipients(doc.employee)

		if doc.end_date and status in ("Active", "Expiring Soon") and not doc.renewed_by:
			days = date_diff(doc.end_date, now)
			for t in thresholds:
				if days <= t and f"exp{t}" not in sent:
					notify(
						who, "Employment Contract", name,
						subject=_("Contract ending in {0} days: {1}").format(days, doc.employee_name),
						message=_("{0}'s {1} contract ends on {2}. Renew it, or plan the exit and notice.").format(
							doc.employee_name, doc.contract_type.lower(), formatdate(doc.end_date)),
						priority="High" if days <= 7 else "Medium",
					)
					# Mark every threshold already passed, so a late start doesn't send several in a row
					_mark("Employment Contract", name, sent, f"exp{t}", [f"exp{x}" for x in thresholds if days <= x])
					break

		if status == "Expired" and "expired" not in sent:
			notify(who, "Employment Contract", name,
			       subject=_("Contract expired: {0}").format(doc.employee_name),
			       message=_("{0}'s contract expired on {1} and has not been renewed. They will be left out of payroll until a new signed contract exists.").format(
				       doc.employee_name, formatdate(doc.end_date)), priority="High")
			_mark("Employment Contract", name, sent, "expired")

		if doc.probation_end_date and not cint(doc.confirmed) and status in ("Active", "Expiring Soon"):
			left = date_diff(doc.probation_end_date, now)
			if 0 <= left <= probation_days and "probation" not in sent:
				notify(who, "Employment Contract", name,
				       subject=_("Probation ends in {0} days: {1}").format(left, doc.employee_name),
				       message=_("{0}'s probation ends on {1}. Complete the review and record confirmation (or extension) on the contract.").format(
					       doc.employee_name, formatdate(doc.probation_end_date)))
				_mark("Employment Contract", name, sent, "probation")

		if not cint(doc.is_signed) and getdate(doc.start_date) <= now and "unsigned" not in sent:
			notify(who, "Employment Contract", name,
			       subject=_("Unsigned contract: {0}").format(doc.employee_name),
			       message=_("{0}'s contract started on {1} but is not marked signed. Unsigned contracts are excluded from payroll.").format(
				       doc.employee_name, formatdate(doc.start_date)), priority="High")
			_mark("Employment Contract", name, sent, "unsigned")


def refresh_insurance():
	settings = get_settings()
	thresholds = parse_days(settings.insurance_reminder_days)
	now = getdate(today())
	for name in frappe.get_all("Staff Insurance Policy", filters={"end_date": [">=", frappe.utils.add_days(now, -1)]}, pluck="name"):
		doc = frappe.get_doc("Staff Insurance Policy", name)
		status = doc.compute_status()
		if status != doc.status:
			frappe.db.set_value("Staff Insurance Policy", name, "status", status, update_modified=False)
		sent = {s for s in (doc.reminders_sent or "").split(",") if s}
		days = date_diff(doc.end_date, now)
		for t in thresholds:
			if 0 <= days <= t and f"exp{t}" not in sent:
				notify(hr_recipients(), "Staff Insurance Policy", name,
				       subject=_("{0} insurance expires in {1} days").format(doc.policy_name, days),
				       message=_("{0} ({1}, {2}) expires on {3}, covering {4} members. Arrange renewal with {5}.").format(
					       doc.policy_name, doc.policy_type, doc.policy_no or _("no policy number"), formatdate(doc.end_date),
					       doc.member_count, doc.insurer_name or _("the insurer")),
				       priority="High" if days <= 7 else "Medium")
				_mark("Staff Insurance Policy", name, sent, f"exp{t}", [f"exp{x}" for x in thresholds if days <= x])
				break
