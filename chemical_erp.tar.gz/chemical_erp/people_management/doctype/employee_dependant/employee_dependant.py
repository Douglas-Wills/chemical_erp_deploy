from frappe.model.document import Document


class EmployeeDependant(Document):
	pass
