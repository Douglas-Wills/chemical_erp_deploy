import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt


class HRManagementSettings(Document):
	def validate(self):
		for field in ("contract_reminder_days", "insurance_reminder_days"):
			days = [d.strip() for d in (self.get(field) or "").split(",") if d.strip()]
			if any(not d.isdigit() for d in days):
				frappe.throw(_("{0} must be whole numbers separated by commas.").format(self.meta.get_label(field)))
			self.set(field, ",".join(days))
		bands = sorted(self.lst_bands, key=lambda b: flt(b.from_amount))
		for i in range(len(bands) - 1):
			if flt(bands[i].to_amount) != flt(bands[i + 1].from_amount):
				frappe.throw(_("LST bands must join up without gaps (check the band starting at {0}).").format(bands[i + 1].from_amount))
