import frappe
from frappe import _
from frappe.model.document import Document


class CompanyPosition(Document):
	def validate(self):
		seen = set()
		for h in self.holders:
			if h.user in seen:
				frappe.throw(_("{0} is listed twice.").format(h.user))
			seen.add(h.user)

	def on_update(self):
		from chemical_erp.people_management.positions import sync_positions

		sync_positions()

	def on_trash(self):
		frappe.enqueue("chemical_erp.people_management.positions.sync_positions", enqueue_after_commit=True)
