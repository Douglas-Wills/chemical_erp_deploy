frappe.listview_settings["Staff Insurance Policy"] = {
	add_fields: ["status"],
	get_indicator(doc) {
		const c = { Active: "green", "Expiring Soon": "orange", Expired: "red", Upcoming: "blue" };
		return [__(doc.status), c[doc.status] || "gray", "status,=," + doc.status];
	},
};
