import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import date_diff, flt, getdate, today

from chemical_erp.people_management.utils import get_settings, parse_days


class StaffInsurancePolicy(Document):
	def validate(self):
		if getdate(self.end_date) < getdate(self.start_date):
			frappe.throw(_("End date can't be before the start date."))
		seen = set()
		for m in self.members:
			key = (m.employee, m.member_type, (m.dependant_name or "").strip().lower())
			if key in seen:
				frappe.throw(_("Row {0}: {1} is listed twice.").format(m.idx, m.dependant_name or m.employee_name))
			seen.add(key)
			if m.member_type != "Principal" and not m.dependant_name:
				frappe.throw(_("Row {0}: enter the dependant's name.").format(m.idx))
		active = [m for m in self.members if not m.date_removed or getdate(m.date_removed) >= getdate(today())]
		self.member_count = len(active)
		self.total_monthly_deductions = sum(flt(m.employee_monthly_contribution) for m in active)
		self.status = self.compute_status()

	def compute_status(self):
		now = getdate(today())
		if getdate(self.start_date) > now:
			return "Upcoming"
		if getdate(self.end_date) < now:
			return "Expired"
		window = max(parse_days(get_settings().insurance_reminder_days) or [30])
		return "Expiring Soon" if date_diff(self.end_date, now) <= window else "Active"
