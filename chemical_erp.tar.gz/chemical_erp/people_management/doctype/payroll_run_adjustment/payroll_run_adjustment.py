from frappe.model.document import Document


class PayrollRunAdjustment(Document):
	pass
