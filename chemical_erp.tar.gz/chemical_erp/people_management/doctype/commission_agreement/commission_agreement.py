from frappe.model.document import Document

from chemical_erp.people_management.commission import validate_agreement


class CommissionAgreement(Document):
	def validate(self):
		validate_agreement(self)
