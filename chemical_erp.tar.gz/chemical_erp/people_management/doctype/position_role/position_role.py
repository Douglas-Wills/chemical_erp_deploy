from frappe.model.document import Document


class PositionRole(Document):
	pass
