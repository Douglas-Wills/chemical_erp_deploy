frappe.views.calendar["Employment Contract"] = {
	field_map: { start: "end_date", end: "end_date", id: "name", title: "employee_name", allDay: "allDay" },
	filters: [{ fieldtype: "Select", fieldname: "status", options: "\nActive\nExpiring Soon\nExpired", label: __("Status") }],
	get_events_method: "frappe.desk.calendar.get_events",
};
