import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, add_months, cint, date_diff, flt, getdate, today

from chemical_erp.people_management.utils import get_settings, parse_days

CLOSED = ("Terminated", "Renewed")


class EmploymentContract(Document):
	def validate(self):
		settings = get_settings()
		if self.end_date and getdate(self.end_date) < getdate(self.start_date):
			frappe.throw(_("End date can't be before the start date."))
		if self.contract_type == "Permanent":
			self.end_date = None
		if self.probation_months is None and self.is_new():
			self.probation_months = cint(settings.default_probation_months)
		self.probation_end_date = (
			add_days(add_months(self.start_date, cint(self.probation_months)), -1) if cint(self.probation_months) else None
		)
		if not self.notice_period_days:
			self.notice_period_days = cint(settings.default_notice_period_days)
		if not self.working_hours_per_week:
			self.working_hours_per_week = flt(settings.working_hours_per_week)
		if not self.currency:
			self.currency = settings.currency or frappe.get_cached_value("Company", self.company, "default_currency")
		if cint(self.confirmed) and not self.confirmation_date:
			self.confirmation_date = today()
		self.calculate_pay()
		self.check_overlap()
		self.set_status()

	def calculate_pay(self):
		gross = flt(self.basic_salary)
		for item in self.pay_items:
			comp_type = frappe.get_cached_value("Pay Component", item.pay_component, "component_type")
			item.component_type = comp_type
			if item.calculation == "Percent of Basic":
				item.monthly_amount = flt(self.basic_salary) * flt(item.percent) / 100
			else:
				item.monthly_amount = flt(item.amount)
			if comp_type == "Earning":
				gross += item.monthly_amount
		self.gross_monthly = gross

	def check_overlap(self):
		end = self.end_date or "9999-12-31"
		clash = frappe.db.sql(
			"""select name from `tabEmployment Contract`
			where employee=%(emp)s and name != %(name)s and status not in ('Terminated')
				and start_date <= %(end)s and ifnull(end_date, '9999-12-31') >= %(start)s
				and (termination_date is null or termination_date >= %(start)s)
			limit 1""",
			{"emp": self.employee, "name": self.name or "", "start": self.start_date, "end": end},
		)
		if clash:
			frappe.throw(
				_("This contract overlaps {0} for the same employee. End or terminate that contract first.").format(clash[0][0]),
				title=_("Overlapping contract"),
			)

	def compute_status(self):
		reminder_window = max(parse_days(get_settings().contract_reminder_days) or [30])
		start, now = getdate(self.start_date), getdate(today())
		if self.termination_date:
			return "Terminated"
		if self.end_date and getdate(self.end_date) < now:
			return "Renewed" if self.renewed_by else "Expired"
		if not cint(self.is_signed):
			return "Draft"
		if start > now:
			return "Upcoming"
		if self.end_date and date_diff(self.end_date, now) <= reminder_window and not self.renewed_by:
			return "Expiring Soon"
		return "Active"

	def set_status(self):
		self.status = self.compute_status()

	def on_update(self):
		if self.previous_contract:
			frappe.db.set_value("Employment Contract", self.previous_contract, "renewed_by", self.name, update_modified=False)
		self.update_employee()

	def update_employee(self):
		if self.status not in ("Active", "Expiring Soon"):
			return
		meta = frappe.get_meta("Employee")
		values = {}
		if meta.has_field("current_contract"):
			values["current_contract"] = self.name
		if meta.has_field("contract_end_date"):
			values["contract_end_date"] = self.end_date
		if meta.has_field("final_confirmation_date") and self.confirmation_date:
			values["final_confirmation_date"] = self.confirmation_date
		if values:
			frappe.db.set_value("Employee", self.employee, values, update_modified=False)

	@frappe.whitelist()
	def renew(self, start_date=None, end_date=None, basic_salary=None):
		frappe.has_permission("Employment Contract", "create", throw=True)
		if self.renewed_by:
			frappe.throw(_("Already renewed by {0}.").format(self.renewed_by))
		new = frappe.copy_doc(self)
		new.start_date = start_date or (add_days(self.end_date, 1) if self.end_date else today())
		new.end_date = end_date or None
		if basic_salary:
			new.basic_salary = flt(basic_salary)
		new.previous_contract = self.name
		new.probation_months = 0
		new.is_signed = 0
		new.insert()
		return new.name

	@frappe.whitelist()
	def terminate(self, termination_date, reason, notes=None, update_employee=0):
		frappe.only_for(("HR Manager", "System Manager"))
		self.termination_date = termination_date
		self.termination_reason = reason
		self.termination_notes = notes
		self.save()
		if cint(update_employee):
			emp = frappe.get_doc("Employee", self.employee)
			if not emp.relieving_date:
				emp.relieving_date = termination_date
				emp.save()
		self.add_comment("Info", _("Contract terminated on {0}: {1}").format(termination_date, reason))
		return self.status
