frappe.ui.form.on("Employment Contract", {
	setup(frm) {
		frm.set_query("previous_contract", () => ({ filters: { employee: frm.doc.employee } }));
	},
	refresh(frm) {
		if (frm.is_new()) return;
		const d = frm.doc;
		if (d.status === "Draft") {
			frm.dashboard.set_headline_alert(__("Not active until it is marked signed. Unsigned contracts are excluded from payroll."), "orange");
		} else if (d.status === "Expiring Soon") {
			frm.dashboard.set_headline_alert(__("Ends on {0}. Renew it or plan the exit.", [frappe.datetime.str_to_user(d.end_date)]), "orange");
		} else if (d.probation_end_date && !d.confirmed && d.status === "Active") {
			frm.dashboard.set_headline_alert(__("On probation until {0}.", [frappe.datetime.str_to_user(d.probation_end_date)]), "blue");
		}

		if (!["Terminated", "Renewed"].includes(d.status) && !d.renewed_by) {
			frm.add_custom_button(__("Renew"), () => {
				frappe.prompt([
					{ fieldname: "start_date", fieldtype: "Date", label: __("New Start Date"), reqd: 1,
					  default: d.end_date ? frappe.datetime.add_days(d.end_date, 1) : frappe.datetime.get_today() },
					{ fieldname: "end_date", fieldtype: "Date", label: __("New End Date"), description: __("Leave blank for permanent") },
					{ fieldname: "basic_salary", fieldtype: "Currency", label: __("New Basic Salary"), default: d.basic_salary },
				], (v) => {
					frm.call("renew", v).then((r) => {
						frappe.show_alert({ message: __("Renewal {0} created as a draft. Mark it signed once both parties sign.", [r.message]), indicator: "green" });
						frappe.set_route("Form", "Employment Contract", r.message);
					});
				}, __("Renew Contract"), __("Create Renewal"));
			}, __("Actions"));
		}
		if (d.status !== "Terminated" && frappe.user.has_role(["HR Manager", "System Manager"])) {
			frm.add_custom_button(__("Terminate"), () => {
				frappe.prompt([
					{ fieldname: "termination_date", fieldtype: "Date", label: __("Last Working Day"), reqd: 1, default: frappe.datetime.get_today() },
					{ fieldname: "reason", fieldtype: "Select", label: __("Reason"), reqd: 1,
					  options: ["Resignation", "Dismissal", "Redundancy", "End of Contract (not renewed)", "Retirement", "Death", "Mutual Agreement", "Other"].join("\n") },
					{ fieldname: "notes", fieldtype: "Small Text", label: __("Notes") },
					{ fieldname: "update_employee", fieldtype: "Check", label: __("Set this as the employee's relieving date"), default: 1 },
				], (v) => frm.call("terminate", v).then(() => frm.reload_doc()), __("Terminate Contract"), __("Terminate"));
			}, __("Actions"));
		}
	},
	basic_salary: (frm) => recalc(frm),
	pay_items_remove: (frm) => recalc(frm),
});

frappe.ui.form.on("Contract Pay Item", {
	amount: (frm) => recalc(frm),
	percent: (frm) => recalc(frm),
	calculation: (frm) => recalc(frm),
	pay_component: (frm) => setTimeout(() => recalc(frm), 300),
});

function recalc(frm) {
	let gross = flt(frm.doc.basic_salary);
	(frm.doc.pay_items || []).forEach((row) => {
		row.monthly_amount = row.calculation === "Percent of Basic" ? flt(frm.doc.basic_salary) * flt(row.percent) / 100 : flt(row.amount);
		if (row.component_type === "Earning") gross += row.monthly_amount;
	});
	frm.doc.gross_monthly = gross;
	frm.refresh_field("pay_items");
	frm.refresh_field("gross_monthly");
}
