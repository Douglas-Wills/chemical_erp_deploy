frappe.listview_settings["Employment Contract"] = {
	add_fields: ["status", "end_date"],
	get_indicator(doc) {
		const c = { Draft: "gray", Upcoming: "blue", Active: "green", "Expiring Soon": "orange", Expired: "red", Renewed: "purple", Terminated: "darkgrey" };
		return [__(doc.status), c[doc.status] || "gray", "status,=," + doc.status];
	},
};
