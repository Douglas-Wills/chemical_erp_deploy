import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import getdate, now_datetime, today

from chemical_erp.people_management.access import activate, check_authority, deactivate, is_md, team_of, employee_of


class AccessGrant(Document):
	def validate(self):
		if not self.user:
			frappe.throw(_("{0} has no ERPNext login. Create a user for them first.").format(self.employee_name or self.employee))
		if self.valid_to and getdate(self.valid_to) < getdate(self.valid_from):
			frappe.throw(_("Valid Until is before Valid From."))
		check_authority(self)

	def on_submit(self):
		self.db_set({"granted_by": frappe.session.user, "granted_on": now_datetime()})
		if getdate(self.valid_from) <= getdate(today()):
			activate(self)
			self.db_set("status", "Active")
		else:
			self.db_set("status", "Draft")  # starts on its date (daily job)
		from chemical_erp.utils import notify

		notify(self.user, self.doctype, self.name, _("You have been given access: {0}").format(self.access_profile or self.role))

	def before_cancel(self):
		user = frappe.session.user
		if user == "Administrator" or is_md(user) or user == self.granted_by:
			return
		me = employee_of(user)
		if not me or self.employee not in team_of(me):
			frappe.throw(_("Only the line manager or the Managing Director can revoke this access."), frappe.PermissionError)

	def on_cancel(self):
		deactivate(self)
		self.db_set({"status": "Revoked", "ended_by": frappe.session.user, "ended_on": now_datetime()})


def query_conditions(user=None):
	"""Line managers see their team's grants; the MD, HR and System Manager see all; everyone sees their own."""
	user = user or frappe.session.user
	roles = frappe.get_roles(user)
	if user == "Administrator" or {"Managing Director", "System Manager", "HR Manager", "HR User"} & set(roles):
		return ""
	me = employee_of(user)
	team = list(team_of(me)) if me else []
	allowed = [frappe.db.escape(e) for e in team] + ([frappe.db.escape(me)] if me else [])
	if not allowed:
		return "1=0"
	return f"`tabAccess Grant`.`employee` in ({', '.join(allowed)})"
