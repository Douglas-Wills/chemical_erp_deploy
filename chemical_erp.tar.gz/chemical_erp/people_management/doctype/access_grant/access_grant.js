frappe.ui.form.on("Access Grant", {
	setup(frm) {
		frm.set_query("role", () => ({ filters: { name: ["not in", ["System Manager", "Administrator", "Guest", "All", "Formula Owner"]], desk_access: 1 } }));
	},
	refresh(frm) {
		if (frm.doc.docstatus === 1 && frm.doc.status === "Active") {
			frm.page.set_indicator(__("Active"), "green");
		}
	},
});
