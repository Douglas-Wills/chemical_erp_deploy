frappe.ui.form.on("Staff Payslip", {
	refresh(frm) {
		if (frm.doc.docstatus === 1) {
			frm.add_custom_button(__("Email to Employee"), () => {
				frm.call("email_to_employee").then((r) => frappe.show_alert({ message: __("Sent to {0}", [r.message]), indicator: "green" }));
			});
		}
	},
});
