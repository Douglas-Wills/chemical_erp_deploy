import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import cint, date_diff, flt

from chemical_erp.people_management.utils import annual_lst, compute_paye, get_settings, is_lst_month


class StaffPayslip(Document):
	def validate(self):
		if not self.days_in_period:
			self.days_in_period = date_diff(self.end_date, self.start_date) + 1
		if not self.payable_days:
			self.payable_days = self.days_in_period
		self.copy_employee_details()
		self.calculate()

	def copy_employee_details(self):
		meta = frappe.get_meta("Employee")
		wanted = {
			"tin": "tin", "nssf_number": "nssf_number", "paye_residency": "paye_residency",
			"payment_mode": "salary_payment_mode", "bank_name": "bank_name", "bank_account": "bank_ac_no",
			"mobile_money_number": "mobile_money_number",
		}
		fields = [src for src in wanted.values() if meta.has_field(src)]
		values = frappe.db.get_value("Employee", self.employee, fields, as_dict=True) or {}
		for target, src in wanted.items():
			if src in values:
				self.set(target, values.get(src))
		self.paye_residency = self.paye_residency or "Resident"

	def calculate(self):
		settings = get_settings()
		flags = frappe._dict()
		meta = frappe.get_meta("Employee")
		for f in ("paye_exempt", "nssf_exempt", "lst_exempt"):
			flags[f] = cint(frappe.db.get_value("Employee", self.employee, f)) if meta.has_field(f) else 0

		# Statutory lines are always rebuilt; everything else is kept as entered.
		self.set("deductions", [d for d in self.deductions if not cint(d.is_statutory)])

		for row in self.earnings + self.deductions:
			comp = frappe.get_cached_doc("Pay Component", row.pay_component)
			row.is_taxable, row.nssf_applicable, row.is_statutory = comp.is_taxable, comp.nssf_applicable, comp.is_statutory
			row.amount = round(flt(row.amount))

		gross = sum(flt(e.amount) for e in self.earnings)
		self.gross_pay = gross
		self.taxable_pay = sum(flt(e.amount) for e in self.earnings if cint(e.is_taxable))
		self.nssf_base = sum(flt(e.amount) for e in self.earnings if cint(e.nssf_applicable))

		if flags.paye_exempt:
			self.paye, self.paye_band_set = 0, None
		else:
			self.paye, self.paye_band_set = compute_paye(self.taxable_pay, self.paye_residency, self.end_date)

		self.nssf_employee = 0 if flags.nssf_exempt else round(self.nssf_base * flt(settings.nssf_employee_rate) / 100)
		self.nssf_employer = 0 if flags.nssf_exempt else round(self.nssf_base * flt(settings.nssf_employer_rate) / 100)

		self.lst = 0
		if not flags.lst_exempt and is_lst_month(self.end_date, settings):
			base = gross - self.paye if settings.lst_base == "Gross pay less PAYE" else gross
			self.lst = round(annual_lst(base, settings) / (cint(settings.lst_installments) or 4))

		for comp_field, amount in (
			("paye_component", self.paye),
			("nssf_component", self.nssf_employee),
			("lst_component", self.lst),
		):
			comp = settings.get(comp_field)
			if amount and comp:
				self.append("deductions", {"pay_component": comp, "amount": amount, "is_statutory": 1})

		self.other_deductions = sum(flt(d.amount) for d in self.deductions if not cint(d.is_statutory))
		self.total_deductions = self.paye + self.nssf_employee + self.lst + self.other_deductions
		self.net_pay = gross - self.total_deductions
		if self.net_pay < 0:
			frappe.msgprint(
				_("{0}'s deductions are more than gross pay; net pay is negative.").format(self.employee_name),
				indicator="red", alert=True,
			)

	@frappe.whitelist()
	def email_to_employee(self):
		from chemical_erp.people_management.api import email_payslip

		return email_payslip(self.name)
