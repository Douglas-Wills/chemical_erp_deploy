from frappe.model.document import Document


class LSTBand(Document):
	pass
