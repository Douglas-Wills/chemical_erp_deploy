import frappe
from frappe import _
from frappe.model.document import Document


class PayComponent(Document):
	def validate(self):
		if self.component_type == "Deduction":
			self.is_taxable = 0
			self.nssf_applicable = 0

	def on_trash(self):
		if self.is_statutory:
			frappe.throw(_("Statutory components are used by the payroll engine and can't be deleted."))
