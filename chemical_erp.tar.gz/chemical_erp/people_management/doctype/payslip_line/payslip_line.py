from frappe.model.document import Document


class PayslipLine(Document):
	pass
