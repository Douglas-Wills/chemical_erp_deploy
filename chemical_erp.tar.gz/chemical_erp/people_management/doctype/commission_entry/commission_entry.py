import frappe
from frappe import _
from frappe.model.document import Document


class CommissionEntry(Document):
	"""Written only by the system (sales, expense claims, payouts). Never edited: corrections are new lines."""

	def validate(self):
		if not self.is_new() and not frappe.flags.in_install:
			frappe.throw(_("Commission lines cannot be edited. Corrections are made as new lines."))

	def on_trash(self):
		if frappe.session.user != "Administrator":
			frappe.throw(_("Commission lines cannot be deleted."))
