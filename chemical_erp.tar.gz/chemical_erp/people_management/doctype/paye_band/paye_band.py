from frappe.model.document import Document


class PAYEBand(Document):
	pass
