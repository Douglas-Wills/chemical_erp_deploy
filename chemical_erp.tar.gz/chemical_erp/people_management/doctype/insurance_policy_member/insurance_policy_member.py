from frappe.model.document import Document


class InsurancePolicyMember(Document):
	pass
