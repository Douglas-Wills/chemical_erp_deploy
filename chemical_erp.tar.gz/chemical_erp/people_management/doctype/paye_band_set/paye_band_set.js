frappe.ui.form.on("PAYE Band Set", {
	refresh(frm) {
		if (frm.is_new()) return;
		frm.add_custom_button(__("Test a Salary"), () => {
			frappe.prompt({ fieldname: "amount", fieldtype: "Currency", label: __("Monthly chargeable income"), reqd: 1 }, (v) => {
				frappe.call("chemical_erp.people_management.api.preview_paye", { amount: v.amount, residency: frm.doc.residency, on_date: frm.doc.effective_from }).then((r) => {
					const [tax, set] = r.message;
					frappe.msgprint(__("PAYE on {0}: <b>{1}</b> (using {2})", [format_currency(v.amount), format_currency(tax), set]));
				});
			}, __("Test PAYE"));
		});
	},
});
