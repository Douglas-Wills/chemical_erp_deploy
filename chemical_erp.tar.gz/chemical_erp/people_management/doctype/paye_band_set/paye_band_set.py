import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt


class PAYEBandSet(Document):
	def validate(self):
		bands = sorted(self.bands, key=lambda b: flt(b.from_amount))
		for i, band in enumerate(bands):
			if flt(band.to_amount) and flt(band.to_amount) <= flt(band.from_amount):
				frappe.throw(_("Row {0}: 'To' must be above 'From'.").format(band.idx))
			if i + 1 < len(bands) and flt(band.to_amount) != flt(bands[i + 1].from_amount):
				frappe.throw(_("Bands must join up: row {0} ends at {1} but the next band starts at {2}.").format(
					band.idx, band.to_amount, bands[i + 1].from_amount))
		if bands and flt(bands[-1].to_amount):
			frappe.throw(_("The last band needs a 'To' of 0 (no upper limit)."))
		frappe.clear_document_cache("PAYE Band Set", self.name)
