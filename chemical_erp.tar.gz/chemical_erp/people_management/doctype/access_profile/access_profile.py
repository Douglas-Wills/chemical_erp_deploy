from frappe.model.document import Document


class AccessProfile(Document):
	pass
