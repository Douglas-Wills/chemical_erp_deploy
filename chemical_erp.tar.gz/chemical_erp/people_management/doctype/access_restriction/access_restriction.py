from frappe.model.document import Document


class AccessRestriction(Document):
	pass
