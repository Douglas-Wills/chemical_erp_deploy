frappe.ui.form.on("Payroll Run", {
	onload(frm) {
		if (frm.is_new() && !frm.doc.payroll_year) {
			const today = frappe.datetime.str_to_obj(frappe.datetime.get_today());
			frm.set_value("payroll_year", today.getFullYear());
			frm.set_value("payroll_month", moment(today).format("MMMM"));
		}
	},
	refresh(frm) {
		const d = frm.doc;
		if (d.docstatus === 0 && !frm.is_new()) {
			frm.add_custom_button(__("Add Payable Commissions"), () => {
				if (frm.is_dirty()) return frappe.msgprint(__("Save first."));
				frappe.call({ method: "chemical_erp.people_management.commission.add_to_payroll", args: { payroll_run: d.name }, freeze: true }).then(({ message }) => {
					frm.reload_doc();
					frappe.msgprint((message || []).length
						? __("Commission added for {0} employee(s). Recalculate the payslips to include it.", [message.length])
						: __("No commission is payable now (it becomes payable as customers pay)."));
				});
			});
			frm.add_custom_button(d.employee_count ? __("Recalculate Payslips") : __("Calculate Payslips"), () => {
				if (frm.is_dirty()) return frappe.msgprint(__("Save first."));
				frm.call({ method: "calculate_payslips", doc: d, freeze: true, freeze_message: __("Calculating payslips…") }).then((r) => {
					frm.reload_doc();
					const m = r.message || {};
					frappe.show_alert({ message: __("{0} payslip(s) created, {1} warning(s)", [m.payslips || 0, m.warnings || 0]), indicator: m.warnings ? "orange" : "green" });
				});
			}).addClass("btn-primary");
		}
		if (d.employee_count) {
			frm.add_custom_button(__("Payslips"), () => {
				frappe.route_options = { payroll_run: d.name };
				frappe.set_route("List", "Staff Payslip");
			}, __("View"));
			frm.add_custom_button(__("Payroll Register"), () => {
				frappe.set_route("query-report", "Payroll Register", { payroll_run: d.name });
			}, __("View"));
		}
		if (d.docstatus === 1) {
			frm.add_custom_button(__("Email Payslips to Staff"), () => {
				frappe.confirm(__("Email every payslip in this run to its employee?"), () => {
					frm.call("email_payslips").then((r) => frappe.show_alert({ message: __("Sending {0} payslips in the background", [r.message]), indicator: "green" }));
				});
			});
		}
		if (d.warnings) {
			frm.dashboard.set_headline_alert(__("Some staff were skipped. See Employees Skipped / Warnings."), "orange");
		}
	},
});
