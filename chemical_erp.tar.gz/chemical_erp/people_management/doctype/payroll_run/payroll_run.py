import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt, get_first_day, get_last_day, getdate

from chemical_erp.people_management.payroll import build_payslip
from chemical_erp.people_management.utils import get_settings, month_number

TOTALS = {
	"total_gross": "gross_pay", "total_paye": "paye", "total_nssf_employee": "nssf_employee",
	"total_nssf_employer": "nssf_employer", "total_lst": "lst", "total_other_deductions": "other_deductions",
	"total_net": "net_pay",
}


class PayrollRun(Document):
	ignore_linked_doctypes = ("Staff Payslip", "Journal Entry")

	def validate(self):
		month = month_number(self.payroll_month)
		first = getdate(f"{self.payroll_year}-{month:02d}-01")
		self.start_date, self.end_date = get_first_day(first), get_last_day(first)
		clash = frappe.db.exists("Payroll Run", {
			"company": self.company, "payroll_month": self.payroll_month, "payroll_year": self.payroll_year,
			"docstatus": ["<", 2], "name": ["!=", self.name], "department": self.department or ["is", "not set"],
			"branch": self.branch or ["is", "not set"],
		})
		if clash:
			frappe.throw(_("{0} already covers {1} {2} for the same staff.").format(clash, self.payroll_month, self.payroll_year))
		if self.docstatus == 0:
			self.status = "Calculated" if self.employee_count else "Draft"

	def payslips(self, docstatus=None):
		filters = {"payroll_run": self.name}
		if docstatus is not None:
			filters["docstatus"] = docstatus
		return frappe.get_all("Staff Payslip", filters=filters, pluck="name")

	@frappe.whitelist()
	def calculate_payslips(self):
		if self.docstatus != 0:
			frappe.throw(_("Only a draft payroll run can be recalculated."))
		if self.is_new():
			self.insert()
		for name in self.payslips(docstatus=0):
			frappe.delete_doc("Staff Payslip", name, ignore_permissions=True, force=True)

		filters = {"company": self.company, "date_of_joining": ["<=", self.end_date]}
		if self.department:
			filters["department"] = self.department
		if self.branch:
			filters["branch"] = self.branch
		employees = frappe.get_all(
			"Employee", filters=filters,
			or_filters=[["relieving_date", "is", "not set"], ["relieving_date", ">=", self.start_date]],
			fields=["name", "status"], order_by="employee_name asc",
		)

		adjustments = {}
		for adj in self.adjustments:
			adjustments.setdefault(adj.employee, []).append(adj)

		warnings, made = [], 0
		for emp in employees:
			# Active staff, plus staff who left during this month (they still get their final pay)
			if emp.status == "Left":
				if not frappe.db.get_value("Employee", emp.name, "relieving_date"):
					continue
			elif emp.status != "Active":
				continue
			try:
				slip, warning = build_payslip(self, emp.name, adjustments.pop(emp.name, []))
			except frappe.ValidationError as e:
				slip, warning = None, f"{emp.name}: {frappe.utils.strip_html(str(e))}"
			if warning:
				warnings.append(warning)
			if slip:
				made += 1
		for emp in adjustments:
			warnings.append(_("Adjustment for {0} ignored: no payslip was created for them").format(emp))

		self.warnings = "\n".join(warnings)
		self.update_totals()
		self.save()
		return {"payslips": made, "warnings": len(warnings)}

	def update_totals(self):
		names = self.payslips(docstatus=["<", 2])
		self.employee_count = len(names)
		for total in TOTALS:
			self.set(total, 0)
		if names:
			rows = frappe.get_all("Staff Payslip", filters={"name": ["in", names]}, fields=list(TOTALS.values()))
			for total, field in TOTALS.items():
				self.set(total, sum(flt(r.get(field)) for r in rows))

	def before_submit(self):
		if not self.payslips(docstatus=0):
			frappe.throw(_("Calculate the payslips before submitting."))
		self.update_totals()

	def on_submit(self):
		for name in self.payslips(docstatus=0):
			frappe.get_doc("Staff Payslip", name).submit()
		self.db_set("status", "Submitted")
		if get_settings().post_journal_entry:
			self.make_journal_entry()

	def on_cancel(self):
		if self.journal_entry:
			je = frappe.get_doc("Journal Entry", self.journal_entry)
			if je.docstatus == 1:
				je.cancel()
			elif je.docstatus == 0:
				frappe.delete_doc("Journal Entry", je.name, ignore_permissions=True)
				self.db_set("journal_entry", None)
		for name in self.payslips(docstatus=1):
			frappe.get_doc("Staff Payslip", name).cancel()
		self.db_set("status", "Cancelled")

	def on_trash(self):
		for name in self.payslips(docstatus=0):
			frappe.delete_doc("Staff Payslip", name, ignore_permissions=True, force=True)

	def make_journal_entry(self):
		s = get_settings()
		required = ("salary_expense_account", "nssf_employer_expense_account", "payroll_payable_account",
		            "paye_payable_account", "nssf_payable_account", "lst_payable_account", "other_deductions_account")
		missing = [frappe.get_meta("HR Management Settings").get_label(f) for f in required if not s.get(f)]
		if missing:
			frappe.throw(_("Set these accounts in HR Management Settings first: {0}").format(", ".join(missing)))

		lines = [
			(s.salary_expense_account, self.total_gross, 0),
			(s.nssf_employer_expense_account, self.total_nssf_employer, 0),
			(s.paye_payable_account, 0, self.total_paye),
			(s.nssf_payable_account, 0, flt(self.total_nssf_employee) + flt(self.total_nssf_employer)),
			(s.lst_payable_account, 0, self.total_lst),
			(s.other_deductions_account, 0, self.total_other_deductions),
			(s.payroll_payable_account, 0, self.total_net),
		]
		je = frappe.new_doc("Journal Entry")
		je.voucher_type = "Journal Entry"
		je.company = self.company
		je.posting_date = self.posting_date
		je.user_remark = _("Payroll for {0} {1} ({2})").format(self.payroll_month, self.payroll_year, self.name)
		je.payroll_run = self.name
		for account, debit, credit in lines:
			if flt(debit) or flt(credit):
				je.append("accounts", {
					"account": account, "debit_in_account_currency": flt(debit),
					"credit_in_account_currency": flt(credit), "cost_center": s.cost_center,
				})
		je.insert()
		if s.submit_journal_entry:
			je.submit()
		self.db_set("journal_entry", je.name)

	@frappe.whitelist()
	def email_payslips(self):
		if self.docstatus != 1:
			frappe.throw(_("Submit the payroll run first."))
		frappe.enqueue("chemical_erp.people_management.api.email_run_payslips", run=self.name, queue="long", enqueue_after_commit=True)
		return len(self.payslips(docstatus=1))
