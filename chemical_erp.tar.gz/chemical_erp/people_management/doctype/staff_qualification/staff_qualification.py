from frappe.model.document import Document


class StaffQualification(Document):
	pass
