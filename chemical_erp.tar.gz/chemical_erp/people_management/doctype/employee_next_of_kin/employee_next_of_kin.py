from frappe.model.document import Document


class EmployeeNextofKin(Document):
	pass
