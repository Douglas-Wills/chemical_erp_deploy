from frappe.model.document import Document


class ContractPayItem(Document):
	pass
