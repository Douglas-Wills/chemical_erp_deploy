from frappe.model.document import Document


class PositionRoleGrant(Document):
	pass
