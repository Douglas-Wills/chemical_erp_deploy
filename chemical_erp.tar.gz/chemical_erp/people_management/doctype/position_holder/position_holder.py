from frappe.model.document import Document


class PositionHolder(Document):
	pass
