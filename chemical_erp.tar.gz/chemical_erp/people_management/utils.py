import calendar

import frappe
from frappe import _
from frappe.utils import cint, flt, getdate

MONTH_NAMES = list(calendar.month_name)[1:]


def get_settings():
	return frappe.get_cached_doc("HR Management Settings")


def month_number(name):
	return MONTH_NAMES.index(name) + 1 if name in MONTH_NAMES else None


def parse_days(text):
	return sorted({cint(d) for d in (text or "").split(",") if d.strip().isdigit()}, reverse=True)


# ---------------------------------------------------------------- PAYE
def get_band_set(residency, on_date):
	rows = frappe.get_all(
		"PAYE Band Set",
		filters={"residency": residency or "Resident", "effective_from": ["<=", getdate(on_date)]},
		pluck="name",
		order_by="effective_from desc",
		limit=1,
	)
	if not rows:
		frappe.throw(
			_("No {0} PAYE Band Set is effective on {1}. Add one under PAYE Band Set.").format(residency, on_date),
			title=_("PAYE bands missing"),
		)
	return frappe.get_cached_doc("PAYE Band Set", rows[0])


def compute_paye(chargeable, residency, on_date):
	"""Returns (paye, band_set_name). Bands are marginal: each rate applies only to income inside its band."""
	band_set = get_band_set(residency, on_date)
	income = flt(chargeable)
	tax = 0.0
	for band in sorted(band_set.bands, key=lambda b: flt(b.from_amount)):
		low = flt(band.from_amount)
		high = flt(band.to_amount) or float("inf")
		if income > low:
			tax += (min(income, high) - low) * flt(band.rate) / 100
	if flt(band_set.surcharge_threshold) and income > flt(band_set.surcharge_threshold):
		tax += (income - flt(band_set.surcharge_threshold)) * flt(band_set.surcharge_rate) / 100
	return round(tax), band_set.name


# ---------------------------------------------------------------- LST
def is_lst_month(period_end, settings=None):
	settings = settings or get_settings()
	start = month_number(settings.lst_start_month) or 7
	count = cint(settings.lst_installments) or 4
	months = {((start - 1 + i) % 12) + 1 for i in range(count)}
	return getdate(period_end).month in months


def annual_lst(monthly_base, settings=None):
	settings = settings or get_settings()
	base = flt(monthly_base)
	for band in sorted(settings.lst_bands or [], key=lambda b: flt(b.from_amount)):
		high = flt(band.to_amount) or float("inf")
		if flt(band.from_amount) < base <= high:
			return flt(band.annual_lst)
	return 0.0


def lst_instalment(monthly_base, period_end, settings=None):
	settings = settings or get_settings()
	if not is_lst_month(period_end, settings):
		return 0.0
	return round(annual_lst(monthly_base, settings) / (cint(settings.lst_installments) or 4))


# ---------------------------------------------------------------- people
from chemical_erp.utils import users_with_role  # noqa: E402,F401  (one shared copy)


def line_manager_user(employee):
	manager = frappe.db.get_value("Employee", employee, "reports_to")
	return frappe.db.get_value("Employee", manager, "user_id") if manager else None


def hr_recipients(employee=None):
	users = users_with_role("HR Manager")
	if employee and cint(get_settings().notify_line_manager):
		manager = line_manager_user(employee)
		if manager:
			users.append(manager)
	return users


def notify(users, doctype, name, subject, message=None, priority="Medium", todo=True):
	"""ToDo + notification bell + optional email. Never raises."""
	if isinstance(users, str):
		users = [users]
	users = [
		u for u in dict.fromkeys(users or [])
		if u and u not in ("Guest", "Administrator") and frappe.db.get_value("User", u, "enabled")
	]
	if not users:
		return
	message = message or subject
	settings = get_settings()
	link = frappe.utils.get_url_to_form(doctype, name)
	for user in users:
		try:
			if todo and not frappe.db.exists(
				"ToDo", {"allocated_to": user, "reference_type": doctype, "reference_name": name,
				         "status": "Open", "description": message},
			):
				frappe.get_doc({
					"doctype": "ToDo", "allocated_to": user, "reference_type": doctype, "reference_name": name,
					"description": message, "priority": priority, "status": "Open", "date": frappe.utils.today(),
				}).insert(ignore_permissions=True)
			from frappe.desk.doctype.notification_log.notification_log import enqueue_create_notification

			enqueue_create_notification(user, {
				"type": "Alert", "document_type": doctype, "document_name": name, "subject": subject,
				"email_content": message, "from_user": "Administrator",
			})
			if cint(settings.email_notifications):
				email = frappe.db.get_value("User", user, "email")
				if email:
					frappe.sendmail(
						recipients=[email], subject=subject, reference_doctype=doctype, reference_name=name,
						message=f"<p>{frappe.utils.escape_html(message)}</p><p><a href=\"{link}\">Open {frappe.utils.escape_html(name)}</a></p>",
					)
		except Exception:
			frappe.log_error(title=f"HR notification to {user} failed", message=frappe.get_traceback())
