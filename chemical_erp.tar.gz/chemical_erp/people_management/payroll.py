"""Builds Staff Payslips for a Payroll Run."""

import frappe
from frappe import _
from frappe.utils import cint, date_diff, flt, getdate

from chemical_erp.people_management.utils import get_settings

EMPLOYEE_FIELDS = (
	"name", "employee_name", "company", "department", "designation", "branch", "date_of_joining", "relieving_date",
)
OPTIONAL_FIELDS = (
	"tin", "nssf_number", "paye_residency", "salary_payment_mode", "bank_name", "bank_ac_no", "mobile_money_number",
)


def employee_details(name):
	meta = frappe.get_meta("Employee")
	fields = list(EMPLOYEE_FIELDS) + [f for f in OPTIONAL_FIELDS if meta.has_field(f)]
	return frappe.db.get_value("Employee", name, fields, as_dict=True)


def active_contract(employee, start, end):
	rows = frappe.get_all(
		"Employment Contract",
		filters={
			"employee": employee,
			"is_signed": 1,
			"status": ["not in", ["Draft", "Terminated"]],
			"start_date": ["<=", end],
		},
		or_filters=[["end_date", "is", "not set"], ["end_date", ">=", start]],
		pluck="name",
		order_by="start_date desc",
		limit=1,
	)
	return frappe.get_doc("Employment Contract", rows[0]) if rows else None


def unpaid_days(employee, start, end):
	"""Absent days and leave without pay, from Frappe HR attendance. Zero if Frappe HR is not installed."""
	if not frappe.db.exists("DocType", "Attendance"):
		return 0
	rows = frappe.get_all(
		"Attendance",
		filters={"employee": employee, "docstatus": 1, "attendance_date": ["between", [start, end]]},
		fields=["status", "leave_type"],
	)
	lwp_types = set(frappe.get_all("Leave Type", filters={"is_lwp": 1}, pluck="name")) if rows else set()
	total = 0.0
	for r in rows:
		if r.status == "Absent":
			total += 1
		elif r.status == "On Leave" and r.leave_type in lwp_types:
			total += 1
		elif r.status == "Half Day" and r.leave_type in lwp_types:
			total += 0.5
	return total


def component(name):
	return frappe.get_cached_doc("Pay Component", name)


def line(comp_name, amount, notes=None):
	comp = component(comp_name)
	return {
		"pay_component": comp_name,
		"amount": round(flt(amount)),
		"is_taxable": comp.is_taxable,
		"nssf_applicable": comp.nssf_applicable,
		"is_statutory": comp.is_statutory,
		"notes": notes,
	}


def insurance_contribution(employee, start, end):
	rows = frappe.db.sql(
		"""select sum(m.employee_monthly_contribution)
		from `tabInsurance Policy Member` m join `tabStaff Insurance Policy` p on p.name = m.parent
		where m.employee=%(emp)s and p.start_date <= %(end)s and p.end_date >= %(start)s
			and (m.date_added is null or m.date_added <= %(end)s)
			and (m.date_removed is null or m.date_removed >= %(start)s)""",
		{"emp": employee, "start": start, "end": end},
	)
	return flt(rows[0][0]) if rows else 0.0


def build_payslip(run, employee, adjustments):
	"""Returns (payslip, warning). Exactly one of them is set."""
	settings = get_settings()
	start, end = getdate(run.start_date), getdate(run.end_date)
	emp = employee_details(employee)
	contract = active_contract(employee, start, end)
	if not contract:
		return None, _("{0}: no signed contract covering this month").format(emp.employee_name)

	period_start = max(d for d in (start, getdate(contract.start_date), getdate(emp.date_of_joining) if emp.date_of_joining else None) if d)
	period_end = min(d for d in (
		end,
		getdate(contract.end_date) if contract.end_date else None,
		getdate(contract.termination_date) if contract.termination_date else None,
		getdate(emp.relieving_date) if emp.relieving_date else None,
	) if d)
	if period_end < period_start:
		return None, _("{0}: not employed during this month").format(emp.employee_name)

	days = date_diff(end, start) + 1
	unpaid = unpaid_days(employee, period_start, period_end)
	payable = max(date_diff(period_end, period_start) + 1 - unpaid, 0)
	factor = payable / days

	basic_component = settings.basic_component or "Basic Salary"
	ps = frappe.new_doc("Staff Payslip")
	ps.update({
		"employee": employee, "employee_name": emp.employee_name, "company": run.company,
		"department": emp.department, "designation": emp.designation, "payroll_run": run.name,
		"contract": contract.name, "posting_date": run.posting_date, "start_date": start, "end_date": end,
		"days_in_period": days, "payable_days": payable,
	})
	full_basic = flt(contract.basic_salary)
	ps.append("earnings", line(basic_component, full_basic * factor,
	                           _("{0} of {1} days").format(payable, days) if payable < days else None))

	for item in contract.pay_items:
		comp = component(item.pay_component)
		monthly = full_basic * flt(item.percent) / 100 if item.calculation == "Percent of Basic" else flt(item.amount)
		if comp.component_type == "Earning":
			ps.append("earnings", line(item.pay_component, monthly * factor))
		elif not cint(comp.is_statutory):
			ps.append("deductions", line(item.pay_component, monthly))

	for adj in adjustments:
		comp = component(adj.pay_component)
		target = "earnings" if comp.component_type == "Earning" else "deductions"
		ps.append(target, line(adj.pay_component, adj.amount, adj.notes))

	insurance = insurance_contribution(employee, start, end)
	if insurance and settings.insurance_component:
		ps.append("deductions", line(settings.insurance_component, insurance, _("Staff insurance contribution")))

	ps.insert()
	return ps, None
