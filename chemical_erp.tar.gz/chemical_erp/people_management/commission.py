"""Sales commission: a set percentage of the profit on each sale, earned by the sale's originator.

Profit of a sale (per Sales Invoice, company currency)
    net sales (excluding VAT)
  − cost of the goods delivered (stock valuation at delivery; the item's valuation rate if not yet delivered)
  − expense claims linked to the sale (directly, or through its Sales Order, shared by invoice value)
A loss-making sale earns nothing; a credit note (return) takes back commission on the profit returned.

The ledger (Commission Entry) is never edited: every change is a new line.
  Earned / Adjustment / Return / Reversal  (+ or −)  per invoice, kept equal to what the invoice should earn now
  Payout / Payout Reversal                 (−  or +) when commission is paid through a Payment Entry or a Payroll Run
Payable = commission on what customers have paid (pro rata) − payouts. Accrued = commission on invoices still unpaid.
"""

import frappe
from frappe import _
from frappe.utils import add_days, cint, flt, getdate, nowdate, today

from chemical_erp.utils import MD_ROLE, has_role

COMPONENT = "Sales Commission"
SALE_TYPES = ("Earned", "Adjustment", "Return", "Reversal")
PAY_TYPES = ("Payout", "Payout Reversal")
MANAGERS = (MD_ROLE, "Sales Manager", "System Manager")


# ---------------------------------------------------------------- who originated the sale
def set_originator(doc, method=None):
	"""Quotation, Sales Order, Sales Invoice: carried from the document it was made from, else whoever raises it.
	Only the Sales Manager or the MD may change it."""
	if not doc.meta.has_field("sale_originator"):
		return
	source = None
	for row in doc.get("items") or []:
		if doc.doctype == "Sales Invoice" and row.get("sales_order"):
			source = frappe.db.get_value("Sales Order", row.sales_order, "sale_originator")
		elif doc.doctype == "Sales Invoice" and row.get("delivery_note"):
			so = frappe.db.get_value("Delivery Note Item", row.get("dn_detail"), "against_sales_order") if row.get("dn_detail") else None
			source = frappe.db.get_value("Sales Order", so, "sale_originator") if so else None
		elif doc.doctype == "Sales Order" and row.get("prevdoc_docname"):
			source = frappe.db.get_value("Quotation", row.prevdoc_docname, "sale_originator")
		if source:
			break
	if doc.is_new() and not doc.sale_originator:
		doc.sale_originator = source or (frappe.session.user if frappe.session.user not in ("Administrator", "Guest") else None)
		return
	before = doc.get_doc_before_save() if not doc.is_new() else None
	changed = before and before.get("sale_originator") != doc.sale_originator
	if (changed or (doc.is_new() and source and doc.sale_originator != source)) and not set(MANAGERS) & set(frappe.get_roles()):
		frappe.throw(_("Only the Sales Manager or the Managing Director can change who originated a sale."), title=_("Sale originator"))


# ---------------------------------------------------------------- agreements
def agreement_for(user, on):
	if not user:
		return None
	emp = frappe.db.get_value("Employee", {"user_id": user}, "name")
	if not emp:
		return None
	for a in frappe.get_all("Commission Agreement", filters={"employee": emp, "active": 1, "valid_from": ["<=", on]},
	                        fields=["name", "valid_to"], order_by="valid_from desc"):
		if not a.valid_to or getdate(a.valid_to) >= getdate(on):
			return frappe.get_cached_doc("Commission Agreement", a.name)
	return None


def validate_agreement(doc, method=None):
	if not has_role(MD_ROLE) and frappe.session.user != "Administrator":
		frappe.throw(_("Only the Managing Director sets commission agreements."), frappe.PermissionError)
	if not 0 < flt(doc.rate) <= 50:
		frappe.throw(_("The commission rate must be above 0% and at most 50% of profit."))
	if doc.valid_to and getdate(doc.valid_to) < getdate(doc.valid_from):
		frappe.throw(_("'To' is before 'From'."))
	if not frappe.db.get_value("Employee", doc.employee, "user_id"):
		frappe.throw(_("{0} has no system login, so their sales cannot be traced to them. Create their account first.").format(doc.employee))
	if cint(doc.active):
		for o in frappe.get_all("Commission Agreement", filters={"employee": doc.employee, "active": 1, "name": ["!=", doc.name or ""]},
		                        fields=["name", "valid_from", "valid_to"]):
			if (not o.valid_to or getdate(o.valid_to) >= getdate(doc.valid_from)) and \
					(not doc.valid_to or getdate(doc.valid_to) >= getdate(o.valid_from)):
				frappe.throw(_("{0} already covers some of these dates. End it first.").format(o.name))


# ---------------------------------------------------------------- profit of one invoice
def _cost_of_row(si, row):
	stock_qty = flt(row.get("stock_qty") or row.qty)
	rate = flt(row.get("incoming_rate"))
	if not rate and row.get("dn_detail"):
		rate = flt(frappe.db.get_value("Delivery Note Item", row.dn_detail, "incoming_rate"))
	if not rate and row.get("so_detail"):
		dn = frappe.get_all("Delivery Note Item", filters={"so_detail": row.so_detail, "docstatus": 1}, fields=["incoming_rate"], limit=1)
		rate = flt(dn[0].incoming_rate) if dn else 0
	if not rate and frappe.get_cached_value("Item", row.item_code, "is_stock_item"):
		rate = flt(frappe.db.get_value("Bin", {"item_code": row.item_code, "warehouse": row.get("warehouse")}, "valuation_rate")) \
			or flt(frappe.get_cached_value("Item", row.item_code, "valuation_rate"))
	return stock_qty * rate


def _expenses_for(si):
	"""Approved expense claims for this invoice, plus a share of those for its sales orders."""
	if not frappe.get_meta("Expense Claim").has_field("for_sales_invoice"):
		return 0.0
	total = sum(flt(x.total_sanctioned_amount) for x in frappe.get_all(
		"Expense Claim", filters={"docstatus": 1, "for_sales_invoice": si.name}, fields=["total_sanctioned_amount"]))
	orders = {r.sales_order for r in si.items if r.get("sales_order")}
	for so in orders:
		claimed = sum(flt(x.total_sanctioned_amount) for x in frappe.get_all(
			"Expense Claim", filters={"docstatus": 1, "for_sales_order": so, "for_sales_invoice": ["is", "not set"]},
			fields=["total_sanctioned_amount"]))
		so_net = flt(frappe.db.get_value("Sales Order", so, "base_net_total"))
		this = sum(flt(r.base_net_amount) for r in si.items if r.get("sales_order") == so)
		if claimed and so_net:
			total += claimed * min(abs(this) / so_net, 1)
	return total


def profit_of(si, agreement):
	rows = [r for r in si.items if cint(agreement.include_services) or frappe.get_cached_value("Item", r.item_code, "is_stock_item")]
	net = sum(flt(r.base_net_amount) for r in rows)
	cost = sum(_cost_of_row(si, r) for r in rows)
	expenses = _expenses_for(si) if cint(agreement.deduct_sale_expenses) and not si.is_return else 0.0
	return frappe._dict(net=net, cost=cost, expenses=expenses, profit=net - cost - expenses)


def target_for(si):
	"""What this invoice should have earned in total, and the working."""
	if si.docstatus != 1:
		return 0.0, None, None
	originator = si.get("sale_originator")
	if si.is_return and si.get("return_against"):
		originator = frappe.db.get_value("Sales Invoice", si.return_against, "sale_originator") or originator
	# A sale keeps the agreement it was first booked under (ending or switching off an agreement stops future
	# commission; it does not take back what was earned). Returns follow the original invoice's agreement.
	agreement = _booked_agreement(si.name) or (_booked_agreement(si.return_against) if si.is_return and si.get("return_against") else None) \
		or agreement_for(originator, si.posting_date)
	if not agreement:
		return 0.0, None, None
	calc = profit_of(si, agreement)
	if si.is_return:
		amount = flt(calc.profit) * flt(agreement.rate) / 100  # negative: commission taken back on the returned profit
		amount = min(amount, 0)
	else:
		amount = max(flt(calc.profit), 0) * flt(agreement.rate) / 100
	return round(amount, 0), agreement, calc


def _booked_agreement(si_name):
	if not si_name:
		return None
	name = frappe.db.get_value("Commission Entry", {"sales_invoice": si_name, "entry_type": ["in", SALE_TYPES]}, "agreement",
	                           order_by="creation asc")
	return frappe.get_cached_doc("Commission Agreement", name) if name and frappe.db.exists("Commission Agreement", name) else None


def booked(si_name):
	return flt(frappe.db.sql("""select sum(amount) from `tabCommission Entry` where sales_invoice=%s and entry_type in %s""",
	                         (si_name, SALE_TYPES))[0][0])


def recalc(si, reason=None):
	"""Bring the ledger for one invoice to what it should earn now (new line for the difference)."""
	if isinstance(si, str):
		si = frappe.get_doc("Sales Invoice", si)
	amount, agreement, calc = target_for(si)
	have = booked(si.name)
	delta = round(amount - have, 0)
	if abs(delta) < 1:
		return 0
	originator = si.get("sale_originator")
	if si.is_return and si.get("return_against"):
		originator = frappe.db.get_value("Sales Invoice", si.return_against, "sale_originator") or originator
	if not agreement:  # e.g. invoice cancelled: take back what was booked, for whoever it was booked to
		last = frappe.get_all("Commission Entry", filters={"sales_invoice": si.name, "entry_type": ["in", SALE_TYPES]},
		                      fields=["employee", "user", "agreement", "rate"], order_by="creation desc", limit=1)
		if not last:
			return 0
		emp, user, agr, rate, calc = last[0].employee, last[0].user, last[0].agreement, last[0].rate, frappe._dict()
		kind = "Reversal"
	else:
		emp, user, agr, rate = agreement.employee, originator, agreement.name, agreement.rate
		kind = "Return" if si.is_return else ("Earned" if not have else "Adjustment")
	frappe.get_doc({"doctype": "Commission Entry", "employee": emp, "user": user, "entry_type": kind,
	                "posting_date": today(), "amount": delta, "sales_invoice": si.name, "customer": si.customer,
	                "net_sales": calc.get("net"), "cost_of_goods": calc.get("cost"), "sale_expenses": calc.get("expenses"),
	                "profit": calc.get("profit"), "rate": rate, "agreement": agr,
	                "remarks": reason or ""}).insert(ignore_permissions=True)
	return delta


# ---------------------------------------------------------------- events
def on_invoice_submit(doc, method=None):
	recalc(doc, _("Invoice issued"))


def on_invoice_cancel(doc, method=None):
	recalc(doc, _("Invoice cancelled"))


def on_expense_change(doc, method=None):
	"""An expense claim for a sale changes that sale's profit, so its commission is worked out again."""
	invoices = set()
	if doc.get("for_sales_invoice"):
		invoices.add(doc.for_sales_invoice)
	if doc.get("for_sales_order"):
		invoices |= set(frappe.get_all("Sales Invoice Item", filters={"sales_order": doc.for_sales_order, "docstatus": 1}, pluck="parent"))
	for name in invoices:
		recalc(name, _("Expense claim {0} {1}").format(doc.name, _("approved") if doc.docstatus == 1 else _("cancelled")))


def daily():
	"""Cost of goods is known once goods are delivered: refresh invoices of the last 60 days."""
	for name in frappe.get_all("Sales Invoice", filters={"docstatus": 1, "posting_date": [">=", add_days(nowdate(), -60)],
	                                                       "sale_originator": ["is", "set"]}, pluck="name"):
		try:
			recalc(name, _("Cost of goods updated"))
		except Exception:
			frappe.log_error(title=f"Commission recalculation failed: {name}", message=frappe.get_traceback())


# ---------------------------------------------------------------- balances
def balances(employee):
	"""{earned, accrued (customers not yet paid), payable now, paid}."""
	rows = frappe.get_all("Commission Entry", filters={"employee": employee}, fields=["entry_type", "amount", "sales_invoice", "agreement"])
	earned = accrued = available = paid = 0.0
	paid_share = {}
	for r in rows:
		if r.entry_type in PAY_TYPES:
			paid -= flt(r.amount)
			continue
		earned += flt(r.amount)
		if r.sales_invoice not in paid_share:
			paid_share[r.sales_invoice] = settled_fraction(r.sales_invoice, r.agreement)
		share = paid_share[r.sales_invoice]
		available += flt(r.amount) * share
		accrued += flt(r.amount) * (1 - share)
	# Paid more than has been earned (a sale was returned or cancelled after payout): recovered from future commission
	return frappe._dict(earned=round(earned), accrued=round(accrued), payable=round(max(available - paid, 0)), paid=round(paid),
	                    available=round(available), owed=round(max(paid - available, 0)))


def settled_fraction(si_name, agreement=None):
	"""How much of the commission on this invoice may be paid: what the customer has paid, or all of it."""
	when = frappe.db.get_value("Commission Agreement", agreement, "earned_when") if agreement else "Customer has paid"
	si = frappe.db.get_value("Sales Invoice", si_name, ["grand_total", "outstanding_amount", "is_return", "docstatus"], as_dict=True)
	if not si or si.docstatus != 1 or si.is_return or when == "Invoice is issued" or not flt(si.grand_total):
		return 1.0
	return min(max(1 - flt(si.outstanding_amount) / flt(si.grand_total), 0), 1)


def employee_of_party(doc):
	return doc.party if doc.get("party_type") == "Employee" else None


def _payout(employee, amount, voucher_type, voucher_no, reverse=False):
	user = frappe.db.get_value("Employee", employee, "user_id")
	frappe.get_doc({"doctype": "Commission Entry", "employee": employee, "user": user,
	                "entry_type": "Payout Reversal" if reverse else "Payout", "posting_date": today(),
	                "amount": flt(amount) if reverse else -flt(amount), "voucher_type": voucher_type, "voucher_no": voucher_no,
	                "remarks": _("Cancelled") if reverse else _("Paid")}).insert(ignore_permissions=True)


def _check_payable(employee, amount):
	b = balances(employee)
	if flt(amount) > b.payable + 1:
		frappe.throw(_("{0} has {1} commission payable now ({2} more is waiting for customers to pay). {3} is more than that.").format(
			frappe.db.get_value("Employee", employee, "employee_name"), fmt(b.payable), fmt(b.accrued), fmt(amount)),
			title=_("Commission not yet payable"))


def fmt(v):
	return frappe.format_value(v, {"fieldtype": "Currency"})


# Payment Entry: a payment to an employee ticked "Commission payout" is taken off their payable commission.
def payment_validate(doc, method=None):
	if cint(doc.get("commission_payout")):
		if doc.payment_type != "Pay" or doc.party_type != "Employee":
			frappe.throw(_("A commission payout is a payment ('Pay') to an Employee."))
		_check_payable(doc.party, doc.base_paid_amount)


def payment_submit(doc, method=None):
	if cint(doc.get("commission_payout")):
		_check_payable(doc.party, doc.base_paid_amount)
		_payout(doc.party, doc.base_paid_amount, doc.doctype, doc.name)


def payment_cancel(doc, method=None):
	if cint(doc.get("commission_payout")):
		_payout(doc.party, doc.base_paid_amount, doc.doctype, doc.name, reverse=True)


# Payroll Run: "Sales Commission" adjustments are paid with salary (taxed as pay) and taken off payable commission.
def payroll_validate(doc, method=None):
	totals = {}
	for a in doc.get("adjustments") or []:
		if a.pay_component == COMPONENT:
			totals[a.employee] = totals.get(a.employee, 0) + flt(a.amount)
	for emp, amount in totals.items():
		_check_payable(emp, amount)


def _on_payslips(run_name, docstatus):
	"""Commission actually on this run's payslips (earning lines), per employee."""
	rows = frappe.db.sql("""select p.employee, sum(l.amount) from `tabPayslip Line` l
		join `tabStaff Payslip` p on p.name = l.parent
		where l.parenttype = 'Staff Payslip' and l.parentfield = 'earnings' and l.pay_component = %s
		and p.payroll_run = %s and p.docstatus = %s group by p.employee""", (COMPONENT, run_name, docstatus))
	return {emp: flt(amount) for emp, amount in rows if flt(amount)}


def payroll_before_submit(doc, method=None):
	"""Commission added (or changed) after the payslips were calculated would be booked as paid but not paid."""
	wanted = {}
	for a in doc.get("adjustments") or []:
		if a.pay_component == COMPONENT and flt(a.amount):
			wanted[a.employee] = wanted.get(a.employee, 0) + flt(a.amount)
	on_slips = _on_payslips(doc.name, 0)
	differ = [e for e in set(wanted) | set(on_slips) if abs(wanted.get(e, 0) - on_slips.get(e, 0)) >= 1]
	if differ:
		frappe.throw(_("Commission on the payslips does not match the adjustments for {0}. Click Calculate Payslips again "
		               "(and check that each person has a payslip) before submitting.").format(", ".join(sorted(differ))),
		             title=_("Recalculate payslips"))


def payroll_submit(doc, method=None):
	# paid = what is on the submitted payslips (they were submitted by the run just before this hook)
	for emp, amount in _on_payslips(doc.name, 1).items():
		_payout(emp, amount, doc.doctype, doc.name)


def payroll_cancel(doc, method=None):
	for emp, amount in _on_payslips(doc.name, 2).items():
		_payout(emp, amount, doc.doctype, doc.name, reverse=True)


@frappe.whitelist()
def add_to_payroll(payroll_run):
	"""Add every employee's payable commission to a draft payroll run."""
	if not set(("HR Manager", "HR User", "Accounts Manager", MD_ROLE)) & set(frappe.get_roles()):
		frappe.throw(_("Not permitted"), frappe.PermissionError)
	run = frappe.get_doc("Payroll Run", payroll_run)
	if run.docstatus != 0:
		frappe.throw(_("Only a draft payroll run can take commission."))
	already = {a.employee: flt(a.amount) for a in run.adjustments if a.pay_component == COMPONENT}
	added = []
	for emp in frappe.get_all("Commission Entry", distinct=True, pluck="employee"):
		pay = balances(emp).payable - already.get(emp, 0)
		if pay >= 1:
			run.append("adjustments", {"employee": emp, "pay_component": COMPONENT, "amount": pay,
			                           "notes": _("Commission payable on {0}").format(frappe.format_value(today(), {"fieldtype": "Date"}))})
			added.append(emp)
	run.save()
	return added


# ---------------------------------------------------------------- the dashboard window
def summary(user):
	emp = frappe.db.get_value("Employee", {"user_id": user}, "name")
	if not emp:
		return None
	has_agreement = frappe.db.exists("Commission Agreement", {"employee": emp, "active": 1})
	if not has_agreement and not frappe.db.exists("Commission Entry", {"employee": emp}):
		return None
	b = balances(emp)
	agreement = agreement_for(user, today())
	month_start = getdate(today()).replace(day=1)
	this_month = flt(frappe.db.sql("""select sum(amount) from `tabCommission Entry`
		where employee=%s and entry_type in %s and posting_date >= %s""", (emp, SALE_TYPES, month_start))[0][0])
	sales = frappe.db.sql("""select sales_invoice, customer, max(posting_date) as d, sum(amount) as commission,
			max(net_sales) as net_sales, max(profit) as profit, max(agreement) as agreement
		from `tabCommission Entry` where employee=%s and entry_type in %s and sales_invoice is not null
		group by sales_invoice, customer order by d desc limit 12""", (emp, SALE_TYPES), as_dict=True)
	for s in sales:
		s.paid_share = round(settled_fraction(s.sales_invoice, s.agreement) * 100)
		s.customer_name = frappe.db.get_value("Customer", s.customer, "customer_name") or s.customer
	return {"rate": agreement.rate if agreement else None, "earned": b.earned, "accrued": b.accrued, "payable": b.payable,
	        "paid": b.paid, "owed": b.owed, "this_month": round(this_month), "sales": sales, "employee": emp}


def all_payable():
	return round(sum(balances(e).payable for e in frappe.get_all("Commission Entry", distinct=True, pluck="employee")))


def query_conditions(user=None):
	"""Staff see only their own commission lines; managers and accounts see all."""
	user = user or frappe.session.user
	if user == "Administrator" or set(("Managing Director", "Accounts Manager", "Accounts User", "HR Manager", "System Manager")) & set(frappe.get_roles(user)):
		return ""
	return f"`tabCommission Entry`.`user` = {frappe.db.escape(user)}"


def has_permission(doc, ptype="read", user=None):
	user = user or frappe.session.user
	if not query_conditions(user):
		return True
	return doc.user == user and ptype in ("read", "print", "report")
