"""System permissions by work scope.

- Line managers grant access to the people who report to them (directly or further down), and only roles they
  hold themselves. The Managing Director grants anything to anyone. Nobody grants access to themselves.
- Sensitive roles are the MD's alone to give. System Manager and Formula Owner are never granted here (the first
  is for the system administrator, the second only through Formula Delegation).
- Limits (User Permissions) narrow what a person sees, e.g. one department or warehouse.
- Roles are only ever removed if this module added them and nothing else still provides them.
"""

import frappe
from frappe import _
from frappe.utils import now_datetime, today

MD = "Managing Director"
NEVER_GRANTED = {"System Manager", "Administrator", "Guest", "All", "Formula Owner",
                 "MD Delegate"}  # given only by the MD's Approval Delegation, never passed on
MD_ONLY = {MD, "Plant Manager", "QC Manager", "Director", "Accounts Manager", "HR Manager", "Purchase Manager",
           "Stock Manager", "Manufacturing Manager", "Sales Manager", "Expense Approver", "Tender Manager"}


def is_md(user=None):
	return MD in frappe.get_roles(user or frappe.session.user)


def employee_of(user):
	return frappe.db.get_value("Employee", {"user_id": user, "status": "Active"}, "name")


def team_of(manager_employee, depth=6):
	"""Everyone reporting to this employee, directly or further down."""
	team, frontier = set(), {manager_employee}
	for _i in range(depth):
		nxt = set(frappe.get_all("Employee", filters={"reports_to": ["in", list(frontier)], "status": "Active"}, pluck="name")) - team
		if not nxt:
			break
		team |= nxt
		frontier = nxt
	return team


def roles_of_grant(doc):
	if doc.grant_type == "Single Role":
		return [doc.role] if doc.role else []
	return frappe.get_all("Position Role", filters={"parent": doc.access_profile, "parenttype": "Access Profile"}, pluck="role")


def check_authority(doc, user=None):
	user = user or frappe.session.user
	if user == "Administrator":
		return
	if doc.user == user:
		frappe.throw(_("You cannot grant access to yourself."), frappe.PermissionError)
	roles = roles_of_grant(doc)
	never = sorted(set(roles) & NEVER_GRANTED)
	if never:
		frappe.throw(_("{0} cannot be granted here.").format(", ".join(never)))
	if is_md(user):
		return
	me = employee_of(user)
	if not me or doc.employee not in team_of(me):
		frappe.throw(_("You can only grant access to people who report to you. Ask their line manager or the Managing Director."),
		             frappe.PermissionError, title=_("Not your team"))
	md_only = sorted(set(roles) & MD_ONLY)
	if md_only:
		frappe.throw(_("Only the Managing Director can grant {0}.").format(", ".join(md_only)), frappe.PermissionError)
	mine = set(frappe.get_roles(user))
	missing = sorted(set(roles) - mine)
	if missing:
		frappe.throw(_("You can only grant roles you hold yourself. You do not hold: {0}.").format(", ".join(missing)), frappe.PermissionError)


# ------------------------------------------------------------------ applying and removing
def _other_sources(user, role, except_grant=None):
	"""Is the role still provided by a post, another active grant, or was it given by hand?"""
	if frappe.db.exists("Position Role Grant", {"user": user, "role": role, "reason": ["in", ["Holder", "Vacancy"]]}):
		return True
	for g in frappe.get_all("Position Role Grant", filters={"user": user, "role": role, "reason": "Access Grant",
	                                                       "access_grant": ["!=", except_grant or ""]}, pluck="access_grant"):
		if frappe.db.get_value("Access Grant", g, "status") == "Active":
			return True
	return False


def activate(doc):
	user_doc = frappe.get_doc("User", doc.user)
	have = {r.role for r in user_doc.roles}
	for role in roles_of_grant(doc):
		given_by_hand = role in have and not frappe.db.exists("Position Role Grant", {"user": doc.user, "role": role})
		if given_by_hand:
			continue  # never take ownership of a role an administrator gave by hand
		if role not in have:
			user_doc.add_roles(role)
		# record this grant's claim, so a post ending (or another grant ending) does not remove a role this grant still needs
		frappe.get_doc({"doctype": "Position Role Grant", "user": doc.user, "role": role, "reason": "Access Grant",
		                "access_grant": doc.name}).insert(ignore_permissions=True)
	from frappe.permissions import add_user_permission

	for r in doc.restrictions:
		if not frappe.db.exists("User Permission", {"user": doc.user, "allow": r.allow, "for_value": r.for_value}):
			add_user_permission(r.allow, r.for_value, doc.user, ignore_permissions=True, applicable_for=r.applies_to or None)


def deactivate(doc):
	for g in frappe.get_all("Position Role Grant", filters={"access_grant": doc.name}, fields=["name", "role"]):
		frappe.delete_doc("Position Role Grant", g.name, ignore_permissions=True, force=True)
		if not _other_sources(doc.user, g.role, except_grant=doc.name):
			# was it added by this module in the first place? only then remove
			frappe.get_doc("User", doc.user).remove_roles(g.role)
	for r in doc.restrictions:
		still = frappe.db.sql("""select 1 from `tabAccess Restriction` ar join `tabAccess Grant` ag on ag.name = ar.parent
			where ag.user = %s and ag.status = 'Active' and ag.name != %s and ar.allow = %s and ar.for_value = %s limit 1""",
		                      (doc.user, doc.name, r.allow, r.for_value))
		if not still:
			for up in frappe.get_all("User Permission", filters={"user": doc.user, "allow": r.allow, "for_value": r.for_value}, pluck="name"):
				frappe.delete_doc("User Permission", up, ignore_permissions=True, force=True)


def expire_grants():
	"""Daily: temporary access ends on its own; access for people who have left ends too."""
	for name in frappe.get_all("Access Grant", filters={"status": "Active", "valid_to": ["<", today()]}, pluck="name"):
		doc = frappe.get_doc("Access Grant", name)
		deactivate(doc)
		doc.db_set({"status": "Expired", "ended_on": now_datetime()})
		frappe.get_doc("Access Grant", name).add_comment("Info", _("Access ended on its end date."))
	for name in frappe.get_all("Access Grant", filters={"status": "Active"}, pluck="name"):
		doc = frappe.get_doc("Access Grant", name)
		if frappe.db.get_value("Employee", doc.employee, "status") != "Active":
			deactivate(doc)
			doc.db_set({"status": "Revoked", "ended_on": now_datetime()})
	for name in frappe.get_all("Access Grant", filters={"status": "Draft", "docstatus": 1, "valid_from": ["<=", today()]}, pluck="name"):
		doc = frappe.get_doc("Access Grant", name)
		activate(doc)
		doc.db_set("status", "Active")
