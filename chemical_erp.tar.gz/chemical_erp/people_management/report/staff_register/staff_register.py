import frappe
from frappe import _

WANTED = [
	("name", _("Employee"), "Link", "Employee", 110), ("employee_name", _("Name"), "Data", None, 170),
	("gender", _("Gender"), "Data", None, 70), ("date_of_birth", _("Date of Birth"), "Date", None, 100),
	("marital_status", _("Marital Status"), "Data", None, 100), ("nin", _("NIN"), "Data", None, 140),
	("department", _("Department"), "Link", "Department", 140), ("designation", _("Designation"), "Link", "Designation", 140),
	("date_of_joining", _("Joined"), "Date", None, 95), ("cell_number", _("Telephone"), "Data", None, 120),
	("personal_email", _("Personal Email"), "Data", None, 160), ("residence_district", _("District"), "Data", None, 110),
	("tin", _("TIN"), "Data", None, 110), ("nssf_number", _("NSSF No."), "Data", None, 120),
	("salary_payment_mode", _("Paid By"), "Data", None, 95), ("bank_name", _("Bank"), "Data", None, 120),
	("bank_ac_no", _("Account No."), "Data", None, 130), ("mobile_money_number", _("Mobile Money"), "Data", None, 120),
	("current_contract", _("Contract"), "Link", "Employment Contract", 130),
]


def execute(filters=None):
	filters = frappe._dict(filters or {})
	meta = frappe.get_meta("Employee")
	cols = [c for c in WANTED if c[0] == "name" or meta.has_field(c[0])]
	conditions = {"status": filters.status or "Active"}
	for f in ("company", "department", "branch"):
		if filters.get(f):
			conditions[f] = filters.get(f)
	data = frappe.get_all("Employee", filters=conditions, fields=[c[0] for c in cols], order_by="employee_name asc")

	kin = {}
	if meta.has_field("next_of_kin"):
		names = [d.name for d in data]
		if names:
			for k in frappe.db.sql(
				"""select parent, full_name, relationship, phone from `tabEmployee Next of Kin`
				where parenttype='Employee' and parent in %(names)s order by is_primary desc, idx asc""",
				{"names": tuple(names)}, as_dict=True,
			):
				kin.setdefault(k.parent, k)
	for row in data:
		k = kin.get(row.name)
		row.kin_name, row.kin_relationship, row.kin_phone = (k.full_name, k.relationship, k.phone) if k else ("", "", "")
		row.missing = ", ".join(label for field, label in (("nin", "NIN"), ("tin", "TIN"), ("nssf_number", "NSSF"))
		                        if meta.has_field(field) and not row.get(field)) + (", Next of kin" if not k else "")
		row.missing = row.missing.strip(", ")

	columns = [{"fieldname": f, "label": l, "fieldtype": t, "options": o, "width": w} for f, l, t, o, w in cols]
	columns += [
		{"fieldname": "kin_name", "label": _("Next of Kin"), "fieldtype": "Data", "width": 160},
		{"fieldname": "kin_relationship", "label": _("Relationship"), "fieldtype": "Data", "width": 100},
		{"fieldname": "kin_phone", "label": _("Next of Kin Tel"), "fieldtype": "Data", "width": 120},
		{"fieldname": "missing", "label": _("Missing Details"), "fieldtype": "Data", "width": 200},
	]
	return columns, data
