frappe.query_reports["Staff Register"] = {
	filters: [
		{ fieldname: "status", label: __("Status"), fieldtype: "Select", options: "Active\nInactive\nSuspended\nLeft", default: "Active" },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department" },
		{ fieldname: "branch", label: __("Branch"), fieldtype: "Link", options: "Branch" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "missing" && data && data.missing) value = `<span style="color:var(--orange-600)">${value}</span>`;
		return value;
	},
};
