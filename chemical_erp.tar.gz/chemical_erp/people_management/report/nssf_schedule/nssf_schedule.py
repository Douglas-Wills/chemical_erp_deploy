import frappe
from frappe import _
from frappe.utils import flt

from chemical_erp.people_management.report.payroll_register.payroll_register import cur, payslip_filters


def execute(filters=None):
	filters = frappe._dict(filters or {})
	data = frappe.get_all("Staff Payslip", filters=payslip_filters(filters),
	                      fields=["employee", "employee_name", "nssf_number", "nssf_base", "nssf_employee", "nssf_employer"],
	                      order_by="employee_name asc")
	for row in data:
		row.total = flt(row.nssf_employee) + flt(row.nssf_employer)
	columns = [
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 110},
		{"fieldname": "employee_name", "label": _("Name"), "fieldtype": "Data", "width": 180},
		{"fieldname": "nssf_number", "label": _("NSSF Number"), "fieldtype": "Data", "width": 130},
		cur("nssf_base", _("Gross Pay (NSSF base)"), 150), cur("nssf_employee", _("Employee 5%")),
		cur("nssf_employer", _("Employer 10%")), cur("total", _("Total 15%")),
	]
	missing = sum(1 for r in data if not r.nssf_number)
	return columns, data, (_("{0} employee(s) have no NSSF number recorded.").format(missing) if missing else None)
