"""Every commission line for one employee (or all, for managers), with a running balance."""

import frappe
from frappe import _
from frappe.utils import flt

from chemical_erp.people_management.commission import balances, query_conditions


def execute(filters=None):
	f = frappe._dict(filters or {})
	conditions = {}
	mine_only = bool(query_conditions())
	if mine_only:
		emp = frappe.db.get_value("Employee", {"user_id": frappe.session.user}, "name")
		conditions["employee"] = emp or "-"
	elif f.get("employee"):
		conditions["employee"] = f.employee
	if f.get("from_date"):
		conditions["posting_date"] = [">=", f.from_date]
	rows = frappe.get_all("Commission Entry", filters=conditions, order_by="employee asc, posting_date asc, creation asc",
	                      fields=["name", "employee", "employee_name", "posting_date", "entry_type", "sales_invoice", "customer",
	                              "net_sales", "cost_of_goods", "sale_expenses", "profit", "rate", "amount", "voucher_type", "voucher_no", "remarks"])
	running, last, data = 0.0, None, []
	for r in rows:
		if r.employee != last:
			running, last = 0.0, r.employee
		running += flt(r.amount)
		r.balance = running
		data.append(r)
	c = lambda n, l, t="Currency", w=120, o=None: {"fieldname": n, "label": l, "fieldtype": t, "width": w, **({"options": o} if o else {})}
	columns = [c("posting_date", _("Date"), "Date", 95), c("employee_name", _("Employee"), "Data", 150), c("entry_type", _("Type"), "Data", 100),
	           c("sales_invoice", _("Invoice"), "Link", 140, "Sales Invoice"), c("customer", _("Customer"), "Link", 160, "Customer"),
	           c("net_sales", _("Net Sales")), c("cost_of_goods", _("Cost of Goods")), c("sale_expenses", _("Sale Expenses")),
	           c("profit", _("Profit")), c("rate", _("Rate %"), "Percent", 70), c("amount", _("Commission")), c("balance", _("Balance")),
	           c("voucher_no", _("Paid Through"), "Dynamic Link", 140, "voucher_type"), c("remarks", _("Remarks"), "Data", 180)]
	summary = None
	emp = conditions.get("employee")
	if emp and emp != "-":
		b = balances(emp)
		summary = [{"label": _("Payable now"), "value": b.payable, "datatype": "Currency", "indicator": "Green"},
		           {"label": _("Waiting for customers to pay"), "value": b.accrued, "datatype": "Currency", "indicator": "Orange"},
		           {"label": _("Earned in total"), "value": b.earned, "datatype": "Currency", "indicator": "Blue"},
		           {"label": _("Paid out"), "value": b.paid, "datatype": "Currency", "indicator": "Blue"}]
		if b.owed:
			summary.append({"label": _("To be recovered from future commission"), "value": b.owed, "datatype": "Currency", "indicator": "Red"})
	return columns, data, None, None, summary
