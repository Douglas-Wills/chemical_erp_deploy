frappe.query_reports["Commission Statement"] = {
	filters: [
		{ fieldname: "employee", label: __("Employee"), fieldtype: "Link", options: "Employee" },
		{ fieldname: "from_date", label: __("From"), fieldtype: "Date" },
	],
};
