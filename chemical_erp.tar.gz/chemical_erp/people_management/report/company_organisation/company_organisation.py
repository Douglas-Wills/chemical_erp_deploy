"""The organisation chart: every post under the post it reports to, with its department and who holds it."""

import frappe
from frappe import _


def execute(filters=None):
	f = frappe._dict(filters or {})
	cond = {"active": 1}
	if f.company:
		cond["company"] = ["in", [f.company, "", None]]
	posts = frappe.get_all("Company Position", filters=cond, fields=["name", "department", "reports_to_position", "status", "company"])
	names = {p.name for p in posts}
	children = {}
	for p in posts:
		parent = p.reports_to_position if p.reports_to_position in names else None
		children.setdefault(parent, []).append(p)
	md = ", ".join(frappe.utils.get_fullname(u) for u in frappe.get_all("Has Role", filters={"role": "Managing Director", "parenttype": "User"}, pluck="parent")
	               if u not in ("Administrator",)) or _("Managing Director")
	data, seen = [], set()

	def walk(parent, depth):
		for p in sorted(children.get(parent, []), key=lambda x: (x.department or "", x.name)):
			if p.name in seen:
				continue
			seen.add(p.name)
			holders = [frappe.utils.get_fullname(h.user) for h in frappe.get_all("Position Holder", filters={"parent": p.name}, fields=["user"])]
			data.append({"post": p.name, "reports_to": parent, "indent": depth, "department": p.department,
			             "held_by": ", ".join(holders) if holders else _("Vacant: covered by {0}").format(md),
			             "status": p.status, "people": len(holders)})
			walk(p.name, depth + 1)

	walk(None, 0)
	filled = sum(1 for d in data if d["people"])
	summary = [{"label": _("Posts"), "value": len(data), "indicator": "Blue"},
	           {"label": _("Filled"), "value": filled, "indicator": "Green"},
	           {"label": _("Vacant (MD covering)"), "value": len(data) - filled, "indicator": "Orange" if len(data) - filled else "Green"}]
	return [
		{"fieldname": "post", "label": _("Post"), "fieldtype": "Link", "options": "Company Position", "width": 260},
		{"fieldname": "department", "label": _("Department"), "fieldtype": "Link", "options": "Department", "width": 170},
		{"fieldname": "held_by", "label": _("Held By"), "fieldtype": "Data", "width": 260},
		{"fieldname": "reports_to", "label": _("Reports To"), "fieldtype": "Link", "options": "Company Position", "width": 200},
	], data, None, None, summary
