frappe.query_reports["Company Organisation"] = {
	filters: [{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company", default: frappe.defaults.get_user_default("Company") }],
	tree: true, name_field: "post", parent_field: "reports_to", initial_depth: 4,
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "held_by" && data && !data.people) value = `<span style="color:var(--orange-600)">${value}</span>`;
		return value;
	},
};
