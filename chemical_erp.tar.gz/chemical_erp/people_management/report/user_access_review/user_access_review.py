"""Who can do what, and why: every user's roles with their source (post, access grant, cover for a vacant post, or
given by hand), limits and end dates. Review it periodically and revoke what is no longer needed."""

import frappe
from frappe import _

IGNORE = {"All", "Guest", "Desk User"}


def execute(filters=None):
	f = frappe._dict(filters or {})
	users = frappe.get_all("User", filters={"enabled": 1, "user_type": "System User", "name": ["not in", ["Administrator", "Guest"]]},
	                       fields=["name", "full_name"])
	data = []
	for u in users:
		emp = frappe.db.get_value("Employee", {"user_id": u.name}, ["name", "department", "status", "reports_to"], as_dict=True) or frappe._dict()
		if f.department and emp.department != f.department:
			continue
		grants = {}
		for g in frappe.get_all("Position Role Grant", filters={"user": u.name}, fields=["role", "reason", "position", "access_grant"]):
			grants.setdefault(g.role, []).append(g)
		limits = ", ".join(f"{p.allow}: {p.for_value}" for p in frappe.get_all("User Permission", filters={"user": u.name}, fields=["allow", "for_value"]))
		for role in sorted(r for r in frappe.get_roles(u.name) if r not in IGNORE):
			sources, until, by = [], None, None
			for g in grants.get(role, []):
				if g.reason == "Holder":
					sources.append(_("Post: {0}").format(g.position))
				elif g.reason == "Vacancy":
					sources.append(_("Covering vacant post: {0}").format(g.position))
				else:
					ag = frappe.db.get_value("Access Grant", g.access_grant, ["valid_to", "granted_by"], as_dict=True) or frappe._dict()
					sources.append(_("Access grant {0}").format(g.access_grant))
					until, by = ag.valid_to, ag.granted_by
			source = "; ".join(sources) or _("Given by hand")
			if f.only_manual and sources:
				continue
			data.append({"user": u.name, "full_name": u.full_name, "department": emp.department, "employee_status": emp.status or _("No employee record"),
			             "role": role, "source": source, "granted_by": by, "valid_to": until, "limits": limits})
	return [
		{"fieldname": "full_name", "label": _("Name"), "fieldtype": "Data", "width": 160},
		{"fieldname": "department", "label": _("Department"), "fieldtype": "Link", "options": "Department", "width": 130},
		{"fieldname": "role", "label": _("Role"), "fieldtype": "Link", "options": "Role", "width": 150},
		{"fieldname": "source", "label": _("Why They Have It"), "fieldtype": "Data", "width": 240},
		{"fieldname": "granted_by", "label": _("Granted By"), "fieldtype": "Link", "options": "User", "width": 140},
		{"fieldname": "valid_to", "label": _("Until"), "fieldtype": "Date", "width": 95},
		{"fieldname": "limits", "label": _("Limited To"), "fieldtype": "Data", "width": 200},
		{"fieldname": "employee_status", "label": _("Employee Status"), "fieldtype": "Data", "width": 110},
		{"fieldname": "user", "label": _("User"), "fieldtype": "Link", "options": "User", "width": 160},
	], data
