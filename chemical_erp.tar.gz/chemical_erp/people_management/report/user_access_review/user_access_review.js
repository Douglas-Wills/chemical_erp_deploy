frappe.query_reports["User Access Review"] = {
	filters: [
		{ fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department" },
		{ fieldname: "only_manual", label: __("Only Roles Given by Hand"), fieldtype: "Check" },
	],
};
