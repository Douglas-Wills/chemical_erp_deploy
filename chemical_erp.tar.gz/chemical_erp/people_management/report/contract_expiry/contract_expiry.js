frappe.query_reports["Contract Expiry"] = {
	filters: [
		{ fieldname: "days", label: __("Look Ahead (days)"), fieldtype: "Int", default: 90 },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "days_left" && data && data.days_left <= 14) value = `<span style="color:var(--red-600);font-weight:600">${value}</span>`;
		return value;
	},
};
