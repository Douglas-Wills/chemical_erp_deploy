import frappe
from frappe import _
from frappe.utils import add_days, cint, date_diff, getdate, today


def execute(filters=None):
	filters = frappe._dict(filters or {})
	horizon = add_days(today(), cint(filters.days or 90))
	conditions = {"status": ["not in", ["Terminated", "Renewed", "Draft"]]}
	if filters.company:
		conditions["company"] = filters.company
	rows = frappe.get_all("Employment Contract", filters=conditions,
	                      fields=["name", "employee", "employee_name", "department", "contract_type", "start_date", "end_date",
	                              "probation_end_date", "confirmed", "status", "renewed_by", "gross_monthly"])
	data = []
	for r in rows:
		events = []
		if r.end_date and getdate(r.end_date) <= getdate(horizon) and not r.renewed_by:
			events.append((r.end_date, _("Contract ends") if getdate(r.end_date) >= getdate(today()) else _("Expired, not renewed")))
		if r.probation_end_date and not cint(r.confirmed) and getdate(r.probation_end_date) <= getdate(horizon):
			events.append((r.probation_end_date, _("Probation ends")))
		for date, event in events:
			data.append({**r, "event": event, "event_date": date, "days_left": date_diff(date, today())})
	data.sort(key=lambda x: x["event_date"])
	columns = [
		{"fieldname": "event_date", "label": _("Date"), "fieldtype": "Date", "width": 100},
		{"fieldname": "days_left", "label": _("Days Left"), "fieldtype": "Int", "width": 85},
		{"fieldname": "event", "label": _("What"), "fieldtype": "Data", "width": 160},
		{"fieldname": "employee_name", "label": _("Employee"), "fieldtype": "Data", "width": 170},
		{"fieldname": "department", "label": _("Department"), "fieldtype": "Link", "options": "Department", "width": 140},
		{"fieldname": "contract_type", "label": _("Type"), "fieldtype": "Data", "width": 100},
		{"fieldname": "name", "label": _("Contract"), "fieldtype": "Link", "options": "Employment Contract", "width": 140},
		{"fieldname": "gross_monthly", "label": _("Gross Monthly"), "fieldtype": "Currency", "width": 120},
	]
	return columns, data
