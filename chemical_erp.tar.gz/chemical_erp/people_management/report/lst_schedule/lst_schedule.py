import frappe
from frappe import _

from chemical_erp.people_management.report.payroll_register.payroll_register import cur, payslip_filters


def execute(filters=None):
	filters = frappe._dict(filters or {})
	conditions = payslip_filters(filters)
	conditions["lst"] = [">", 0]
	data = frappe.get_all("Staff Payslip", filters=conditions,
	                      fields=["employee", "employee_name", "gross_pay", "paye", "lst"], order_by="employee_name asc")
	has_lg = frappe.get_meta("Employee").has_field("lst_local_government")
	for row in data:
		row.take_home = (row.gross_pay or 0) - (row.paye or 0)
		row.local_government = frappe.db.get_value("Employee", row.employee, "lst_local_government") if has_lg else ""
	data.sort(key=lambda r: ((r.local_government or "zzz").lower(), r.employee_name))
	columns = [
		{"fieldname": "local_government", "label": _("Local Government"), "fieldtype": "Data", "width": 160},
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 110},
		{"fieldname": "employee_name", "label": _("Name"), "fieldtype": "Data", "width": 180},
		cur("gross_pay", _("Gross")), cur("take_home", _("Gross less PAYE")), cur("lst", _("LST Instalment")),
	]
	return columns, data
