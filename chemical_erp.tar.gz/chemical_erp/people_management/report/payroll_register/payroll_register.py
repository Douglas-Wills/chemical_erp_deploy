import frappe
from frappe import _
from frappe.utils import get_first_day, get_last_day, getdate

MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]


def payslip_filters(filters):
	conditions = {"docstatus": 1 if not filters.include_drafts else ["<", 2]}
	if filters.payroll_run:
		conditions["payroll_run"] = filters.payroll_run
	else:
		month = MONTHS.index(filters.month or MONTHS[getdate().month - 1]) + 1
		first = getdate(f"{filters.year or getdate().year}-{month:02d}-01")
		conditions["end_date"] = ["between", [get_first_day(first), get_last_day(first)]]
	if filters.company:
		conditions["company"] = filters.company
	if filters.department:
		conditions["department"] = filters.department
	return conditions


def cur(fieldname, label, width=120):
	return {"fieldname": fieldname, "label": label, "fieldtype": "Currency", "width": width}


def execute(filters=None):
	filters = frappe._dict(filters or {})
	data = frappe.get_all(
		"Staff Payslip", filters=payslip_filters(filters),
		fields=["name", "employee", "employee_name", "department", "payable_days", "days_in_period", "gross_pay",
		        "paye", "nssf_employee", "nssf_employer", "lst", "other_deductions", "net_pay", "payment_mode",
		        "bank_name", "bank_account", "mobile_money_number"],
		order_by="employee_name asc",
	)
	columns = [
		{"fieldname": "name", "label": _("Payslip"), "fieldtype": "Link", "options": "Staff Payslip", "width": 140},
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 110},
		{"fieldname": "employee_name", "label": _("Name"), "fieldtype": "Data", "width": 170},
		{"fieldname": "department", "label": _("Department"), "fieldtype": "Link", "options": "Department", "width": 130},
		{"fieldname": "payable_days", "label": _("Days"), "fieldtype": "Int", "width": 60},
		cur("gross_pay", _("Gross")), cur("paye", _("PAYE")), cur("nssf_employee", _("NSSF 5%")),
		cur("nssf_employer", _("NSSF 10% (employer)")), cur("lst", _("LST"), 100), cur("other_deductions", _("Other Deductions")),
		cur("net_pay", _("Net Pay")),
		{"fieldname": "payment_mode", "label": _("Paid By"), "fieldtype": "Data", "width": 100},
		{"fieldname": "bank_name", "label": _("Bank"), "fieldtype": "Data", "width": 120},
		{"fieldname": "bank_account", "label": _("Account No."), "fieldtype": "Data", "width": 130},
		{"fieldname": "mobile_money_number", "label": _("Mobile Money"), "fieldtype": "Data", "width": 120},
	]
	return columns, data
