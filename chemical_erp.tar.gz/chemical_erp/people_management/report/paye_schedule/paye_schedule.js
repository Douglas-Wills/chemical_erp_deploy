frappe.query_reports["PAYE Schedule"] = {
	filters: [
		{ fieldname: "payroll_run", label: __("Payroll Run"), fieldtype: "Link", options: "Payroll Run" },
		{ fieldname: "month", label: __("Month"), fieldtype: "Select", options: moment.months().join("\n"), default: moment().format("MMMM") },
		{ fieldname: "year", label: __("Year"), fieldtype: "Int", default: new Date().getFullYear() },
		{ fieldname: "company", label: __("Company"), fieldtype: "Link", options: "Company" },
		{ fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department" },
		{ fieldname: "include_drafts", label: __("Include Draft Payslips"), fieldtype: "Check" },
	],
};
