import frappe
from frappe import _

from chemical_erp.people_management.report.payroll_register.payroll_register import cur, payslip_filters


def execute(filters=None):
	filters = frappe._dict(filters or {})
	data = frappe.get_all("Staff Payslip", filters=payslip_filters(filters),
	                      fields=["employee", "employee_name", "tin", "paye_residency", "gross_pay", "taxable_pay", "paye", "paye_band_set"],
	                      order_by="employee_name asc")
	for row in data:
		row.missing_tin = 0 if row.tin else 1
	columns = [
		{"fieldname": "employee", "label": _("Employee"), "fieldtype": "Link", "options": "Employee", "width": 110},
		{"fieldname": "employee_name", "label": _("Name"), "fieldtype": "Data", "width": 180},
		{"fieldname": "tin", "label": _("TIN"), "fieldtype": "Data", "width": 120},
		{"fieldname": "paye_residency", "label": _("Residency"), "fieldtype": "Data", "width": 100},
		cur("gross_pay", _("Gross Employment Income"), 150), cur("taxable_pay", _("Chargeable Income"), 140),
		cur("paye", _("PAYE")),
		{"fieldname": "paye_band_set", "label": _("Bands Used"), "fieldtype": "Link", "options": "PAYE Band Set", "width": 170},
	]
	missing = sum(r.missing_tin for r in data)
	message = _("{0} employee(s) have no TIN recorded.").format(missing) if missing else None
	return columns, data, message
