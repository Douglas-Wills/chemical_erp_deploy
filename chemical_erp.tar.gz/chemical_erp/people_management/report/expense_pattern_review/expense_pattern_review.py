"""Expense claims per employee per month: how many, how many small, totals, and how many were flagged."""

import frappe
from frappe import _
from frappe.utils import add_months, flt, getdate, today

from chemical_erp.utils import get_settings


def execute(filters=None):
	f = frappe._dict(filters or {})
	small = flt(get_settings().get("small_expense_amount")) or 100000
	start = f.from_date or add_months(today(), -6)
	rows = frappe.db.sql("""select employee, employee_name, date_format(posting_date, '%%Y-%%m') month, count(*) claims,
		sum(case when total_claimed_amount < %(small)s then 1 else 0 end) small_claims,
		sum(case when total_claimed_amount < %(small)s then total_claimed_amount else 0 end) small_total,
		sum(total_claimed_amount) total, sum(ifnull(pattern_flag, 0)) flagged,
		sum(case when ifnull(pattern_flag, 0) = 1 and ifnull(pattern_reviewed, 0) = 0 then 1 else 0 end) unreviewed
		from `tabExpense Claim` where docstatus < 2 and posting_date >= %(start)s {emp}
		group by employee, month order by small_claims desc, month desc""".format(emp="and employee = %(employee)s" if f.employee else ""),
		{"small": small, "start": start, "employee": f.employee}, as_dict=True)
	return [
		{"fieldname": "employee_name", "label": _("Employee"), "fieldtype": "Data", "width": 180},
		{"fieldname": "month", "label": _("Month"), "fieldtype": "Data", "width": 80},
		{"fieldname": "claims", "label": _("Claims"), "fieldtype": "Int", "width": 70},
		{"fieldname": "small_claims", "label": _("Small Claims"), "fieldtype": "Int", "width": 100},
		{"fieldname": "small_total", "label": _("Small Claims Total"), "fieldtype": "Currency", "width": 140},
		{"fieldname": "total", "label": _("All Claims Total"), "fieldtype": "Currency", "width": 140},
		{"fieldname": "flagged", "label": _("Flagged"), "fieldtype": "Int", "width": 80},
		{"fieldname": "unreviewed", "label": _("Flagged, Not Reviewed"), "fieldtype": "Int", "width": 150},
		{"fieldname": "employee", "label": _("Employee ID"), "fieldtype": "Link", "options": "Employee", "width": 120},
	], rows
