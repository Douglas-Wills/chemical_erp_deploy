"""QR codes that return the very document they are printed on, whatever its state.

The QR holds a short signed link: /api/method/chemical_erp.doc_qr.v?c=<code>. The code carries a fingerprint of the
document's content when the copy was printed. Scanning returns the document as a PDF, with a status stamp in the
upper corner:
  FINAL COPY issued and unchanged since this copy was printed
  ALTERED    changed since this copy was printed (the current version is shown)
  DRAFT      not yet issued
  CANCELLED  no longer valid (and its replacement, if amended)
The signature (HMAC with the site's own key) covers the document name and fingerprint, so a tampered code is refused
rather than allowed to open another document.
"""

import hashlib
import hmac
import json
from urllib.parse import quote

import frappe
from frappe import _
from frappe.rate_limiter import rate_limit

# Short codes keep the QR small and easy to scan.
DOCTYPES = {"QTN": "Quotation", "SINV": "Sales Invoice", "PO": "Purchase Order", "DN": "Delivery Note", "QI": "Quality Inspection",
            "PE": "Payment Entry", "WA": "Water Analysis"}
ABBR = {v: k for k, v in DOCTYPES.items()}
PRINT_FORMATS = {"Quotation": "Quotation (House Style)", "Sales Invoice": "Tax Invoice (EFRIS)", "Purchase Order": "Purchase Order (House Style)",
                 "Quality Inspection": "Certificate of Analysis", "Payment Entry": "Receipt (House Style)", "Water Analysis": "Water Analysis Report"}


def _secret():
	from frappe.utils.password import get_encryption_key

	return get_encryption_key().encode()


PARTY = {"Quotation": "party_name", "Sales Invoice": "customer", "Purchase Order": "supplier", "Delivery Note": "customer",
         "Quality Inspection": "item_code", "Payment Entry": "party", "Water Analysis": "customer"}
DATE = {"Quotation": "transaction_date", "Sales Invoice": "posting_date", "Purchase Order": "transaction_date",
        "Delivery Note": "posting_date", "Quality Inspection": "report_date", "Payment Entry": "posting_date",
        "Water Analysis": "analysed_on"}


def fingerprint(doc):
	"""Content that matters on paper. Status changes and later admin fields (EFRIS number, WHT, attachments) are left out,
	so they do not count as alterations."""
	lines = [(r.get("item_code"), round(float(r.get("qty") or 0), 4), round(float(r.get("rate") or 0), 4))
	         for r in (doc.get("items") or [])]
	if doc.doctype == "Payment Entry":
		lines = [(r.get("reference_name"), round(float(r.get("allocated_amount") or 0), 2)) for r in doc.get("references") or []]
		lines += [("deduction", round(float(d.get("amount") or 0), 2)) for d in doc.get("deductions") or []]
	if doc.doctype == "Water Analysis":
		lines = [(r.get("sample_point"), r.get("parameter"), r.get("result"), r.get("comment")) for r in doc.get("results") or []]
	if doc.doctype == "Quality Inspection":
		lines = [(r.get("specification"), str(r.get("reading_value") or r.get("reading_1") or ""), r.get("status")) for r in doc.get("readings") or []]
	body = {"p": doc.get(PARTY.get(doc.doctype, "")), "d": str(doc.get(DATE.get(doc.doctype, "")) or ""), "c": doc.get("currency"),
	        "t": round(float(doc.get("grand_total") or doc.get("paid_amount") or 0), 2), "l": lines, "b": doc.get("batch_no")}
	return hashlib.sha256(json.dumps(body, sort_keys=True, default=str).encode()).hexdigest()[:8]


def sign(doctype, name, fp=""):
	return hmac.new(_secret(), f"{doctype}\x1f{name}\x1f{fp}".encode(), hashlib.sha256).hexdigest()[:16]


def code_for(doctype, name, fp=""):
	return f"{ABBR[doctype]}~{name}~{fp}~{sign(doctype, name, fp)}"


def qr_base():
	"""Where QR codes point: the QR Link Address setting (e.g. https://bravechemicals.com/system), else the site's address."""
	base = (frappe.db.get_single_value("Chemical ERP Settings", "qr_base_url") or "").strip().rstrip("/")
	return base or frappe.utils.get_url().rstrip("/")


def url_for(doc):
	code = code_for(doc.doctype, doc.name, fingerprint(doc))
	return f"{qr_base()}/api/method/chemical_erp.doc_qr.v?c={quote(code, safe='~')}"


def qr_image(text, scale=4):
	"""PNG data URI. pyqrcode ships with Frappe (it draws the two-factor login codes)."""
	try:
		import pyqrcode

		return "data:image/png;base64," + pyqrcode.create(text, error="M").png_as_base64_str(scale=scale, quiet_zone=2)
	except Exception:
		frappe.log_error(title="QR code could not be drawn", message=frappe.get_traceback())
		return ""


def qr_for_doc(doc, size_mm=26, caption=None):
	"""Jinja: the document's own QR code, centred, with a caption. Empty for unsaved documents."""
	if not getattr(doc, "name", None) or doc.doctype not in ABBR or (hasattr(doc, "is_new") and doc.is_new()):
		return ""
	src = qr_image(url_for(doc))
	if not src:
		return ""
	caption = caption or _("Scan to view and verify this document")
	shown_as = doc.doctype
	if doc.doctype == "Payment Entry":
		shown_as = _("Receipt") if doc.get("payment_type") == "Receive" else _("Payment")
	return (f'<div style="text-align:center;margin-top:14pt;page-break-inside:avoid">'
	        f'<img src="{src}" style="width:{size_mm}mm;height:{size_mm}mm" alt="QR">'
	        f'<div style="font-family:Arial,\'Liberation Sans\',sans-serif;font-size:8pt;color:#55606b;margin-top:2pt">'
	        f'{frappe.utils.escape_html(caption)}<br>{frappe.utils.escape_html(shown_as)} {frappe.utils.escape_html(doc.name)}</div></div>')


def qr_text_image(text, size_mm=24):
	"""Jinja: a QR image for any text, e.g. the EFRIS code URA returns."""
	if not text:
		return ""
	src = qr_image(text, scale=3)
	return f'<img src="{src}" style="width:{size_mm}mm;height:{size_mm}mm" alt="QR">' if src else ""


def _company():
	from chemical_erp.company import company_name

	return company_name(short=True)


def _page(title, message):
	frappe.respond_as_web_page(title, message, http_status_code=200, indicator_color="orange")


def scan_status(doc, printed_fp):
	"""Status stamp for a scanned copy."""
	now = frappe.utils.format_datetime(frappe.utils.now_datetime(), "d MMM yyyy HH:mm")
	if doc.docstatus == 2:
		replaced = frappe.db.get_value(doc.doctype, {"amended_from": doc.name}, "name")
		return {"label": _("CANCELLED"), "colour": "#b3261e", "result": "Cancelled",
		        "detail": _("Replaced by {0}").format(replaced) if replaced else _("No longer valid")}
	if printed_fp and printed_fp != fingerprint(doc):
		return {"label": _("ALTERED"), "colour": "#b3261e", "result": "Altered",
		        "detail": _("Changed since this copy was printed. Current version shown, {0}").format(now)}
	if doc.docstatus == 0:
		return {"label": _("DRAFT"), "colour": "#b26a00", "result": "Draft", "detail": _("Not issued. Checked {0}").format(now)}
	return {"label": _("FINAL COPY"), "colour": "#2a6a4a", "result": "Final Copy", "detail": _("Verified {0}").format(now)}


@frappe.whitelist(allow_guest=True)
@rate_limit(limit=60, seconds=60)
def v(c=None):
	"""Scan target. Always returns the document itself as a PDF, stamped with its status."""
	parts = (c or "").split("~")
	try:
		if len(parts) == 4:
			abbr, name, printed_fp, sig = parts
		else:  # codes printed before fingerprints were added
			abbr, name, sig = parts
			printed_fp = ""
		doctype = DOCTYPES[abbr]
	except (ValueError, KeyError):
		_log(None, None, "Not recognised")
		return _page(_("Not recognised"), _("This code is not a {0} document code.").format(_company()))
	if not hmac.compare_digest(sig, sign(doctype, name, printed_fp)) or not frappe.db.exists(doctype, name):
		_log(doctype, None, "Not recognised")
		return _page(_("Not recognised"), _("This code has been tampered with or does not match any {0} document. "
		                                     "Please contact {0} to confirm the document.").format(_company()))
	user = frappe.session.user
	try:
		frappe.set_user("Administrator")  # the signed code is the permission: it names exactly this document
		doc = frappe.get_doc(doctype, name)
		status = scan_status(doc, printed_fp)
		doc._qr_status = status
		doc.flags.ignore_print_permissions = True
		pdf = frappe.get_print(doctype, name, PRINT_FORMATS.get(doctype), doc=doc, as_pdf=True)
	finally:
		frappe.set_user(user)
	_log(doctype, name, status["result"])
	frappe.local.response.filename = f"{doctype} {name} ({status['result']}).pdf"
	frappe.local.response.filecontent = pdf
	frappe.local.response.type = "pdf"


def _log(doctype, name, result):
	try:
		frappe.get_doc({"doctype": "Document Scan", "reference_doctype": doctype, "reference_name": name, "result": result,
		                "ip_address": frappe.local.request_ip if hasattr(frappe.local, "request_ip") else None,
		                "user_agent": (frappe.request.headers.get("User-Agent") if frappe.request else "")[:140]}).insert(ignore_permissions=True)
		frappe.db.commit()
	except Exception:
		pass
