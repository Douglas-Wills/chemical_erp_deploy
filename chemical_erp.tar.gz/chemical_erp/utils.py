"""Shared helpers for chemical_erp."""

import frappe
from frappe import _
from frappe.utils import getdate, today

MD_ROLE = "Managing Director"
FORMULA_ROLE = "Formula Owner"
USABLE_EQUIPMENT = ("In Service", "Calibration Due")

# Positions. Approvals on production and quality documents go to a position, not a person.
# Today the Managing Director holds Plant Manager; when the post is filled, move the role. No code change.
PLANT_MANAGER = "Plant Manager"
QC_MANAGER = "QC Manager"


def approver_role(kind="production"):
	"""Role that approves production or quality documents. Quality can be split off to a QC Manager in settings."""
	if kind == "quality":
		return get_settings().get("quality_approver") or PLANT_MANAGER
	return PLANT_MANAGER


def position_holders(kind="production"):
	return users_with_role(approver_role(kind))


def position_title(kind="production"):
	s = get_settings()
	role = approver_role(kind)
	return (s.get("qc_manager_title") if role == QC_MANAGER else s.get("plant_manager_title")) or role


def get_settings():
	return frappe.get_cached_doc("Chemical ERP Settings")


def has_role(role, user=None):
	return role in frappe.get_roles(user or frappe.session.user)


def is_formula_owner(user=None):
	user = user or frappe.session.user
	return user == "Administrator" or has_role(FORMULA_ROLE, user) or has_role(MD_ROLE, user)


def warehouse_zone(warehouse):
	if not warehouse:
		return None
	return frappe.get_cached_value("Warehouse", warehouse, "qc_zone") or "Neutral"


def batch_info(batch_no):
	return frappe.db.get_value(
		"Batch", batch_no,
		["name", "item", "qc_status", "expiry_date", "retest_date", "is_waste_batch", "assay", "reference_doctype"],
		as_dict=True,
	)


def row_batches(row):
	"""Batches on a stock row, whether entered directly or through a Serial and Batch Bundle."""
	batches = []
	if row.get("batch_no"):
		batches.append((row.batch_no, abs(row.get("stock_qty") or row.get("transfer_qty") or row.get("qty") or 0)))
	bundle = row.get("serial_and_batch_bundle")
	if bundle and not batches:
		for e in frappe.get_all("Serial and Batch Entry", filters={"parent": bundle}, fields=["batch_no", "qty"]):
			if e.batch_no:
				batches.append((e.batch_no, abs(e.qty or 0)))
	return batches


def batch_balances(batch_no):
	"""[(warehouse, qty)] with qty > 0 for a batch."""
	try:
		from erpnext.stock.doctype.batch.batch import get_batch_qty

		rows = get_batch_qty(batch_no=batch_no) or []
		return [(r.get("warehouse"), r.get("qty")) for r in rows if (r.get("qty") or 0) > 0]
	except Exception:
		frappe.log_error(title=f"Could not read balance of batch {batch_no}", message=frappe.get_traceback())
		return []


def current_sds(item_code, on_date=None):
	on_date = getdate(on_date or today())
	rows = frappe.get_all(
		"SDS File",
		filters={"item_code": item_code, "sds_status": "Current", "docstatus": 1, "effective_from": ["<=", on_date]},
		or_filters=[["effective_to", "is", "not set"], ["effective_to", ">=", on_date]],
		pluck="name", order_by="effective_from desc", limit=1,
	)
	return rows[0] if rows else None


def users_with_role(role):
	if not role:
		return []
	users = frappe.get_all("Has Role", filters={"role": role, "parenttype": "User"}, pluck="parent")
	return [u for u in set(users) if u not in ("Administrator", "Guest") and frappe.db.get_value("User", u, "enabled")]


def notify(users, doctype, name, subject, message=None, priority="Medium"):
	"""ToDo + bell notification. Never raises."""
	if isinstance(users, str):
		users = [users]
	for user in dict.fromkeys(u for u in (users or []) if u and u not in ("Guest", "Administrator")):
		try:
			if not frappe.db.exists("ToDo", {"allocated_to": user, "reference_type": doctype, "reference_name": name,
			                                   "status": "Open", "description": message or subject}):
				frappe.get_doc({"doctype": "ToDo", "allocated_to": user, "reference_type": doctype,
				                "reference_name": name, "description": message or subject, "priority": priority,
				                "date": today()}).insert(ignore_permissions=True)
			from frappe.desk.doctype.notification_log.notification_log import enqueue_create_notification

			enqueue_create_notification(user, {"type": "Alert", "document_type": doctype, "document_name": name,
			                                   "subject": subject, "email_content": message or subject,
			                                   "from_user": "Administrator"})
		except Exception:
			frappe.log_error(title=f"chemical_erp notification to {user} failed", message=frappe.get_traceback())


def _open_actions(fields, roles=None, user=None):
	"""Open Workflow Actions. Frappe v15 records the roles that may act (permitted_roles); the user field is legacy
	and normally blank, so both are read."""
	names = set()
	if roles:
		names |= set(frappe.get_all("Workflow Action Permitted Role", filters={"role": ["in", list(roles)], "parenttype": "Workflow Action"},
		                            pluck="parent"))
	if user and frappe.get_meta("Workflow Action").has_field("user"):
		names |= set(frappe.get_all("Workflow Action", filters={"status": "Open", "user": user}, pluck="name"))
	if roles is None and user is None:
		return frappe.get_all("Workflow Action", filters={"status": "Open"}, fields=fields, order_by="creation asc")
	if not names:
		return []
	return frappe.get_all("Workflow Action", filters={"status": "Open", "name": ["in", list(names)]}, fields=fields, order_by="creation asc")


def pending_approvals(user=None):
	"""What is waiting for this user to act on: approvals they may sign (never their own document, unless the MD
	raised it), and their own drafts waiting to be sent. Others' unsent drafts are not their task."""
	from frappe.model.workflow import get_workflow_name

	from chemical_erp.controls.approvals import SUBMISSION_ACTIONS

	user = user or frappe.session.user
	roles = set(frappe.get_roles(user))
	fields = ["name", "reference_doctype", "reference_name", "workflow_state", "creation"]
	out = []
	for r in _open_actions(fields, roles=roles, user=user):
		wf_name = get_workflow_name(r.reference_doctype)
		if not wf_name:
			continue
		mine = [t for t in frappe.get_cached_doc("Workflow", wf_name).transitions if t.state == r.workflow_state and t.allowed in roles]
		if not mine:
			continue
		try:
			doc = frappe.get_doc(r.reference_doctype, r.reference_name)
		except frappe.DoesNotExistError:
			continue
		sending_only = all(t.action in SUBMISSION_ACTIONS for t in mine)
		own = doc.owner == user
		if sending_only and not own:
			continue  # someone else's draft: theirs to send
		if not sending_only and own and not doc.get("raised_by_md"):
			continue  # nobody approves their own document
		out.append(r)
	return out


def all_pending_approvals():
	"""Every open workflow action with the roles it waits on. For the MD and the Approval Aging report."""
	from frappe.model.workflow import get_workflow_name

	from chemical_erp.controls.approvals import SUBMISSION_ACTIONS

	fields = ["name", "reference_doctype", "reference_name", "workflow_state", "creation"]
	out = []
	for r in _open_actions(fields):
		wf_name = get_workflow_name(r.reference_doctype)
		steps = [t for t in frappe.get_cached_doc("Workflow", wf_name).transitions if t.state == r.workflow_state] if wf_name else []
		if not steps or all(t.action in SUBMISSION_ACTIONS for t in steps):
			continue  # a draft waiting to be sent is not an approval waiting
		r.user = ", ".join(frappe.get_all("Workflow Action Permitted Role", filters={"parent": r.name}, pluck="role"))
		out.append(r)
	return out


def company_currency(company=None):
	company = company or frappe.defaults.get_user_default("Company") or frappe.db.get_single_value("Global Defaults", "default_company")
	return frappe.get_cached_value("Company", company, "default_currency") if company else None


def exchange_rate(from_currency, to_currency=None, date=None):
	"""Rate to convert from_currency into to_currency (company currency by default). 1 if they are the same."""
	to_currency = to_currency or company_currency()
	if not from_currency or not to_currency or from_currency == to_currency:
		return 1.0
	from erpnext.setup.utils import get_exchange_rate

	rate = get_exchange_rate(from_currency, to_currency, date or today()) or 0
	if not rate:
		frappe.throw(_("No exchange rate from {0} to {1}. Enter it under Currency Exchange (e.g. the Bank of Uganda rate).").format(
			from_currency, to_currency), title=_("Exchange rate missing"))
	return float(rate)


def make_stock_entry(company, purpose, rows, flags=None, submit=True, **values):
	"""Create (and submit) a system Stock Entry. rows: dicts with item_code, qty, s_warehouse/t_warehouse, batch_no."""
	se = frappe.new_doc("Stock Entry")
	se.company = company
	se.stock_entry_type = purpose
	se.purpose = purpose
	se.update(values)
	for r in rows:
		r = dict(r)
		r.setdefault("use_serial_batch_fields", 1)
		se.append("items", r)
	for k, v in (flags or {}).items():
		se.flags[k] = v
	se.flags.ignore_permissions = True
	se.insert()
	if submit:
		se.submit()
	return se
