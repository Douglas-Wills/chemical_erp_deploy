"""Help: keyword search over the user manual, stored as Help Topics so it can be kept up to date in the system."""
import json
import os
import re

import frappe

SOURCE = os.path.join(os.path.dirname(__file__), "manual_topics.json")
STOP = set("a an and are as at be by can do does for from how i in is it me my of on or the to what when where which who why with you your".split())

# Words people type -> words the manual uses. Both directions are searched.
SYNONYMS = {
	"lpo": ["purchase order"], "po": ["purchase order"], "grn": ["purchase receipt", "receiving goods"],
	"goods received": ["purchase receipt"], "bom": ["formula"], "recipe": ["formula"], "formula": ["bom"],
	"work order": ["production order"], "production order": ["work order"], "manufacture": ["production entry"],
	"invoice": ["tax invoice", "sales invoice"], "efris": ["tax invoice"], "receipt": ["payment entry"],
	"payment": ["payment entry"], "delivery note": ["delivery"], "dn": ["delivery"], "coa": ["certificate of analysis", "certificate"],
	"msds": ["sds", "safety data sheet"], "sds": ["safety data sheet"], "md": ["managing director"],
	"boss": ["managing director"], "approve": ["approval"], "approver": ["approval"], "sign": ["approval", "signature"],
	"delete": ["deletion", "deleting"], "remove": ["deletion"], "password": ["signing in", "sign in"],
	"login": ["signing in", "sign in"], "log in": ["signing in"], "2fa": ["two-factor"], "otp": ["two-factor"],
	"leave": ["leave application", "absence"], "salary": ["payroll"], "paye": ["payroll"], "nssf": ["payroll"],
	"claim": ["expense claim"], "refund": ["expense claim"], "commission": ["commission"], "scrap": ["waste"],
	"yield": ["waste", "formula"], "loss": ["waste"], "whatsapp": ["quick order"], "brave home": ["quick order"],
	"discount": ["price list", "quotation"], "price": ["price list"], "credit": ["credit limit"],
	"boiler": ["field laboratory", "water"], "cooling tower": ["field laboratory", "water"], "offline": ["field screen"],
	"tender": ["tender"], "bid": ["tender"], "training": ["learning"], "course": ["learning"],
	"diagnostic": ["business diagnostics"], "cash": ["cash flow forecast"], "forecast": ["cash flow forecast"],
	"delegate": ["delegation"], "away": ["delegation"], "phone": ["phone pages", "mobile"], "mobile": ["phone pages"],
	"spill": ["incident"], "accident": ["incident"], "fire": ["emergency drill"], "calibrate": ["calibration"],
	"import": ["imports"], "container": ["returnable containers"], "drum": ["returnable containers"],
	"complaint": ["complaints"], "return": ["returns"], "batch": ["releasing a batch"], "release": ["releasing a batch"],
}


def _norm(s):
	return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9%\- ]+", " ", (s or "").lower())).strip()


def _stem(w):
	for suf in ("ing", "ies", "es", "s", "ed"):
		if len(w) > 4 and w.endswith(suf):
			return w[: -len(suf)] + ("y" if suf == "ies" else "")
	return w


def terms_for(query):
	"""The query as phrases and words, with synonyms. Returns (terms, weights)."""
	q = _norm(query)
	if not q:
		return []
	terms = []
	words = [w for w in q.split() if w not in STOP]
	for w in words:
		terms.append((w, 1.0))
	if len(words) > 1:
		terms.append((" ".join(words), 2.0))  # the whole phrase
	for key, alts in SYNONYMS.items():
		if re.search(r"\b" + re.escape(key) + r"\b", q):
			terms.extend((a, 0.7) for a in alts)
	return terms


def score_topic(t, terms):
	title, section = _norm(t["topic_title"]), _norm(t.get("section"))
	keywords, body = _norm(t.get("keywords")), _norm(t.get("body"))
	total, matched = 0.0, set()
	for term, weight in terms:
		stem = _stem(term) if " " not in term else term
		pat = re.compile(r"\b" + re.escape(stem))
		hit = 0.0
		if pat.search(title):
			hit += 10
		if pat.search(keywords):
			hit += 6
		if pat.search(section):
			hit += 3
		n = len(pat.findall(body))
		if n:
			hit += min(n, 6) * 1.2
		if hit:
			matched.add(term)
		total += hit * weight
	words = [t for t, w in terms if w == 1.0]
	if words and all(w in matched for w in words):
		total *= 1.5  # every word the person typed is in this topic
	return total


def snippet(body, terms, width=220):
	plain = re.sub(r"^\s*\|?[\s:|-]+\|[\s:|-]*$", " ", body or "", flags=re.M)  # table rule lines
	plain = re.sub(r"[*_`#|>]+", " ", plain)
	plain = re.sub(r"\s+", " ", plain).strip()
	low = plain.lower()
	pos = -1
	for term, _w in sorted(terms, key=lambda x: -len(x[0])):
		pos = low.find(_stem(term) if " " not in term else term)
		if pos >= 0:
			break
	start = max(0, pos - 60) if pos >= 0 else 0
	if start:
		sp = plain.find(" ", start)
		start = sp + 1 if 0 <= sp < (pos if pos > start else start + 20) else start  # begin on a whole word
	text = plain[start : start + width]
	return ("… " if start else "") + text + (" …" if start + width < len(plain) else "")


def _topics():
	return frappe.get_all("Help Topic", filters={"published": 1},
		fields=["name", "topic_title", "section", "body", "keywords", "related_doctypes", "sort_order"], order_by="sort_order asc")


@frappe.whitelist()
def search(query=None, doctype=None, limit=12):
	"""Topics for the keyword(s), best first; with no keywords, the topics for the page the person is on."""
	limit = min(int(limit or 12), 40)
	topics = _topics()
	terms = terms_for(query or "")
	if not terms:
		return {"query": "", "results": [_out(t, []) for t in for_doctype(topics, doctype)][:limit], "context": True}
	scored = [(score_topic(t, terms), t) for t in topics]
	scored = [(s + (4 if doctype and doctype in _list(t.get("related_doctypes")) else 0), t) for s, t in scored if s > 0]
	scored.sort(key=lambda x: (-x[0], x[1]["sort_order"] or 0))
	words = sorted({w for term, _ in terms for w in term.split() if len(w) > 1}, key=len, reverse=True)
	return {"query": query, "results": [dict(_out(t, terms), score=round(s, 1)) for s, t in scored[:limit]],
		"highlight": words, "context": False}


def _list(s):
	return [x.strip() for x in (s or "").split(",") if x.strip()]


def for_doctype(topics, doctype):
	if not doctype:
		return [t for t in topics if (t.get("section") or "") == "Getting started"]
	return [t for t in topics if doctype in _list(t.get("related_doctypes"))]


def _out(t, terms):
	return {"name": t["name"], "title": t["topic_title"], "section": t.get("section"), "snippet": snippet(t.get("body"), terms)}


@frappe.whitelist()
def topic(name):
	t = frappe.get_doc("Help Topic", name)
	t.check_permission("read")
	frappe.db.set_value("Help Topic", name, "views", (t.views or 0) + 1, update_modified=False)
	return {"name": t.name, "title": t.topic_title, "section": t.section, "body": t.body,
		"related_doctypes": _list(t.related_doctypes), "can_edit": frappe.has_permission("Help Topic", "write")}


@frappe.whitelist()
def contents():
	"""The whole manual as a table of contents, section by section."""
	out = {}
	for t in _topics():
		out.setdefault(t.get("section") or "Other", []).append({"name": t["name"], "title": t["topic_title"]})
	return [{"section": s, "topics": ts} for s, ts in out.items()]


@frappe.whitelist()
def not_found(query, doctype=None):
	"""Nothing matched: tell the System Manager, so the manual can grow where people get stuck."""
	query = (query or "").strip()[:140]
	if not query:
		return
	key = (query.lower() + (f" [{doctype}]" if doctype else ""))[:180]
	frappe.cache().hset(MISSED, key, (frappe.cache().hget(MISSED, key) or 0) + 1)


MISSED = "chem_help_missing"


@frappe.whitelist()
def missed_searches():
	"""What people searched for and found nothing: the topics worth writing next."""
	if not (frappe.has_permission("Help Topic", "write")):
		frappe.throw("Only the MD or a System Manager can see this.", frappe.PermissionError)
	rows = [{"search": k if isinstance(k, str) else k.decode(), "times": v} for k, v in (frappe.cache().hgetall(MISSED) or {}).items()]
	return sorted(rows, key=lambda r: -r["times"])[:100]


@frappe.whitelist()
def clear_missed():
	if frappe.has_permission("Help Topic", "write"):
		frappe.cache().delete_value(MISSED)


def ensure_topics():
	"""Load the manual: new topics are added, unedited ones refreshed, topics edited here left as they are."""
	if not frappe.db.exists("DocType", "Help Topic"):
		return
	with open(SOURCE) as f:
		topics = json.load(f)
	existing = {r.topic_key: r for r in frappe.get_all("Help Topic", filters={"source": "Manual"},
		fields=["name", "topic_key", "edited_here", "body", "topic_title", "section", "sort_order", "related_doctypes"])
		if r.get("topic_key")}
	frappe.flags.in_help_seed = True
	try:
		for t in topics:
			row = existing.get(t["name"])
			values = {"topic_title": t["title"], "section": t["section"], "body": t["body"],
				"sort_order": t["sort_order"], "related_doctypes": t.get("related_doctypes")}
			if not row:
				frappe.get_doc(dict(values, doctype="Help Topic", topic_key=t["name"], source="Manual",
					published=1)).insert(ignore_permissions=True)
			elif not row.edited_here and any((row.get(k) or "") != (v or "") for k, v in values.items()):
				frappe.db.set_value("Help Topic", row.name, values, update_modified=False)
	finally:
		frappe.flags.in_help_seed = False
