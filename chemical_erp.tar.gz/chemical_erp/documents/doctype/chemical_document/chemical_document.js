// Form script for Chemical Document
frappe.ui.form.on("Chemical Document", {
	refresh: function(frm) {
		if (!frm.is_new()) {
			// 1. Download Attached File button
			if (frm.doc.attached_document) {
				frm.add_custom_button(__("Download File"), function() {
					window.open(frm.doc.attached_document, "_blank");
				}, __("Document Actions")).addClass("btn-secondary");

				// 2. Interactive Preview button
				frm.add_custom_button(__("Preview Document"), function() {
					show_document_preview_modal(frm);
				}, __("Document Actions"));
			}

			// 3. Share Document button
			frm.add_custom_button(__("Share Document"), function() {
				show_share_dialog(frm);
			}).addClass("btn-primary");
		}
	}
});

function show_document_preview_modal(frm) {
	const url = frm.doc.attached_document;
	const ft = (frm.doc.file_type || "").toUpperCase();
	let contentHtml = "";

	if (ft.includes("PDF")) {
		contentHtml = `<iframe src="${url}#toolbar=1" style="width: 100%; height: 75vh; border: none; border-radius: 6px;"></iframe>`;
	} else if (ft.includes("PNG") || ft.includes("JPG") || ft.includes("JPEG") || ft.includes("WEBP") || ft.includes("SVG")) {
		contentHtml = `<div style="text-align: center; max-height: 75vh; overflow-y: auto; padding: 20px;">
			<img src="${url}" style="max-width: 100%; max-height: 70vh; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.15);" />
		</div>`;
	} else {
		contentHtml = `<div style="text-align: center; padding: 40px;">
			<div style="font-size: 50px; margin-bottom: 15px;">📁</div>
			<h3>${frappe.utils.escape_html(frm.doc.document_name)}</h3>
			<p class="text-muted">Type: ${frm.doc.file_type || 'File'} | Size: ${frm.doc.file_size || 'N/A'}</p>
			<a href="${url}" download class="btn btn-primary" style="margin-top: 15px;">Download File to View</a>
		</div>`;
	}

	const d = new frappe.ui.Dialog({
		title: __("Document Preview: {0}", [frm.doc.document_name]),
		size: "large"
	});
	d.$body.html(contentHtml);
	d.set_secondary_action_label(__("Download"));
	d.set_secondary_action(() => {
		window.open(url, "_blank");
	});
	d.show();
}

function show_share_dialog(frm) {
	if (!frm.doc.attached_document) {
		frappe.msgprint({
			title: __("No File Attached"),
			indicator: "orange",
			message: __("Please upload a document file before creating a share link.")
		});
		return;
	}

	// Fetch sharing settings to know limits
	frappe.db.get_single_value("Document Sharing Settings", "default_expiry_hours").then(defaultHours => {
		frappe.db.get_single_value("Document Sharing Settings", "max_allowed_expiry_hours").then(maxHours => {
			const defH = defaultHours || 24;
			const maxH = maxHours || 168;

			const d = new frappe.ui.Dialog({
				title: __("Share Document: {0}", [frm.doc.document_name]),
				fields: [
					{
						fieldname: "intro_html",
						fieldtype: "HTML",
						options: `<div style="margin-bottom: 15px; padding: 10px 12px; background: #f0fdf4; border-left: 4px solid #16a34a; border-radius: 4px; font-size: 13px; color: #166534;">
							<b>Secure Document Sharing</b>: Links automatically expire once the configured duration elapses. SuperAdmin maximum limit is <b>${maxH} hours</b> (${Math.round(maxH/24)} days).
						</div>`
					},
					{
						fieldname: "channel",
						fieldtype: "Select",
						label: __("Share Channel"),
						options: ["WhatsApp", "Email", "Direct Link"],
						default: "WhatsApp",
						reqd: 1
					},
					{
						fieldname: "recipient_name",
						fieldtype: "Data",
						label: __("Recipient Name / Company"),
						placeholder: __("e.g. John Mukasa / Crown Beverages")
					},
					{
						fieldname: "recipient_contact",
						fieldtype: "Data",
						label: __("Phone Number (for WhatsApp) or Email"),
						placeholder: __("e.g. 256700000000 or client@example.com")
					},
					{
						fieldtype: "Section Break",
						label: __("Access Duration & Expiration")
					},
					{
						fieldname: "duration_preset",
						fieldtype: "Select",
						label: __("Access Duration"),
						options: [
							{label: __("1 Hour"), value: "1"},
							{label: __("6 Hours"), value: "6"},
							{label: __("12 Hours"), value: "12"},
							{label: __("24 Hours (1 Day)"), value: "24"},
							{label: __("48 Hours (2 Days)"), value: "48"},
							{label: __("72 Hours (3 Days)"), value: "72"},
							{label: __("7 Days (1 Week)"), value: "168"},
							{label: __("Custom Duration (in Hours)"), value: "custom"}
						],
						default: String(defH)
					},
					{
						fieldname: "custom_duration",
						fieldtype: "Int",
						label: __("Custom Duration (Hours)"),
						depends_on: "eval:doc.duration_preset == 'custom'",
						default: defH
					},
					{
						fieldtype: "Section Break",
						label: __("Security Restrictions")
					},
					{
						fieldname: "allow_download",
						fieldtype: "Check",
						label: __("Allow File Download (Uncheck for View-Only)"),
						default: 1
					},
					{
						fieldname: "require_passcode",
						fieldtype: "Check",
						label: __("Protect with Passcode / PIN"),
						default: frm.doc.confidentiality === "Confidential" || frm.doc.confidentiality === "Restricted (SuperAdmin Only)" ? 1 : 0
					},
					{
						fieldname: "passcode",
						fieldtype: "Data",
						label: __("Enter 4-6 Digit Passcode / PIN"),
						depends_on: "require_passcode",
						placeholder: __("e.g. 8492")
					},
					{
						fieldname: "max_downloads",
						fieldtype: "Int",
						label: __("Max Download Count Limit (0 = Unlimited)"),
						default: 0
					}
				],
				primary_action_label: __("Generate & Share"),
				primary_action: function(values) {
					let finalHours = values.duration_preset === "custom" ? values.custom_duration : parseFloat(values.duration_preset);
					if (!finalHours || finalHours <= 0) {
						finalHours = defH;
					}

					frappe.call({
						method: "chemical_erp.documents.sharing.create_share_link",
						args: {
							document: frm.doc.name,
							recipient_name: values.recipient_name,
							recipient_contact: values.recipient_contact,
							share_channel: values.channel,
							duration_hours: finalHours,
							allow_download: values.allow_download,
							require_passcode: values.require_passcode,
							passcode: values.passcode,
							max_downloads: values.max_downloads
						},
						freeze: true,
						freeze_message: __("Creating secure time-limited share link..."),
						callback: function(r) {
							if (r.message) {
								d.hide();
								show_share_result_dialog(r.message, values.channel);
								frm.reload_doc();
							}
						}
					});
				}
			});

			d.show();
		});
	});
}

function show_share_result_dialog(res, channel) {
	const shareUrl = res.share_url;
	const expiry = res.expires_at;

	let actionButtonsHtml = `
		<div style="display: flex; gap: 10px; flex-wrap: wrap; margin-top: 20px;">
			<button class="btn btn-default btn-copy-link" style="flex: 1; min-width: 140px;">
				📋 Copy Link
			</button>
	`;

	if (channel === "WhatsApp" || res.whatsapp_url) {
		actionButtonsHtml += `
			<a href="${res.whatsapp_url}" target="_blank" class="btn btn-success" style="flex: 1; min-width: 140px; background: #25D366; border-color: #25D366; color: #fff; text-decoration: none; text-align: center; padding: 6px 12px; border-radius: 4px; font-weight: 500;">
				💬 Open in WhatsApp
			</a>
		`;
	}

	if (channel === "Email" || res.mailto_url) {
		actionButtonsHtml += `
			<a href="${res.mailto_url}" class="btn btn-info" style="flex: 1; min-width: 140px; text-decoration: none; text-align: center; padding: 6px 12px; border-radius: 4px; font-weight: 500;">
				✉️ Send via Email
			</a>
		`;
	}

	actionButtonsHtml += `
			<a href="${shareUrl}" target="_blank" class="btn btn-primary" style="flex: 1; min-width: 140px; text-decoration: none; text-align: center; padding: 6px 12px; border-radius: 4px; font-weight: 500;">
				👁️ Open Preview
			</a>
		</div>
	`;

	const resultDialog = new frappe.ui.Dialog({
		title: __("Document Shared Successfully!"),
		fields: [
			{
				fieldname: "result_html",
				fieldtype: "HTML",
				options: `
					<div style="padding: 10px 0;">
						<div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 15px;">
							<div style="font-size: 12px; color: #64748b; font-weight: 600; text-transform: uppercase; margin-bottom: 5px;">Secure Share URL:</div>
							<div style="word-break: break-all; font-family: monospace; font-size: 14px; background: #fff; padding: 10px; border: 1px solid #cbd5e1; border-radius: 4px; color: #1e293b;">
								${shareUrl}
							</div>
							<div style="margin-top: 10px; font-size: 13px; color: #b45309; display: flex; align-items: center; gap: 6px;">
								<span>⏰</span> <b>Access Expires:</b> ${expiry} (${res.duration_hours} hours). Access will automatically terminate.
							</div>
						</div>
						${actionButtonsHtml}
					</div>
				`
			}
		]
	});

	resultDialog.show();

	resultDialog.$body.find(".btn-copy-link").on("click", function() {
		navigator.clipboard.writeText(shareUrl).then(() => {
			frappe.show_alert({message: __("Share link copied to clipboard!"), indicator: "green"});
		});
	});
}
