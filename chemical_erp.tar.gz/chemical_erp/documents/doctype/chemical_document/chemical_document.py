# Chemical Document controller
import os
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import cint, flt, format_datetime, now_datetime


class ChemicalDocument(Document):
	def validate(self):
		if not self.uploaded_by:
			self.uploaded_by = frappe.session.user
		if not self.upload_date:
			self.upload_date = now_datetime()
		if not self.document_code and self.name:
			self.document_code = self.name

		self._detect_file_attributes()
		self._build_preview_html()
		self.sync_shared_links()

	def _detect_file_attributes(self):
		if not self.attached_document:
			return
		url = self.attached_document.strip()
		ext = os.path.splitext(url)[1].lower()
		ext_map = {
			".pdf": "PDF",
			".png": "PNG Image",
			".jpg": "JPEG Image",
			".jpeg": "JPEG Image",
			".webp": "WEBP Image",
			".svg": "SVG Vector",
			".doc": "Word (DOC)",
			".docx": "Word (DOCX)",
			".xls": "Excel (XLS)",
			".xlsx": "Excel (XLSX)",
			".csv": "CSV Spreadsheet",
			".txt": "Plain Text",
			".zip": "ZIP Archive",
		}
		self.file_type = ext_map.get(ext, ext.replace(".", "").upper() or "Unknown")

		# Get file size from File doctype if available
		file_size = frappe.db.get_value("File", {"file_url": url}, "file_size")
		if file_size:
			size = flt(file_size)
			if size >= 1048576:
				self.file_size = f"{size / 1048576:.2f} MB"
			elif size >= 1024:
				self.file_size = f"{size / 1024:.1f} KB"
			else:
				self.file_size = f"{int(size)} Bytes"
		elif not self.file_size:
			self.file_size = "Attached"

	def _build_preview_html(self):
		if not self.attached_document:
			self.preview_html = "<div class='text-muted p-3 text-center'><i>No document file attached yet. Upload a file above.</i></div>"
			return

		url = self.attached_document
		ft = (self.file_type or "").upper()

		if "PDF" in ft:
			self.preview_html = f"""
			<div style="border: 1px solid #dcdfe6; border-radius: 8px; overflow: hidden; background: #fff; box-shadow: 0 2px 6px rgba(0,0,0,0.05);">
				<div style="padding: 10px 15px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
					<span style="font-weight: 600; color: #1f3864;">📄 {frappe.utils.escape_html(self.document_name)} (PDF Preview)</span>
					<a href="{url}" target="_blank" class="btn btn-xs btn-primary" style="text-decoration: none;">Open Fullscreen</a>
				</div>
				<iframe src="{url}#toolbar=1" width="100%" height="520px" style="border: none;"></iframe>
			</div>
			"""
		elif any(img in ft for img in ("PNG", "JPEG", "JPG", "WEBP", "SVG")):
			self.preview_html = f"""
			<div style="border: 1px solid #dcdfe6; border-radius: 8px; overflow: hidden; background: #fff; padding: 15px; text-align: center;">
				<img src="{url}" style="max-width: 100%; max-height: 500px; border-radius: 6px; box-shadow: 0 3px 10px rgba(0,0,0,0.1);" alt="Preview"/>
				<div style="margin-top: 10px;"><a href="{url}" target="_blank" class="btn btn-xs btn-default">View Original Image</a></div>
			</div>
			"""
		else:
			self.preview_html = f"""
			<div style="border: 1px solid #e2e8f0; border-radius: 8px; background: #f8fafc; padding: 25px; text-align: center;">
				<div style="font-size: 40px; margin-bottom: 10px;">📁</div>
				<h4 style="margin: 0 0 5px; color: #1f3864;">{frappe.utils.escape_html(self.document_name)}</h4>
				<p style="color: #64748b; margin-bottom: 15px;">Format: <b>{self.file_type or 'File'}</b> | Size: <b>{self.file_size or 'N/A'}</b></p>
				<a href="{url}" download class="btn btn-sm btn-primary">Download Attached File</a>
			</div>
			"""

	def sync_shared_links(self):
		if not self.name:
			return
		# Query share links
		shares = frappe.get_all(
			"Document Share Link",
			filters={"document": self.name},
			fields=["name", "recipient_name", "recipient_contact", "share_channel", "expires_at", "status", "view_count", "download_count", "share_url", "is_revoked"],
			order_by="creation desc"
		)

		self.shared_links = []
		active_cnt = 0
		views_cnt = 0
		downloads_cnt = 0

		now = now_datetime()
		for s in shares:
			status = s.status
			if s.is_revoked:
				status = "Revoked"
			elif s.expires_at and now > s.expires_at:
				status = "Expired"

			if status == "Active":
				active_cnt += 1

			views_cnt += (s.view_count or 0)
			downloads_cnt += (s.download_count or 0)

			self.append("shared_links", {
				"link_name": s.name,
				"recipient": f"{s.recipient_name or 'Public'} ({s.recipient_contact or 'N/A'})",
				"channel": s.share_channel,
				"expires_at": s.expires_at,
				"status": status,
				"views": s.view_count or 0,
				"downloads": s.download_count or 0,
				"share_url": s.share_url
			})

		self.active_shares = active_cnt
		self.total_views = views_cnt
		self.total_downloads = downloads_cnt
