frappe.ui.form.on("Document Sharing Settings", {
	refresh: function(frm) {
		frm.set_intro(__("Configure global document sharing restrictions, maximum duration limits, and allowed channels. Only SuperAdmin / System Managers can modify these settings."));
	}
});
