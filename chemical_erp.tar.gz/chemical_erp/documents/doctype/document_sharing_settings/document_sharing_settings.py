# Document Sharing Settings controller
import frappe
from frappe import _
from frappe.model.document import Document


class DocumentSharingSettings(Document):
	def validate(self):
		if self.max_allowed_expiry_hours and self.default_expiry_hours:
			if self.default_expiry_hours > self.max_allowed_expiry_hours:
				frappe.throw(_("Default duration ({0} hrs) cannot exceed Maximum permitted duration ({1} hrs).").format(
					self.default_expiry_hours, self.max_allowed_expiry_hours
				))
		if (self.default_expiry_hours or 0) <= 0:
			self.default_expiry_hours = 24
		if (self.max_allowed_expiry_hours or 0) <= 0:
			self.max_allowed_expiry_hours = 168
