frappe.ui.form.on("Document Access Log", {
	refresh: function(frm) {
		// Read only audit view
	}
});
