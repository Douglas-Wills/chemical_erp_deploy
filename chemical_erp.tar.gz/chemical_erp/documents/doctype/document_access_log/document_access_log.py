# Document Access Log controller
from frappe.model.document import Document


class DocumentAccessLog(Document):
	pass
