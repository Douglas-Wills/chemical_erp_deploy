# Document Share Link Item child document
from frappe.model.document import Document


class DocumentShareLinkItem(Document):
	pass
