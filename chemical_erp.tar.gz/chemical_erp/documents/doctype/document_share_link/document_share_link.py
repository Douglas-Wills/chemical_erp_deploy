# Document Share Link controller
import secrets
import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_to_date, flt, get_url, now_datetime


class DocumentShareLink(Document):
	def validate(self):
		if not self.token:
			self.token = secrets.token_urlsafe(24)
		if not self.creation_date:
			self.creation_date = now_datetime()
		if not self.created_by:
			self.created_by = frappe.session.user

		# Duration & Expiry calculation
		settings = frappe.get_single("Document Sharing Settings")
		if not self.expires_at:
			duration = flt(self.duration_hours) or flt(settings.default_expiry_hours) or 24
			self.duration_hours = duration
			self.expires_at = add_to_date(now_datetime(), hours=duration)

		# State evaluation
		if self.is_revoked:
			self.status = "Revoked"
			if not self.revoked_by:
				self.revoked_by = frappe.session.user
			if not self.revoked_at:
				self.revoked_at = now_datetime()
		elif self.expires_at and now_datetime() > self.expires_at:
			self.status = "Expired"
		else:
			self.status = "Active"

		# Computed share URL
		self.share_url = get_url(f"/shared-doc/{self.token}")

	def on_update(self):
		# Refresh parent document child table
		if self.document:
			try:
				doc = frappe.get_doc("Chemical Document", self.document)
				doc.sync_shared_links()
			except Exception:
				pass
