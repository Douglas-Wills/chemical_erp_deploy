frappe.ui.form.on("Document Share Link", {
	refresh: function(frm) {
		if (frm.doc.share_url) {
			frm.add_custom_button(__("Copy Share Link"), function() {
				navigator.clipboard.writeText(frm.doc.share_url).then(() => {
					frappe.show_alert({message: __("Share link copied to clipboard!"), indicator: "green"});
				});
			}, __("Actions"));

			frm.add_custom_button(__("Open Shared Page"), function() {
				window.open(frm.doc.share_url, "_blank");
			}, __("Actions"));
		}

		if (frm.doc.status === "Active" && !frm.doc.is_revoked) {
			frm.add_custom_button(__("Revoke Access Now"), function() {
				frappe.prompt([
					{fieldname: "reason", fieldtype: "Small Text", label: __("Revocation Reason"), reqd: 1}
				], function(values) {
					frm.set_value("is_revoked", 1);
					frm.set_value("revocation_reason", values.reason);
					frm.save();
				}, __("Revoke Access"), __("Revoke"));
			}).addClass("btn-danger");
		}
	}
});
