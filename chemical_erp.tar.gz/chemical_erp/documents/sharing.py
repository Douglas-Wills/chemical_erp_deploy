# Document Sharing Backend API
import os
import secrets
import urllib.parse
import frappe
from frappe import _
from frappe.utils import add_to_date, cint, flt, format_datetime, get_url, now_datetime


def get_client_ip():
	return frappe.local.request_ip if hasattr(frappe.local, "request_ip") else (
		frappe.request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
		if hasattr(frappe, "request") and frappe.request
		else "127.0.0.1"
	)


def get_client_user_agent():
	if hasattr(frappe, "request") and frappe.request:
		return str(frappe.request.headers.get("User-Agent", ""))[:250]
	return "Unknown"


@frappe.whitelist()
def create_share_link(
	document,
	recipient_name=None,
	recipient_contact=None,
	share_channel="Direct Link",
	duration_hours=24,
	allow_download=1,
	require_passcode=0,
	passcode=None,
	max_downloads=0
):
	"""Generates a secure, time-limited document share link enforced by SuperAdmin rules."""
	settings = frappe.get_single("Document Sharing Settings")
	if not settings.enable_document_sharing:
		frappe.throw(_("Document sharing is currently disabled by Super Admin."), title=_("Sharing Disabled"))

	# Check admin-only sharing restriction
	user_roles = frappe.get_roles()
	is_admin = bool({"Administrator", "System Manager", "Managing Director"} & set(user_roles))
	if settings.only_admin_can_share and not is_admin:
		frappe.throw(_("Document sharing is restricted to Super Admin and System Managers only."), title=_("Permission Denied"))

	# Check requested duration against SuperAdmin max allowed duration
	duration = flt(duration_hours) or flt(settings.default_expiry_hours) or 24
	max_allowed = flt(settings.max_allowed_expiry_hours) or 168

	if duration > max_allowed:
		if not (is_admin and settings.allow_super_admin_override):
			frappe.throw(
				_("Access duration of {0} hours exceeds the SuperAdmin limit of {1} hours (approx {2:.1f} days).").format(
					duration, max_allowed, max_allowed / 24.0
				),
				title=_("Duration Limit Exceeded")
			)

	doc = frappe.get_doc("Chemical Document", document)
	if not doc.attached_document:
		frappe.throw(_("Cannot share a document without an uploaded file attachment."))

	# Passcode enforcement on confidential files
	if doc.confidentiality in ("Confidential", "Restricted (SuperAdmin Only)") and settings.enforce_passcode_on_confidential:
		if not passcode:
			frappe.throw(_("A Passcode / PIN is mandatory for Confidential and Restricted documents per security policy."))
		require_passcode = 1

	token = secrets.token_urlsafe(24)
	expires_at = add_to_date(now_datetime(), hours=duration)
	share_url = get_url(f"/shared-doc/{token}")

	share = frappe.get_doc({
		"doctype": "Document Share Link",
		"token": token,
		"document": doc.name,
		"document_title": doc.document_name,
		"recipient_name": (recipient_name or "").strip(),
		"recipient_contact": (recipient_contact or "").strip(),
		"share_channel": share_channel,
		"duration_hours": duration,
		"expires_at": expires_at,
		"allow_download": 1 if cint(allow_download) else 0,
		"require_passcode": 1 if cint(require_passcode) else 0,
		"passcode": (passcode or "").strip() if cint(require_passcode) else "",
		"max_downloads": cint(max_downloads),
		"status": "Active",
		"share_url": share_url,
		"created_by": frappe.session.user,
		"creation_date": now_datetime()
	})
	share.insert(ignore_permissions=True)

	# Format WhatsApp & Email messages
	formatted_expiry = format_datetime(expires_at, "dd-MM-yyyy HH:mm")
	wa_text = (settings.whatsapp_template or "Document: {document_name}\nLink: {share_url}\nExpires: {expires_at}").format(
		recipient=recipient_name or "Colleague",
		document_name=doc.document_name,
		share_url=share_url,
		expires_at=formatted_expiry
	)
	phone_clean = "".join(filter(str.isdigit, recipient_contact or ""))
	wa_url = f"https://api.whatsapp.com/send?text={urllib.parse.quote(wa_text)}"
	if phone_clean:
		wa_url = f"https://api.whatsapp.com/send?phone={phone_clean}&text={urllib.parse.quote(wa_text)}"

	email_subj = (settings.email_subject or "Secure Document Shared: {document_name}").format(
		document_name=doc.document_name
	)
	email_body_text = (settings.email_body or "Document: {document_name}\nLink: {share_url}\nExpires: {expires_at}").format(
		recipient=recipient_name or "Sir/Madam",
		document_name=doc.document_name,
		share_url=share_url,
		expires_at=formatted_expiry
	)
	mailto_url = f"mailto:{(recipient_contact or '')}?subject={urllib.parse.quote(email_subj)}&body={urllib.parse.quote(email_body_text)}"

	# Update parent doc child table
	doc.sync_shared_links()
	doc.db_update()

	return {
		"share_name": share.name,
		"token": token,
		"share_url": share_url,
		"expires_at": formatted_expiry,
		"duration_hours": duration,
		"whatsapp_url": wa_url,
		"mailto_url": mailto_url,
		"message": _("Secure document link successfully created.")
	}


@frappe.whitelist()
def revoke_share_link(link_name, reason="Revoked by Administrator"):
	"""Instantly terminates access for a shared link."""
	if not frappe.db.exists("Document Share Link", link_name):
		frappe.throw(_("Share link record not found."))

	link = frappe.get_doc("Document Share Link", link_name)
	link.is_revoked = 1
	link.status = "Revoked"
	link.revoked_by = frappe.session.user
	link.revoked_at = now_datetime()
	link.revocation_reason = reason or "Access revoked by admin"
	link.save(ignore_permissions=True)

	# Log revocation
	_log_access(link, "Blocked Revoked", "Blocked", f"Revoked by {frappe.session.user}: {reason}")

	if link.document:
		try:
			doc = frappe.get_doc("Chemical Document", link.document)
			doc.sync_shared_links()
			doc.db_update()
		except Exception:
			pass

	return {"success": True, "message": _("Access has been permanently revoked.")}


@frappe.whitelist(allow_guest=True)
def download_shared_document(token, passcode=None):
	"""Secure, validated download of the attached document file with expiration and restriction enforcement."""
	link = frappe.db.get_value(
		"Document Share Link",
		{"token": token},
		["name", "document", "document_title", "recipient_name", "expires_at", "status", "allow_download", "require_passcode", "passcode", "max_downloads", "download_count", "is_revoked"],
		as_dict=True
	)
	if not link:
		frappe.throw(_("Invalid or unrecognized document access token."), frappe.PermissionError)

	now = now_datetime()

	# 1. Revocation check
	if link.is_revoked:
		_log_access_dict(link, "Blocked Revoked", "Blocked", "Attempted download on revoked link")
		frappe.throw(_("Access Denied: This shared link has been revoked by the administrator."), frappe.PermissionError)

	# 2. Expiration check
	if link.expires_at and now > link.expires_at:
		frappe.db.set_value("Document Share Link", link.name, "status", "Expired")
		_log_access_dict(link, "Blocked Expired", "Blocked", "Attempted download on expired link")
		frappe.throw(_("Access Expired: The time duration set for this document has expired. You no longer have access."), frappe.PermissionError)

	# 3. Allow download setting check
	if not link.allow_download:
		_log_access_dict(link, "Blocked Limit Reached", "Blocked", "Download blocked - View only link")
		frappe.throw(_("Downloading is disabled for this shared link. View-only access."), frappe.PermissionError)

	# 4. Max downloads limit check
	if link.max_downloads and link.download_count >= link.max_downloads:
		_log_access_dict(link, "Blocked Limit Reached", "Blocked", f"Maximum download limit of {link.max_downloads} reached")
		frappe.throw(_("Download limit exceeded: This document has reached its maximum allowed downloads ({0}).").format(link.max_downloads), frappe.PermissionError)

	# 5. Passcode check
	if link.require_passcode and link.passcode:
		if not passcode or passcode.strip() != link.passcode.strip():
			_log_access_dict(link, "Passcode Failed", "Blocked", "Incorrect passcode on download attempt")
			frappe.throw(_("Incorrect Passcode / PIN. Please enter the valid passcode."), frappe.PermissionError)

	# 6. Fetch file URL
	doc = frappe.get_doc("Chemical Document", link.document)
	if not doc.attached_document:
		frappe.throw(_("No file attached to this document record."))

	file_url = doc.attached_document

	# Increment download count and update timestamp
	frappe.db.sql(
		"update `tabDocument Share Link` set download_count = download_count + 1, last_accessed_at = %s where name = %s",
		(now, link.name)
	)
	frappe.db.commit()

	_log_access_dict(link, "Download", "Allowed", "File downloaded successfully")

	# Redirect to or stream file
	frappe.local.response["type"] = "redirect"
	frappe.local.response["location"] = file_url


def _log_access_dict(link_dict, action, status, details=""):
	try:
		log = frappe.get_doc({
			"doctype": "Document Access Log",
			"share_link": link_dict.get("name"),
			"document": link_dict.get("document"),
			"document_name": link_dict.get("document_title"),
			"recipient_name": link_dict.get("recipient_name"),
			"action": action,
			"status": status,
			"access_time": now_datetime(),
			"ip_address": get_client_ip(),
			"user_agent": get_client_user_agent(),
			"details": details
		})
		log.insert(ignore_permissions=True)
		frappe.db.commit()
	except Exception:
		pass


def _log_access(link_doc, action, status, details=""):
	try:
		log = frappe.get_doc({
			"doctype": "Document Access Log",
			"share_link": link_doc.name,
			"document": link_doc.document,
			"document_name": link_doc.document_title,
			"recipient_name": link_doc.recipient_name,
			"action": action,
			"status": status,
			"access_time": now_datetime(),
			"ip_address": get_client_ip(),
			"user_agent": get_client_user_agent(),
			"details": details
		})
		log.insert(ignore_permissions=True)
		frappe.db.commit()
	except Exception:
		pass
