# Document background scheduled tasks
import frappe
from frappe.utils import now_datetime


def expire_shared_links():
	"""Runs hourly to check for expired share links and mark their status."""
	now = now_datetime()
	expired_links = frappe.get_all(
		"Document Share Link",
		filters={"status": "Active", "is_revoked": 0, "expires_at": ["<", now]},
		fields=["name", "document"]
	)

	for link in expired_links:
		frappe.db.set_value("Document Share Link", link.name, "status", "Expired")
		try:
			doc = frappe.get_doc("Chemical Document", link.document)
			doc.sync_shared_links()
			doc.db_update()
		except Exception:
			pass

	if expired_links:
		frappe.db.commit()
