"""Chemical stock at customers' sites and our equipment there (Field Laboratory > Clients and Equipment).

- On each visit the technician reads the customer's tank levels (Water Sample > Tank Levels Read).
- Use per day = (previous level + delivered since + topped up today − level now) ÷ days since the last reading,
  smoothed with the previous figure; days left = level ÷ use per day.
- Daily: a tank at or below its reorder level, or with fewer days left than the lead time (Settings), gets a draft
  Sales Order for the customer (once until it is delivered), and Sales is told.
- Monthly: customers on a service contract get a draft invoice for the monthly fee.
"""

import frappe
from frappe import _
from frappe.utils import add_days, cint, date_diff, flt, getdate, today

from chemical_erp.utils import get_settings, notify, users_with_role


def delivered_between(customer, item_code, since, until):
	return flt(frappe.db.sql("""select sum(dni.stock_qty) from `tabDelivery Note Item` dni join `tabDelivery Note` dn on dn.name = dni.parent
		where dn.docstatus=1 and dn.is_return=0 and dn.customer=%s and dni.item_code=%s and dn.posting_date > %s and dn.posting_date <= %s""",
	                         (customer, item_code, since, until))[0][0])


def apply_readings(doc, method=None):
	"""Water Sample saved: carry tank readings to the equipment's site tanks."""
	when = getdate(doc.sampled_on)
	for r in doc.get("tank_readings") or []:
		system = frappe.get_doc("Client Water System", r.water_system)
		tank = next((t for t in system.site_tanks if t.item_code == r.item_code), None)
		if not tank:
			tank = system.append("site_tanks", {"item_code": r.item_code})
		if tank.level_read_on and getdate(tank.level_read_on) == when and flt(tank.current_level) == flt(r.level):
			continue  # already applied
		if tank.level_read_on and getdate(tank.level_read_on) < when:
			days = date_diff(when, tank.level_read_on)
			used = flt(tank.current_level) + delivered_between(system.customer, r.item_code, tank.level_read_on, when) + flt(r.delivered_today) - flt(r.level)
			rate = max(used, 0) / days if days else 0
			tank.daily_use = round(rate if not flt(tank.daily_use) else 0.5 * rate + 0.5 * flt(tank.daily_use), 3)
		tank.current_level, tank.level_read_on = flt(r.level), when
		tank.days_left = int(flt(tank.current_level) / flt(tank.daily_use)) if flt(tank.daily_use) else 0
		system.flags.ignore_permissions = True
		system.save()


def tanks_due():
	lead = cint(get_settings().get("vmi_lead_days")) or 7
	out = []
	for t in frappe.get_all("Site Chemical Tank", fields=["name", "parent", "item_code", "capacity", "reorder_level", "current_level", "days_left",
	                                                      "daily_use", "reorder_sales_order", "level_read_on"]):
		low = (flt(t.reorder_level) and flt(t.current_level) <= flt(t.reorder_level)) or (flt(t.daily_use) and cint(t.days_left) <= lead)
		if low:
			out.append(t)
	return out


def open_order(name):
	if not name:
		return False
	so = frappe.db.get_value("Sales Order", name, ["docstatus", "per_delivered", "status"], as_dict=True)
	return bool(so and so.docstatus < 2 and flt(so.per_delivered) < 100 and so.status not in ("Closed", "Completed"))


def daily():
	for t in tanks_due():
		if open_order(t.reorder_sales_order):
			continue
		system = frappe.get_doc("Client Water System", t.parent)
		if not system.active:
			continue
		qty = flt(t.capacity) - flt(t.current_level) if flt(t.capacity) else max(flt(t.reorder_level) * 2, flt(t.daily_use) * 30)
		if qty <= 0:
			continue
		from chemical_erp.chemical_core.material_check import round_to_pack

		qty = round_to_pack(qty, t.item_code)[0] or qty
		so = frappe.get_doc({"doctype": "Sales Order", "customer": system.customer, "transaction_date": today(),
		                     "delivery_date": add_days(today(), max(min(cint(t.days_left), 5), 1)), "po_no": _("Site stock: {0}").format(system.system_name),
		                     "items": [{"item_code": t.item_code, "qty": qty, "delivery_date": add_days(today(), max(min(cint(t.days_left), 5), 1))}]})
		so.flags.ignore_permissions = True
		so.flags.ignore_mandatory = True
		so.insert()
		frappe.db.set_value("Site Chemical Tank", t.name, "reorder_sales_order", so.name)
		notify([system.responsible] + users_with_role("Sales Manager"), "Sales Order", so.name,
		       _("{0} at {1}: {2} is low ({3} left, about {4} days). Draft order {5} raised; confirm with the customer.").format(
			       system.system_name, system.customer, t.item_code, flt(t.current_level), cint(t.days_left), so.name), priority="High")
	frappe.db.commit()
	if getdate(today()).day == 1:
		bill_contracts()


def bill_contracts():
	month = today()[:7]
	item = get_settings().get("lab_service_item")
	for s in frappe.get_all("Client Water System", filters={"service_contract": 1, "active": 1, "monthly_fee": [">", 0]},
	                        fields=["name", "system_name", "customer", "monthly_fee", "contract_item", "contract_start", "contract_end", "last_billed_month"]):
		if s.last_billed_month == month or (s.contract_start and getdate(s.contract_start) > getdate(today())) or \
				(s.contract_end and getdate(s.contract_end) < getdate(today())):
			continue
		inv = frappe.get_doc({"doctype": "Sales Invoice", "customer": s.customer, "posting_date": today(),
		                      "remarks": _("Water treatment service: {0}, {1}").format(s.system_name, month),
		                      "items": [{"item_code": s.contract_item or item, "qty": 1, "rate": s.monthly_fee,
		                                 "description": _("Monthly service contract: {0} ({1})").format(s.system_name, month)}]})
		inv.flags.ignore_permissions = True
		inv.insert()
		frappe.db.set_value("Client Water System", s.name, "last_billed_month", month)
		notify(users_with_role("Accounts User"), "Sales Invoice", inv.name, _("Monthly service invoice drafted for {0}: check and submit.").format(s.customer))
	frappe.db.commit()
