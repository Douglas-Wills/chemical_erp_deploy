"""Field Laboratory on a phone or tablet, with or without signal.

/field-lab is a single page the technician opens once while online (it is then kept on the device by a service
worker). It downloads the equipment, sample points, tests and specifications, lets the technician enter readings at
the client's site with no connection, flags results outside specification as they are typed, and keeps everything on
the device until "Sync" sends it. Sync creates or updates the Water Sample and its draft Water Analyses; the report is
signed on the desk as before.
"""

import json

import frappe
from frappe import _
from frappe.utils import cint, flt, get_datetime, now_datetime

from chemical_erp.field_laboratory.specs import COMMON_POINTS, point_limits, spec_text, split_tests

ROLES = ("Field Technician", "QC Analyst", "QC Manager", "Plant Manager", "Managing Director", "System Manager")
VERSION = "2026-10-08.1"  # bump to refresh the copy kept on devices


def _check_access():
	if frappe.session.user == "Guest":
		frappe.throw(_("Please log in."), frappe.PermissionError)
	if not set(ROLES) & set(frappe.get_roles()):
		frappe.throw(_("The field laboratory screen is for field technicians and the laboratory."), frappe.PermissionError)


@frappe.whitelist(methods=["GET"])
def token():
	"""A fresh CSRF token for the sync call (the page may have been opened days ago, offline)."""
	_check_access()
	return frappe.sessions.get_csrf_token()


def _parameters():
	out = {}
	for p in frappe.get_all("Water Test Parameter", fields=["name", "unit", "tested_at", "method", "method_reference", "range_min",
	                                                        "range_max", "default_instrument", "decimals", "qualitative"]):
		out[p.name] = p
	return out


def _defs(limits, params):
	tests = []
	for parameter, lim in limits:
		par = params.get(parameter)
		if not par or par.tested_at == "Calculated":
			continue  # worked out on the server from the other readings
		tests.append({"parameter": parameter, "min": flt(lim.min_value), "max": flt(lim.max_value),
		              "nil": (lim.target_text or "").strip().lower() in ("0", "nil", "none", "nil (0)"),
		              "spec": spec_text(lim, par.unit), "adjusted": cint(lim.adjusted)})
	return tests


def _standards(params):
	"""Every active specification, so an extra sample can be judged against any of them offline."""
	from chemical_erp.field_laboratory.specs import standard_limits

	return {s.name: {"water_type": s.water_type, "tests": _defs(standard_limits(s.name), params)}
	        for s in frappe.get_all("Water Standard", filters={"active": 1}, fields=["name", "water_type"], order_by="name")}


def _system(name, params):
	s = frappe.get_doc("Client Water System", name)
	points = [{"point_name": p.point_name or _("Results"), "tests": _defs(point_limits(s, p.point_name), params)}
	          for p in s.points or [frappe._dict(point_name=None)]]
	tanks = [{"item_code": t.item_code, "item_name": frappe.get_cached_value("Item", t.item_code, "item_name"),
	          "uom": frappe.get_cached_value("Item", t.item_code, "stock_uom"), "last": t.current_level}
	         for t in (s.get("site_tanks") or [])]
	return {"name": s.name, "system_name": s.system_name, "system_type": s.system_type, "customer": s.customer, "standard": s.standard,
	        "tanks": tanks,
	        "customer_name": frappe.db.get_value("Customer", s.customer, "customer_name"), "site": s.site,
	        "contact_person": s.contact_person, "next_due": str(s.next_due or ""), "points": points}


def instruments():
	"""The field instruments and whether results read on them can be issued."""
	from chemical_erp.utils import USABLE_EQUIPMENT

	codes = {p.default_instrument for p in frappe.get_all("Water Test Parameter", fields=["default_instrument"]) if p.default_instrument}
	out = []
	for code in sorted(codes):
		eq = frappe.db.get_value("Equipment", code, ["name", "equipment_name", "status", "next_calibration_due", "last_calibration"], as_dict=True)
		if not eq:
			continue
		draft = frappe.db.get_value("Calibration Record", {"equipment": code, "docstatus": 0}, "name")
		out.append({"code": code, "name": eq.equipment_name, "status": eq.status, "next_due": str(eq.next_calibration_due or ""),
		            "last": str(eq.last_calibration or ""), "ready": eq.status in USABLE_EQUIPMENT, "draft": draft,
		            "never": not eq.last_calibration})
	return out


@frappe.whitelist(methods=["GET"])
def bootstrap():
	_check_access()
	params = _parameters()
	systems = frappe.get_all("Client Water System", filters={"active": 1}, pluck="name", order_by="next_due asc", limit=400)
	open_visits = []
	for ws in frappe.get_all("Water Sample", filters={"status": ["in", ["Open", "Analysed"]], "docstatus": 0,
	                                                  "sampled_on": [">=", frappe.utils.add_days(frappe.utils.today(), -14)]},
	                         fields=["name", "customer", "sampled_on", "client_representative", "observations", "offline_ref",
	                                 "buffer_reading_ph"], order_by="sampled_on desc", limit=60):
		sample = frappe.get_doc("Water Sample", ws.name)
		values, comments, signed = {}, {}, []
		for wa in frappe.get_all("Water Analysis", filters={"water_sample": ws.name, "docstatus": ["<", 2]},
		                         fields=["name", "water_system", "workflow_state", "docstatus"]):
			if wa.docstatus == 1 or (wa.workflow_state and wa.workflow_state != "Draft"):
				signed.append(wa.water_system)
			for r in frappe.get_all("Water Analysis Result", filters={"parent": wa.name}, fields=["sample_point", "parameter", "result", "comment"]):
				key = f"{wa.water_system}||{r.sample_point or ''}||{r.parameter}"
				if r.result:
					values[key] = r.result
				if r.comment:
					comments[key] = r.comment
		open_visits.append({"sample": ws.name, "uuid": ws.offline_ref or ws.name, "customer": ws.customer,
		                    "customer_name": frappe.db.get_value("Customer", ws.customer, "customer_name"),
		                    "sampled_on": str(ws.sampled_on), "client_representative": ws.client_representative or "",
		                    "observations": ws.observations or "", "buffer_ph": ws.buffer_reading_ph,
		                    "points": [{"water_system": p.water_system, "point_name": p.point_name, "tests": split_tests(p.tests),
		                                "standard": p.standard,
		                                "temperature_c": p.temperature_c, "appearance": p.appearance or ""} for p in sample.sample_points],
		                    "values": values, "comments": comments, "signed_systems": signed,
		                    "tanks": {f"{t.water_system}||{t.item_code}": t.level for t in (sample.get("tank_readings") or [])}})
		for p in sample.sample_points:
			if p.water_system not in systems:
				systems.append(p.water_system)
	from chemical_erp.utils import get_settings

	return {"version": VERSION, "user": frappe.session.user, "full_name": frappe.utils.get_fullname(frappe.session.user),
	        "server_time": str(now_datetime()), "parameters": params,
	        "systems": [_system(s, params) for s in systems if frappe.db.exists("Client Water System", s)],
	        "open_visits": open_visits, "instruments": instruments(), "standards": _standards(params),
	        "suggestions": COMMON_POINTS,
	        "buffer_tolerance": flt(get_settings().get("lab_buffer_tolerance")) or 0.1}


# ---------------------------------------------------------------- sync
@frappe.whitelist(methods=["POST"])
def sync(visits):
	"""Save visits entered on the device. Each visit is saved on its own; one failure never loses the others."""
	_check_access()
	if isinstance(visits, str):
		if len(visits) > 2_000_000:
			frappe.throw(_("Too much at once: sync fewer visits."))
		visits = json.loads(visits)
	if len(visits or []) > 50:
		frappe.throw(_("Sync at most 50 visits at a time."))
	out = {}
	for v in visits or []:
		if len(v.get("values") or {}) > 2000 or len(v.get("points") or []) > 200:
			out[v.get("uuid") or "?"] = {"error": _("Visit too large")}
			continue
		uuid = (v.get("uuid") or "").strip()[:64]
		if not uuid:
			continue
		frappe.db.savepoint("fieldlab_visit")
		try:
			out[uuid] = save_visit(v)
			frappe.db.commit()
		except Exception as e:
			frappe.db.rollback(save_point="fieldlab_visit")
			frappe.clear_messages()
			out[uuid] = {"error": frappe.utils.strip_html(str(e))[:500] or _("Could not be saved")}
			frappe.log_error(title=f"Field lab sync failed: {uuid}", message=frappe.get_traceback())
	return out


def _find_sample(v):
	if v.get("sample") and frappe.db.exists("Water Sample", v["sample"]):
		return frappe.get_doc("Water Sample", v["sample"])
	name = frappe.db.get_value("Water Sample", {"offline_ref": v["uuid"]}, "name")
	return frappe.get_doc("Water Sample", name) if name else None


def save_visit(v):
	from chemical_erp.utils import get_settings

	warnings = []
	points = v.get("points") or []
	if not points:
		frappe.throw(_("No sample points on this visit."))
	sample = _find_sample(v)
	header = {"client_representative": (v.get("client_representative") or "")[:140] or None,
	          "observations": v.get("observations") or None,
	          "arrival_time": v.get("arrival_time") or None, "departure_time": v.get("departure_time") or None}
	if v.get("buffer_ph") not in (None, ""):
		header["buffer_reading_ph"] = flt(v["buffer_ph"])
	if not sample:
		sample = frappe.get_doc({"doctype": "Water Sample", "customer": v["customer"], "offline_ref": v["uuid"],
		                         "sampled_on": get_datetime(v.get("sampled_on") or now_datetime()),
		                         "sample_points": [{"water_system": p["water_system"], "point_name": p["point_name"],
		                                            "standard": p.get("standard") if p.get("extra") else None,
		                                            "temperature_c": p.get("temperature_c"), "appearance": p.get("appearance"),
		                                            "tests": ", ".join(p.get("tests") or [])} for p in points], **header})
		sample.insert()
	else:
		sample.check_permission("write")
		if sample.status == "Cancelled":
			frappe.throw(_("{0} was cancelled on the desk.").format(sample.name))
		sample.update({k: val for k, val in header.items() if val is not None})
		have = {(r.water_system, r.point_name): r for r in sample.sample_points}
		for p in points:
			row = have.get((p["water_system"], p["point_name"]))
			if row:
				row.temperature_c = p.get("temperature_c") if p.get("temperature_c") not in ("", None) else row.temperature_c
				row.appearance = p.get("appearance") or row.appearance
				known = split_tests(row.tests)
				row.tests = ", ".join(known + [t for t in p.get("tests") or [] if t not in known])  # tests added on site
			else:
				sample.append("sample_points", {"water_system": p["water_system"], "point_name": p["point_name"],
				                                "standard": p.get("standard") if p.get("extra") else None,
				                                "temperature_c": p.get("temperature_c"), "appearance": p.get("appearance"),
				                                "tests": ", ".join(p.get("tests") or [])})
		sample.save()
	tanks = {key: lvl for key, lvl in (v.get("tanks") or {}).items() if str(lvl).strip() not in ("", "None")}
	if tanks and sample.meta.has_field("tank_readings"):
		keep = [r for r in sample.tank_readings if f"{r.water_system}||{r.item_code}" not in tanks]
		sample.set("tank_readings", [r.as_dict() for r in keep])
		for key, level in tanks.items():
			system, item = (key.split("||") + [""])[:2]
			if system and item and frappe.db.exists("Item", item):
				sample.append("tank_readings", {"water_system": system, "item_code": item, "level": flt(level)})
		sample.save()
	sample.reload()
	tol = flt(get_settings().get("lab_buffer_tolerance")) or 0.1
	if sample.get("buffer_reading_ph") and abs(flt(sample.buffer_reading_ph) - 7.01) > tol:
		warnings.append(_("pH meter read {0} on the 7.01 buffer (more than ±{1} off). Recalibrate and re-read pH.").format(
			sample.buffer_reading_ph, tol))
	analyses = sample.start_analysis()
	values = v.get("values") or {}
	comments = v.get("comments") or {}
	result = []
	for name in analyses:
		wa = frappe.get_doc("Water Analysis", name)
		if wa.docstatus != 0 or (wa.get("workflow_state") and wa.workflow_state != "Draft"):
			if any(k.startswith(f"{wa.water_system}||") for k in values):
				warnings.append(_("{0} is already signed: readings for {1} were not changed.").format(wa.name, wa.water_system))
			result.append({"name": wa.name, "water_system": wa.water_system, "compliance": wa.compliance, "signed": 1})
			continue
		rows = {(r.sample_point or "", r.parameter): r for r in wa.results}
		for key, value in values.items():
			system, point, parameter = (key.split("||") + ["", "", ""])[:3]
			if system != wa.water_system or not parameter:
				continue
			value = str(value).strip()[:140]
			row = rows.get((point, parameter))
			if not row:
				if not value or not frappe.db.exists("Water Test Parameter", parameter):
					continue
				row = wa.append("results", {"sample_point": point or None, "parameter": parameter})
				rows[(point, parameter)] = row
			row.result = value
			if comments.get(key) is not None:
				row.comment = str(comments[key])[:140]
		wa.flags.from_field_device = True
		wa.save()
		warnings.extend(wa.flags.get("tool_warnings") or [])
		result.append({"name": wa.name, "water_system": wa.water_system, "compliance": wa.compliance, "results_out": wa.results_out,
		               "signed": 0})
	return {"sample": sample.name, "analyses": result, "warnings": list(dict.fromkeys(warnings)), "synced_at": str(now_datetime())}


# ---------------------------------------------------------------- the page, its service worker and manifest
class FieldLabRenderer:
	"""Serves /field-lab, /field-lab-sw.js and /field-lab.webmanifest (hooks: page_renderer)."""

	ROUTES = {"field-lab": "page", "field-lab-sw.js": "sw", "field-lab.webmanifest": "manifest"}

	def __init__(self, path=None, http_status_code=None):
		self.path = (path or "").strip("/ ")
		self.http_status_code = http_status_code or 200

	def can_render(self):
		return self.path in self.ROUTES

	def render(self):
		from werkzeug.wrappers import Response

		kind = self.ROUTES[self.path]
		folder = frappe.get_app_path("chemical_erp", "field_laboratory", "offline_app")
		if kind == "sw":
			body = open(f"{folder}/sw.js").read().replace("__VERSION__", VERSION)
			return Response(body, mimetype="application/javascript",
			                headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"})
		if kind == "manifest":
			from chemical_erp.company import company_name

			return Response(json.dumps({"name": f"{company_name(short=True)} Field Lab", "short_name": "Field Lab",
			                            "start_url": "/field-lab", "scope": "/field-lab", "display": "standalone",
			                            "background_color": "#ffffff", "theme_color": "#1f3864",
			                            "icons": [{"src": "/assets/chemical_erp/images/brave_logo.png", "sizes": "192x192", "type": "image/png"}]}),
			                mimetype="application/manifest+json")
		if frappe.session.user == "Guest":
			return Response(status=302, headers={"Location": "/login?redirect-to=/field-lab"})
		from chemical_erp.company import company_name

		body = open(f"{folder}/index.html").read()
		body = body.replace("__COMPANY__", frappe.utils.escape_html(company_name(short=True))).replace("__VERSION__", VERSION)
		return Response(body, mimetype="text/html", headers={"Cache-Control": "no-cache"})
