"""First calibration records for the field instruments.

The HANNA meter and the HACH DR900 count as 'Out of Calibration' until a calibration is on record, and a Water
Analysis cannot be signed with readings from them until then. `prepare_first_calibrations` opens a draft
Calibration Record for each with the check points already listed; the technician enters the readings, attaches the
buffer/standard certificate and sends it for review.
"""

import frappe
from frappe import _
from frappe.utils import add_days, today

from chemical_erp.field_laboratory.seed import DR900, HANNA

# (check, nominal, tolerance ±). HI98130 accuracy: pH ±0.05; EC ±2% of full scale (20 mS/cm → 400 µS/cm);
# TDS ±2% of full scale (10 ppt → 0.2 ppt); temperature ±0.5 °C.
POINTS = {
	HANNA: [("pH 4.01 buffer", 4.01, 0.05), ("pH 7.01 buffer", 7.01, 0.05), ("pH 10.01 buffer", 10.01, 0.05),
	        ("EC 12880 µS/cm standard (HI7030)", 12880, 400), ("TDS 6.44 ppt standard (HI70442)", 6.44, 0.2),
	        ("Temperature vs reference thermometer, °C", 25.0, 0.5)],
	# DR900: SpecCheck secondary standards. Nominal values are printed on each kit's certificate: replace the 0s.
	DR900: [("Zero / blank (deionised water)", 0.0, 0.02), ("SpecCheck standard: low (enter certificate value)", 0.0, 0.0),
	        ("SpecCheck standard: mid (enter certificate value)", 0.0, 0.0), ("SpecCheck standard: high (enter certificate value)", 0.0, 0.0)],
}
REFERENCE = {HANNA: "HANNA pH 4.01/7.01/10.01 buffers, HI7030 EC and HI70442 TDS standards (lot numbers on certificate)",
             DR900: "HACH SpecCheck secondary standard kit (lot number on certificate)"}


def readiness():
	from chemical_erp.field_laboratory.offline import instruments

	return instruments()


@frappe.whitelist()
def readiness_status():
	"""Field instruments that cannot be relied on today (for the banner on the Water Sample form)."""
	return [{"code": r["code"], "name": r["name"], "status": r["status"], "draft": r["draft"]} for r in readiness() if not r["ready"]]


@frappe.whitelist()
def prepare_first_calibrations():
	"""Open a draft calibration for every field instrument that has none on record. Returns the drafts."""
	if not set(frappe.get_roles()) & {"QC Analyst", "Field Technician", "Maintenance Technician", "Plant Manager", "Managing Director",
	                                  "System Manager", "QC Manager"}:
		frappe.throw(_("Not permitted"), frappe.PermissionError)
	made = []
	for row in readiness():
		if row["ready"] or row["draft"]:
			if row["draft"]:
				made.append(row["draft"])
			continue
		points = POINTS.get(row["code"]) or [(_("Check point"), 0.0, 0.0)]
		doc = frappe.get_doc({"doctype": "Calibration Record", "equipment": row["code"], "calibration_date": today(),
		                      "performed_by_type": "In-house", "performed_by_user": frappe.session.user,
		                      "reference_standard": REFERENCE.get(row["code"], ""), "standard_valid_to": add_days(today(), 365),
		                      "points": [{"check_point": c, "nominal": n, "tolerance_abs": t} for c, n, t in points]})
		doc.flags.ignore_mandatory = True
		doc.insert()
		doc.add_comment("Comment", _("Opened from the Field Laboratory. Enter the as-found readings, attach the buffer or "
		                             "standard certificate, set the standard's expiry date, then Send for Review."))
		made.append(doc.name)
	return made


def remind():
	"""Daily: visits are due soon but a field instrument cannot be relied on."""
	from chemical_erp.utils import notify, users_with_role

	due = frappe.db.count("Client Water System", {"active": 1, "next_due": ["<=", add_days(today(), 7)]})
	if not due:
		return
	bad = [r for r in readiness() if not r["ready"]]
	if not bad:
		return
	who = users_with_role("Field Technician") + users_with_role("QC Analyst")
	for r in bad:
		notify(who, "Equipment", r["code"],
		       _("{0} is {1}: {2} site visit(s) are due within 7 days. Calibrate it first, or results cannot be signed.").format(
			       r["name"], r["status"], due), priority="High")
