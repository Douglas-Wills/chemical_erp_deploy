"""Chemical stock in customers' tanks: level, use per day, days left, reorder raised."""

import frappe
from frappe import _


def execute(filters=None):
	data = []
	for t in frappe.get_all("Site Chemical Tank", fields=["parent", "item_code", "capacity", "reorder_level", "current_level", "level_read_on",
	                                                      "daily_use", "days_left", "reorder_sales_order"], order_by="days_left asc"):
		s = frappe.db.get_value("Client Water System", t.parent, ["system_name", "customer", "active"], as_dict=True)
		if not s or not s.active:
			continue
		t.update({"system_name": s.system_name, "customer": s.customer})
		data.append(t)
	c = lambda n, l, t="Float", w=110, o=None: {"fieldname": n, "label": l, "fieldtype": t, "width": w, **({"options": o} if o else {})}
	return [c("customer", _("Customer"), "Link", 160, "Customer"), c("parent", _("Equipment"), "Link", 130, "Client Water System"),
	        c("system_name", _("Name"), "Data", 150), c("item_code", _("Product"), "Link", 140, "Item"), c("capacity", _("Capacity")),
	        c("current_level", _("Level")), c("level_read_on", _("Read On"), "Date", 95), c("daily_use", _("Use/Day")), c("days_left", _("Days Left"), "Int", 80),
	        c("reorder_level", _("Reorder At")), c("reorder_sales_order", _("Reorder"), "Link", 130, "Sales Order")], data
