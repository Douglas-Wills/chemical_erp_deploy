"""One piece of equipment over time: every result for a parameter at a sample point, against its specification."""

import frappe
from frappe import _

from chemical_erp.field_laboratory.doctype.water_analysis.water_analysis import WaterAnalysis


def execute(filters=None):
	f = frappe._dict(filters or {})
	if not f.water_system:
		return _columns(), [], _("Choose the equipment.")
	cond = ["wa.docstatus = 1", "wa.water_system = %(sys)s"]
	if f.parameter:
		cond.append("r.parameter = %(par)s")
	if f.sample_point:
		cond.append("r.sample_point = %(pt)s")
	rows = frappe.db.sql(f"""select wa.name, wa.analysed_on, r.sample_point, r.parameter, r.unit, r.result, r.limit_text, r.status, r.comment
		from `tabWater Analysis` wa join `tabWater Analysis Result` r on r.parent = wa.name
		where {' and '.join(cond)} order by wa.analysed_on, r.sample_point, r.idx""",
		{"sys": f.water_system, "par": f.parameter, "pt": f.sample_point}, as_dict=True)
	data = [r for r in rows if (r.result or "").strip()]
	chart = None
	if f.parameter:
		pts = [r for r in data if WaterAnalysis.number(r.result) is not None]
		if pts:
			chart = {"data": {"labels": [frappe.format(r.analysed_on, {"fieldtype": "Date"}) for r in pts],
			                  "datasets": [{"name": f"{f.parameter} ({pts[0].unit})" if pts[0].unit else f.parameter,
			                                "values": [WaterAnalysis.number(r.result) for r in pts]}]},
			         "type": "line", "colors": ["#1f3864"]}
	out = sum(1 for r in data if r.status in ("Above Limit", "Below Limit", "Not Met"))
	summary = [{"label": _("Results"), "value": len(data), "indicator": "Blue"},
	           {"label": _("Outside specification"), "value": out, "indicator": "Red" if out else "Green"}]
	return _columns(), data, None, chart, summary


def _columns():
	return [
		{"fieldname": "analysed_on", "label": _("Test Date"), "fieldtype": "Date", "width": 100},
		{"fieldname": "name", "label": _("Report"), "fieldtype": "Link", "options": "Water Analysis", "width": 130},
		{"fieldname": "sample_point", "label": _("Sample Point"), "fieldtype": "Data", "width": 120},
		{"fieldname": "parameter", "label": _("Parameter"), "fieldtype": "Data", "width": 170},
		{"fieldname": "result", "label": _("Result"), "fieldtype": "Data", "width": 80},
		{"fieldname": "unit", "label": _("Unit"), "fieldtype": "Data", "width": 70},
		{"fieldname": "limit_text", "label": _("Specification"), "fieldtype": "Data", "width": 110},
		{"fieldname": "status", "label": _("Status"), "fieldtype": "Data", "width": 110},
		{"fieldname": "comment", "label": _("Comment"), "fieldtype": "Data", "width": 220},
	]
