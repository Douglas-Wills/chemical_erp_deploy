frappe.query_reports["Water Trend"] = {
	filters: [
		{ fieldname: "water_system", label: __("Equipment"), fieldtype: "Link", options: "Client Water System", reqd: 1 },
		{ fieldname: "sample_point", label: __("Sample Point"), fieldtype: "Data" },
		{ fieldname: "parameter", label: __("Parameter (for the chart)"), fieldtype: "Link", options: "Water Test Parameter" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "result" && data && ["Above Limit", "Below Limit", "Not Met"].includes(data.status))
			value = `<b style="color:#e00000;text-decoration:underline">${value}</b>`;
		return value;
	},
};
