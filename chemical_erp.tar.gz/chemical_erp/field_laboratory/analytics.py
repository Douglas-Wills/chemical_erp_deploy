"""Technical analysis of water results: what an experienced water-treatment engineer works out from the numbers.

Pure functions (no database) take a simple view of the analysis so they can be tested on their own:
  results: list of dicts {point, parameter, value (float or None), text, lo, hi, nil, status, unit}
  equipment: {type: Boiler | Cooling Tower | Chiller, capacity_lph, operating_hours}
They return indices, risk levels and findings. `svg_*` helpers draw the report's charts.
"""

import math

OUT = ("Above Limit", "Below Limit", "Not Met")
NA_SULPHITE_PER_O2 = 7.88       # mg sodium sulphite needed per mg dissolved oxygen (theoretical)
NA_SULPHITE_PER_SO3 = 1.575     # mg sodium sulphite per mg sulphite (SO3) residual


# ------------------------------------------------------------------ helpers
def _find(results, point_words, parameter):
	"""Value of a parameter at the first sample point whose name contains any of point_words."""
	for r in results:
		if r["parameter"] != parameter or r["value"] is None:
			continue
		name = (r["point"] or "").lower()
		if not point_words or any(w in name for w in point_words):
			return r["value"]
	return None


def _row(results, point_words, parameter):
	for r in results:
		if r["parameter"] == parameter and (not point_words or any(w in (r["point"] or "").lower() for w in point_words)):
			return r
	return None


def deviation(r):
	"""How far outside its specification a result is: (times the limit, grade)."""
	v = r["value"]
	if v is None or r["status"] not in OUT:
		return None, None
	if r["nil"]:
		return None, "Major" if v > 0 else None
	if r["hi"] and v > r["hi"]:
		times = v / r["hi"] if r["hi"] else None
		grade = "Critical" if times and times >= 3 else ("Major" if times and times >= 1.25 else "Minor")
		return times, grade
	if r["lo"] and v < r["lo"]:
		short = (r["lo"] - v) / r["lo"]
		return None, "Critical" if short >= 0.75 else ("Major" if short >= 0.2 else "Minor")
	return None, "Minor"


def compliance_score(results):
	judged = [r for r in results if r["status"] in ("Within Limit",) + OUT]
	if not judged:
		return None
	return round(100.0 * sum(1 for r in judged if r["status"] == "Within Limit") / len(judged), 1)


def lsi_rsi(ph, temp_c, tds, ca_hardness, m_alk):
	"""Langelier and Ryznar indices (calcium hardness and alkalinity as mg/L CaCO3)."""
	if None in (ph, temp_c, tds, ca_hardness, m_alk) or min(tds, ca_hardness, m_alk) <= 0:
		return None, None
	a = (math.log10(tds) - 1) / 10
	b = -13.12 * math.log10(temp_c + 273.15) + 34.55
	c = math.log10(ca_hardness) - 0.4
	d = math.log10(m_alk)
	phs = (9.3 + a + b) - (c + d)
	return round(ph - phs, 2), round(2 * phs - ph, 2)


# ------------------------------------------------------------------ the analysis
def analyse(results, equipment, previous=None):
	"""Returns dict: score, indices, risks, findings (list of (area, severity, finding, recommendation)), trends."""
	etype = equipment.get("type")
	cap = equipment.get("capacity_lph") or 0
	hours = equipment.get("operating_hours") or 24
	out = {"score": compliance_score(results), "coc": None, "max_coc": None, "bd_now": None, "bd_needed": None,
	       "scavenger": None, "lsi": None, "rsi": None, "findings": [], "risks": {}}
	F = out["findings"]
	covered = set()  # parameters already explained by a specific finding
	scale = corrosion = carry = micro = 0

	# Measurement check: TDS against conductivity, at every point that has both
	points = sorted({r["point"] or "" for r in results})
	for p in points:
		tds = _find(results, [p.lower()] if p else [], "Total Dissolved Solids")
		cond = _find(results, [p.lower()] if p else [], "Conductivity")
		if tds and cond:
			ratio = tds / cond
			if not 0.45 <= ratio <= 0.8:
				F.append(("Measurement Check", "Medium", f"{p or 'Sample'}: TDS is {ratio:.2f} × conductivity; it is normally 0.5 to 0.7.",
				          "Re-check the meter calibration and the TDS factor, then retest."))

	if etype == "Boiler":
		bw, fw = ["boiler"], ["feed"]
		b_tds, f_tds = _find(results, bw, "Total Dissolved Solids"), _find(results, fw, "Total Dissolved Solids")
		b_cond, f_cond = _find(results, bw, "Conductivity"), _find(results, fw, "Conductivity")
		basis = (b_tds, f_tds, "TDS") if b_tds and f_tds else ((b_cond, f_cond, "conductivity") if b_cond and f_cond else (None, None, None))
		if basis[0]:
			coc = basis[0] / basis[1]
			out["coc"] = round(coc, 1)
			tds_row = _row(results, bw, "Total Dissolved Solids") if basis[2] == "TDS" else _row(results, bw, "Conductivity")
			limit = tds_row["hi"] if tds_row else None
			if limit:
				max_coc = limit / basis[1]
				out["max_coc"] = round(max_coc, 1)
				if cap:
					b_now = 1 / coc
					b_need = 1 / max_coc
					out["bd_now"] = round(cap * b_now / (1 - b_now)) if b_now < 1 else None
					out["bd_needed"] = round(cap * b_need / (1 - b_need)) if b_need < 1 else None
				if coc > max_coc:
					covered.update({("boiler", "Total Dissolved Solids"), ("boiler", "Conductivity")})
					carry += 2 if coc > 1.5 * max_coc else 1
					rec = (f"Increase blowdown from about {out['bd_now']:,} to about {out['bd_needed']:,} l/hr "
					       f"(about {100 / max_coc:.1f}% of feed) to bring {basis[2]} within specification."
					       if out["bd_now"] and out["bd_needed"] else f"Increase blowdown to about {100 / max_coc:.1f}% of feed.")
					F.append(("Blowdown", "High" if coc > 1.5 * max_coc else "Medium",
					          f"The boiler runs at {coc:.1f} cycles of concentration; the specification allows {max_coc:.1f}.", rec))
		do_feed = _find(results, fw, "Dissolved Oxygen")
		sulphite = _find(results, bw, "Sulphites")
		sul_row = _row(results, bw, "Sulphites")
		if do_feed is not None and cap:
			bd = out["bd_needed"] or out["bd_now"] or 0
			feed_l_day = (cap + bd) * hours
			target_res = ((sul_row["lo"] + sul_row["hi"]) / 2) if sul_row and sul_row["lo"] and sul_row["hi"] else 30
			kg = (NA_SULPHITE_PER_O2 * do_feed * feed_l_day + NA_SULPHITE_PER_SO3 * target_res * bd * hours) / 1e6
			out["scavenger"] = round(kg, 1)
		do_row = _row(results, fw, "Dissolved Oxygen")
		if do_row and do_row["status"] in OUT:
			covered.update({("feed", "Dissolved Oxygen"), ("boiler", "Dissolved Oxygen")})
			corrosion += 2
			F.append(("Oxygen Control", "High", f"Feed water dissolved oxygen is {do_feed:g} mg/L against {do_row['hi']:g} mg/L or less.",
			          f"Raise oxygen-scavenger feed to about {out['scavenger']} kg/day as sodium sulphite (adjust for the product's strength); "
			          "check the feed tank temperature and deaeration." if out["scavenger"] else "Raise oxygen-scavenger feed."))
		if sul_row and sulphite is not None and sul_row["status"] in OUT and sulphite < (sul_row["lo"] or 0):
			covered.add(("boiler", "Sulphites"))
			corrosion += 2
			F.append(("Oxygen Control", "High", f"Boiler sulphite residual is {sulphite:g} ppm; the target is {sul_row['lo']:g} to {sul_row['hi']:g} ppm.",
			          "No scavenger reserve is left in the boiler: increase scavenger dosing and confirm the dosing pump is delivering."))
		b_hard = _row(results, bw, "Total Hardness")
		f_hard = _row(results, fw, "Total Hardness")
		if b_hard and b_hard["status"] in OUT:
			covered.add(("boiler", "Total Hardness"))
			scale += 2
			feed_ok = f_hard and f_hard["status"] == "Within Limit"
			F.append(("Water Softening", "High", f"Boiler water hardness is {b_hard['value']:g} ppm"
			          + (" while feed water reads nil at sampling: hardness is entering intermittently." if feed_ok else "."),
			          "Check softener regeneration, salt level and the hardness of the softened water through the day; test feed hardness daily."))
		elif f_hard and f_hard["status"] in OUT:
			covered.add(("feed", "Total Hardness"))
			scale += 1
			F.append(("Water Softening", "Medium", f"Feed water hardness is {f_hard['value']:g} ppm.", "Regenerate or service the softener."))
		phos = _row(results, bw, "Phosphates")
		if phos and phos["status"] in OUT:
			covered.add(("boiler", "Phosphates"))
			if phos["hi"] and phos["value"] > phos["hi"]:
				carry += 1
				F.append(("Treatment Dosing", "Medium", f"Phosphate is {phos['value']:g} ppm against {phos['lo']:g} to {phos['hi']:g} ppm: overdosed.",
				          "Reduce scale-inhibitor (phosphate) dosing; the excess adds to dissolved solids and sludge."))
			else:
				scale += 1
				F.append(("Treatment Dosing", "Medium", f"Phosphate is {phos['value']:g} ppm, below the {phos['lo']:g} ppm minimum.",
				          "Increase scale-inhibitor dosing to restore the reserve."))
		f_tds_row = _row(results, fw, "Total Dissolved Solids") or _row(results, fw, "Conductivity")
		if f_tds_row and f_tds_row["status"] in OUT:
			covered.update({("feed", "Total Dissolved Solids"), ("feed", "Conductivity")})
			carry += 1
			F.append(("Blowdown", "Medium", f"Feed water {f_tds_row['parameter'].lower()} is {f_tds_row['text']} against "
			          f"{doc_spec(f_tds_row)}{' ' + f_tds_row['unit'] if f_tds_row['unit'] else ''}: every litre carries more solids into the boiler.",
			          "Check the make-up water source and softener, and raise condensate return where possible; "
			          "until then, more blowdown is needed to hold boiler solids within specification."))
		f_ph = _row(results, fw, "pH")
		if f_ph and f_ph["status"] in OUT and f_ph["lo"] and f_ph["value"] < f_ph["lo"]:
			covered.add(("feed", "pH"))
			corrosion += 1
			F.append(("Corrosion", "Medium", f"Feed water pH is {f_ph['value']:g}, below {f_ph['lo']:g}.",
			          "Low feed pH points to dissolved carbon dioxide: consider a neutralising amine or alkalinity adjustment."))
		b_ph = _row(results, bw, "pH")
		if b_ph and b_ph["status"] in OUT:
			corrosion += 1
		tds_row = _row(results, bw, "Total Dissolved Solids")
		if tds_row and tds_row["status"] in OUT:
			carry += 1
	elif etype == "Cooling Tower":
		tw, mu = ["tower"], ["make"]
		t_cond, m_cond = _find(results, tw, "Conductivity"), _find(results, mu, "Conductivity")
		if t_cond and m_cond:
			out["coc"] = round(t_cond / m_cond, 1)
			c_row = _row(results, tw, "Cycles of Concentration")
			if c_row and c_row["hi"] and out["coc"] > c_row["hi"]:
				scale += 1
				F.append(("Blowdown", "Medium", f"The tower runs at {out['coc']} cycles; the guide maximum is {c_row['hi']:g}.", "Increase bleed-off."))
		lsi, rsi = lsi_rsi(_find(results, tw, "pH"), _find(results, tw, "Temperature") or 30, _find(results, tw, "Total Dissolved Solids"),
		                   _find(results, tw, "Calcium Hardness"), _find(results, tw, "M-Alkalinity (Total Alkalinity)"))
		out["lsi"], out["rsi"] = lsi, rsi
		if lsi is not None:
			if lsi > 0.5:
				scale += 2
				F.append(("Scale", "High" if lsi > 1.5 else "Medium", f"Langelier index {lsi:+.2f}: the water is scale-forming.",
				          "Increase bleed-off or scale-inhibitor dosing; check heat-exchanger approach temperatures."))
			elif lsi < -0.5:
				corrosion += 2
				F.append(("Corrosion", "High" if lsi < -1.5 else "Medium", f"Langelier index {lsi:+.2f}: the water is corrosive.",
				          "Raise corrosion-inhibitor dosing and check pH control."))
		coli = _row(results, tw, "Total Coliforms")
		chl = _row(results, tw, "Free Residual Chlorine")
		if coli and coli["status"] in OUT:
			micro += 2
			F.append(("Microbiological", "High", f"Bacterial count {coli['value']:g} CFU/100 mL is above the guide.", "Shock-dose biocide and review the routine biocide programme."))
		if chl and chl["status"] in OUT and chl["lo"] and chl["value"] < chl["lo"]:
			micro += 1
			F.append(("Microbiological", "Medium", f"Free chlorine {chl['value']:g} mg/L is below {chl['lo']:g}.", "Increase oxidising biocide feed."))
	elif etype == "Chiller":
		ch = ["chill", "loop"]
		iron = _row(results, ch, "Iron (Total)")
		if iron and iron["status"] in OUT:
			corrosion += 2
			F.append(("Corrosion", "High", f"Iron {iron['value']:g} mg/L in the closed loop shows active corrosion.", "Raise corrosion-inhibitor level and check for oxygen ingress (make-up, leaks)."))
		ph = _row(results, ch, "pH")
		if ph and ph["status"] in OUT:
			corrosion += 1

	# general: every remaining out-of-specification result is listed
	def is_covered(r):
		name = (r["point"] or "").lower()
		return any(word in name and par == r["parameter"] for word, par in covered)

	for r in results:
		if r["status"] in OUT and not is_covered(r):
			times, grade = deviation(r)
			sev = {"Critical": "High", "Major": "Medium"}.get(grade, "Low")
			extra = f" ({times:.1f}× the maximum)" if times else ""
			F.append(("Treatment Dosing", sev, f"{r['point'] + ': ' if r['point'] else ''}{r['parameter']} is {r['text']}{extra}, outside specification.",
			          "Review the treatment programme for this parameter."))

	def level(n, assessed=True):
		return "Not Assessed" if not assessed else ("High" if n >= 3 else ("Medium" if n >= 1 else "Low"))

	micro_assessed = any(r["parameter"] in ("Total Coliforms", "Free Residual Chlorine") and r["value"] is not None for r in results)
	out["risks"] = {"Scale": level(scale), "Corrosion": level(corrosion), "Carryover": level(carry, etype == "Boiler"),
	                "Microbiological": level(micro, micro_assessed)}
	order = {"High": 0, "Medium": 1, "Low": 2, "Info": 3}
	F.sort(key=lambda f: order.get(f[1], 4))

	# trend against the previous visit
	trends = {}
	for r in results:
		prev = (previous or {}).get((r["point"], r["parameter"]))
		if r["value"] is not None and prev:
			last = prev[-1]
			if last:
				trends[(r["point"], r["parameter"])] = {"previous": last, "change": round((r["value"] - last) / abs(last) * 100, 1) if last else None,
				                                        "series": prev[-5:] + [r["value"]]}
	out["trends"] = trends
	return out


# ------------------------------------------------------------------ charts (SVG, drawn on the report)
GREEN, RED, AMBER, GREY, NAVY = "#16a34a", "#e00000", "#d97706", "#9ca3af", "#1f3864"


def svg_ring(pct, size=86):
	if pct is None:
		return ""
	r, c = 34, 2 * math.pi * 34
	colour = GREEN if pct >= 90 else (AMBER if pct >= 60 else RED)
	return (f'<svg width="{size}" height="{size}" viewBox="0 0 86 86"><circle cx="43" cy="43" r="{r}" fill="none" stroke="#e5e7eb" stroke-width="9"/>'
	        f'<circle cx="43" cy="43" r="{r}" fill="none" stroke="{colour}" stroke-width="9" stroke-dasharray="{c * pct / 100:.1f} {c:.1f}" '
	        f'transform="rotate(-90 43 43)"/><text x="43" y="48" text-anchor="middle" font-family="Arial, Liberation Sans, Helvetica, sans-serif" font-size="17" font-weight="bold" '
	        f'fill="#111827">{pct:.0f}%</text></svg>')


def svg_spec_bar(r, width=170, height=16):
	"""Where a result sits against its specification band (green), clipped at 3x the band for very high values."""
	v, lo, hi = r["value"], r["lo"] or 0, r["hi"] or 0
	if v is None or not (lo or hi or r["nil"]):
		return ""
	top = max(hi * 1.6 if hi else lo * 2, lo * 1.6, 1e-9)
	clipped = v > top * 1.875
	span = top * 1.875
	x = lambda val: 4 + (width - 8) * max(0, min(val, span)) / span
	colour = RED if r["status"] in OUT else GREEN
	band = (f'<rect x="{x(lo):.1f}" y="4" width="{max(x(hi if hi else span) - x(lo), 2):.1f}" height="{height - 8}" fill="#bbf7d0"/>'
	        if not r["nil"] else f'<rect x="4" y="4" width="3" height="{height - 8}" fill="#bbf7d0"/>')
	mark = f'<rect x="{x(v) - 1.5:.1f}" y="1" width="3" height="{height - 2}" fill="{colour}"/>'
	arrow = (f'<text x="{width - 2}" y="{height - 4}" text-anchor="end" font-family="Arial, Liberation Sans, sans-serif" font-size="8" fill="{RED}">&#9654;</text>' if clipped else "")
	return (f'<svg width="{width}" height="{height}"><rect x="4" y="4" width="{width - 8}" height="{height - 8}" fill="#f3f4f6"/>'
	        f'{band}{mark}{arrow}</svg>')


def svg_sparkline(series, width=74, height=20, bad=False):
	vals = [s for s in series if s is not None]
	if len(vals) < 2:
		return ""
	lo, hi = min(vals), max(vals)
	rng = (hi - lo) or 1
	pts = [(2 + (width - 4) * i / (len(vals) - 1), height - 3 - (height - 6) * (v - lo) / rng) for i, v in enumerate(vals)]
	path = " ".join(f"{px:.1f},{py:.1f}" for px, py in pts)
	return (f'<svg width="{width}" height="{height}"><polyline points="{path}" fill="none" stroke="{NAVY}" stroke-width="1.4"/>'
	        f'<circle cx="{pts[-1][0]:.1f}" cy="{pts[-1][1]:.1f}" r="2.4" fill="{RED if bad else GREEN}"/></svg>')


# ------------------------------------------------------------------ the report's technical page (Jinja: water_technical_section(doc))
TILE = {"High": ("#fde2e2", "#b91c1c"), "Medium": ("#fef3c7", "#b45309"), "Low": ("#dcfce7", "#15803d"), "Not Assessed": ("#f3f4f6", "#6b7280")}
CHIP = {"High": "#b91c1c", "Medium": "#b45309", "Low": "#15803d", "Info": "#6b7280"}


def _esc(s):
	return (str(s if s is not None else "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def technical_html(doc, view, out, equipment_type):
	parts = ['<div style="page-break-before:always"></div><style>.wr .tech td{border:none}</style>'
	         '<div class="tech" style="font-family:Arial,\'Liberation Sans\',sans-serif;font-size:9.5pt;color:#111827">',
	         f'<div style="font-size:14pt;font-weight:bold;text-decoration:underline;text-align:center;margin:2pt 0 8pt">Technical Analysis</div>',
	         f'<div style="text-align:center;color:#4b5563;font-size:8.5pt;margin-bottom:8pt">{_esc(doc.report_title)} · {_esc(doc.equipment_name)} · Report {_esc(doc.name)}</div>']
	# score and risks
	tiles = "".join(
		f'<td style="width:19%;padding:4pt"><div style="background:{TILE[v][0]};border-radius:6pt;padding:6pt;text-align:center">'
		f'<div style="font-size:8pt;color:#374151">{k} risk</div><div style="font-size:12pt;font-weight:bold;color:{TILE[v][1]}">{v}</div></div></td>'
		for k, v in out["risks"].items())
	judged = sum(1 for r in view if r["status"] in ("Within Limit",) + OUT)
	outn = sum(1 for r in view if r["status"] in OUT)
	parts.append(f'<table style="width:100%;border-collapse:collapse"><tr><td style="width:24%;text-align:center">{svg_ring(out["score"])}'
	             f'<div style="font-size:8pt;color:#374151">Compliance: {judged - outn} of {judged} tests within specification</div></td>{tiles}</tr></table>')
	# key figures
	figs = []
	if out["coc"] is not None:
		verdict = ("within the specification's limit" if not out["max_coc"] or out["coc"] <= out["max_coc"]
		           else f"{out['coc'] / out['max_coc']:.1f}× the {out['max_coc']:g} the specification allows")
		figs.append(("Cycles of concentration", f"{out['coc']:g}", verdict))
	if out["bd_now"] is not None and out["bd_needed"] is not None:
		figs.append(("Blowdown (estimated)", f"{out['bd_now']:,} → {out['bd_needed']:,} l/hr", "now → needed to hold dissolved solids within specification"))
	if out["scavenger"] is not None:
		figs.append(("Oxygen scavenger demand", f"{out['scavenger']:g} kg/day", "as sodium sulphite, from feed-water oxygen and the sulphite reserve"))
	if out["lsi"] is not None:
		figs.append(("Langelier index", f"{out['lsi']:+.2f}", "scale-forming above +0.5, corrosive below −0.5"))
		figs.append(("Ryznar index", f"{out['rsi']:.2f}", "6.0–7.0 balanced; lower forms scale, higher corrodes"))
	if figs:
		rows = "".join(f'<tr><td style="padding:4pt;border-bottom:1px solid #e5e7eb;width:34%">{_esc(a)}</td>'
		               f'<td style="padding:4pt;border-bottom:1px solid #e5e7eb;font-weight:bold;width:22%">{_esc(b)}</td>'
		               f'<td style="padding:4pt;border-bottom:1px solid #e5e7eb;color:#374151">{_esc(c)}</td></tr>' for a, b, c in figs)
		parts.append(f'<div style="font-weight:bold;font-size:11pt;margin:10pt 0 3pt">Key figures</div><table style="width:100%;border-collapse:collapse">{rows}</table>')
	# results at a glance
	parts.append('<div style="font-weight:bold;font-size:11pt;margin:12pt 0 3pt">Results against specification</div>'
	             '<table style="width:100%;border-collapse:collapse;font-size:9pt"><tr style="background:#e5e7eb">'
	             '<td style="padding:4pt">Parameter</td><td style="padding:4pt;text-align:center">Result</td><td style="padding:4pt;text-align:center">Specification</td>'
	             '<td style="padding:4pt">Position (green = specification)</td><td style="padding:4pt;text-align:center">vs last visit</td><td style="padding:4pt">Trend</td></tr>')
	current = None
	for r in view:
		if r["value"] is None and not r["text"]:
			continue
		if r["point"] != current:
			current = r["point"]
			parts.append(f'<tr><td colspan="6" style="padding:5pt 4pt 2pt;font-weight:bold;border-bottom:1.5px solid #111827">{_esc(current or "Results")}</td></tr>')
		bad = r["status"] in OUT
		t = out["trends"].get((r["point"], r["parameter"]))
		change = ""
		if t and t["change"] is not None:
			arrow = "▲" if t["change"] > 0 else ("▼" if t["change"] < 0 else "●")
			change = f'{arrow} {abs(t["change"]):g}%<br><span style="color:#6b7280;font-size:7.5pt">was {t["previous"]:g}</span>'
		spec = doc_spec(r)
		parts.append(f'<tr><td style="padding:3pt 4pt;border-bottom:1px solid #e5e7eb">{_esc(r["parameter"])}{" (" + _esc(r["unit"]) + ")" if r["unit"] else ""}</td>'
		             f'<td style="padding:3pt 4pt;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:bold;'
		             f'{"color:#e00000;text-decoration:underline" if bad else "text-decoration:underline"}">{_esc(r["text"])}</td>'
		             f'<td style="padding:3pt 4pt;border-bottom:1px solid #e5e7eb;text-align:center">{_esc(spec)}</td>'
		             f'<td style="padding:3pt 4pt;border-bottom:1px solid #e5e7eb">{svg_spec_bar(r)}</td>'
		             f'<td style="padding:3pt 4pt;border-bottom:1px solid #e5e7eb;text-align:center;font-size:8.5pt">{change}</td>'
		             f'<td style="padding:3pt 4pt;border-bottom:1px solid #e5e7eb">{svg_sparkline(t["series"], bad=bad) if t else ""}</td></tr>')
	parts.append("</table>")
	# findings
	if out["findings"]:
		parts.append('<div style="font-weight:bold;font-size:11pt;margin:12pt 0 3pt">Findings and recommended actions</div><table style="width:100%;border-collapse:collapse">')
		for area, sev, finding, rec in out["findings"]:
			parts.append(f'<tr><td style="padding:4pt;vertical-align:top;width:13%;border-bottom:1px solid #e5e7eb">'
			             f'<span style="background:{CHIP.get(sev, "#6b7280")};color:#fff;border-radius:3pt;padding:1pt 5pt;font-size:8pt">{_esc(sev)}</span>'
			             f'<div style="font-size:7.5pt;color:#6b7280;margin-top:2pt">{_esc(area)}</div></td>'
			             f'<td style="padding:4pt;vertical-align:top;border-bottom:1px solid #e5e7eb">{_esc(finding)}'
			             f'<div style="color:#1f3864;margin-top:2pt">→ {_esc(rec)}</div></td></tr>')
		parts.append("</table>")
	parts.append('<div style="font-size:7.5pt;color:#6b7280;margin-top:8pt">Basis: cycles of concentration from boiler and feed TDS (or conductivity); '
	             'blowdown = capacity × b ÷ (1 − b), where b = 1 ÷ cycles; oxygen scavenger at 7.88 mg sodium sulphite per mg dissolved oxygen plus the '
	             'sulphite reserve lost in blowdown. Figures are engineering estimates from a single sample and should be confirmed on site.</div></div>')
	return "".join(parts)


def doc_spec(r):
	if r["nil"]:
		return "Nil"
	lo, hi = r["lo"], r["hi"]
	return f"{lo:g} - {hi:g}" if lo and hi else (f"<{hi:g}" if hi else (f">{lo:g}" if lo else ""))


def water_technical_section(doc):
	"""Jinja method for the Water Analysis Report."""
	import frappe

	system = frappe.get_doc("Client Water System", doc.water_system) if doc.get("water_system") else None
	view = doc.analytics_view()
	series, _last = doc.previous_series()
	out = analyse(view, {"type": system.system_type if system else None, "capacity_lph": doc.get("capacity_lph") or 0,
	                     "operating_hours": doc.get("operating_hours") or 24}, series)
	return technical_html(doc, view, out, system.system_type if system else None)
