from frappe.model.document import Document


class WaterTestParameter(Document):
	pass
