from frappe.model.document import Document


class TankReading(Document):
	pass
