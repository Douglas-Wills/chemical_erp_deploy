from frappe.model.document import Document


class SiteEquipment(Document):
	pass
