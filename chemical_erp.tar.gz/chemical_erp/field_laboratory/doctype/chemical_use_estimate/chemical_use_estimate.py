from frappe.model.document import Document


class ChemicalUseEstimate(Document):
	pass
