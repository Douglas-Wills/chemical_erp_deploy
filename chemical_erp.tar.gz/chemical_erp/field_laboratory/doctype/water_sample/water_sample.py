import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import flt

from chemical_erp.field_laboratory.specs import COMMON_POINTS, limits_for_point, point_limits, split_tests


class WaterSample(Document):
	def before_insert(self):
		self.sampled_by = frappe.session.user  # the technician is whoever is logged in

	def validate(self):
		if self.water_system and not self.sample_points:  # one piece of equipment: take all its points
			for p in frappe.get_doc("Client Water System", self.water_system).points:
				self.append("sample_points", {"water_system": self.water_system, "point_name": p.point_name})
		if not self.location and self.sample_points:
			self.location = frappe.db.get_value("Client Water System", self.sample_points[0].water_system, "site")
		if not self.client_representative and self.sample_points:
			self.client_representative = next((frappe.db.get_value("Client Water System", r.water_system, "contact_person")
			                                   for r in self.sample_points
			                                   if frappe.db.get_value("Client Water System", r.water_system, "contact_person")), None)
		seen = set()
		for i, row in enumerate(self.sample_points, 1):
			system = frappe.get_doc("Client Water System", row.water_system)
			if system.customer != self.customer:
				frappe.throw(_("Row {0}: {1} belongs to {2}, not {3}.").format(i, system.system_name, system.customer, self.customer))
			key = (row.water_system, row.point_name)
			if key in seen:
				frappe.throw(_("Row {0}: {1} at {2} is listed twice.").format(i, row.point_name, system.system_name))
			seen.add(key)
			row.bottle_code = f"{self.name}-{i}" if self.name and not self.is_new() else row.bottle_code
			defined = row.point_name in {p.point_name for p in system.points}
			if defined or not row.standard:  # an extra sample keeps the standard chosen for it
				limits = point_limits(system, row.point_name)
				row.standard = next((l.standard for _p, l in limits if l.standard), None) or system.standard
			if not (row.tests or "").strip():
				row.tests = ", ".join(limits_for_point(system, row.point_name, row.standard))
			unknown = [t for t in split_tests(row.tests) if not frappe.db.exists("Water Test Parameter", t)]
			if unknown:
				frappe.throw(_("Row {0}: unknown test(s): {1}. Use names from Water Test Parameter.").format(i, ", ".join(unknown)))
		if not self.water_system and self.sample_points:
			self.water_system = self.sample_points[0].water_system
		if self.meta.has_field("buffer_check"):
			from chemical_erp.utils import get_settings

			tol = flt(get_settings().get("lab_buffer_tolerance")) or 0.1
			self.buffer_check = ("Not Done" if not self.get("buffer_reading_ph")
			                     else ("Pass" if abs(flt(self.buffer_reading_ph) - 7.01) <= tol else "Fail"))
		if self.status == "Cancelled" and not (self.cancellation_reason or "").strip():
			frappe.throw(_("Give the reason the visit was cancelled."))

	def after_insert(self):
		for i, row in enumerate(self.sample_points, 1):  # bottle codes need the visit number
			row.db_set("bottle_code", f"{self.name}-{i}", update_modified=False)

	@frappe.whitelist()
	def start_analysis(self):
		"""One analysis per piece of equipment, with only the points and tests taken on this visit."""
		made = []
		for system_name in dict.fromkeys(r.water_system for r in self.sample_points):
			existing = frappe.db.get_value("Water Analysis", {"water_sample": self.name, "water_system": system_name, "docstatus": ["<", 2]}, "name")
			if existing:
				made.append(existing)
				continue
			system = frappe.get_doc("Client Water System", system_name)
			results = []
			for row in [r for r in self.sample_points if r.water_system == system_name]:
				for parameter in split_tests(row.tests):
					par = frappe.get_cached_doc("Water Test Parameter", parameter)
					results.append({"sample_point": row.point_name, "parameter": parameter, "tested_at": par.tested_at,
					                "method": par.method, "instrument": par.get("default_instrument")})
			wa = frappe.get_doc({"doctype": "Water Analysis", "water_sample": self.name, "water_system": system_name,
			                     "standard": system.standard, "originator": self.sampled_by,
			                     "results": results})
			wa.insert()
			made.append(wa.name)
		self.db_set({"water_analysis": made[0] if made else None, "status": "Analysed"})
		return made


@frappe.whitelist()
def equipment_points(water_system):
	"""For the Add Equipment dialog: the equipment's sample points and their tests."""
	system = frappe.get_doc("Client Water System", water_system)
	system.check_permission("read")
	return [{"point_name": p.point_name, "tests": ", ".join(par for par, _l in point_limits(system, p.point_name))} for p in system.points]


@frappe.whitelist()
def extra_sample_options(water_system):
	"""For the Add Sample dialog: suggested names, the equipment's default standard, and every field/lab test."""
	system = frappe.get_doc("Client Water System", water_system)
	system.check_permission("read")
	taken = {p.point_name for p in system.points}
	return {"suggestions": [p for p in COMMON_POINTS if p not in taken], "standard": system.standard,
	        "parameters": frappe.get_all("Water Test Parameter", filters={"tested_at": ["!=", "Calculated"]},
	                                     fields=["name", "unit", "tested_at"], order_by="name")}


@frappe.whitelist()
def standard_tests(standard):
	from chemical_erp.field_laboratory.specs import standard_limits

	return [p for p, _l in standard_limits(standard)]


@frappe.whitelist()
def client_equipment(customer):
	return frappe.get_all("Client Water System", filters={"customer": customer, "active": 1},
	                      fields=["name", "system_name", "system_type"], order_by="system_name")
