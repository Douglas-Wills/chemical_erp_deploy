frappe.ui.form.on("Water Sample", {
	setup(frm) {
		frm.set_query("water_system", () => ({ filters: { customer: frm.doc.customer, active: 1 } }));
		frm.set_query("water_system", "sample_points", () => ({ filters: { customer: frm.doc.customer, active: 1 } }));
	},
	refresh(frm) {
		frm.add_custom_button(__("Field Screen (works offline)"), () => window.open("/field-lab", "_blank"));
		frappe.call("chemical_erp.field_laboratory.calibration.readiness_status").then(({ message: bad }) => {
			if (!bad || !bad.length) return;
			frm.dashboard.set_headline_alert(
				`${__("Not calibrated")}: ${bad.map((i) => frappe.utils.escape_html(i.name)).join(", ")}. ` +
				__("Readings can be entered; the report cannot be signed until a calibration is on record."), "red");
			frm.add_custom_button(__("Prepare First Calibrations"), () =>
				frappe.call("chemical_erp.field_laboratory.calibration.prepare_first_calibrations").then(({ message: made }) => {
					if ((made || []).length === 1) frappe.set_route("Form", "Calibration Record", made[0]);
					else frappe.msgprint((made || []).map((n) => `<a href="/app/calibration-record/${n}">${n}</a>`).join("<br>"), __("Calibration records"));
				}));
		});
		if (frm.doc.docstatus === 0 && frm.doc.customer) {
			frm.add_custom_button(__("Add Equipment"), () => add_equipment(frm), __("Sample Points"));
			frm.add_custom_button(__("Add All Client Equipment"), () => add_all(frm), __("Sample Points"));
			frm.add_custom_button(__("Add Any Sample"), () => add_extra_sample(frm), __("Sample Points"));
		}
		if (frm.is_new()) return;
		frm.add_custom_button(__("Print Field Sheet"), () => frm.print_doc());
		if (frm.doc.status !== "Cancelled" && (frm.doc.sample_points || []).length) {
			frm.add_custom_button(__("Enter Results"), () => frm.call({ doc: frm.doc, method: "start_analysis" }).then((r) => {
				const made = r.message || [];
				if (made.length === 1) frappe.set_route("Form", "Water Analysis", made[0]);
				else frappe.msgprint({ title: __("Analyses"), indicator: "green",
					message: made.map((n) => `<a href="/app/water-analysis/${n}">${n}</a>`).join("<br>") });
			})).addClass("btn-primary");
		}
	},
});

function add_rows(frm, water_system, points) {
	points.forEach((p) => {
		if ((frm.doc.sample_points || []).some((r) => r.water_system === water_system && r.point_name === p.point_name)) return;
		frm.add_child("sample_points", { water_system, point_name: p.point_name, tests: p.tests });
	});
	frm.refresh_field("sample_points");
}

function add_equipment(frm) {
	const d = new frappe.ui.Dialog({
		title: __("Add Equipment"),
		fields: [
			{ fieldname: "water_system", fieldtype: "Link", options: "Client Water System", label: __("Equipment"), reqd: 1,
			  get_query: () => ({ filters: { customer: frm.doc.customer, active: 1 } }),
			  onchange() {
				const sys = d.get_value("water_system");
				if (!sys) return;
				frappe.call("chemical_erp.field_laboratory.doctype.water_sample.water_sample.equipment_points", { water_system: sys }).then((r) => {
					d.points = r.message || [];
					d.set_df_property("points_html", "options", d.points.map((p, i) =>
						`<label style="display:block;margin:4px 0"><input type="checkbox" data-i="${i}" checked> <b>${frappe.utils.escape_html(p.point_name)}</b>
						 <span class="text-muted small">${frappe.utils.escape_html(p.tests)}</span></label>`).join("") || __("This equipment has no sample points."));
				});
			} },
			{ fieldname: "points_html", fieldtype: "HTML", label: __("Sample Points") },
		],
		primary_action_label: __("Add"),
		primary_action(v) {
			const picked = [];
			d.$wrapper.find("input[data-i]:checked").each((_, el) => picked.push(d.points[$(el).data("i")]));
			add_rows(frm, v.water_system, picked);
			d.hide();
		},
	});
	d.show();
}

function add_all(frm) {
	frappe.call("chemical_erp.field_laboratory.doctype.water_sample.water_sample.client_equipment", { customer: frm.doc.customer }).then(async (r) => {
		for (const sys of r.message || []) {
			const pts = await frappe.call("chemical_erp.field_laboratory.doctype.water_sample.water_sample.equipment_points", { water_system: sys.name });
			add_rows(frm, sys.name, pts.message || []);
		}
		frappe.show_alert({ message: __("Sample points added"), indicator: "green" });
	});
}

function add_extra_sample(frm) {
	const esc = frappe.utils.escape_html;
	const draw_tests = (d, ticked) => {
		d.set_df_property("tests_html", "options", (d.params || []).map((p) =>
			`<label style="display:inline-block;width:49%;margin:2px 0"><input type="checkbox" data-p="${esc(p.name)}" ${ticked.includes(p.name) ? "checked" : ""}>
			 ${esc(p.name)} <span class="text-muted small">${esc(p.unit || "")}${p.tested_at === "Laboratory" ? " · lab" : ""}</span></label>`).join(""));
	};
	const load_standard = (d) => {
		const std = d.get_value("standard");
		if (!std) return draw_tests(d, []);
		frappe.call("chemical_erp.field_laboratory.doctype.water_sample.water_sample.standard_tests", { standard: std })
			.then((r) => draw_tests(d, r.message || []));
	};
	const d = new frappe.ui.Dialog({
		title: __("Add Any Sample"),
		fields: [
			{ fieldname: "water_system", fieldtype: "Link", options: "Client Water System", label: __("Equipment / system"), reqd: 1,
			  default: frm.doc.water_system, get_query: () => ({ filters: { customer: frm.doc.customer, active: 1 } }),
			  onchange() {
				const sys = d.get_value("water_system");
				if (!sys) return;
				frappe.call("chemical_erp.field_laboratory.doctype.water_sample.water_sample.extra_sample_options", { water_system: sys }).then((r) => {
					d.params = r.message.parameters;
					d.fields_dict.point_name.set_data(r.message.suggestions);
					if (!d.get_value("standard")) d.set_value("standard", r.message.standard); else load_standard(d);
				});
			} },
			{ fieldname: "point_name", fieldtype: "Autocomplete", label: __("Sample"), reqd: 1,
			  description: __("Pick a suggestion or type any name, e.g. Condensate Return, Softener Outlet, Raw Water Tap") },
			{ fieldname: "standard", fieldtype: "Link", options: "Water Standard", label: __("Judge against"),
			  get_query: () => ({ filters: { active: 1 } }), onchange: () => load_standard(d),
			  description: __("The tests in this specification are ticked below; change them as you like") },
			{ fieldname: "tests_html", fieldtype: "HTML", label: __("Tests") },
		],
		primary_action_label: __("Add Sample"),
		primary_action(v) {
			const tests = [];
			d.$wrapper.find("input[data-p]:checked").each((_, el) => tests.push($(el).data("p")));
			if (!tests.length) return frappe.msgprint(__("Tick at least one test."));
			if ((frm.doc.sample_points || []).some((r) => r.water_system === v.water_system && r.point_name === v.point_name))
				return frappe.msgprint(__("{0} is already on this visit.", [v.point_name]));
			frm.add_child("sample_points", { water_system: v.water_system, point_name: v.point_name, standard: v.standard, tests: tests.join(", ") });
			frm.refresh_field("sample_points");
			d.hide();
		},
	});
	d.show();
	if (frm.doc.water_system) d.fields_dict.water_system.df.onchange();
}
