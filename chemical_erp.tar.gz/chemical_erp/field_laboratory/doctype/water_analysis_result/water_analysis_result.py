from frappe.model.document import Document


class WaterAnalysisResult(Document):
	pass
