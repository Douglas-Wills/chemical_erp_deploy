from frappe.model.document import Document


class DosingRecommendation(Document):
	pass
