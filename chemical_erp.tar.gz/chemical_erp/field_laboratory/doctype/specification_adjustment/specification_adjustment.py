from frappe.model.document import Document


class SpecificationAdjustment(Document):
	pass
