frappe.ui.form.on("Water Standard", {
	refresh(frm) {
		if (frm.is_new()) return;
		frm.add_custom_button(__("Make Industry Version"), () => {
			frappe.prompt([
				{ fieldname: "industry", fieldtype: "Link", options: "Industry Type", label: __("Industry"), reqd: 1 },
				{ fieldname: "application", fieldtype: "Data", label: __("Application"), description: __("e.g. clean steam, low pressure") },
			], (v) => frm.call({ doc: frm.doc, method: "make_industry_version", args: v })
				.then((r) => frappe.set_route("Form", "Water Standard", r.message)), __("Make Industry Version"), __("Create"));
		});
		if (frm.doc.basis === "Statutory Standard") {
			frm.dashboard.set_headline_alert(__("A statutory standard: industry versions may tighten its limits but should not relax them."), "orange");
		}
	},
});
