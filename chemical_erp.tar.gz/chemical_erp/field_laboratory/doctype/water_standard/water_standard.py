import frappe
from frappe import _
from frappe.model.document import Document


class WaterStandard(Document):
	def validate(self):
		seen = set()
		for l in self.limits:
			if l.parameter in seen:
				frappe.throw(_("{0} is listed twice.").format(l.parameter))
			seen.add(l.parameter)
			if l.min_value and l.max_value and l.min_value > l.max_value:
				frappe.throw(_("{0}: minimum is above maximum.").format(l.parameter))

	@frappe.whitelist()
	def make_industry_version(self, industry, application=None):
		"""A copy of this standard for one industry, to tighten or relax its limits for that industry's demands."""
		base = self.standard_name.split(" - ")[0] if self.industry else self.standard_name
		name = f"{base} - {industry}"
		if frappe.db.exists("Water Standard", name):
			frappe.throw(_("{0} already exists.").format(name))
		copy = frappe.copy_doc(self)
		copy.standard_name, copy.industry, copy.application = name, industry, application or self.application
		copy.basis, copy.confirmed = "Client Specification" if self.basis == "Statutory Standard" else self.basis, 0
		copy.reference = _("Industry version of {0}: adjust the limits to the industry's demands").format(self.name)
		copy.insert()
		return copy.name
