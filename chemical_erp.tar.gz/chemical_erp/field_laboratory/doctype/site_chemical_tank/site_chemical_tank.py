from frappe.model.document import Document


class SiteChemicalTank(Document):
	pass
