from frappe.model.document import Document


class WaterSystemPoint(Document):
	pass
