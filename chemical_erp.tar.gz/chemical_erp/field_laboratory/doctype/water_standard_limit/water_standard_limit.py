from frappe.model.document import Document


class WaterStandardLimit(Document):
	pass
