import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, cint, today


class ClientWaterSystem(Document):
	def validate(self):
		from chemical_erp.field_laboratory.seed import DEFAULT_POINTS
		from chemical_erp.field_laboratory.specs import pick_standard

		if not self.points:
			for point, std in DEFAULT_POINTS.get(self.system_type, []):
				if frappe.db.exists("Water Standard", std):
					self.append("points", {"point_name": point, "standard": pick_standard(std, self.industry)})
		if not self.products:
			from chemical_erp.field_laboratory.seed import DEFAULT_PRODUCTS

			for code, note in DEFAULT_PRODUCTS.get(self.system_type, []):
				if frappe.db.exists("Item", code):
					self.append("products", {"item_code": code, "notes": note})
		every = cint(self.sampling_every_days) or 30
		self.next_due = add_days(self.last_sampled_on, every) if self.last_sampled_on else today()
		if not self.points and not self.standard:
			frappe.throw(_("Add at least one sample point with its specification (or a default specification)."))
		names = [p.point_name for p in self.points]
		if len(names) != len(set(names)):
			frappe.throw(_("Each sample point name must be different."))
		self.control_adjustments()

	def control_adjustments(self):
		"""Widening a window turns failures into passes, so only the quality approver or the MD approves an adjustment.
		Changing an approved adjustment sends it back for approval."""
		from chemical_erp.utils import approver_role, has_role, notify, position_title, users_with_role

		before = {a.name: a for a in (self.get_doc_before_save().spec_adjustments if self.get_doc_before_save() else [])}
		approver = has_role(approver_role("quality")) or has_role("Managing Director")
		pending = []
		for a in self.spec_adjustments:
			old = before.get(a.name)
			changed = old and (old.min_value, old.max_value, old.target_text, old.sample_point, old.parameter) != \
				(a.min_value, a.max_value, a.target_text, a.sample_point, a.parameter)
			if a.approved and (not old or not old.approved or changed):
				if not approver:
					if changed and old.approved:
						a.approved, a.approved_by = 0, None
					else:
						frappe.throw(_("Only the {0} or the Managing Director can approve a specification adjustment.").format(
							position_title("quality")), frappe.PermissionError)
				else:
					a.approved_by = frappe.session.user
			if not a.approved:
				a.approved_by = None
				pending.append(a)
		if pending and not approver:
			notify(users_with_role(approver_role("quality")), self.doctype, self.name,
			       _("{0} specification adjustment(s) on {1} ({2}) await approval").format(len(pending), self.system_name, self.customer))
