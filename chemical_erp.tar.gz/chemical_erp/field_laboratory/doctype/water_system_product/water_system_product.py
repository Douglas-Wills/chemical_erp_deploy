from frappe.model.document import Document


class WaterSystemProduct(Document):
	pass
