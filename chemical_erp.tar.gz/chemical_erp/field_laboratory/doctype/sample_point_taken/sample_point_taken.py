from frappe.model.document import Document


class SamplePointTaken(Document):
	pass
