from frappe.model.document import Document


class WaterAnalysisInsight(Document):
	pass
