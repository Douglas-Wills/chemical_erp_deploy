import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, cint, flt, getdate, now_datetime, today

from chemical_erp.utils import USABLE_EQUIPMENT

OUT = ("Above Limit", "Below Limit", "Not Met")


def fmt(v):
	return f"{flt(v):g}"


NIL = ("0", "nil", "none", "nil (0)")
TITLES = {"Boiler": "Boiler Water Analysis", "Cooling Tower": "Cooling Water Analysis", "Chiller": "Chiller Water Analysis"}


class WaterAnalysis(Document):
	def validate(self):
		system = frappe.get_doc("Client Water System", self.water_system) if self.water_system else None
		if system and not self.report_title:
			self.report_title = TITLES.get(system.system_type, f"{system.system_type} Analysis")
		from chemical_erp.field_laboratory.specs import effective_limits

		if system:
			limits = effective_limits(system)
		else:
			limits = {(None, l.parameter): frappe._dict(min_value=l.min_value, max_value=l.max_value, target_text=l.target_text,
			                                            standard=self.standard, adjusted=0, reason=None)
			          for l in (frappe.get_doc("Water Standard", self.standard).limits if self.standard else [])}
		chosen = {}  # extra samples added at the visit: point -> standard chosen for it
		if system and self.water_sample:
			defined = {p.point_name for p in system.points}
			for row in frappe.get_all("Sample Point Taken", filters={"parent": self.water_sample, "water_system": system.name},
			                          fields=["point_name", "standard"]):
				if row.point_name not in defined and row.standard:
					chosen[row.point_name] = row.standard
		if not self.results:
			for (point, parameter) in limits:
				par = frappe.get_cached_doc("Water Test Parameter", parameter)
				self.append("results", {"sample_point": point, "parameter": parameter, "tested_at": par.tested_at, "method": par.method,
				                        "instrument": par.default_instrument})
		for r in self.results:
			par = frappe.get_cached_doc("Water Test Parameter", r.parameter)
			r.unit = par.unit
			r.method = r.method or par.method
			r.method_reference = par.get("method_reference")
			r.tested_at = r.tested_at or par.tested_at
			if not r.instrument and par.get("default_instrument") and r.tested_at != "Calculated":
				r.instrument = par.default_instrument
			l = None
			if r.sample_point in chosen:
				from chemical_erp.field_laboratory.specs import limits_for_point

				l = limits_for_point(system, r.sample_point, chosen[r.sample_point]).get(r.parameter)
			else:
				l = limits.get((r.sample_point or None, r.parameter)) or limits.get((None, r.parameter))
			if not l and system and r.sample_point and r.sample_point not in chosen:
				from chemical_erp.field_laboratory.specs import point_limits

				l = dict(point_limits(system, r.sample_point)).get(r.parameter)
			r.min_value, r.max_value, r.target_text = (l.min_value, l.max_value, l.target_text) if l else (0, 0, None)
			r.adjusted, r.adjustment_reason, r.standard = (l.adjusted, l.reason, l.standard) if l else (0, None, None)
			r.limit_text = self.limit_text(r)
			r.status = self.status_of(r, par)
		state = self.get("workflow_state")
		signing = bool(state and state != "Draft") or self.docstatus == 1
		self.flags.tool_warnings = []
		for r in self.results:
			# A draft keeps whatever was read on site; an uncalibrated or expired tool stops only the signature.
			warning = self.check_tools(r, strict=signing and bool((r.result or "").strip()))
			if warning:
				self.flags.tool_warnings.append(warning)
		if self.flags.tool_warnings and not self.flags.get("from_field_device"):
			frappe.msgprint("<br>".join(dict.fromkeys(self.flags.tool_warnings)), title=_("Fix before signing"), indicator="orange")
		for c in self.chemical_use:
			if flt(c.daily_kg) and not flt(c.monthly_kg):
				c.monthly_kg = flt(c.daily_kg) * 30
			if c.item_code and not c.product_label:
				c.product_label = frappe.get_cached_value("Item", c.item_code, "item_name")
		self.run_analytics(system)
		statuses = [r.status for r in self.results]
		self.results_out = sum(1 for s in statuses if s in OUT)
		self.compliance = "Non-compliant" if self.results_out else ("Incomplete" if "Not Tested" in statuses or not statuses else "Compliant")
		state = self.get("workflow_state")
		if state and state != "Draft" or self.docstatus == 1:
			if self.compliance == "Non-compliant" and not (self.recommendations or "").strip() and not any(r.comment for r in self.results if r.status in OUT):
				frappe.throw(_("{0} result(s) are outside specification: comment on them or write recommendations before signing.").format(self.results_out),
				             title=_("Comments needed"))
		if state == "Analyst Signed" and not self.analyst_signed_by:
			self.analyst_signed_by, self.analyst_signed_on = frappe.session.user, now_datetime()

	# ------------------------------------------------------------------ technical analysis
	def analytics_view(self):
		rows = []
		for r in self.results:
			raw = (r.result or "").strip()
			rows.append({"point": r.sample_point or "", "parameter": r.parameter, "value": self.number(raw) if raw else None, "text": raw,
			             "lo": flt(r.min_value), "hi": flt(r.max_value), "nil": (r.target_text or "").strip().lower() in NIL,
			             "status": r.status, "unit": r.unit})
		return rows

	def previous_series(self):
		"""Results from up to five earlier issued reports for the same equipment, oldest first."""
		if not self.water_system:
			return {}, None
		prev = frappe.get_all("Water Analysis", filters={"water_system": self.water_system, "docstatus": 1, "name": ["!=", self.name or ""],
		                                                 "analysed_on": ["<=", self.analysed_on]}, fields=["name"], order_by="analysed_on desc", limit=5)
		series = {}
		for p in reversed(prev):
			for r in frappe.get_all("Water Analysis Result", filters={"parent": p.name}, fields=["sample_point", "parameter", "result"]):
				series.setdefault((r.sample_point or "", r.parameter), []).append(self.number(r.result) if (r.result or "").strip() else None)
		return series, (prev[0].name if prev else None)

	def run_analytics(self, system):
		from chemical_erp.field_laboratory.analytics import analyse

		series, last = self.previous_series()
		out = analyse(self.analytics_view(), {"type": system.system_type if system else None, "capacity_lph": flt(self.capacity_lph),
		                                      "operating_hours": flt(self.operating_hours) or 24}, series)
		self.compliance_score = out["score"]
		self.cycles_of_concentration, self.max_cycles = out["coc"], out["max_coc"]
		self.blowdown_now_lph, self.blowdown_needed_lph = out["bd_now"], out["bd_needed"]
		self.scavenger_kg_day, self.lsi, self.rsi = out["scavenger"], out["lsi"], out["rsi"]
		self.previous_analysis = last
		self.scale_risk, self.corrosion_risk = out["risks"]["Scale"], out["risks"]["Corrosion"]
		self.carryover_risk, self.micro_risk = out["risks"]["Carryover"], out["risks"]["Microbiological"]
		manual = [i for i in self.insights if not i.auto]
		self.set("insights", [])
		for area, sev, finding, rec in out["findings"]:
			self.append("insights", {"area": area, "severity": sev, "finding": finding, "recommendation": rec, "auto": 1})
		for r in self.results:  # method checks: reading above the method's range; limit tighter than the method can detect
			par = frappe.get_cached_doc("Water Test Parameter", r.parameter)
			value = self.number(r.result) if (r.result or "").strip() and not (r.result or "").strip().startswith("<") else None
			ref = par.get("method_reference") or par.method or ""
			if value is not None and flt(par.get("range_max")) and value > flt(par.range_max) and not r.dilution:
				self.append("insights", {"area": "Measurement Check", "severity": "Medium", "auto": 1,
				                         "finding": f"{r.sample_point + ': ' if r.sample_point else ''}{r.parameter} {r.result} is above the range of {ref} "
				                                    f"({flt(par.range_max):g}).",
				                         "recommendation": "Dilute the sample, retest, and record the dilution used." +
				                                           (f" Alternative: {par.alternative_method}" if par.get("alternative_method") else "")})
			if r.status == "Below Detection Limit" or (flt(r.max_value) and flt(par.get("range_min")) and flt(r.max_value) < flt(par.range_min)):
				self.append("insights", {"area": "Measurement Check", "severity": "Low", "auto": 1,
				                         "finding": f"{r.parameter}: the specification (<{flt(r.max_value):g}) is below what {ref} can detect "
				                                    f"({flt(par.range_min):g}), so compliance cannot be proven with this method.",
				                         "recommendation": "Report as below the detection limit, or align the specification with the method's limit."})
		self.buffer_insight()
		for i in manual:
			self.append("insights", i.as_dict())
		self.flags.trends = out["trends"]

	def buffer_insight(self):
		"""The pH 7.01 buffer read on site before testing (Water Sample)."""
		if not self.water_sample or not frappe.get_meta("Water Sample").has_field("buffer_check"):
			return
		ws = frappe.db.get_value("Water Sample", self.water_sample, ["buffer_reading_ph", "buffer_check"], as_dict=True) or {}
		if not any(r.parameter == "pH" or (r.parameter or "").startswith("pH") for r in self.results):
			return
		if ws.get("buffer_check") == "Fail":
			self.append("insights", {"area": "Measurement Check", "severity": "Medium", "auto": 1,
			                         "finding": f"The pH meter read {flt(ws.buffer_reading_ph):g} on the pH 7.01 buffer before testing.",
			                         "recommendation": "Recalibrate the pH meter (two-point) and re-read pH before issuing this report."})
		elif ws.get("buffer_check") in (None, "", "Not Done"):
			self.append("insights", {"area": "Measurement Check", "severity": "Low", "auto": 1,
			                         "finding": "No on-site pH buffer check was recorded for this visit.",
			                         "recommendation": "Read the pH 7.01 buffer at the start of each visit and record it on the visit."})

	@frappe.whitelist()
	def draft_interpretation(self):
		"""Suggested observations and recommendations from the findings, for the analyst to edit."""
		top = [i for i in self.insights if i.severity in ("High", "Medium")] or list(self.insights)
		seen, recs = set(), []
		for i in top:
			if i.recommendation and i.recommendation not in seen:
				seen.add(i.recommendation)
				recs.append(f"{len(recs) + 1}. {i.recommendation}")
		obs = (f"Compliance {self.compliance_score:g}% ({self.results_out} result(s) outside specification). "
		       + " ".join(i.finding for i in top[:6]))
		return {"observations": obs, "recommendations": "\n".join(recs)}

	@staticmethod
	def limit_text(r):
		unit = f" {r.unit}" if r.unit else ""
		if (r.target_text or "").strip().lower() in NIL:
			return "Nil"
		lo, hi = flt(r.min_value), flt(r.max_value)
		if lo and hi:
			return f"{fmt(lo)} - {fmt(hi)}{unit}"
		if hi:
			return f"<{fmt(hi)}{unit}"
		if lo:
			return f">{fmt(lo)}{unit}"
		return r.target_text or ""

	@staticmethod
	def number(value):
		try:
			return float(str(value).replace(",", "").strip())
		except (TypeError, ValueError):
			return None

	@classmethod
	def status_of(cls, r, par):
		raw = (r.result or "").strip()
		if not raw:
			return "Not Tested"
		target = (r.target_text or "").strip().lower()
		if raw.startswith("<") and not cint(par.qualitative):
			# below the method's detection limit, e.g. "<0.010"
			dl = cls.number(raw[1:])
			if dl is not None:
				lo, hi = flt(r.min_value), flt(r.max_value)
				if target in NIL or (hi and dl <= hi):
					return "Within Limit"
				if lo and dl <= lo:
					return "Below Limit"
				return "Below Detection Limit" if hi else "No Limit Set"
		value = None if cint(par.qualitative) else cls.number(raw)
		if value is None:  # a text result (visual tests, or a note instead of a number)
			if r.target_text and target not in NIL:
				return "Within Limit" if raw.lower() == target else "Not Met"
			return "No Limit Set"
		if target in NIL:
			return "Within Limit" if value <= 0 else "Above Limit"
		lo, hi = flt(r.min_value), flt(r.max_value)
		if not (lo or hi):
			return "No Limit Set"
		if hi and value > hi:
			return "Above Limit"
		if lo and value < lo:
			return "Below Limit"
		return "Within Limit"

	@staticmethod
	def check_tools(r, strict=True):
		"""Returns a warning for a draft; stops signing (strict) when an instrument or reagent cannot be relied on."""
		problem = None
		if r.instrument:
			status = frappe.db.get_value("Equipment", r.instrument, "status")
			if status not in USABLE_EQUIPMENT:
				never = not frappe.db.get_value("Equipment", r.instrument, "last_calibration")
				problem = (_("{0}: instrument {1} has no calibration on record. Record its first calibration, then sign.")
				           if never else _("{0}: instrument {1} is {2} and cannot be used.")).format(r.parameter, r.instrument, status)
		if not problem and r.reagent:
			rs = frappe.db.get_value("Reagent Solution", r.reagent, ["status", "expires_on"], as_dict=True)
			if not rs or rs.status != "Valid" or getdate(rs.expires_on) < getdate(today()):
				problem = _("{0}: reagent {1} is expired or discarded.").format(r.parameter, r.reagent)
		if problem and strict:
			frappe.throw(problem, title=_("Instrument or reagent not usable"))
		return problem

	def on_submit(self):
		others = frappe.db.count("Water Analysis", {"water_sample": self.water_sample, "docstatus": 0, "name": ["!=", self.name]})
		if not others:
			frappe.db.set_value("Water Sample", self.water_sample, "status", "Reported")
		sampled = frappe.db.get_value("Water Sample", self.water_sample, "sampled_on")
		every = cint(frappe.db.get_value("Client Water System", self.water_system, "sampling_every_days")) or 30
		frappe.db.set_value("Client Water System", self.water_system,
		                    {"last_sampled_on": getdate(sampled), "next_due": add_days(getdate(sampled), every)})
		if self.compliance == "Non-compliant":
			from chemical_erp.utils import notify, users_with_role

			notify(users_with_role("Sales Manager"), self.doctype, self.name,
			       _("Water analysis {0} for {1}: {2} result(s) outside limits. Follow up with the customer.").format(
				       self.name, self.customer, self.results_out))

	def on_cancel(self):
		frappe.db.set_value("Water Sample", self.water_sample, "status", "Analysed")

	@frappe.whitelist()
	def make_invoice(self):
		"""A draft invoice for the analysis service; the price comes from the service item's selling price."""
		if self.sales_invoice:
			return self.sales_invoice
		item = frappe.db.get_single_value("Chemical ERP Settings", "lab_service_item")
		if not item:
			frappe.throw(_("Choose the water analysis service item in Chemical ERP Settings (Field Laboratory)."))
		system = frappe.db.get_value("Client Water System", self.water_system, "system_name")
		si = frappe.get_doc({"doctype": "Sales Invoice", "customer": self.customer, "company": frappe.defaults.get_user_default("Company"),
		                     "items": [{"item_code": item, "qty": 1, "description": _("Water analysis {0}: {1}, sample {2}").format(
			                     self.name, system, self.water_sample)}]})
		si.run_method("set_missing_values")
		si.insert()
		self.db_set("sales_invoice", si.name)
		return si.name
