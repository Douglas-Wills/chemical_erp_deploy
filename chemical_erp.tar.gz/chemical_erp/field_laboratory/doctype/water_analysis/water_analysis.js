frappe.ui.form.on("Water Analysis", {
	refresh(frm) {
		if (frm.doc.docstatus === 1 && !frm.doc.sales_invoice) {
			frm.add_custom_button(__("Make Invoice"), () => frm.call({ doc: frm.doc, method: "make_invoice" })
				.then((r) => frappe.set_route("Form", "Sales Invoice", r.message)), __("Create"));
		}
		if (frm.doc.docstatus === 0 && (frm.doc.insights || []).length) {
			frm.add_custom_button(__("Draft Interpretation"), () => frm.call({ doc: frm.doc, method: "draft_interpretation" }).then((r) => {
				const apply = () => { frm.set_value("observations", r.message.observations); frm.set_value("recommendations", r.message.recommendations); };
				if (frm.doc.observations || frm.doc.recommendations) frappe.confirm(__("Replace the current observations and recommendations with the drafted text?"), apply);
				else apply();
			}), __("Actions"));
		}
		if (frm.doc.water_system) {
			frm.add_custom_button(__("Trend for This System"), () => frappe.set_route("query-report", "Water Trend", { water_system: frm.doc.water_system }), __("View"));
		}
		const c = { Compliant: "green", "Non-compliant": "red", Incomplete: "orange" }[frm.doc.compliance];
		if (c) frm.dashboard.set_headline_alert(__("{0}: {1} result(s) outside limits", [frm.doc.compliance, frm.doc.results_out || 0]), c);
	},
});
