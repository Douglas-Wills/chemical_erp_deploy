"""Starter lists for the Field Laboratory. Created only when the lists are empty; edit freely afterwards.

- Boiler and feed-water specifications are the ones printed on Brave's boiler water reports.
- Cooling tower and chiller ranges are typical guides, marked 'confirm before use'.
- Drinking-water (US EAS 12) and NEMA effluent standards list their parameters without limits: enter those from the
  official text.
- Instruments: HANNA meter (pH, temperature, TDS, conductivity) and HACH DR900 colorimeter (colorimetric tests)."""

import frappe

HANNA, DR900 = "LAB-HANNA-01", "LAB-HACH-DR900"
INSTRUMENTS = [
	(HANNA, "HANNA Combo HI98130 (pH / EC / TDS / temperature, high range)", "HANNA Instruments", "HI98130", 30,
	 "pH ±0.05; EC and TDS ±2% of full scale; temperature ±0.5 °C",
	 "pH: two-point with buffers (7.01 plus 4.01 or 10.01). EC/TDS: one point at 12880 µS/cm or 6.44 ppt. "
	 "Keep the EC-to-TDS conversion factor fixed (0.5 matches Brave's reports)."),
	(DR900, "HACH DR900 colorimeter", "HACH", "DR900", 365, "Within the verification standard's stated range",
	 "Verification with HACH SpecCheck secondary standards or known standard solutions"),
]

# name, unit, tested at, method, method reference, range min, range max, alternative method, sample handling, qualitative, instrument
P = lambda *a: a
PARAMETERS = [
	P("pH", "", "Field", "Glass electrode, automatic temperature compensation", "HANNA HI98130", 0, 14,
	  "", "Calibrate before each visit. For boiler water use 7.01 and 10.01 buffers.", 0, HANNA),
	P("Temperature", "°C", "Field", "Built-in sensor", "HANNA HI98130", 0, 60, "", "Read at the sampling point.", 0, HANNA),
	P("Conductivity", "µS/cm", "Field", "Amperometric EC probe, temperature compensated", "HANNA HI98130", 0, 20000,
	  "HANNA HI98129 (0 to 3999 µS/cm) gives finer resolution for feed water", "Cool hot samples before reading.", 0, HANNA),
	P("Total Dissolved Solids", "ppm", "Field", "From conductivity (conversion factor 0.5)", "HANNA HI98130", 0, 10000,
	  "HANNA HI98129 (0 to 2000 ppm) for feed water", "Keep the same conversion factor on every visit so results compare.", 0, HANNA),
	P("Total Hardness", "ppm", "Field", "Calmagite colorimetric", "HACH Method 8030", 0.05, 4.0,
	  "Above 4 ppm (e.g. boiler water): EDTA titration, HACH Method 8213, or dilute", "", 0, DR900),
	P("Calcium Hardness", "ppm", "Field", "Calmagite colorimetric", "HACH Method 8030", 0.05, 4.0, "EDTA titration above range", "", 0, DR900),
	P("P-Alkalinity", "ppm", "Field", "Acid titration to pH 8.3", "Titration", 0, 0, "", "", 0, None),
	P("M-Alkalinity (Total Alkalinity)", "ppm", "Field", "Acid titration to pH 4.5", "Titration", 0, 0, "", "", 0, None),
	P("OH-Alkalinity", "ppm", "Calculated", "2P - M", "Calculation", 0, 0, "", "", 0, None),
	P("Chloride", "ppm", "Field", "Argentometric titration", "Titration", 0, 0, "", "", 0, None),
	P("Sulphites", "ppm", "Field", "Iodate-iodide titration (not a DR900 test)", "HACH Method 8216 (digital titrator)", 4, 400,
	  "HACH Method 8071, buret titration, 0 to 500 mg/L", "Test immediately on site: sulphite reacts with air. Do not keep the sample.", 0, None),
	P("Dissolved Oxygen", "mg/L", "Field", "HRDO AccuVac ampoule", "HACH Method 8166", 0.3, 15.0,
	  "Low range: indigo carmine AccuVac, HACH Method 8316, 10 to 1000 µg/L on the DR900 (enter as mg/L, e.g. 0.010)",
	  "Test immediately from a flowing sample; avoid rubber tubing and air contact.", 0, DR900),
	P("Phosphates", "ppm", "Field", "Molybdovanadate", "HACH Method 8114", 0.3, 45.0,
	  "Low range: PhosVer 3, HACH Method 8048, 0.06 to 5.00 mg/L. Dilute boiler water above 45 ppm.",
	  "Do not wash bottles with phosphate detergent.", 0, DR900),
	P("Iron (Total)", "mg/L", "Field", "FerroVer (1,10-phenanthroline)", "HACH Method 8008", 0.02, 3.00,
	  "", "Digestion is needed for true total iron; filter at once for dissolved iron only.", 0, DR900),
	P("Silica", "mg/L", "Field", "Silicomolybdate (high range)", "HACH Method 8185", 1, 100,
	  "Low range: heteropoly blue, HACH Method 8186, 0 to 1.60 mg/L", "", 0, DR900),
	P("Free Residual Chlorine", "mg/L", "Field", "DPD", "HACH Method 8021", 0.02, 2.00, "", "Test immediately.", 0, DR900),
	P("Total Chlorine", "mg/L", "Field", "DPD", "HACH Method 8167", 0.02, 2.00, "", "Test immediately.", 0, DR900),
	P("Sulphate", "mg/L", "Field", "SulfaVer 4", "HACH Method 8051", 2, 70, "", "", 0, DR900),
	P("Manganese", "mg/L", "Field", "PAN (low range)", "HACH Method 8149", 0.006, 0.7, "", "", 0, DR900),
	P("Nitrite", "mg/L", "Field", "Diazotization (low range)", "HACH Method 8507", 0, 0, "", "", 0, DR900),
	P("Nitrate", "mg/L", "Field", "Cadmium reduction", "HACH colorimetric", 0, 0, "", "", 0, DR900),
	P("Ammonia", "mg/L", "Field", "Salicylate", "HACH colorimetric", 0, 0, "", "", 0, DR900),
	P("Colour", "Pt-Co", "Field", "Platinum-cobalt", "HACH colorimetric", 0, 0, "", "", 0, DR900),
	P("Turbidity", "NTU", "Field", "Turbidity meter", "", 0, 0, "", "", 0, None),
	P("Appearance", "", "Field", "Visual", "", 0, 0, "", "", 1, None),
	P("Total Coliforms", "CFU/100 mL", "Laboratory", "Membrane filtration / dip slide", "", 0, 0, "", "", 0, None),
	P("Cycles of Concentration", "", "Calculated", "Tower / make-up conductivity", "Calculation", 0, 0, "", "", 0, None),
]
FIELDS = ("parameter_name", "unit", "tested_at", "method", "method_reference", "range_min", "range_max", "alternative_method",
          "sample_handling", "qualitative", "default_instrument")

CONFIRM = "Guide range: confirm before use"
BRAVE_SPEC = "Specification printed on Brave boiler water reports"
STANDARDS = [
	("Boiler Water", "Boiler", "Internal Guide", BRAVE_SPEC, 1, [
		("pH", 9, 12.5, None), ("Total Dissolved Solids", None, 2000, None), ("Conductivity", None, 5000, None),
		("Total Hardness", None, 10, None), ("Sulphites", 10, 70, None), ("Dissolved Oxygen", None, 0.007, None),
		("Phosphates", 10, 80, None), ("Iron (Total)", None, 1.0, None)]),
	("Boiler Feed Water", "Boiler", "Internal Guide", BRAVE_SPEC, 1, [
		("pH", 7, 8.5, None), ("Total Dissolved Solids", None, 100, None), ("Conductivity", None, 200, None),
		("Total Hardness", None, None, "Nil"), ("Dissolved Oxygen", None, 0.007, None), ("Iron (Total)", None, 0.1, None)]),
	("Cooling Tower Water (Guide)", "Cooling Tower", "Industry Guide", "Typical guide for open recirculating towers", 0, [
		("pH", 7.5, 9.0, None), ("Conductivity", None, 3000, None), ("Total Hardness", None, 800, None), ("Chloride", None, 500, None),
		("Iron (Total)", None, 1, None), ("Free Residual Chlorine", 0.2, 1.0, None), ("Total Coliforms", None, 10000, None),
		("Cycles of Concentration", 3, 6, None)]),
	("Cooling Tower Make-up Water (Guide)", "Cooling Tower", "Industry Guide", "Typical make-up water guide", 0, [
		("pH", 6.5, 8.5, None), ("Conductivity", None, 1000, None), ("Total Hardness", None, 300, None)]),
	("Chiller Closed Loop (Guide)", "Chiller", "Industry Guide", "Typical guide for closed chilled-water loops", 0, [
		("pH", 8.5, 10.5, None), ("Iron (Total)", None, 1, None), ("Appearance", None, None, "Clear")]),
	("Drinking Water - US EAS 12 (enter limits)", "Drinking Water", "Statutory Standard", "US EAS 12: enter limits from the published standard", 0, [
		("pH", None, None, None), ("Turbidity", None, None, None), ("Colour", None, None, None), ("Total Dissolved Solids", None, None, None),
		("Total Hardness", None, None, None), ("Iron (Total)", None, None, None), ("Free Residual Chlorine", None, None, None),
		("Nitrate", None, None, None), ("Total Coliforms", None, None, None)]),
	("Effluent Discharge - NEMA (enter limits)", "Effluent", "Statutory Standard", "NEMA effluent regulations: enter limits from the gazetted text", 0, [
		("pH", None, None, None), ("Temperature", None, None, None), ("Colour", None, None, None), ("Ammonia", None, None, None)]),
]

DEFAULT_PRODUCTS = {  # Brave's treatment range by equipment type (added only if the items exist)
	"Boiler": [("SCAV-1204", "Oxygen scavenger"), ("AQUATREAT-9510", "Scale and corrosion inhibitor")],
	"Cooling Tower": [("COTOCIDE-1402", "Biocide"), ("COTOCIDE-1403", "Biocide (alternate)"), ("BR-HYPO-12", "Oxidising biocide")],
	"Chiller": [("AQUATREAT-9510", "Closed-loop corrosion inhibitor")],
}

DEFAULT_POINTS = {
	"Boiler": [("Boiler Water", "Boiler Water"), ("Feed Water", "Boiler Feed Water")],
	"Cooling Tower": [("Tower Water", "Cooling Tower Water (Guide)"), ("Make-up Water", "Cooling Tower Make-up Water (Guide)")],
	"Chiller": [("Chilled Water Loop", "Chiller Closed Loop (Guide)")],
}


def ensure_instruments():
	"""The field instruments, as calibrated laboratory equipment. Enter a first Calibration Record for each before use."""
	if not frappe.db.exists("DocType", "Equipment"):
		return
	for code, name, maker, model, interval, tol, method in INSTRUMENTS:
		if frappe.db.exists("Equipment", code):
			continue
		frappe.get_doc({"doctype": "Equipment", "equipment_code": code, "equipment_name": name, "category": "Laboratory Instrument",
		                "criticality": "A - Quality or safety", "manufacturer": maker, "model": model, "location": "Field kit",
		                "requires_calibration": 1, "calibration_interval_days": interval, "tolerance": tol,
		                "calibration_method": method}).insert(ignore_permissions=True)


def ensure_seed(brave=False):
	if brave:
		ensure_instruments()
	for row in PARAMETERS:
		values = dict(zip(FIELDS, row))
		inst = values["default_instrument"]
		values["default_instrument"] = inst if inst and frappe.db.exists("Equipment", inst) else None
		name = values["parameter_name"]
		if not frappe.db.exists("Water Test Parameter", name):
			frappe.get_doc({"doctype": "Water Test Parameter", **values}).insert(ignore_permissions=True)
		elif not frappe.db.get_value("Water Test Parameter", name, "method_reference"):
			# earlier installs: add the method details without touching anything already filled in
			frappe.db.set_value("Water Test Parameter", name, {k: v for k, v in values.items()
			                                                    if k in ("method", "method_reference", "range_min", "range_max",
			                                                             "alternative_method", "sample_handling")})
	add_iron_to_boiler_specs()
	add_coliforms_to_cooling_spec()
	if not frappe.db.count("Water Standard"):
		for name, wtype, basis, ref, confirmed, limits in STANDARDS:
			if ref == BRAVE_SPEC and not brave:
				ref, confirmed, basis = "Typical specification: confirm before use", 0, "Industry Guide"
			frappe.get_doc({"doctype": "Water Standard", "standard_name": name, "water_type": wtype, "basis": basis, "reference": ref,
			                "confirmed": confirmed,
			                "limits": [{"parameter": p, "min_value": lo or 0, "max_value": hi or 0, "target_text": t,
			                            "notes": CONFIRM if basis == "Industry Guide" or p == "Iron (Total)" else ("" if confirmed else "Enter from the source")}
			                           for p, lo, hi, t in limits]}).insert(ignore_permissions=True)


IRON_GUIDE = {"Boiler Water": 1.0, "Boiler Feed Water": 0.1}


def add_iron_to_boiler_specs():
	"""Iron is tested on boilers: add it to the boiler specifications already installed (guide limits, to be confirmed)."""
	for std, limit in IRON_GUIDE.items():
		if frappe.db.exists("Water Standard", std) and not frappe.db.exists("Water Standard Limit", {"parent": std, "parameter": "Iron (Total)"}):
			doc = frappe.get_doc("Water Standard", std)
			doc.append("limits", {"parameter": "Iron (Total)", "max_value": limit, "notes": CONFIRM})
			doc.flags.ignore_permissions = True
			doc.save()


def add_coliforms_to_cooling_spec():
	"""Microbiological risk is assessed on cooling towers: put the bacteria guide back on specifications already installed."""
	std = "Cooling Tower Water (Guide)"
	if frappe.db.exists("Water Standard", std) and frappe.db.exists("Water Test Parameter", "Total Coliforms") \
			and not frappe.db.exists("Water Standard Limit", {"parent": std, "parameter": "Total Coliforms"}):
		doc = frappe.get_doc("Water Standard", std)
		doc.append("limits", {"parameter": "Total Coliforms", "max_value": 10000, "notes": CONFIRM})
		doc.flags.ignore_permissions = True
		doc.save()


def due_for_sampling():
	"""Daily: remind the responsible technician three days before equipment is due for sampling."""
	from frappe import _
	from frappe.utils import add_days, today

	from chemical_erp.utils import notify, users_with_role

	for s in frappe.get_all("Client Water System", filters={"active": 1, "next_due": ["<=", add_days(today(), 3)]},
	                        fields=["name", "system_name", "customer", "next_due", "responsible"]):
		who = [s.responsible] if s.responsible else users_with_role("Field Technician") + users_with_role("QC Analyst")
		notify(who, "Client Water System", s.name, _("Water sampling due {0}: {1} at {2}").format(s.next_due, s.system_name, s.customer))
	from chemical_erp.field_laboratory.calibration import remind

	remind()
