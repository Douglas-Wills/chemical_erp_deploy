/* Field Lab service worker: keeps the /field-lab screen on the device so it opens with no signal.
   Readings themselves live in the page's local storage until they are synced. */
const CACHE = "fieldlab-__VERSION__";
const PAGE = "/field-lab";

async function refreshPage() {
	const res = await fetch(PAGE, { credentials: "same-origin", cache: "no-store" });
	// never keep a login page in place of the screen
	if (res.ok && !res.redirected && new URL(res.url).pathname === PAGE) {
		const cache = await caches.open(CACHE);
		await cache.put(PAGE, res.clone());
	}
	return res;
}

self.addEventListener("install", (event) => {
	event.waitUntil(refreshPage().catch(() => null).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
	event.waitUntil(caches.keys()
		.then((keys) => Promise.all(keys.filter((k) => k.startsWith("fieldlab-") && k !== CACHE).map((k) => caches.delete(k))))
		.then(() => self.clients.claim()));
});

self.addEventListener("fetch", (event) => {
	const url = new URL(event.request.url);
	if (event.request.method !== "GET" || url.origin !== self.location.origin) return;
	if (url.pathname === PAGE) {
		event.respondWith((async () => {
			try {
				const res = await Promise.race([refreshPage(), new Promise((_, reject) => setTimeout(() => reject(new Error("slow")), 5000))]);
				if (res.ok) return res;
				throw new Error("bad");
			} catch (e) {
				const cached = await caches.match(PAGE);
				return cached || new Response("<h3>Field Lab</h3><p>Open this page once while online to keep it on this device.</p>",
					{ headers: { "Content-Type": "text/html" } });
			}
		})());
	}
});
