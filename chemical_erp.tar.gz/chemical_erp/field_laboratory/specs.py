"""The specification each result is judged against: the sample point's standard (an industry version where the
customer's industry has one), with this equipment's approved adjustments applied on top."""

import frappe
from frappe import _

NIL = ("0", "nil", "none", "nil (0)")


def pick_standard(base_name, industry):
	"""An industry version of a standard if one exists (same base name, tagged with the industry), else the base."""
	if industry:
		version = frappe.db.get_value("Water Standard", {"industry": industry, "active": 1, "standard_name": ["like", f"{base_name}%"]}, "name")
		if version:
			return version
	return base_name


def effective_limits(system):
	"""Ordered {(point, parameter): limit dict} for a Client Water System."""
	points = [(p.point_name, p.standard) for p in system.points] or [(None, system.standard)]
	limits = {}
	for point, std in points:
		if not std:
			continue
		for l in frappe.get_doc("Water Standard", std).limits:
			limits[(point, l.parameter)] = frappe._dict(min_value=l.min_value, max_value=l.max_value, target_text=l.target_text,
			                                            standard=std, adjusted=0, reason=None)
	for a in system.get("spec_adjustments") or []:
		if not a.approved:
			continue
		targets = [(a.sample_point, a.parameter)] if a.sample_point else [(p, a.parameter) for p, _s in points]
		for key in targets:
			base = limits.get(key) or frappe._dict(standard=dict(points).get(key[0]))
			base.update(min_value=a.min_value, max_value=a.max_value, target_text=a.target_text, adjusted=1, reason=a.reason)
			limits[key] = base
	return limits


def spec_text(lim, unit=None):
	u = f" {unit}" if unit else ""
	if (lim.get("target_text") or "").strip().lower() in NIL:
		return "Nil"
	lo, hi = lim.get("min_value") or 0, lim.get("max_value") or 0
	if lo and hi:
		return f"{lo:g} - {hi:g}{u}"
	if hi:
		return f"<{hi:g}{u}"
	if lo:
		return f">{lo:g}{u}"
	return lim.get("target_text") or ""


def sheet_rows(system):
	"""For the Field Sampling Sheet: per point, the parameters with their effective specification and usual instrument."""
	out = []
	for (point, parameter), lim in effective_limits(system).items():
		par = frappe.get_cached_doc("Water Test Parameter", parameter)
		block = next((b for b in out if b["point"] == point), None)
		if not block:
			block = {"point": point or _("Results"), "rows": []}
			out.append(block)
		block["rows"].append({"parameter": parameter, "unit": par.unit, "spec": spec_text(lim, par.unit) + ("*" if lim.adjusted else ""),
		                      "instrument": frappe.db.get_value("Equipment", par.default_instrument, "equipment_name") if par.default_instrument else ""})
	return out


def water_sheet_rows(system):
	"""Jinja name for sheet_rows."""
	return sheet_rows(system)


def point_limits(system, point_name):
	"""Ordered [(parameter, limit)] for one sample point of a piece of equipment. A point not listed on the equipment
	uses the equipment's default specification."""
	eff = effective_limits(system)
	rows = [(par, lim) for (pt, par), lim in eff.items() if pt == point_name]
	if rows or not system.get("standard"):
		return rows
	out = []
	for l in frappe.get_doc("Water Standard", system.standard).limits:
		out.append((l.parameter, frappe._dict(min_value=l.min_value, max_value=l.max_value, target_text=l.target_text,
		                                      standard=system.standard, adjusted=0, reason=None)))
	for a in system.get("spec_adjustments") or []:
		if a.approved and not a.sample_point:
			lim = frappe._dict(min_value=a.min_value, max_value=a.max_value, target_text=a.target_text, standard=system.standard,
			                   adjusted=1, reason=a.reason)
			out = [(p, lim if p == a.parameter else l) for p, l in out] + ([] if any(p == a.parameter for p, _l in out) else [(a.parameter, lim)])
	return out


def standard_limits(standard):
	"""[(parameter, limit)] straight from a Water Standard."""
	if not standard or not frappe.db.exists("Water Standard", standard):
		return []
	return [(l.parameter, frappe._dict(min_value=l.min_value, max_value=l.max_value, target_text=l.target_text, standard=standard,
	                                   adjusted=0, reason=None)) for l in frappe.get_doc("Water Standard", standard).limits]


def limits_for_point(system, point_name, standard=None):
	"""{parameter: limit} for any sample. A point set up on the equipment uses its own specification (with adjustments);
	an extra sample the technician added (condensate, softener outlet, raw water…) uses the standard chosen for it,
	falling back to the equipment's default specification."""
	defined = {p.point_name for p in system.points}
	if point_name in defined or not standard:
		return dict(point_limits(system, point_name))
	return dict(standard_limits(standard))


COMMON_POINTS = ["Raw Water", "Softened Water", "Feed Water", "Boiler Water", "Condensate Return", "Deaerator Outlet", "Blowdown",
                 "Make-up Water", "Tower Water", "Chilled Water Loop", "RO Permeate", "Effluent", "Drinking Water Tap"]


def split_tests(text):
	return [t.strip() for t in (text or "").replace("\n", ",").split(",") if t.strip()]


def sheet_data(sample):
	"""Everything the Field Sampling Sheet prints, grouped by equipment then sample point."""
	groups = []
	for row in sample.get("sample_points") or []:
		system = frappe.get_cached_doc("Client Water System", row.water_system)
		g = next((x for x in groups if x["name"] == system.name), None)
		if not g:
			g = {"name": system.name, "system": system, "points": [],
			     "products": [frappe.db.get_value("Item", p.item_code, "item_name") for p in system.products]}
			groups.append(g)
		limits = limits_for_point(system, row.point_name, row.get("standard"))  # an extra sample: its chosen spec
		chosen = split_tests(row.tests) or list(limits)
		tests = []
		for parameter in chosen:
			if not frappe.db.exists("Water Test Parameter", parameter):
				continue
			par = frappe.get_cached_doc("Water Test Parameter", parameter)
			lim = limits.get(parameter)
			tests.append({"parameter": parameter, "unit": par.unit, "method": par.get("method_reference") or par.method or "",
			              "spec": (spec_text(lim, par.unit) + ("*" if lim.adjusted else "")) if lim else "",
			              "handling": par.get("sample_handling") or ""})
		g["points"].append({"row": row, "tests": tests})
	return groups


def water_sheet_data(sample):
	"""Jinja name for sheet_data."""
	return sheet_data(sample)
