frappe.query_reports["Maintenance Overview"] = { filters: [{ fieldname: "from_date", label: __("From"), fieldtype: "Date", default: frappe.datetime.add_months(frappe.datetime.get_today(), -12) }] };
