"""PM compliance, overdue work, downtime, repair time and spares cost by equipment."""

import frappe
from frappe import _
from frappe.utils import flt, getdate, time_diff_in_hours, today


def execute(filters=None):
	f = frappe._dict(filters or {})
	cond = {"creation": [">=", f.from_date]} if f.from_date else {}
	by_eq = {}
	for j in frappe.get_all("Maintenance Job", filters=cond, fields=["equipment", "job_type", "status", "due_date", "modified",
	                                                               "downtime_start", "downtime_end", "spares_entry"]):
		r = by_eq.setdefault(j.equipment, {"equipment": j.equipment, "pm_done": 0, "pm_on_time": 0, "pm_overdue": 0,
		                                   "breakdowns": 0, "downtime_h": 0.0, "spares_cost": 0.0})
		if j.job_type == "Preventive":
			if j.status == "Done":
				r["pm_done"] += 1
				if j.due_date and getdate(j.modified) <= getdate(j.due_date):
					r["pm_on_time"] += 1
			elif j.due_date and getdate(j.due_date) < getdate(today()):
				r["pm_overdue"] += 1
		else:
			r["breakdowns"] += 1
			if j.downtime_start and j.downtime_end:
				r["downtime_h"] += time_diff_in_hours(j.downtime_end, j.downtime_start)
		if j.spares_entry:
			r["spares_cost"] += flt(frappe.db.get_value("Stock Entry", j.spares_entry, "total_outgoing_value"))
	data = []
	for r in by_eq.values():
		r["pm_compliance"] = flt(r["pm_on_time"] / r["pm_done"] * 100, 1) if r["pm_done"] else None
		r["mttr_h"] = flt(r["downtime_h"] / r["breakdowns"], 1) if r["breakdowns"] else None
		data.append(r)
	data.sort(key=lambda r: (-r["pm_overdue"], -r["breakdowns"]))
	return [
		{"fieldname": "equipment", "label": _("Equipment"), "fieldtype": "Link", "options": "Equipment", "width": 150},
		{"fieldname": "pm_done", "label": _("PM Done"), "fieldtype": "Int", "width": 80},
		{"fieldname": "pm_compliance", "label": _("PM On Time %"), "fieldtype": "Percent", "width": 110},
		{"fieldname": "pm_overdue", "label": _("PM Overdue"), "fieldtype": "Int", "width": 100},
		{"fieldname": "breakdowns", "label": _("Breakdowns"), "fieldtype": "Int", "width": 100},
		{"fieldname": "downtime_h", "label": _("Downtime (h)"), "fieldtype": "Float", "width": 110},
		{"fieldname": "mttr_h", "label": _("Mean Repair Time (h)"), "fieldtype": "Float", "width": 140},
		{"fieldname": "spares_cost", "label": _("Spares Cost"), "fieldtype": "Currency", "width": 120},
	], data
