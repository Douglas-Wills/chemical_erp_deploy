import frappe
from frappe import _
from frappe.utils import date_diff, today


def execute(filters=None):
	data = []
	for e in frappe.get_all("Equipment", filters={"requires_calibration": 1, "status": ["!=", "Retired"]},
	                        fields=["name", "equipment_name", "category", "criticality", "status", "last_calibration", "next_calibration_due"]):
		last = frappe.db.get_value("Calibration Record", {"equipment": e.name, "docstatus": 1}, ["name", "as_found_result"],
		                           order_by="calibration_date desc", as_dict=True) or {}
		e.update({"last_result": last.get("as_found_result"),
		          "days_left": date_diff(e.next_calibration_due, today()) if e.next_calibration_due else None})
		data.append(e)
	data.sort(key=lambda r: r["days_left"] if r["days_left"] is not None else -9999)
	return [
		{"fieldname": "name", "label": _("Equipment"), "fieldtype": "Link", "options": "Equipment", "width": 130},
		{"fieldname": "equipment_name", "label": _("Name"), "fieldtype": "Data", "width": 180},
		{"fieldname": "category", "label": _("Category"), "fieldtype": "Data", "width": 140},
		{"fieldname": "criticality", "label": _("Criticality"), "fieldtype": "Data", "width": 140},
		{"fieldname": "status", "label": _("Status"), "fieldtype": "Data", "width": 130},
		{"fieldname": "last_calibration", "label": _("Last Calibrated"), "fieldtype": "Date", "width": 110},
		{"fieldname": "last_result", "label": _("As Found"), "fieldtype": "Data", "width": 80},
		{"fieldname": "next_calibration_due", "label": _("Next Due"), "fieldtype": "Date", "width": 100},
		{"fieldname": "days_left", "label": _("Days Left"), "fieldtype": "Int", "width": 80},
	], data
