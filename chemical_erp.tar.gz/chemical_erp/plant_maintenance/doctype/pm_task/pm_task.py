from frappe.model.document import Document


class PMTask(Document):
	pass
