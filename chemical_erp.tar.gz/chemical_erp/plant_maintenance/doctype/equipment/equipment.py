import frappe
from frappe.model.document import Document
from frappe.utils import cint, date_diff, getdate, today

from chemical_erp.utils import get_settings


def compute_status(eq):
	"""Out of Service and Retired are set by events; calibration states follow the dates."""
	if eq.get("status") in ("Out of Service", "Retired"):
		return eq.status
	if not cint(eq.get("requires_calibration")):
		return "In Service"
	due = eq.get("next_calibration_due")
	if not due or getdate(due) <= getdate(today()):
		return "Out of Calibration"
	if date_diff(due, today()) <= cint(get_settings().expiry_warning_days or 30):
		return "Calibration Due"
	return "In Service"


class Equipment(Document):
	def validate(self):
		if self.is_new() and not self.status:
			self.status = "In Service"
		self.status = compute_status(self)

	def on_update(self):
		if self.status == "Retired":
			frappe.db.set_value("PM Schedule", {"equipment": self.name}, "active", 0)
