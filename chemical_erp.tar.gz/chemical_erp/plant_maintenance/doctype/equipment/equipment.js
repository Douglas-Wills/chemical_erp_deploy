frappe.ui.form.on("Equipment", {
	refresh(frm) {
		if (frm.is_new()) return;
		const g = __("Create");
		if (frm.doc.requires_calibration) frm.add_custom_button(__("Calibration Record"), () => frappe.new_doc("Calibration Record", { equipment: frm.doc.name }), g);
		frm.add_custom_button(__("Report Breakdown"), () => frappe.new_doc("Maintenance Job", { equipment: frm.doc.name, job_type: "Breakdown" }), g);
		frm.add_custom_button(__("PM Schedule"), () => frappe.new_doc("PM Schedule", { equipment: frm.doc.name }), g);
		if (frm.doc.status === "Out of Service") frm.add_custom_button(__("Return to Service"), () => frappe.new_doc("Return to Service", { equipment: frm.doc.name }), g);
	},
});
