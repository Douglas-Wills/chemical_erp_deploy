from frappe.model.document import Document


class MaintenanceSpare(Document):
	pass
