import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, cint, flt, getdate, today

from chemical_erp.utils import approver_role, notify, users_with_role


class CalibrationRecord(Document):
	def validate(self):
		eq = frappe.get_cached_doc("Equipment", self.equipment)
		if not eq.requires_calibration:
			frappe.throw(_("{0} is not set up for calibration.").format(self.equipment))
		if getdate(self.standard_valid_to) < getdate(self.calibration_date):
			frappe.throw(_("The reference standard's certificate had expired on the calibration date."))
		for p in self.points:
			p.as_found_ok = int(p.as_found is None or abs(flt(p.as_found) - flt(p.nominal)) <= flt(p.tolerance_abs))
			p.as_left_ok = int(abs(flt(p.as_left if p.as_left is not None else p.as_found) - flt(p.nominal)) <= flt(p.tolerance_abs))
		self.as_found_result = "Pass" if all(p.as_found_ok for p in self.points) else "Fail"
		self.as_left_result = "Pass" if all(p.as_left_ok for p in self.points) else "Fail"
		self.next_due = add_days(self.calibration_date, cint(eq.calibration_interval_days))

	def on_submit(self):
		eq = frappe.get_doc("Equipment", self.equipment)
		if self.as_found_result == "Fail":
			self.impact_review(eq)
		if self.as_left_result == "Pass" and self.as_found_result == "Pass":
			eq.last_calibration, eq.next_calibration_due = self.calibration_date, self.next_due
			if eq.status == "Out of Calibration":
				eq.status = "In Service"
		else:
			# Adjusted or failed: back in use only through a signed Return to Service
			eq.last_calibration, eq.next_calibration_due = self.calibration_date, self.next_due
			eq.status = "Out of Service"
		eq.flags.ignore_permissions = True
		eq.save()

	def impact_review(self, eq):
		last_pass = frappe.db.get_value("Calibration Record", {"equipment": eq.name, "docstatus": 1, "as_found_result": "Pass",
		                                                       "name": ["!=", self.name]}, "max(calibration_date)") or "2000-01-01"
		rows = frappe.db.sql("""select distinct qi.name, qi.batch_no, qi.report_date
			from `tabQuality Inspection` qi join `tabQuality Inspection Reading` r on r.parent = qi.name
			where r.instrument=%s and qi.docstatus=1 and qi.report_date between %s and %s""",
		                     (eq.name, last_pass, self.calibration_date), as_dict=True)
		affected = []
		for r in rows:
			status = frappe.db.get_value("Batch", r.batch_no, "qc_status") if r.batch_no else ""
			self.append("impact", {"quality_inspection": r.name, "batch": r.batch_no, "batch_status": status, "inspected_on": r.report_date})
			if r.batch_no:
				affected.append(f"{r.batch_no} ({status})")
		dev = frappe.get_doc({"doctype": "Deviation", "title": _("{0} failed calibration as found").format(eq.name),
		                      "source_type": "Calibration Record", "source_name": self.name,
		                      "batch": rows[0].batch_no if rows and rows[0].batch_no else None, "batch_blocked": 1,
		                      "affected_batches": ", ".join(affected),
		                      "description": _("Instrument out of tolerance as found. {0} inspection(s) since the last passed calibration on {1} may be affected.").format(len(rows), last_pass)})
		dev.insert(ignore_permissions=True)
		for r in rows:
			if r.batch_no and frappe.db.get_value("Batch", r.batch_no, "qc_status") == "Quarantine" and r.batch_no != dev.batch:
				frappe.get_doc({"doctype": "Deviation", "title": _("Batch {0} measured with failed instrument {1}").format(r.batch_no, eq.name),
				                "source_type": "Calibration Record", "source_name": self.name, "batch": r.batch_no,
				                "batch_blocked": 1, "description": _("See {0}.").format(dev.name)}).insert(ignore_permissions=True)
		self.db_set("deviation", dev.name)
		for row in self.impact:
			row.db_insert()
		notify(users_with_role(approver_role("quality")) + users_with_role("QC Analyst"), "Deviation", dev.name,
		       _("{0} failed calibration: {1} inspection(s) to review").format(eq.name, len(rows)), priority="High")
