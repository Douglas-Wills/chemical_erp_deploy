from frappe.model.document import Document


class CalibrationPoint(Document):
	pass
