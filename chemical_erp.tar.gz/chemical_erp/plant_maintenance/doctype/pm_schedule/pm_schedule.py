from frappe.model.document import Document
from frappe.utils import add_days, cint, today


class PMSchedule(Document):
	def validate(self):
		for t in self.tasks:
			if t.frequency_type == "Days" and not t.next_due:
				t.next_due = add_days(t.last_done or today(), cint(t.interval))
