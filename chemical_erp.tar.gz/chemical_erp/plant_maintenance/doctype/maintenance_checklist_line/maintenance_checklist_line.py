from frappe.model.document import Document


class MaintenanceChecklistLine(Document):
	pass
