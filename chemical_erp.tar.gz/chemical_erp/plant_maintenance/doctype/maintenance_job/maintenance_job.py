import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import add_days, cint, getdate, today

from chemical_erp.utils import approver_role, get_settings, make_stock_entry, notify, users_with_role


class MaintenanceJob(Document):
	def after_insert(self):
		if self.job_type == "Breakdown":
			frappe.db.set_value("Equipment", self.equipment, "status", "Out of Service")
			notify(users_with_role("Manufacturing Manager") + users_with_role(approver_role()), self.doctype, self.name,
			       _("Breakdown: {0}").format(self.equipment), priority="High")

	def validate(self):
		before = self.get_doc_before_save()
		if self.status == "Done" and (not before or before.status != "Done"):
			undone = [c.task for c in self.checklist if not c.done]
			if undone:
				frappe.throw(_("Tick every checklist line before closing: {0}").format(", ".join(undone)))
			self.issue_spares()
			self.update_schedule()

	def issue_spares(self):
		if not self.spares_used or self.spares_entry:
			return
		s = get_settings()
		eq = frappe.get_cached_doc("Equipment", self.equipment)
		company = frappe.get_cached_value("Warehouse", s.spares_warehouse, "company")
		rows = [{"item_code": r.item_code, "qty": r.qty, "s_warehouse": s.spares_warehouse,
		         "expense_account": s.maintenance_expense_account, "cost_center": eq.cost_center or s.default_cost_center}
		        for r in self.spares_used]
		se = make_stock_entry(company, "Material Issue", rows, remarks=_("Spares for {0}").format(self.name))
		self.spares_entry = se.name

	def update_schedule(self):
		if not (self.pm_schedule and self.pm_task):
			return
		sched = frappe.get_doc("PM Schedule", self.pm_schedule)
		for t in sched.tasks:
			if t.task == self.pm_task:
				t.last_done = today()
				t.batches_since = 0
				t.next_due = add_days(today(), cint(t.interval)) if t.frequency_type == "Days" else None
		sched.flags.ignore_permissions = True
		sched.save()
