from frappe.model.document import Document


class CalibrationImpact(Document):
	pass
