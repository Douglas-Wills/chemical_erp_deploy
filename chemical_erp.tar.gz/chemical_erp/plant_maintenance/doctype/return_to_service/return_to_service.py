import frappe
from frappe import _
from frappe.model.document import Document


class ReturntoService(Document):
	def validate(self):
		eq = frappe.get_cached_doc("Equipment", self.equipment)
		if eq.requires_calibration:
			last = frappe.db.get_value("Calibration Record", {"equipment": eq.name, "docstatus": 1},
			                           ["name", "as_left_result"], order_by="calibration_date desc, creation desc", as_dict=True)
			if not last or last.as_left_result != "Pass":
				frappe.throw(_("{0} needs a passed calibration before it returns to service.").format(eq.name))
		if self.maintenance_job and frappe.db.get_value("Maintenance Job", self.maintenance_job, "status") != "Done":
			frappe.throw(_("Close Maintenance Job {0} first.").format(self.maintenance_job))

	def on_submit(self):
		eq = frappe.get_doc("Equipment", self.equipment)
		eq.status = "In Service"
		eq.flags.ignore_permissions = True
		eq.save()
		eq.add_comment("Info", _("Returned to service by {0}").format(self.name))
