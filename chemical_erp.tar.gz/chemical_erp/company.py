"""The company behind each document: name, logo, address, phones, emails, website, banks.

Everything printed or shown to outsiders reads from the Company Profile of the document's company (or the default
company), so the system serves any company, or several on one site, without code changes."""

import frappe


def default_company():
	return (frappe.defaults.get_user_default("Company") or frappe.db.get_single_value("Global Defaults", "default_company")
	        or frappe.db.get_value("Company", {}, "name"))


def get_profile(company=None):
	"""Company Profile for a company (cached per request). Falls back to the ERPNext Company record."""
	company = company or default_company()
	cache = getattr(frappe.local, "_chem_profiles", None)
	if cache is None:
		cache = frappe.local._chem_profiles = {}
	if company in cache:
		return cache[company]
	if company and frappe.db.exists("Company Profile", company):
		p = frappe.get_cached_doc("Company Profile", company)
	else:
		c = frappe.get_cached_doc("Company", company) if company else frappe._dict()
		p = frappe._dict(company=company, legal_name=(c.get("company_name") or "").upper(), trading_name=c.get("company_name"),
		                 tin=c.get("tax_id"), website=c.get("website"), address_lines="", phones=[], emails=[], bank_accounts=[],
		                 logo_wide=c.get("company_logo"), logo_square=c.get("company_logo"), brand_colour="#1f3864", quotation_title="QUOTATION")
		if c.get("phone_no"):
			p.phones = [frappe._dict(label="Office", number=c.phone_no, print_on_documents=1)]
		if c.get("email"):
			p.emails = [frappe._dict(label="General", email=c.email, print_on_documents=1)]
	cache[company] = p
	return p


def _company_of(doc_or_company=None):
	if isinstance(doc_or_company, str) or doc_or_company is None:
		return doc_or_company
	return doc_or_company.get("company")


def company_name(doc=None, short=False):
	p = get_profile(_company_of(doc))
	return (p.get("trading_name") if short else None) or p.get("legal_name") or p.get("company") or ""


def phone_lines(p, style="sales"):
	flag = "print_on_letterhead" if style == "letter" else "print_on_documents"
	shown = [x for x in p.get("phones") or [] if x.get(flag) and not (x.get("label") or "").startswith("Emergency")]
	if style == "letter":
		short = {"Office": "Off", "Mobile": "Mob"}
		return ["   ".join(f"{short.get(x.label, x.label)}: {x.number}" for x in shown)] if shown else []
	return [f"{x.label}: {x.number}" for x in shown]


def company_block(doc=None, style="sales"):
	"""Lines of the company block. style='sales' (quotations, invoices, orders) or 'letter' (certificates, letters)."""
	p = get_profile(_company_of(doc))
	lines = [] if style == "letter" else [p.get("legal_name")]
	lines += [l.strip() for l in (p.get("address_lines") or "").split("\n") if l.strip()]
	lines += phone_lines(p, style)
	if style == "sales":  # letter templates print the email on their own styled line
		for e in p.get("emails") or []:
			if e.get("print_on_documents"):
				lines.append(f"Email: {e.email}")
				break
	if p.get("website") and style == "letter":
		lines.append(p.website.replace("https://", "").replace("http://", "").rstrip("/"))
	if p.get("tin") and style == "sales":
		lines.append(f"TIN: {p.tin}")
	return [l for l in lines if l]


def company_phone(doc=None, label="Office"):
	p = get_profile(_company_of(doc))
	return next((x.number for x in p.get("phones") or [] if x.get("label") == label), "")


def company_email(doc=None):
	p = get_profile(_company_of(doc))
	return next((e.email for e in p.get("emails") or [] if e.get("print_on_documents")), "")


def emergency_phone(doc=None):
	p = get_profile(_company_of(doc))
	return next((x.number for x in p.get("phones") or [] if (x.get("label") or "").startswith("Emergency")), "")


def bank_lines(doc=None):
	p = get_profile(_company_of(doc))
	banks = [b for b in p.get("bank_accounts") or [] if b.get("print_on_invoices")]
	if not banks:
		return []
	lines = ["BANK DETAILS:"]
	if len({(b.bank_name, b.branch, b.account_name) for b in banks}) == 1:
		b = banks[0]
		lines += [f"Bank Name: {b.bank_name}"] + ([f"Branch: {b.branch}"] if b.branch else []) + [f"Account Name: {b.account_name}"]
		lines += [f"Account Number ({x.currency or ''}): {x.account_number}".replace(" ()", "") for x in banks]
		if b.swift_code:
			lines.append(f"SWIFT: {b.swift_code}")
	else:
		for b in banks:
			lines.append(f"{b.bank_name}{', ' + b.branch if b.branch else ''}: {b.account_name}, "
			             f"{b.currency + ' ' if b.currency else ''}account {b.account_number}{', SWIFT ' + b.swift_code if b.swift_code else ''}")
	if p.get("invoice_note"):
		lines += [""] + [l for l in p.invoice_note.split("\n")]
	return lines


BLANK = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"


def embedded_image(url):
	"""An image file as a data: URI, so PDFs always show it (wkhtmltopdf cannot always reach the site's own URL)."""
	if not url:
		return BLANK
	if url.startswith("data:"):
		return url
	key = f"chem_img_uri::{url}"
	cached = frappe.cache().get_value(key)
	if cached:
		return cached
	try:
		import base64
		import mimetypes

		path = url.split("?")[0]
		if path.startswith("http"):
			from urllib.parse import urlparse

			path = urlparse(path).path
		f = frappe.get_doc("File", {"file_url": path})
		mime = mimetypes.guess_type(f.file_name or path)[0] or "image/png"
		uri = f"data:{mime};base64," + base64.b64encode(f.get_content()).decode()
		frappe.cache().set_value(key, uri, expires_in_sec=3600)
		return uri
	except Exception:
		return url if url.startswith("http") else frappe.utils.get_url() + url


def brand_colour(doc=None):
	p = get_profile(_company_of(doc))
	return p.get("brand_colour") or "#008bc6"


def quotation_title(doc=None):
	p = get_profile(_company_of(doc))
	return p.get("quotation_title") or "QUOTATION"


def fill(text, doc=None):
	"""Expand the company placeholder in configurable certificate notes."""
	name = company_name(doc)
	return (text or "").replace("{company}", name.title() if name.isupper() else name)


def company_logo(doc=None, wide=True):
	p = get_profile(_company_of(doc))
	url = (p.get("logo_wide") if wide else p.get("logo_square")) or p.get("logo_wide") or p.get("logo_square")
	return embedded_image(url)  # no logo set: a blank pixel, never another company's logo


JINJA = ["company_phone", "company_name", "company_block", "company_email", "emergency_phone", "bank_lines", "company_logo", "brand_colour",
         "quotation_title", "fill"]
