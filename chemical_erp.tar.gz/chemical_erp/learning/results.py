
from chemical_erp.learning.room import attendance_minutes


def fill_online_minutes(doc, method=None):
	"""Copy each person's time in the online training room onto the result, for the trainer to judge attendance."""
	if not doc.get("training_event"):
		return
	minutes = attendance_minutes(doc.training_event)
	for row in doc.get("employees") or []:
		if row.meta.has_field("online_minutes"):
			row.online_minutes = minutes.get(row.employee, 0)
