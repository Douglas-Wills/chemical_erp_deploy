"""Training needs: raised from HR and compliance records, closed when training is passed.

Sources:
- Staff Certification nearing expiry (Certification Renewal)
- Training Requirement by designation or workstation that someone lacks (Missing Required Training)
- New joiners without the induction program (Induction)
- A Job Card blocked for missing training (Missing Required Training)
- Appraisals and managers, raised by hand from the Employee or Appraisal form
"""

import frappe
from frappe import _
from frappe.utils import add_days, add_months, cint, getdate, today

from chemical_erp.utils import notify, users_with_role


def settings():
	return frappe.get_cached_doc("Learning Settings")


def program_for(title):
	return frappe.db.get_value("Training Program", {"certification_title": title}, "name")


def raise_need(employee, title, need_type, due_date=None, source=None, priority="Medium", notes=None, program=None):
	"""Create an open Training Need unless one is already open or scheduled for the same employee and training."""
	existing = frappe.db.get_value("Training Need", {"employee": employee, "title": title, "status": ["in", ["Open", "Scheduled"]]})
	if existing:
		return existing
	doc = frappe.get_doc({
		"doctype": "Training Need", "employee": employee, "title": title, "need_type": need_type,
		"training_program": program or program_for(title), "due_date": due_date, "priority": priority, "notes": notes,
		"source_doctype": source.doctype if source else None, "source_name": source.name if source else None,
	})
	doc.insert(ignore_permissions=True)
	notify(users_with_role("HR Manager") + users_with_role("HR User"), "Training Need", doc.name,
	       _("Training needed: {0} for {1}").format(title, doc.employee_name), priority=priority)
	return doc.name


def _has_current(employee, title):
	return frappe.db.exists("Staff Certification", {"parent": employee, "parenttype": "Employee", "title": title,
	                                                "expires_on": [">=", today()]}) or \
	       frappe.db.exists("Staff Certification", {"parent": employee, "parenttype": "Employee", "title": title,
	                                                "expires_on": ["is", "not set"]})


def daily():
	s = settings()
	remind_awaited_certificates()
	if not cint(s.auto_create_needs):
		return
	soon = add_days(today(), cint(s.renewal_warning_days) or 60)
	# 1. Certifications nearing expiry
	for c in frappe.get_all("Staff Certification", filters={"parenttype": "Employee", "expires_on": ["between", [today(), soon]],
	                                                       "record_type": ["in", ["Training", "Certification", "Medical"]]},
	                        fields=["parent", "title", "expires_on"]):
		if frappe.db.get_value("Employee", c.parent, "status") == "Active":
			raise_need(c.parent, c.title, "Certification Renewal", due_date=c.expires_on, priority="High",
			           notes=_("Current certificate expires on {0}").format(c.expires_on))
	# 2. Role requirements nobody may work without
	for req in frappe.get_all("Training Requirement", filters={"active": 1, "designation": ["is", "set"]},
	                          fields=["name", "designation", "required_record", "training_program"]):
		for emp in frappe.get_all("Employee", filters={"status": "Active", "designation": req.designation}, pluck="name"):
			if not _has_current(emp, req.required_record):
				raise_need(emp, req.required_record, "Missing Required Training", due_date=today(), priority="High",
				           source=frappe._dict(doctype="Training Requirement", name=req.name), program=req.training_program)
	# 3. Induction for new joiners
	induction = frappe.db.get_value("Training Program", {"is_induction": 1}, ["name", "certification_title"], as_dict=True)
	if induction:
		title = induction.certification_title or induction.name
		since = add_days(today(), -90)
		for e in frappe.get_all("Employee", filters={"status": "Active", "date_of_joining": [">=", since]},
		                        fields=["name", "date_of_joining"]):
			if not _has_current(e.name, title):
				raise_need(e.name, title, "Induction", due_date=add_days(e.date_of_joining, cint(s.induction_days) or 14),
				           priority="High", program=induction.name)


def remind_awaited_certificates():
	rows = frappe.get_all("Staff Certification", filters={"parenttype": "Employee", "awaiting_certificate": 1}, fields=["parent", "title"])
	if rows:
		by = {}
		for r in rows:
			by.setdefault(r.parent, []).append(r.title)
		for emp, titles in by.items():
			notify(users_with_role("HR User") + users_with_role("HR Manager"), "Employee", emp,
			       _("Upload certificate copies for {0}: {1}").format(frappe.db.get_value("Employee", emp, "employee_name"), ", ".join(titles)))


def on_job_card_blocked(employee, title, job_card=None):
	try:
		raise_need(employee, title, "Missing Required Training", due_date=today(), priority="High",
		           source=frappe._dict(doctype="Job Card", name=job_card) if job_card else None)
		frappe.db.commit()
	except Exception:
		frappe.log_error(title="Could not raise training need", message=frappe.get_traceback())


@frappe.whitelist()
def raise_from_form(employee, title, need_type="Manager Request", due_date=None, notes=None, source_doctype=None, source_name=None):
	frappe.has_permission("Training Need", "create", throw=True)
	src = frappe._dict(doctype=source_doctype, name=source_name) if source_doctype and source_name else None
	return raise_need(employee, title, need_type, due_date=due_date, notes=notes, source=src)


# ------------------------------------------------------------------ closing the loop
def training_result_on_submit(doc, method=None):
	"""Passed training issues the certificate on the Employee and closes their needs. The Job Card block lifts at once."""
	event = frappe.get_doc("Training Event", doc.training_event)
	program = frappe.get_doc("Training Program", event.training_program) if event.get("training_program") else None
	title = (program.get("certification_title") if program else None) or (program.name if program else event.event_name)
	months = cint(program.get("validity_months")) if program else 0
	issued = getdate(event.get("end_time") or event.get("start_time") or today())
	for row in doc.get("employees") or []:
		if (row.get("outcome") or "Passed") != "Passed":
			continue
		emp = frappe.get_doc("Employee", row.employee)
		cert = row.get("certificate")
		emp.append("staff_certifications", {"record_type": "Certification" if months else "Training", "title": title,
		                                    "issued_on": issued, "expires_on": add_months(issued, months) if months else None,
		                                    "attachment": cert, "awaiting_certificate": 0 if cert else 1})
		emp.flags.ignore_permissions = True
		emp.save()
		for need in frappe.get_all("Training Need", filters={"employee": row.employee, "title": title,
		                                                     "status": ["in", ["Open", "Scheduled"]]}, pluck="name"):
			frappe.db.set_value("Training Need", need, {"status": "Completed", "completed_on": today(), "training_event": event.name})
