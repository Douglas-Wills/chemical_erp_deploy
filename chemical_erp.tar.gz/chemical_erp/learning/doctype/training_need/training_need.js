frappe.ui.form.on("Training Need", {
	refresh(frm) { render_materials(frm); },
	training_program(frm) { render_materials(frm); },
});

function render_materials(frm) {
	const field = frm.get_field("materials_html");
	if (!frm.doc.training_program) { field.$wrapper.html(`<p class="text-muted">${__("Choose a recommended program to see its learning material.")}</p>`); return; }
	frappe.call("chemical_erp.learning.doctype.training_need.training_need.get_materials", { training_program: frm.doc.training_program })
		.then(({ message: rows }) => {
			if (!rows || !rows.length) { field.$wrapper.html(`<p class="text-muted">${__("This program has no self-paced material yet.")}</p>`); return; }
			const esc = frappe.utils.escape_html;
			field.$wrapper.html(`<table class="table table-bordered"><tr><th>${__("Material")}</th><th>${__("Type")}</th><th>${__("Minutes")}</th><th></th></tr>` +
				rows.map((r) => {
					const href = r.url || r.attachment;
					return `<tr><td>${esc(r.title)}${r.mandatory ? "" : ` <span class="text-muted">(${__("optional")})</span>`}</td><td>${esc(r.material_type)}</td>` +
						`<td>${r.duration_minutes || ""}</td><td>${href ? `<a href="${encodeURI(href)}" target="_blank" rel="noopener">${__("Open")}</a>` : ""}</td></tr>`;
				}).join("") + "</table>");
		});
}
