import frappe
from frappe.model.document import Document


class TrainingNeed(Document):
	def validate(self):
		if not self.training_program and self.title:
			self.training_program = frappe.db.get_value("Training Program", {"certification_title": self.title}, "name")


@frappe.whitelist()
def get_materials(training_program):
	if not training_program:
		return []
	return frappe.get_all("Course Material", filters={"parent": training_program, "parenttype": "Training Program"},
	                      fields=["title", "material_type", "url", "attachment", "duration_minutes", "mandatory"], order_by="idx")
