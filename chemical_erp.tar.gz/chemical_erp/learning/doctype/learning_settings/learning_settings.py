from frappe.model.document import Document


class LearningSettings(Document):
	pass
