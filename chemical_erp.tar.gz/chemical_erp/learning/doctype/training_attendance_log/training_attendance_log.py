from frappe.model.document import Document


class TrainingAttendanceLog(Document):
	pass
