"""Training Event hooks: the room is created when a session is online, and invitations carry the join link."""

import frappe
from frappe import _
from frappe.utils import format_datetime, get_url

from chemical_erp.learning.room import room_name


def training_event_validate(doc, method=None):
	s = frappe.get_cached_doc("Learning Settings")
	if doc.get("delivery_mode") in ("Online", "Hybrid") and not s.video_platform.startswith("External") and not doc.get("meeting_room"):
		doc.meeting_room = room_name(doc.event_name or "session")
	if doc.get("delivery_mode") in ("Online", "Hybrid") and s.video_platform.startswith("External") and not doc.get("meeting_url"):
		frappe.throw(_("Paste the Zoom, Google Meet or Teams link for this session."))


def training_event_on_submit(doc, method=None):
	link = get_url(f"/app/training-room?event={doc.name}") if doc.get("delivery_mode") in ("Online", "Hybrid") else None
	when = format_datetime(doc.get("start_time"), "d MMMM yyyy, HH:mm") if doc.get("start_time") else ""
	for row in doc.get("employees") or []:
		for need in frappe.get_all("Training Need", filters={"employee": row.employee, "status": "Open",
		                                                     "training_program": doc.get("training_program")}, pluck="name"):
			frappe.db.set_value("Training Need", need, {"status": "Scheduled", "training_event": doc.name})
		email = frappe.db.get_value("Employee", row.employee, ["user_id", "prefered_email", "company_email", "personal_email"], as_dict=True) or {}
		to = email.get("prefered_email") or email.get("company_email") or email.get("user_id") or email.get("personal_email")
		if not to:
			continue
		body = _("<p>You are booked on <b>{0}</b> on {1}.</p>").format(frappe.utils.escape_html(doc.event_name), when)
		if doc.get("location") and doc.get("delivery_mode") != "Online":
			body += _("<p>Venue: {0}</p>").format(frappe.utils.escape_html(doc.location))
		if link:
			body += _('<p>Join online: <a href="{0}">{0}</a><br>Log in to ERPNext first. Cameras start off to save data.</p>').format(link)
		elif doc.get("meeting_url"):
			body += _('<p>Join online: <a href="{0}">{0}</a></p>').format(doc.meeting_url)
		frappe.sendmail(recipients=[to], subject=_("Training: {0}").format(doc.event_name), message=body,
		                reference_doctype="Training Event", reference_name=doc.name)
