"""The training room: a video meeting embedded in ERPNext, with attendance logged automatically.

JaaS (8x8) and token-protected self-hosted Jitsi need a signed JWT. Secrets live in site_config,
never in the database:  bench --site <site> set-config jaas_private_key "$(cat jaas-key.pem)"
"""

import re
import time

import frappe
from frappe import _
from frappe.utils import flt, now_datetime, time_diff_in_seconds

from chemical_erp.utils import has_role

JAAS = "JaaS (8x8 Jitsi as a Service)"
SELF = "Self-hosted Jitsi"


def room_name(event_name):
	token = frappe.generate_hash(length=8)
	return "Training-" + re.sub(r"[^A-Za-z0-9]", "", event_name)[:40] + "-" + token


def _participant(event):
	user = frappe.session.user
	if user == "Administrator" or has_role("HR Manager") or has_role("HR User") or has_role("Managing Director"):
		return None, True
	if event.get("trainer_email") and event.trainer_email == user:
		return None, True
	emp = frappe.db.get_value("Employee", {"user_id": user}, "name")
	if emp and any(r.employee == emp for r in event.get("employees") or []):
		return emp, False
	frappe.throw(_("You are not on the list for this training session."), frappe.PermissionError)


@frappe.whitelist()
def get_join_info(training_event):
	event = frappe.get_doc("Training Event", training_event)
	if event.get("delivery_mode") not in ("Online", "Hybrid"):
		frappe.throw(_("This session is in person only."))
	employee, moderator = _participant(event)
	s = frappe.get_cached_doc("Learning Settings")
	user = frappe.get_doc("User", frappe.session.user)
	info = {"platform": s.video_platform, "display_name": user.full_name or user.name, "email": user.email,
	        "event": event.name, "title": event.event_name, "employee": employee, "moderator": moderator,
	        "low_bandwidth": s.low_bandwidth}
	if s.video_platform.startswith("External"):
		if not event.get("meeting_url"):
			frappe.throw(_("No meeting link has been entered for this session."))
		info["external_url"] = event.meeting_url
		return info
	if not event.get("meeting_room"):
		frappe.throw(_("This session has no training room yet. Save it as Online or Hybrid."))
	if s.video_platform == JAAS:
		if not (s.jaas_app_id and s.jaas_key_id and frappe.conf.get("jaas_private_key")):
			frappe.throw(_("Set the JaaS App ID and Key ID in Learning Settings, and jaas_private_key in site_config."))
		info.update({"domain": "8x8.vc", "script": f"https://8x8.vc/{s.jaas_app_id}/external_api.js",
		             "room": f"{s.jaas_app_id}/{event.meeting_room}", "jwt": _jaas_token(s, user, moderator)})
	else:
		if not s.jitsi_domain:
			frappe.throw(_("Set the Jitsi server domain in Learning Settings."))
		info.update({"domain": s.jitsi_domain, "script": f"https://{s.jitsi_domain}/external_api.js", "room": event.meeting_room,
		             "jwt": _jitsi_token(s, user, moderator) if s.jitsi_app_id and frappe.conf.get("jitsi_jwt_secret") else None})
	return info


def _claims(user, moderator, s):
	now = int(time.time())
	return now, {"context": {"user": {"id": user.name, "name": user.full_name or user.name, "email": user.email,
	                                  "moderator": "true" if moderator else "false"},
	                         "features": {"recording": "true" if (moderator and s.allow_recording) else "false",
	                                      "livestreaming": "false", "transcription": "false", "outbound-call": "false"}}}


def _jaas_token(s, user, moderator):
	import jwt

	now, claims = _claims(user, moderator, s)
	claims.update({"aud": "jitsi", "iss": "chat", "sub": s.jaas_app_id, "room": "*", "iat": now, "nbf": now - 10, "exp": now + 4 * 3600})
	return jwt.encode(claims, frappe.conf.get("jaas_private_key"), algorithm="RS256", headers={"kid": s.jaas_key_id, "typ": "JWT"})


def _jitsi_token(s, user, moderator):
	import jwt

	now, claims = _claims(user, moderator, s)
	claims.update({"aud": "jitsi", "iss": s.jitsi_app_id, "sub": s.jitsi_domain, "room": "*", "nbf": now - 10, "exp": now + 4 * 3600})
	return jwt.encode(claims, frappe.conf.get("jitsi_jwt_secret"), algorithm="HS256")


@frappe.whitelist()
def log_attendance(training_event, action):
	"""Called by the room when someone joins or leaves; minutes feed the training record."""
	employee = frappe.db.get_value("Employee", {"user_id": frappe.session.user}, "name")
	if action == "join":
		frappe.get_doc({"doctype": "Training Attendance Log", "training_event": training_event, "employee": employee,
		                "user": frappe.session.user, "joined_at": now_datetime()}).insert(ignore_permissions=True)
	else:
		open_log = frappe.get_all("Training Attendance Log", filters={"training_event": training_event, "user": frappe.session.user,
		                                                             "left_at": ["is", "not set"]},
		                          fields=["name", "joined_at"], order_by="joined_at desc", limit=1)
		if open_log:
			left = now_datetime()
			frappe.db.set_value("Training Attendance Log", open_log[0].name,
			                    {"left_at": left, "minutes": flt(time_diff_in_seconds(left, open_log[0].joined_at) / 60, 1)})
	return True


def attendance_minutes(training_event):
	rows = frappe.db.sql("""select employee, sum(minutes) from `tabTraining Attendance Log`
		where training_event=%s and employee is not null group by employee""", training_event)
	return {r[0]: flt(r[1]) for r in rows}
