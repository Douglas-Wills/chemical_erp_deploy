frappe.query_reports["Training Matrix"] = {
	filters: [
		{ fieldname: "department", label: __("Department"), fieldtype: "Link", options: "Department" },
		{ fieldname: "only_gaps", label: __("Only Gaps"), fieldtype: "Check" },
	],
	formatter(value, row, column, data, default_formatter) {
		value = default_formatter(value, row, column, data);
		if (column.fieldname === "status" && data) {
			const c = { Missing: "var(--red-600)", Expired: "var(--red-600)", Expiring: "var(--orange-600)", Scheduled: "var(--blue-600)", Current: "var(--green-600)" }[data.status];
			value = `<b style="color:${c}">${value}</b>`;
		}
		return value;
	},
};
