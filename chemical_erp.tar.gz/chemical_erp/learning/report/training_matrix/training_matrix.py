"""Who must hold which training, and whether they do: Current, Expiring, Expired, Missing or Scheduled."""

import frappe
from frappe import _
from frappe.utils import cint, date_diff, getdate, today


def execute(filters=None):
	f = frappe._dict(filters or {})
	warn = cint(frappe.get_cached_doc("Learning Settings").renewal_warning_days or 60)
	emp_filters = {"status": "Active"}
	if f.department:
		emp_filters["department"] = f.department
	employees = frappe.get_all("Employee", filters=emp_filters, fields=["name", "employee_name", "department", "designation"])
	reqs = frappe.get_all("Training Requirement", filters={"active": 1}, fields=["designation", "workstation", "required_record"])
	data = []
	for e in employees:
		needed = {r.required_record for r in reqs if r.designation and r.designation == e.designation}
		held = {c.title: c for c in frappe.get_all("Staff Certification", filters={"parent": e.name, "parenttype": "Employee"},
		                                           fields=["title", "expires_on"], order_by="expires_on asc")}
		for title in sorted(needed | set(held)):
			c = held.get(title)
			if not c:
				status, expires = "Missing", None
			elif not c.expires_on:
				status, expires = "Current", None
			elif getdate(c.expires_on) < getdate(today()):
				status, expires = "Expired", c.expires_on
			elif date_diff(c.expires_on, today()) <= warn:
				status, expires = "Expiring", c.expires_on
			else:
				status, expires = "Current", c.expires_on
			need = frappe.db.get_value("Training Need", {"employee": e.name, "title": title, "status": ["in", ["Open", "Scheduled"]]},
			                           ["name", "status", "training_event"], as_dict=True)
			if need and need.status == "Scheduled" and status in ("Missing", "Expired", "Expiring"):
				status = "Scheduled"
			data.append({"employee": e.name, "employee_name": e.employee_name, "department": e.department, "designation": e.designation,
			             "training": title, "required": 1 if title in needed else 0, "status": status, "expires_on": expires,
			             "training_need": need.name if need else None, "session": need.training_event if need else None})
	if f.only_gaps:
		data = [d for d in data if d["status"] in ("Missing", "Expired", "Expiring")]
	order = {"Missing": 0, "Expired": 1, "Expiring": 2, "Scheduled": 3, "Current": 4}
	data.sort(key=lambda d: (order[d["status"]], d["employee_name"]))
	gaps = sum(d["status"] in ("Missing", "Expired") and d["required"] for d in data)
	return [
		{"fieldname": "employee_name", "label": _("Employee"), "fieldtype": "Data", "width": 170},
		{"fieldname": "designation", "label": _("Role"), "fieldtype": "Link", "options": "Designation", "width": 140},
		{"fieldname": "training", "label": _("Training / Certificate"), "fieldtype": "Data", "width": 200},
		{"fieldname": "required", "label": _("Required"), "fieldtype": "Check", "width": 80},
		{"fieldname": "status", "label": _("Status"), "fieldtype": "Data", "width": 100},
		{"fieldname": "expires_on", "label": _("Expires"), "fieldtype": "Date", "width": 100},
		{"fieldname": "training_need", "label": _("Training Need"), "fieldtype": "Link", "options": "Training Need", "width": 130},
		{"fieldname": "session", "label": _("Session"), "fieldtype": "Link", "options": "Training Event", "width": 130},
	], data, (_("{0} required training(s) missing or expired.").format(gaps) if gaps else None)
