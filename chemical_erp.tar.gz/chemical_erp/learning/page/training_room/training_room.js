frappe.pages["training-room"].on_page_load = function (wrapper) {
	const page = frappe.ui.make_app_page({ parent: wrapper, title: __("Training Room"), single_column: true });
	const $body = $(`<div style="min-height:70vh"><div class="tr-status text-muted" style="padding:12px 0"></div><div class="tr-frame" style="height:72vh;border-radius:8px;overflow:hidden"></div></div>`).appendTo(page.body);
	wrapper.page_obj = page;
	wrapper.$body = $body;
};

frappe.pages["training-room"].on_page_show = function (wrapper) {
	const event = frappe.utils.get_url_arg("event") || (frappe.route_options || {}).event;
	const $status = wrapper.$body.find(".tr-status");
	const $frame = wrapper.$body.find(".tr-frame").empty();
	if (wrapper.api) { wrapper.api.dispose(); wrapper.api = null; }
	if (!event) { $status.text(__("Open a training session from its Training Event and press Join Training.")); return; }
	$status.text(__("Connecting…"));
	frappe.call("chemical_erp.learning.room.get_join_info", { training_event: event }).then(({ message: info }) => {
		wrapper.page_obj.set_title(info.title);
		if (info.external_url) {
			$status.html(__("This session runs on an external platform.") + ` <a class="btn btn-primary btn-sm" target="_blank" rel="noopener" href="${encodeURI(info.external_url)}">${__("Open meeting")}</a>`);
			log(event, "join");
			return;
		}
		$status.text(info.moderator ? __("You are the host of this session.") : __("Cameras start off to save data. Unmute when you speak."));
		frappe.require(info.script, () => {
			const options = {
				roomName: info.room, parentNode: $frame[0], width: "100%", height: "100%",
				userInfo: { displayName: info.display_name, email: info.email },
				configOverwrite: Object.assign({ prejoinConfig: { enabled: true }, disableDeepLinking: true, startWithAudioMuted: true },
					info.low_bandwidth ? { startWithVideoMuted: true, resolution: 360, constraints: { video: { height: { ideal: 360, max: 360 } } } } : {}),
			};
			if (info.jwt) options.jwt = info.jwt;
			const api = new JitsiMeetExternalAPI(info.domain, options);
			wrapper.api = api;
			api.addListener("videoConferenceJoined", () => log(event, "join"));
			api.addListener("videoConferenceLeft", () => log(event, "leave"));
			api.addListener("readyToClose", () => { log(event, "leave"); frappe.set_route("Form", "Training Event", event); });
		});
	});
};

frappe.pages["training-room"].on_page_hide = function (wrapper) {
	if (wrapper.api) { wrapper.api.dispose(); wrapper.api = null; }
};

function log(event, action) {
	frappe.call({ method: "chemical_erp.learning.room.log_attendance", args: { training_event: event, action }, freeze: false });
}
