"""Seeds the BR HYPO 10 inspection template from Brave's own Certificate of Analysis, so the first
hypochlorite batch prints exactly like the existing certificate. Created only if missing."""

import frappe

HYPO_TEMPLATE = "BR HYPO 10"
# (parameter, QATM No., specification as printed, numeric, min, max, accepted value for descriptive tests)
HYPO_PARAMETERS = [
	("Appearance", "108", "Clear, light green–yellow liquid, free from suspended matter", 0, None, None, "Complies"),
	("Percentage NaOCl (%)", "18", "8.0 – 10.0", 1, 8.0, 10.0, None),
	("Free Available Chlorine (%)", "", "7.8 – 9.8", 1, 7.8, 9.8, None),
	("pH (1% solution)", "05", "11.5 – 12.5", 1, 11.5, 12.5, None),
	("Specific Gravity (SG) @ 25°C", "", "1.12 – 1.14", 1, 1.12, 1.14, None),
	("Odor", "109", "Faint chlorinous odor", 0, None, None, "Complies"),
]
HYPO_NOTES = "\n".join([
	"Results are valid only for the sample as tested, at the time and under the conditions of testing stated. Available chlorine content declines naturally over time and is accelerated by heat, light, and prolonged or improper storage; Brave Chemicals Limited does not warrant the stated assay beyond the declared expiry date where storage recommendations have not been followed.",
	"Recommended storage: in tightly closed original containers, in a cool, dry, well-ventilated area protected from direct sunlight and heat, away from acids, ammonia, organic materials, and other incompatible substances. Refer to the current Safety Data Sheet (SDS) for full handling, storage, and personal protective equipment requirements before use.",
	"Sodium hypochlorite solution is corrosive and an oxidizing agent. It must be handled only by trained personnel using appropriate PPE (chemical-resistant gloves, eye/face protection, protective clothing). Do not mix with acids or ammonia-based products, as this may liberate hazardous chlorine or chloramine gas.",
])


def ensure_coa_seed():
	if not frappe.db.exists("DocType", "Quality Inspection Template"):
		return
	for name, *_ in HYPO_PARAMETERS:
		if frappe.db.exists("DocType", "Quality Inspection Parameter") and not frappe.db.exists("Quality Inspection Parameter", name):
			frappe.get_doc({"doctype": "Quality Inspection Parameter", "parameter": name}).insert(ignore_permissions=True)
	if not frappe.db.exists("Quality Inspection Template", HYPO_TEMPLATE):
		rows = []
		for name, method, spec, numeric, lo, hi, value in HYPO_PARAMETERS:
			row = {"specification": name, "test_method": method, "specification_text": spec, "numeric": numeric}
			if numeric:
				row.update({"min_value": lo, "max_value": hi})
			else:
				row["value"] = value
			rows.append(row)
		frappe.get_doc({"doctype": "Quality Inspection Template", "quality_inspection_template_name": HYPO_TEMPLATE,
		                "item_quality_inspection_parameter": rows, "coa_product_notes": HYPO_NOTES}).insert(ignore_permissions=True)
	if frappe.db.exists("DocType", "Substance Register") and not frappe.db.exists("Substance Register", "Sodium Hypochlorite"):
		frappe.get_doc({"doctype": "Substance Register", "substance_name": "Sodium Hypochlorite", "cas_number": "7681-52-9",
		                "un_number": "UN1791", "proper_shipping_name": "HYPOCHLORITE SOLUTION", "hazard_class": "8",
		                "density_kg_per_l": 1.13}).insert(ignore_permissions=True)
