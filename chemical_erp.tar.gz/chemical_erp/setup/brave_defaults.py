"""Brave Chemicals Limited as the default company, taken from its website (brave-chemicals-website, 27 September 2026),
plus polyelectrolyte and fertilisers, which Brave keeps in scope.

Applied automatically when the default company is Brave (and from Company Profile → Setup → Apply Brave Defaults).
Idempotent: creates what is missing and fills only empty fields, never overwriting anything already entered.

What it sets up, and how it links the modules
  Company Profile  scope of work, sectors, tagline, website        → documents, tender scan, portal
  Item Groups      the six service lines, Brave Home, fertilisers  → items, tender categories
  Substances       CAS, UN number, hazard class                    → items, SDS, transport emergency card
  Items            Brave-made and distributed products, Brave Home, services
                   → SDS, batches and QC, costing, certification, field lab treatment products, quotations, tenders
  Customer Groups  the website's sectors and Brave Home channels   → customers, tender leads
  Tender Desk      scope keywords tied to tender categories, scanning on
  Field Laboratory analysis service item; treatment products per equipment type
  Certification    Brave Home and BR-Hypo marked for a UNBS scope check
  IMS register     Standard Terms and Conditions of Sale (draft)
"""

import frappe
from frappe import _

WEBSITE = "https://bravechemicals.com"
TAGLINE = "Reliable Chemical Solutions"

GROUPS = [  # (name, parent, is_group)
	("Brave Chemicals Range", "All Item Groups", 1),
	("Generic and Specialty Chemicals", "Brave Chemicals Range", 1),
	("Disinfection", "Generic and Specialty Chemicals", 0),
	("Cleaning and Descaling", "Generic and Specialty Chemicals", 0),
	("Boilers and Steam", "Generic and Specialty Chemicals", 0),
	("Cooling Water", "Generic and Specialty Chemicals", 0),
	("Water Treatment Chemicals", "Generic and Specialty Chemicals", 0),
	("Process Chemicals", "Generic and Specialty Chemicals", 0),
	("Laboratory Chemicals", "Generic and Specialty Chemicals", 0),
	("Fertilisers and Agro-inputs", "Brave Chemicals Range", 0),
	("Chemical Laboratory Supplies", "Brave Chemicals Range", 0),
	("PPE", "Brave Chemicals Range", 0),
	("Industrial Equipment", "Brave Chemicals Range", 0),
	("Brave Home", "Brave Chemicals Range", 0),
	("Brave Services", "Brave Chemicals Range", 0),
]

# substance name: (CAS, UN number, proper shipping name, hazard class)
SUBSTANCES = {
	"Sodium hypochlorite": ("7681-52-9", "UN1791", "HYPOCHLORITE SOLUTION", "8"),
	"Sodium hydroxide": ("1310-73-2", "UN1824", "SODIUM HYDROXIDE SOLUTION", "8"),
	"Hydrochloric acid": ("7647-01-0", "UN1789", "HYDROCHLORIC ACID", "8"),
	"Sulphuric acid": ("7664-93-9", "UN1830", "SULPHURIC ACID", "8"),
	"Acetone": ("67-64-1", "UN1090", "ACETONE", "3"),
	"Ethanol": ("64-17-5", "UN1170", "ETHANOL", "3"),
	"Methanol": ("67-56-1", "UN1230", "METHANOL", "3"),
	"Carbon dioxide": ("124-38-9", "UN1013", "CARBON DIOXIDE", "2.2"),
	"Oxygen": ("7782-44-7", "UN1072", "OXYGEN, COMPRESSED", "2.2"),
	"Propane": ("74-98-6", "UN1978", "PROPANE", "2.1"),
	"Urea": ("57-13-6", None, None, None),
	"Diammonium phosphate": ("7783-28-0", None, None, None),
}

# code, name, group, uom, substance, hazardous, description (from the website)
MADE = [
	("BR-HYPO-10", "BR-Hypo 10", "Disinfection", "Litre", "Sodium hypochlorite", 1, "Sodium hypochlorite. Potable and process water disinfection."),
	("BR-HYPO-12", "BR-Hypo 12", "Disinfection", "Litre", "Sodium hypochlorite", 1, "Sodium hypochlorite. Water and surface disinfection."),
	("BR-HYPO-35", "BR-Hypo 35", "Disinfection", "Litre", "Sodium hypochlorite", 1, "Sodium hypochlorite. [Confirm application]"),
	("BR-HYPO-56", "BR-Hypo 56", "Disinfection", "Litre", "Sodium hypochlorite", 1, "Sodium hypochlorite. [Confirm application]"),
	("BR-SAV", "BR-SAV", "Cleaning and Descaling", "Kg", "Sodium hydroxide", 1, "Sodium hydroxide. Cleaning, CIP and pH control."),
	("BR-SAV-1201", "BR-Sav 1201", "Cleaning and Descaling", "Litre", None, 0, "[Confirm chemistry and application]"),
	("BR-SAV-1202", "BR-Sav 1202", "Cleaning and Descaling", "Litre", None, 0, "[Confirm chemistry and application]"),
	("ACIDEX", "ACIDEX", "Cleaning and Descaling", "Litre", None, 1, "Descaling. [Confirm chemistry]"),
	("ACIDEX-1202", "ACIDEX 1202", "Cleaning and Descaling", "Litre", "Hydrochloric acid", 1, "Inhibited hydrochloric acid. Heat-exchanger and boiler descaling."),
	("COTOCIDE-1402", "COTOCIDE 1402", "Cooling Water", "Litre", None, 1, "Cooling-water microbial control. [Confirm biocide type]"),
	("COTOCIDE-1403", "COTOCIDE 1403", "Cooling Water", "Litre", None, 1, "Cooling-water microbial control. [Confirm biocide type]"),
	("SCAV-1204", "SCAV 1204", "Boilers and Steam", "Litre", None, 0, "Boiler feedwater oxygen scavenging. [Confirm scavenger type]"),
	("AQUATREAT-9510", "AQUATREAT 9510", "Boilers and Steam", "Litre", None, 0, "Scale and corrosion inhibition. [Confirm chemistry]"),
	("BR-OXO-PLUS", "BR-OXO+", "Cleaning and Descaling", "Litre", None, 1, "Oxidising cleaner and sanitiser. [Confirm chemistry]"),
]
DISTRIBUTED = [
	("SULPHURIC-ACID", "Sulphuric acid", "Process Chemicals", "Litre", "Sulphuric acid", 1, "Process chemistry, pH adjustment. Grades: technical, AR."),
	("ACETONE", "Acetone", "Laboratory Chemicals", "Litre", "Acetone", 1, "Solvent, cleaning. Grades: technical, AR."),
	("ETHANOL", "Ethanol", "Laboratory Chemicals", "Litre", "Ethanol", 1, "Solvent, sanitiser base. Grades: denatured, AR."),
	("METHANOL", "Methanol", "Laboratory Chemicals", "Litre", "Methanol", 1, "Solvent, laboratory. Grades: technical, AR."),
	("CARBON-DIOXIDE", "Carbon dioxide", "Process Chemicals", "Kg", "Carbon dioxide", 1, "Industrial and beverage gas."),
	("OXYGEN", "Oxygen", "Process Chemicals", "Kg", "Oxygen", 1, "Industrial gas."),
	("PROPANE", "Propane", "Process Chemicals", "Kg", "Propane", 1, "Fuel gas."),
	("SURFACTANTS", "Surfactants", "Process Chemicals", "Kg", None, 0, "Detergent formulation. By specification."),
	("POLYELECTROLYTE", "Polyelectrolyte", "Water Treatment Chemicals", "Kg", None, 0, "Flocculant for water and wastewater treatment. 25 kg bags."),
	("DAP", "DAP (diammonium phosphate)", "Fertilisers and Agro-inputs", "Kg", "Diammonium phosphate", 0, "Fertiliser. 50 kg bags."),
	("UREA", "Urea", "Fertilisers and Agro-inputs", "Kg", "Urea", 0, "Fertiliser. 50 kg bags."),
]
HOME = [  # Brave Home: 13 products, batch-tested, sold in retail and institutional (5 L, 20 L) sizes
	("BH-SUDSWAVE", "SudsWave Dishwashing Liquid", "Washing dishes, cutlery and cookware; cuts through grease."),
	("BH-SURFAGLEAM", "SurfaGleam Multi-Surface Cleaner", "Countertops, tiles and general household surfaces."),
	("BH-FLUSHFORCE", "FlushForce Toilet Bowl Cleaner", "Descaling and cleaning toilets; removes limescale and stains."),
	("BH-SCRUBZEST", "ScrubZest Bathroom Cleaner", "Tiles, sinks and bathtubs; targets soap scum and mildew."),
	("BH-STEPSHINE", "StepShine Floor Cleaner", "Mopping tile, vinyl and ceramic floors."),
	("BH-WASHRITE", "WashRite Laundry Detergent (Liquid)", "Washing clothes; removes stains and odours."),
	("BH-SOFTWEAVE", "SoftWeave Fabric Softener", "Softens clothes and reduces static after washing."),
	("BH-WHITEGUARD", "WhiteGuard Household Bleach", "Disinfecting, stain removal and whitening fabrics and surfaces."),
	("BH-GLINTPRO", "GlintPro Glass and Window Cleaner", "Streak-free cleaning of glass, mirrors and windows."),
	("BH-PURETOUCH", "PureTouch Hand Wash", "Everyday hand washing."),
	("BH-GERMBLOCK", "GermBlock Disinfectant Spray", "Sanitising high-touch surfaces."),
	("BH-AIRBLOOM", "AirBloom Air Freshener", "Neutralising household odours."),
	("BH-SANIGEL", "SaniGel Hand Sanitiser Gel", "Waterless hand hygiene without rinsing."),
]
SERVICES = [  # non-stock service items for quotations, invoices and tender pricing
	("SRV-WATER-TREATMENT", "Water Treatment Programme (boiler, cooling tower, chiller)", "Dosing, monitoring and routine water testing."),
	("SRV-WATER-ANALYSIS", "Water Analysis (field laboratory)", "On-site sampling and testing with a Water Analysis Report."),
	("SRV-INDUSTRIAL-CLEANING", "Industrial Chemicals Cleaning", "Plant, equipment and tank cleaning; commissioning spill clean-up."),
	("SRV-SPILL-RESPONSE", "Emergency Spill Response", "Containment, neutralisation, decontamination and lawful disposal under manifest."),
	("SRV-EQUIPMENT-SERVICE", "Industrial Equipment Installation and Servicing", "Installation, commissioning, preventive maintenance and breakdown support."),
	("SRV-SAFETY-AUDIT", "Chemical Safety Audit", "Audits of chemical stores, plants and laboratories."),
	("SRV-SAFETY-CONSULTANCY", "Chemicals and Safety Consultancy", "Risk assessments, handling and storage advice, compliance documents, process optimisation."),
]
CUSTOMER_GROUPS = ["Major Projects and Remote Sites", "Manufacturing", "Water and Utilities", "Healthcare and Laboratories",
                   "Government and NGOs", "Brave Home: Retailers", "Brave Home: Distributors", "Brave Home: Institutions",
                   "Brave Home: Households"]
# tender category → item group it sells from
CATEGORY_GROUP = {
	"Generic and Specialty Chemicals": "Generic and Specialty Chemicals", "Water Treatment": "Generic and Specialty Chemicals",
	"Industrial Chemicals Cleaning": "Brave Services", "Industrial Equipment Supply and Servicing": "Industrial Equipment",
	"Chemical Laboratory Supplies": "Chemical Laboratory Supplies", "PPE Supply": "PPE",
	"Chemicals and Safety Consultancy": "Brave Services", "Household and Institutional Cleaning (Brave Home)": "Brave Home",
	"Fertilisers and Agro-inputs": "Fertilisers and Agro-inputs",
}
SCOPE_NAME = "Brave Chemicals (website 27 Sep 2026, plus fertilisers)"


def _group(name, parent, is_group):
	if not frappe.db.exists("Item Group", name):
		frappe.get_doc({"doctype": "Item Group", "item_group_name": name, "parent_item_group": parent, "is_group": is_group}).insert(ignore_permissions=True)


def _uom(name):
	return name if frappe.db.exists("UOM", name) else ("Litre" if name.startswith("L") and frappe.db.exists("UOM", "Litre") else "Nos")


def _item(code, name, group, uom, desc, stock=1, batch=1, substance=None, hazardous=0, sales=1, purchase=1, sds=None):
	if frappe.db.exists("Item", code):
		return
	doc = {"doctype": "Item", "item_code": code, "item_name": name, "item_group": group, "stock_uom": _uom(uom), "description": desc,
	       "is_stock_item": stock, "is_sales_item": sales, "is_purchase_item": purchase, "include_item_in_manufacturing": stock}
	if stock and batch:
		doc.update({"has_batch_no": 1, "create_new_batch": 1, "batch_number_series": f"{code}-.YY.-.####"})
	meta = frappe.get_meta("Item")
	for field, value in (("substance", substance), ("is_hazardous", hazardous), ("requires_current_sds", hazardous if sds is None else sds)):
		if meta.has_field(field) and value:
			doc[field] = value
	frappe.get_doc(doc).insert(ignore_permissions=True)


def apply(company=None):
	from chemical_erp.company import default_company

	company = company or default_company()
	# Company Profile: scope, sectors, tagline, website (empty fields only)
	if company and frappe.db.exists("Company Profile", company):
		from chemical_erp.tenders_desk.scan_seed import BRAVE_SECTORS_TEXT, BRAVE_WEBSITE_SCOPE_TEXT

		p = frappe.get_doc("Company Profile", company)
		for field, value in (("trading_name", "Brave Chemicals"), ("tagline", TAGLINE), ("website", WEBSITE),
		                     ("scope_of_work", BRAVE_WEBSITE_SCOPE_TEXT), ("sectors_served", BRAVE_SECTORS_TEXT)):
			if not p.get(field):
				p.set(field, value)
		p.flags.ignore_permissions = True
		p.save()
	# Item groups and substances
	for name, parent, is_group in GROUPS:
		_group(name, parent, is_group)
	for name, (cas, un, psn, cls) in SUBSTANCES.items():
		if not frappe.db.exists("Substance Register", name):
			frappe.get_doc({"doctype": "Substance Register", "substance_name": name, "cas_number": cas, "un_number": un,
			                "proper_shipping_name": psn, "hazard_class": cls}).insert(ignore_permissions=True)
	# Drug precursors (UN 1988 Convention, Table II): sales need an end-user declaration. Confirm the licence
	# threshold against Uganda's current precursor regulations.
	for name in ("Hydrochloric acid", "Sulphuric acid", "Acetone"):
		if frappe.db.exists("Substance Register", name) and frappe.get_meta("Substance Register").has_field("is_controlled") \
				and not frappe.db.get_value("Substance Register", name, "is_controlled"):
			frappe.db.set_value("Substance Register", name, {"is_controlled": 1, "control_category": "Drug precursor", "licence_above_kg": 1000,
			                                                 "control_notes": "UN 1988 Convention Table II precursor. Confirm the licence threshold "
			                                                                  "against current Ugandan regulations."})
	# Items
	for code, name, group, uom, sub, haz, desc in MADE:
		_item(code, name, group, uom, desc, substance=sub, hazardous=haz, purchase=0)
	for code, name, group, uom, sub, haz, desc in DISTRIBUTED:
		_item(code, name, group, uom, desc, substance=sub, hazardous=haz)
	for code, name, desc in HOME:
		_item(code, name, "Brave Home", "Litre", desc, purchase=0, sds=0)
	for code, name, desc in SERVICES:
		_item(code, name, "Brave Services", "Nos", desc, stock=0, batch=0, purchase=0)
	# Customer groups
	for name in CUSTOMER_GROUPS:
		if not frappe.db.exists("Customer Group", name):
			frappe.get_doc({"doctype": "Customer Group", "customer_group_name": name, "parent_customer_group": "All Customer Groups",
			                "is_group": 0}).insert(ignore_permissions=True)
	# Business lines for the monthly management accounts (budgets entered by the MD)
	for order, (line, groups) in enumerate([("Industrial and Water Treatment Chemicals", ["Generic and Specialty Chemicals"]),
	                                         ("Brave Home", ["Brave Home"]), ("Services", ["Brave Services"]),
	                                         ("Laboratory Supplies, PPE and Equipment", ["Chemical Laboratory Supplies", "PPE", "Industrial Equipment"]),
	                                         ("Fertilisers and Agro-inputs", ["Fertilisers and Agro-inputs"])], 1):
		if frappe.db.exists("DocType", "Business Line") and not frappe.db.exists("Business Line", line):
			frappe.get_doc({"doctype": "Business Line", "line_name": line, "sort_order": order,
			                "item_groups": [{"item_group": g} for g in groups if frappe.db.exists("Item Group", g)]}).insert(ignore_permissions=True)
	# A price list per customer group (utilities, manufacturers, Brave Home channels) and the quick-order settings
	from chemical_erp.chemical_core.pricing import apply_brave as brave_prices

	brave_prices()
	# Tenders Desk: Brave scope, categories linked to item groups, scanning on
	from chemical_erp.tenders_desk.scan_seed import load_example_scope

	if not frappe.db.exists("Tender Scope Keyword", {"parenttype": "Tender Settings", "parentfield": "scope_keywords"}):
		load_example_scope(SCOPE_NAME, skip_role_check=True)
	for cat, group in CATEGORY_GROUP.items():
		if frappe.db.exists("Tender Category", cat) and frappe.get_meta("Tender Category").has_field("item_group") \
				and not frappe.db.get_value("Tender Category", cat, "item_group"):
			frappe.db.set_value("Tender Category", cat, "item_group", group)
	if company and frappe.db.exists("Company Profile", company) and not frappe.db.get_single_value("Tender Settings", "scan_enabled"):
		s = frappe.get_single("Tender Settings")
		s.scan_enabled = 1
		s.flags.ignore_permissions = True
		s.save()
	# Field Laboratory: the analysis fee item
	if not frappe.db.get_single_value("Chemical ERP Settings", "lab_service_item"):
		frappe.db.set_single_value("Chemical ERP Settings", "lab_service_item", "SRV-WATER-ANALYSIS")
	# Certification: UNBS scope to confirm for the consumer and disinfection products
	for code in [c for c, _n, _d in HOME] + ["BR-HYPO-10", "BR-HYPO-12"]:
		if frappe.db.exists("Item", code) and not frappe.db.exists("Product Certification", {"item_code": code}):
			frappe.get_doc({"doctype": "Product Certification", "item_code": code, "in_scope": "To Be Confirmed", "certification_body": "UNBS",
			                "notes": _("Website: UNBS certification marks and permit numbers to be added once issued.")}).insert(ignore_permissions=True)
	# IMS register: the Terms of Sale named on the website
	if frappe.db.exists("IMS Document Series", "BC/CS") and not frappe.db.exists("IMS Document", {"title": ["like", "%Terms and Conditions of Sale%"]}):
		used = frappe.get_all("IMS Document", filters={"series": "BC/CS"}, pluck="document_number")
		n = max([int(x.rsplit("/", 1)[-1]) for x in used if x.rsplit("/", 1)[-1].isdigit()] or [0]) + 1
		frappe.get_doc({"doctype": "IMS Document", "document_number": f"BC/CS/{n:03d}", "title": "Standard Terms and Conditions of Sale",
		                "series": "BC/CS", "document_type": "Policy", "owner_role": "Sales and Logistics", "status": "Draft",
		                "effective_date": frappe.utils.today(), "current_revision": "0.0", "review_frequency_months": 12,
		                "review_date": frappe.utils.add_months(frappe.utils.today(), 12)}).insert(ignore_permissions=True)
	return _("Brave Chemicals defaults applied")


@frappe.whitelist()
def apply_now():
	frappe.only_for(("System Manager", "Managing Director"))
	return apply()
