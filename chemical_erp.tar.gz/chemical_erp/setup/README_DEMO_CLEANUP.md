# Demo Content Cleanup Guide

This guide explains how to manage demo/test data in the Chemical ERP dashboard.

## Overview

The dashboard displays **live operational data** from your database. However, the system included a seeding function that created demo/test data for development purposes. This guide helps you clean up that demo data and prevent it from being created in the future.

## What is Demo Content?

Demo content includes:
- **Customers**: Mukwano Industries, Kakira Sugar, National Water & Sewerage Corp, etc.
- **Suppliers**: Brenntag East Africa, Desbro Uganda, Crown Packaging
- **Chemical Items**: CHEM-CS-50, CHEM-HCL-33, CHEM-NAOCL-15, etc.
- **Employees**: David Kato, Sarah Namubiru, Geoffrey Okello, etc.
- **Batches**: BATCH-CS-2026-*, BATCH-HCL-2026-*, etc.
- **Work Orders, Invoices, HSE Incidents, Events, Documents**, and more

## How to Remove Demo Content

### Step 1: Preview What Will Be Deleted (Safe - Dry Run)

First, run a dry-run to see what demo data exists without deleting anything:

```bash
bench --site your-site-name execute chemical_erp.setup.remove_demo_content.dry_run
```

This will show you a report of all demo records that would be deleted.

### Step 2: Remove Demo Data (Execute Cleanup)

Once you're ready to delete the demo data:

```bash
bench --site your-site-name execute chemical_erp.setup.remove_demo_content.execute
```

This will:
1. Delete all demo records matching the known patterns
2. Show progress for each record type
3. Provide a summary of what was deleted
4. Commit the changes to your database

**Note**: This operation is permanent. Make sure you have a database backup before running it.

### Step 3: Verify Dashboard

After cleanup, visit your dashboard. You should see:
- Zero counts for metrics where no real data exists
- Only your actual operational data (if any exists)
- A clean slate ready for production use

## Demo Data Seeding is Now Disabled

The demo seeding function has been **automatically disabled** to prevent accidental creation of test data in production.

### If You Need to Re-enable Seeding (for Development/Testing ONLY)

If you're in a development environment and need to create demo data for testing:

```bash
# Enable demo seeding
export ENABLE_DEMO_SEEDING=1

# Run the seeding function
bench --site your-site-name execute chemical_erp.setup.seed_real_content.seed_all
```

**WARNING**: Never enable demo seeding in production environments!

## Files Modified

1. **`chemical_erp/setup/remove_demo_content.py`** (NEW)
   - Cleanup script to remove all demo data
   - Functions: `dry_run()` and `execute()`

2. **`chemical_erp/setup/seed_real_content.py`** (MODIFIED)
   - Added safety guard to prevent accidental execution
   - Requires `ENABLE_DEMO_SEEDING=1` environment variable

## Dashboard Behavior After Cleanup

After removing demo content, the dashboard will:
- Display only **real operational data** from your actual business
- Show `0` or empty states for sections with no data yet
- Continue to function normally as you add real customers, orders, batches, etc.
- Automatically update metrics as you create new records

## Troubleshooting

### "I accidentally deleted real data"

If you have a database backup:
```bash
bench --site your-site-name restore /path/to/backup.sql.gz
```

### "The cleanup script won't run"

Make sure you're in your bench directory and the site name is correct:
```bash
cd frappe-bench
bench --site your-site-name execute chemical_erp.setup.remove_demo_content.dry_run
```

### "Some demo data is still showing"

The cleanup script targets specific known patterns. If you manually created additional test data, you may need to delete it manually through the ERPNext interface or create a custom cleanup script.

## Best Practices

1. **Always run dry_run first** before executing the cleanup
2. **Backup your database** before major cleanup operations
3. **Never enable demo seeding** in production environments
4. **Document any custom test data** you create for easy cleanup later

## Support

For issues or questions about demo data cleanup, refer to:
- This README file
- The Chemical ERP documentation
- Your system administrator

---

**Last Updated**: October 17, 2026
