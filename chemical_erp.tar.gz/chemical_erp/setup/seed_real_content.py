"""Seed realistic chemical manufacturing operational data for Chemical ERP.
Ensures every section of the ERP has real records, metrics, and relationships.
"""

import frappe
from frappe.utils import add_days, getdate, now_datetime, today, flt


def seed_all():
	"""
	WARNING: This function creates DEMO/TEST data only!
	DO NOT run this in production environments.
	
	To prevent accidental execution, this function is now disabled by default.
	To enable it for development/testing purposes, set the environment variable:
	ENABLE_DEMO_SEEDING=1
	"""
	import os
	
	if not os.environ.get("ENABLE_DEMO_SEEDING"):
		print("\n" + "="*80)
		print("DEMO DATA SEEDING IS DISABLED")
		print("="*80)
		print("\nThis function creates demo/test data and should NOT be used in production.")
		print("\nTo enable demo seeding for development/testing:")
		print("  export ENABLE_DEMO_SEEDING=1")
		print("  bench execute chemical_erp.setup.seed_real_content.seed_all")
		print("\nTo remove existing demo data, run:")
		print("  bench execute chemical_erp.setup.remove_demo_content.execute")
		print("\n" + "="*80 + "\n")
		return
	
	frappe.set_user("Administrator")
	company = frappe.db.get_single_value("Global Defaults", "default_company") or "WADO CONCEPTS LTD"
	currency = frappe.db.get_value("Company", company, "default_currency") or "UGX"

	print(f"Seeding DEMO operational chemical data for {company} ({currency})...")

	seed_customers_and_suppliers(company)
	seed_chemical_items(company)
	seed_employees_and_hr(company)
	seed_batches_and_qc(company)
	seed_work_orders_and_manufacturing(company)
	seed_sales_invoices(company, currency)
	seed_purchase_invoices(company, currency)
	seed_treasury(company)
	seed_hse_and_compliance(company)
	seed_maintenance_and_calibration(company)
	seed_events_and_calendar(company)
	seed_documents_and_vault()

	frappe.db.commit()
	print("Seeding complete! All operational sections now have real content.")


def seed_customers_and_suppliers(company):
	customers = [
		{"name": "Mukwano Industries Uganda", "customer_name": "Mukwano Industries Uganda", "customer_group": "Commercial", "territory": "Uganda"},
		{"name": "Kakira Sugar Limited", "customer_name": "Kakira Sugar Limited", "customer_group": "Commercial", "territory": "Uganda"},
		{"name": "National Water & Sewerage Corp", "customer_name": "National Water & Sewerage Corp", "customer_group": "Government", "territory": "Uganda"},
		{"name": "Tororo Cement Works", "customer_name": "Tororo Cement Works", "customer_group": "Commercial", "territory": "Uganda"},
		{"name": "Nile Breweries Jinja", "customer_name": "Nile Breweries Jinja", "customer_group": "Commercial", "territory": "Uganda"}
	]
	for c in customers:
		if not frappe.db.exists("Customer", c["name"]):
			doc = frappe.new_doc("Customer")
			doc.update(c)
			doc.flags.ignore_validate = True
			doc.insert(ignore_permissions=True)

	suppliers = [
		{"name": "Brenntag East Africa Ltd", "supplier_name": "Brenntag East Africa Ltd", "supplier_group": "Raw Material"},
		{"name": "Desbro Uganda Limited", "supplier_name": "Desbro Uganda Limited", "supplier_group": "Distributor"},
		{"name": "Crown Packaging Industries", "supplier_name": "Crown Packaging Industries", "supplier_group": "Local"}
	]
	for s in suppliers:
		if not frappe.db.exists("Supplier", s["name"]):
			doc = frappe.new_doc("Supplier")
			doc.update(s)
			doc.insert(ignore_permissions=True)


def seed_chemical_items(company):
	items = [
		{"item_code": "CHEM-CS-50", "item_name": "Caustic Soda Lye 50% Tech Grade", "item_group": "Products", "stock_uom": "Kg", "has_batch_no": 1, "is_stock_item": 1},
		{"item_code": "CHEM-HCL-33", "item_name": "Hydrochloric Acid 33% Industrial Grade", "item_group": "Products", "stock_uom": "Kg", "has_batch_no": 1, "is_stock_item": 1},
		{"item_code": "CHEM-NAOCL-15", "item_name": "Sodium Hypochlorite 15% Solution", "item_group": "Products", "stock_uom": "Kg", "has_batch_no": 1, "is_stock_item": 1},
		{"item_code": "CHEM-ALUM-SOL", "item_name": "Liquid Aluminium Sulphate 8%", "item_group": "Products", "stock_uom": "Kg", "has_batch_no": 1, "is_stock_item": 1},
		{"item_code": "CHEM-PAC-18", "item_name": "Poly Aluminium Chloride (PAC-18)", "item_group": "Products", "stock_uom": "Kg", "has_batch_no": 1, "is_stock_item": 1},
		{"item_code": "RAW-SALT-IND", "item_name": "Industrial Vacuum Salt (NaCl 99.5%)", "item_group": "Raw Material", "stock_uom": "Kg", "has_batch_no": 1, "is_stock_item": 1},
		{"item_code": "RAW-BAUXITE", "item_name": "Processed Refined Bauxite Ore", "item_group": "Raw Material", "stock_uom": "Kg", "has_batch_no": 0, "is_stock_item": 1},
		{"item_code": "PKG-IBC-1000L", "item_name": "UN Certified 1000L Chemical IBC Tote", "item_group": "Consumable", "stock_uom": "Nos", "has_batch_no": 0, "is_stock_item": 1}
	]
	for it in items:
		if not frappe.db.exists("Item", it["item_code"]):
			doc = frappe.new_doc("Item")
			doc.update(it)
			doc.insert(ignore_permissions=True)


def seed_employees_and_hr(company):
	staff = [
		{"first_name": "David", "last_name": "Kato", "designation": "Plant Manager", "gender": "Male"},
		{"first_name": "Sarah", "last_name": "Namubiru", "designation": "QC Analyst", "gender": "Female"},
		{"first_name": "Geoffrey", "last_name": "Okello", "designation": "HSE Officer", "gender": "Male"},
		{"first_name": "Grace", "last_name": "Atuhaire", "designation": "Laboratory Technician", "gender": "Female"},
		{"first_name": "Brian", "last_name": "Mugisha", "designation": "Maintenance Technician", "gender": "Male"}
	]
	for s in staff:
		email = f"{s['first_name'].lower()}.{s['last_name'].lower()}@wcl.local"
		if not frappe.db.exists("Employee", {"first_name": s["first_name"], "last_name": s["last_name"]}):
			doc = frappe.new_doc("Employee")
			doc.first_name = s["first_name"]
			doc.last_name = s["last_name"]
			doc.gender = s["gender"]
			doc.company = company
			doc.status = "Active"
			doc.date_of_joining = add_days(today(), -180)
			doc.date_of_birth = add_days(today(), -12000)
			if frappe.db.has_column("Employee", "appointment_letter"):
				doc.appointment_letter = "/files/appointment_letter.pdf"
			doc.flags.ignore_validate = True
			doc.flags.ignore_mandatory = True
			doc.insert(ignore_permissions=True)


def seed_batches_and_qc(company):
	batches = [
		{"batch_id": "BATCH-CS-2026-001", "item": "CHEM-CS-50", "qc_status": "Released", "manufacturing_date": add_days(today(), -14), "expiry_date": add_days(today(), 350)},
		{"batch_id": "BATCH-CS-2026-002", "item": "CHEM-CS-50", "qc_status": "Released", "manufacturing_date": add_days(today(), -7), "expiry_date": add_days(today(), 357)},
		{"batch_id": "BATCH-CS-2026-003", "item": "CHEM-CS-50", "qc_status": "Quarantine", "manufacturing_date": add_days(today(), -2), "expiry_date": add_days(today(), 362)},
		{"batch_id": "BATCH-HCL-2026-01", "item": "CHEM-HCL-33", "qc_status": "Released", "manufacturing_date": add_days(today(), -10), "expiry_date": add_days(today(), 354)},
		{"batch_id": "BATCH-HCL-2026-02", "item": "CHEM-HCL-33", "qc_status": "Quarantine", "manufacturing_date": add_days(today(), -1), "expiry_date": add_days(today(), 363)},
		{"batch_id": "BATCH-NAOCL-2026", "item": "CHEM-NAOCL-15", "qc_status": "Released", "manufacturing_date": add_days(today(), -5), "expiry_date": add_days(today(), 85)},
		{"batch_id": "BATCH-ALUM-2026", "item": "CHEM-ALUM-SOL", "qc_status": "Quarantine", "manufacturing_date": add_days(today(), -3), "expiry_date": add_days(today(), 180)},
		{"batch_id": "BATCH-PAC-2026-01", "item": "CHEM-PAC-18", "qc_status": "Rejected", "manufacturing_date": add_days(today(), -20), "expiry_date": add_days(today(), 160)}
	]
	for b in batches:
		if not frappe.db.exists("Batch", b["batch_id"]):
			try:
				doc = frappe.new_doc("Batch")
				doc.batch_id = b["batch_id"]
				doc.item = b["item"]
				if frappe.db.has_column("Batch", "qc_status"):
					doc.qc_status = b["qc_status"]
				doc.manufacturing_date = b["manufacturing_date"]
				doc.expiry_date = b["expiry_date"]
				doc.flags.ignore_validate = True
				doc.flags.ignore_mandatory = True
				doc.insert(ignore_permissions=True)
			except Exception as e:
				print(f"Error seeding batch {b['batch_id']}: {e}")


def seed_work_orders_and_manufacturing(company):
	abbr = frappe.db.get_value("Company", company, "abbr") or "WCL"
	wos = [
		{"production_item": "CHEM-CS-50", "qty": 10000, "status": "Completed"},
		{"production_item": "CHEM-HCL-33", "qty": 8000, "status": "Completed"},
		{"production_item": "CHEM-NAOCL-15", "qty": 5000, "status": "In Process"},
		{"production_item": "CHEM-ALUM-SOL", "qty": 12000, "status": "In Process"},
		{"production_item": "CHEM-PAC-18", "qty": 6000, "status": "Not Started"}
	]
	wip_wh = frappe.db.get_value("Warehouse", {"company": company, "warehouse_name": ["like", "%Work In Progress%"]}) or f"Work In Progress - {abbr}"
	fg_wh = frappe.db.get_value("Warehouse", {"company": company, "warehouse_name": ["like", "%Finished Goods%"]}) or f"Finished Goods - {abbr}"

	for wo in wos:
		if not frappe.db.exists("Work Order", {"production_item": wo["production_item"], "qty": wo["qty"]}):
			try:
				doc = frappe.new_doc("Work Order")
				doc.company = company
				doc.production_item = wo["production_item"]
				doc.qty = wo["qty"]
				doc.status = wo["status"]
				doc.wip_warehouse = wip_wh
				doc.fg_warehouse = fg_wh
				doc.flags.ignore_validate = True
				doc.flags.ignore_mandatory = True
				doc.insert(ignore_permissions=True)
			except Exception as e:
				print(f"Error seeding work order {wo['production_item']}: {e}")


def seed_sales_invoices(company, currency):
	sales = [
		{"customer": "Mukwano Industries Uganda", "date": add_days(today(), -150), "amount": 28500000, "item": "CHEM-CS-50"},
		{"customer": "Kakira Sugar Limited", "date": add_days(today(), -120), "amount": 34200000, "item": "CHEM-HCL-33"},
		{"customer": "National Water & Sewerage Corp", "date": add_days(today(), -90), "amount": 31800000, "item": "CHEM-NAOCL-15"},
		{"customer": "Tororo Cement Works", "date": add_days(today(), -60), "amount": 42100000, "item": "CHEM-CS-50"},
		{"customer": "National Water & Sewerage Corp", "date": add_days(today(), -30), "amount": 39600000, "item": "CHEM-ALUM-SOL"},
		{"customer": "Mukwano Industries Uganda", "date": add_days(today(), -10), "amount": 26400000, "item": "CHEM-CS-50"},
		{"customer": "Nile Breweries Jinja", "date": add_days(today(), -3), "amount": 21800000, "item": "CHEM-PAC-18"}
	]
	abbr = frappe.db.get_value("Company", company, "abbr") or "WCL"
	income_acc = frappe.db.get_value("Company", company, "default_income_account") or f"Sales - {abbr}"
	receivable_acc = frappe.db.get_value("Company", company, "default_receivable_account") or f"Debtors - {abbr}"
	cost_center = frappe.db.get_value("Company", company, "cost_center") or f"Main - {abbr}"

	for s in sales:
		if not frappe.db.exists("Sales Invoice", {"customer": s["customer"], "posting_date": s["date"]}):
			try:
				doc = frappe.new_doc("Sales Invoice")
				doc.company = company
				doc.currency = currency
				doc.customer = s["customer"]
				doc.debit_to = receivable_acc
				doc.cost_center = cost_center
				doc.posting_date = s["date"]
				doc.due_date = add_days(s["date"], 30)
				doc.append("items", {
					"item_code": s.get("item", "CHEM-CS-50"),
					"qty": 5000,
					"rate": s["amount"] / 5000,
					"amount": s["amount"],
					"income_account": income_acc,
					"cost_center": cost_center
				})
				doc.set_missing_values()
				doc.net_total = s["amount"]
				doc.base_net_total = s["amount"]
				doc.grand_total = s["amount"]
				doc.base_grand_total = s["amount"]
				doc.outstanding_amount = s["amount"] * 0.35
				doc.flags.ignore_mandatory = True
				doc.flags.ignore_validate = True
				doc.flags.ignore_permissions = True
				doc.insert(ignore_permissions=True)
				try:
					doc.submit()
				except Exception:
					# Force docstatus to 1 if submission has hook checks
					frappe.db.set_value("Sales Invoice", doc.name, "docstatus", 1)
			except Exception as e:
				print(f"Error seeding invoice for {s['customer']}: {e}")


def seed_purchase_invoices(company, currency):
	purchases = [
		{"supplier": "Brenntag East Africa Ltd", "date": add_days(today(), -25), "amount": 24500000, "item": "RAW-SALT-IND"},
		{"supplier": "Desbro Uganda Limited", "date": add_days(today(), -12), "amount": 18200000, "item": "RAW-BAUXITE"}
	]
	abbr = frappe.db.get_value("Company", company, "abbr") or "WCL"
	payable_acc = frappe.db.get_value("Company", company, "default_payable_account") or f"Creditors - {abbr}"
	expense_acc = f"Cost of Goods Sold - {abbr}"
	cost_center = frappe.db.get_value("Company", company, "cost_center") or f"Main - {abbr}"

	for p in purchases:
		if not frappe.db.exists("Purchase Invoice", {"supplier": p["supplier"], "posting_date": p["date"]}):
			try:
				doc = frappe.new_doc("Purchase Invoice")
				doc.company = company
				doc.currency = currency
				doc.supplier = p["supplier"]
				doc.credit_to = payable_acc
				doc.cost_center = cost_center
				doc.posting_date = p["date"]
				doc.due_date = add_days(p["date"], 30)
				doc.append("items", {
					"item_code": p["item"],
					"qty": 5000,
					"rate": p["amount"] / 5000,
					"amount": p["amount"],
					"expense_account": expense_acc,
					"cost_center": cost_center
				})
				doc.set_missing_values()
				doc.net_total = p["amount"]
				doc.base_net_total = p["amount"]
				doc.grand_total = p["amount"]
				doc.base_grand_total = p["amount"]
				doc.outstanding_amount = p["amount"]
				doc.flags.ignore_mandatory = True
				doc.flags.ignore_validate = True
				doc.flags.ignore_permissions = True
				doc.insert(ignore_permissions=True)
				frappe.db.set_value("Purchase Invoice", doc.name, "docstatus", 1)
			except Exception as e:
				print(f"Error seeding purchase invoice for {p['supplier']}: {e}")


def seed_treasury(company):
	abbr = frappe.db.get_value("Company", company, "abbr") or "WCL"
	bank_acc = f"Stanbic Bank Operating - {abbr}"
	if not frappe.db.exists("Account", bank_acc):
		try:
			acc = frappe.new_doc("Account")
			acc.account_name = "Stanbic Bank Operating"
			acc.company = company
			acc.parent_account = f"Bank Accounts - {abbr}"
			acc.account_type = "Bank"
			acc.is_group = 0
			acc.flags.ignore_validate = True
			acc.flags.ignore_mandatory = True
			acc.insert(ignore_permissions=True)
		except Exception as e:
			print(f"Error creating bank account: {e}")

	if not frappe.db.exists("GL Entry", {"company": company, "account": bank_acc}):
		try:
			gle = frappe.new_doc("GL Entry")
			gle.company = company
			gle.posting_date = add_days(today(), -60)
			gle.account = bank_acc
			gle.debit = 145000000.0
			gle.credit = 0.0
			gle.debit_in_account_currency = 145000000.0
			gle.credit_in_account_currency = 0.0
			gle.against = "Opening Balance"
			gle.voucher_type = "Sales Invoice"
			gle.voucher_no = "ACC-SINV-2026-00001"
			gle.is_opening = "Yes"
			gle.flags.ignore_validate = True
			gle.flags.ignore_mandatory = True
			gle.insert(ignore_permissions=True)
		except Exception as e:
			print(f"Error seeding treasury: {e}")


def seed_hse_and_compliance(company):
	if frappe.db.exists("DocType", "HSE Incident"):
		incidents = [
			{"incident_type": "Near Miss", "occurred_on": add_days(today(), -45), "description": "Chemical splash goggles not worn during acid sample collection; corrected immediately.", "root_cause": "Operator momentary lapse; mandatory PPE refresher conducted."},
			{"incident_type": "Spill or Release", "occurred_on": add_days(today(), -12), "description": "Minor 5L sodium hypochlorite pipe flange leak at dosing station. Contained with spill kit.", "root_cause": "Gasket wear on flange F-12; replaced with EPDM chemical-resistant gasket."}
		]
		for inc in incidents:
			if not frappe.db.exists("HSE Incident", {"occurred_on": inc["occurred_on"]}):
				doc = frappe.new_doc("HSE Incident")
				doc.update(inc)
				doc.status = "Closed"
				doc.flags.ignore_validate = True
				doc.flags.ignore_mandatory = True
				doc.insert(ignore_permissions=True)

	if frappe.db.exists("DocType", "Legal Requirement"):
		permits = [
			{"law_name": "National Environment Act, 2019", "licence_permit_filing": "NEMA Chemical Effluent Discharge Permit", "regulator": "NEMA Uganda", "legal_area": "Environment — Chemicals", "expiry_date": add_days(today(), 24)},
			{"law_name": "National Drug Policy and Authority Act, Cap 206", "licence_permit_filing": "NDA Precursor & Controlled Chemical License", "regulator": "National Drug Authority", "legal_area": "Chemical Precursors", "expiry_date": add_days(today(), 120)},
			{"law_name": "Uganda National Bureau of Standards Act, Cap 327", "licence_permit_filing": "UNBS Quality Certification Mark (Q-Mark)", "regulator": "UNBS", "legal_area": "Product Standards", "expiry_date": add_days(today(), 280)},
			{"law_name": "Occupational Safety and Health Act, 2006", "licence_permit_filing": "Factory Workplace Registration & Fire Certificate", "regulator": "Ministry of Gender, Labour & Social Dev", "legal_area": "Occupational Safety & Health", "expiry_date": add_days(today(), 45)}
		]
		for p in permits:
			if not frappe.db.exists("Legal Requirement", {"licence_permit_filing": p["licence_permit_filing"]}):
				doc = frappe.new_doc("Legal Requirement")
				doc.update(p)
				doc.compliance_status = "Compliant"
				doc.flags.ignore_validate = True
				doc.flags.ignore_mandatory = True
				doc.insert(ignore_permissions=True)


def seed_maintenance_and_calibration(company):
	if frappe.db.exists("DocType", "Maintenance Job"):
		jobs = [
			{"pm_task": "Chlorine Neutralization Scrubber Pump Overhaul", "job_type": "Preventive", "status": "Done", "due_date": add_days(today(), -10)},
			{"pm_task": "pH & Conductivity Analyzer Probe Recalibration", "job_type": "Preventive", "status": "Done", "due_date": add_days(today(), -3)},
			{"pm_task": "Reactor Vessel R-101 Pressure Relief Valve Testing", "job_type": "Preventive", "status": "In Progress", "due_date": add_days(today(), 5)},
			{"pm_task": "Bulk Chemical Storage Tank T-204 Wall Ultrasonic Thickness Scan", "job_type": "Preventive", "status": "Open", "due_date": add_days(today(), 14)}
		]
		for j in jobs:
			if not frappe.db.exists("Maintenance Job", {"pm_task": j["pm_task"]}):
				doc = frappe.new_doc("Maintenance Job")
				doc.update(j)
				doc.flags.ignore_validate = True
				doc.flags.ignore_mandatory = True
				doc.insert(ignore_permissions=True)


def seed_events_and_calendar(company):
	events = [
		{"subject": "Technical Site Water Sampling & Analysis Audit", "event_kind": "Field Visit", "starts_on": f"{today()} 09:30:00", "party_type": "Customer", "party": "National Water & Sewerage Corp", "location": "Ggaba Water Treatment Plant"},
		{"subject": "UNBS Annual Chemical Quality Surveillance Inspection", "event_kind": "Meeting", "starts_on": f"{add_days(today(), 2)} 10:00:00", "location": "Main Chemical Laboratory"},
		{"subject": "Plant Safety & Hazardous Spill Response Emergency Drill", "event_kind": "Training", "starts_on": f"{add_days(today(), 4)} 14:00:00", "location": "Production Bay A"},
		{"subject": "Executive Management Review & IMS Quality Performance", "event_kind": "Meeting", "starts_on": f"{add_days(today(), 7)} 11:00:00", "location": "Executive Boardroom"}
	]
	for ev in events:
		if not frappe.db.exists("Event", {"subject": ev["subject"]}):
			doc = frappe.new_doc("Event")
			doc.subject = ev["subject"]
			doc.event_category = "Event"
			doc.event_type = "Public"
			doc.starts_on = ev["starts_on"]
			if frappe.db.has_column("Event", "event_kind"):
				doc.event_kind = ev["event_kind"]
			if frappe.db.has_column("Event", "party_type"):
				doc.party_type = ev.get("party_type")
				doc.party = ev.get("party")
			doc.location = ev.get("location")
			doc.flags.ignore_validate = True
			doc.flags.ignore_mandatory = True
			doc.insert(ignore_permissions=True)


def seed_documents_and_vault():
	docs = [
		{"title": "Material Safety Data Sheet (MSDS) - Caustic Soda Lye 50%", "category": "Safety Data Sheet (SDS)", "document_code": "SDS-CS-50-UG", "confidential": 0},
		{"title": "Technical Data Sheet (TDS) - Industrial Hydrochloric Acid 33%", "category": "Technical Data Sheet (TDS)", "document_code": "TDS-HCL-33", "confidential": 0},
		{"title": "Certificate of Analysis (COA) - Master Blend Batch 2026-001", "category": "Certificate of Analysis (CoA)", "document_code": "COA-CS-001", "confidential": 0},
		{"title": "Confidential Formulation Specification - Poly Aluminium Chloride PAC-18", "category": "Standard Operating Procedure (SOP)", "document_code": "SPEC-PAC-FORMULA", "confidential": 1},
		{"title": "NEMA Statutory Operating License & Environmental Approval", "category": "Regulatory Permit & License", "document_code": "NEMA-LIC-2026", "confidential": 0}
	]
	for d in docs:
		if not frappe.db.exists("Chemical Document", {"title": d["title"]}):
			doc = frappe.new_doc("Chemical Document")
			doc.update(d)
			doc.status = "Active"
			doc.version = "1.0"
			doc.flags.ignore_validate = True
			doc.flags.ignore_mandatory = True
			doc.insert(ignore_permissions=True)
