"""Idempotent setup for chemical_erp. Runs after install and after every migrate.

It never overwrites a Workflow, setting or record that already exists, so changes made
on site survive upgrades.
"""

import frappe
from frappe.custom.doctype.custom_field.custom_field import create_custom_fields

ROLES = ("Managing Director", "Plant Manager", "QC Manager", "Formula Owner", "QC Analyst", "Laboratory Technician", "HSE Officer",
         "Waste Officer", "Maintenance Technician", "Field Technician")

# Laboratory work uses Chemical ERP's own roles, not ERPNext's broad "Quality Manager" (which can also delete and cancel
# inspections and reads assets, cost centres and accounts). QC Analyst signs results; a Laboratory Technician enters
# readings but cannot sign (the workflow's Sign Results is for QC Analyst); release stays with the quality approver.
LAB_READ = ("Quality Inspection Template", "Quality Inspection Parameter", "Quality Inspection Parameter Group", "Batch", "Item",
            "Purchase Receipt", "Stock Entry", "Warehouse")
LAB_ROLES = ("QC Analyst", "Laboratory Technician")

# Roles that sign last on standard documents need permission to submit (and cancel) them.
APPROVER_PERMS = {
	"Managing Director": ("Purchase Order", "Purchase Receipt", "Quality Inspection", "BOM", "Work Order", "Expense Claim",
	                      "Payment Entry", "Stock Reconciliation", "Quotation", "Sales Order", "Stock Entry", "Bank Guarantee"),
	"Expense Approver": ("Expense Claim",),
	"Plant Manager": ("Quality Inspection", "Work Order", "Stock Reconciliation", "Stock Entry"),
	"QC Manager": ("Quality Inspection",),
}


def ensure_positions():
	"""Seed Brave's posts once, then give each post's roles to its holder, or to the MD while it is vacant."""
	from chemical_erp.people_management.positions import seed_positions, sync_positions
	from chemical_erp.setup.workflows import sync_quality_approver

	seed_positions()
	sync_positions()
	sync_quality_approver(frappe.db.get_single_value("Chemical ERP Settings", "quality_approver") or "Plant Manager")


COST_ELEMENTS = [
	("Direct Labour", "Labour", "Per labour hour", 8, 1),
	("Production Overheads", "Production Overheads", "% of material cost", 1, 1),
	("Electricity", "Utilities", "Per kg of output", 1, 1),
	("Water", "Utilities", "Per kg of output", 1, 1),
	("Container (jerrycan / drum)", "Packaging", "Per pack", 1, 0),
	("Labels and Caps", "Packaging", "Per pack", 1, 0),
	("QC Testing", "Quality Control", "Per batch", 1, 1),
	("Delivery", "Transport and Delivery", "Per kg of output", 1, 0),
	("Administration Overhead", "Administration", "Per month (spread over volume)", 1, 0),
]


ACCESS_PROFILES = [
	("Stores Assistant", ["Stock User"], "Receipts, transfers and deliveries (no approvals)"),
	("Sales Support", ["Sales User"], "Quotations, orders and customer records"),
	("Accounts Assistant", ["Accounts User"], "Invoices, payments and bank entries"),
	("Production Assistant", ["Manufacturing User"], "Work orders, job cards and manufacture entries"),
	("Maintenance Support", ["Maintenance Technician"], "Maintenance jobs and calibration readings"),
	("HR Assistant", ["HR User"], "Staff records and training (no payroll approval)"),
	("Procurement Support", ["Purchase User"], "Requests for quotation and purchase orders"),
	("Laboratory Assistant", ["Laboratory Technician"], "Enter inspection readings; signing stays with the QC Analyst"),
	("Field Technician", ["Field Technician"], "Client equipment visits, water sampling and field tests"),
]


def is_brave():
	from chemical_erp.company import default_company

	return "brave" in (default_company() or "").lower() or bool(frappe.conf.get("chemical_erp_reference_data"))


def migrate_company_profile():
	"""Move the company details that used to live in Chemical ERP Settings into the default company's Company Profile.
	Runs once: only when that company has no profile yet. Values are read straight from the stored settings."""
	from chemical_erp.company import default_company

	company = default_company()
	if not company or frappe.db.exists("Company Profile", company):
		return
	old = {r.field: r.value for r in frappe.db.sql("""select field, value from `tabSingles` where doctype = 'Chemical ERP Settings'""", as_dict=True)}
	block = [l.strip() for l in (old.get("sales_company_lines") or "").split("\n") if l.strip()]
	legal = block[0] if block else (old.get("coa_company_name") or frappe.db.get_value("Company", company, "company_name") or company).upper()
	address, phones, emails, tin = [], [], [], None
	for line in block[1:]:
		low = line.lower()
		if low.startswith("office:") or low.startswith("off:"):
			phones.append({"label": "Office", "number": line.split(":", 1)[1].strip(), "print_on_documents": 1, "print_on_letterhead": 1})
		elif low.startswith("mob"):
			phones.append({"label": "Mobile", "number": line.split(":", 1)[1].strip(), "print_on_documents": 1, "print_on_letterhead": 1})
		elif low.startswith("email:"):
			emails.append({"label": "General", "email": line.split(":", 1)[1].strip(), "print_on_documents": 1})
		elif low.startswith("tin:"):
			tin = line.split(":", 1)[1].strip()
		else:
			address.append(line)
	for part in (old.get("coa_header_lines") or "").replace("   ", "\n").split("\n"):
		if part.lower().startswith("mob") and not any(p["label"] == "Mobile" for p in phones):
			phones.append({"label": "Mobile", "number": part.split(":", 1)[1].strip(), "print_on_documents": 0, "print_on_letterhead": 1})
	if old.get("emergency_phone"):
		phones.append({"label": "Emergency (24 hours)", "number": old["emergency_phone"], "print_on_documents": 0, "print_on_letterhead": 0})
	if not emails and old.get("coa_email"):
		emails.append({"label": "General", "email": old["coa_email"], "print_on_documents": 1})
	banks, bank = [], {}
	for line in (old.get("bank_details") or "").split("\n"):
		if ":" not in line:
			continue
		k, v = [x.strip() for x in line.split(":", 1)]
		kl = k.lower()
		if kl == "bank name":
			bank["bank_name"] = v
		elif kl == "branch":
			bank["branch"] = v
		elif kl == "account name":
			bank["account_name"] = v
		elif kl.startswith("account number"):
			cur = k[k.find("(") + 1:k.find(")")] if "(" in k else None
			banks.append({**bank, "account_number": v, "currency": cur if cur and frappe.db.exists("Currency", cur) else None, "print_on_invoices": 1})
	if not address and not block:
		if not is_brave():
			return  # nothing to migrate: the company fills in its own profile
		legal, address = "BRAVE CHEMICALS LIMITED", ["P.O.BOX 163089, Kampala", "Bweyogerere-off Kyobe Road"]
		phones = [{"label": "Office", "number": "+256(0)200 930115", "print_on_documents": 1, "print_on_letterhead": 1},
		          {"label": "Mobile", "number": "+256 (0) 772 226481", "print_on_documents": 0, "print_on_letterhead": 1}]
		emails = [{"label": "General", "email": "info@bravechemicals.com", "print_on_documents": 1}]
		tin = "1046184442"
		banks = [{"bank_name": "EQUITY BANK", "branch": "KIREKA", "account_name": "BRAVE CHEMICALS LIMITED", "account_number": n,
		          "currency": c if frappe.db.exists("Currency", c) else None, "print_on_invoices": 1}
		         for c, n in (("UGX", "1047203232104"), ("USD", "1047203232108"))]
		old.setdefault("quotation_title", "ESTIMATE")
	frappe.get_doc({"doctype": "Company Profile", "company": company, "legal_name": legal, "tin": tin or old.get("efris_tin"),
	                "address_lines": "\n".join(address) or "-", "phones": phones, "emails": emails,
	                "bank_accounts": [b for b in banks if b.get("bank_name") and b.get("account_name")],
	                "logo_square": old.get("coa_logo") or ("/assets/chemical_erp/images/brave_logo.png" if is_brave() else None),
	                "logo_wide": old.get("sales_logo") or ("/assets/chemical_erp/images/brave_logo_wide.png" if is_brave() else None),
	                "quotation_title": old.get("quotation_title") or "QUOTATION",
	                "trading_name": frappe.db.get_value("Company", company, "company_name")}).insert(ignore_permissions=True)


RENAMED_MODULES = {"Brave IMS": "Management Systems", "Brave Tenders": "Tenders Desk"}
RENAMED_WORKSPACES = {"Brave IMS": "Management Systems", "Tenders": "Tenders Desk"}


def tidy_renamed_modules():
	"""After the rename (Brave Tenders -> Tenders Desk, Brave IMS -> Management Systems): remove the old workspaces and
	module entries once the new ones exist, so menus show only the new names. Records themselves are untouched."""
	for old, new in RENAMED_WORKSPACES.items():
		if frappe.db.exists("Workspace", old) and frappe.db.exists("Workspace", new):
			frappe.delete_doc("Workspace", old, ignore_permissions=True, force=True)
	for old, new in RENAMED_MODULES.items():
		if not frappe.db.exists("Module Def", old) or not frappe.db.exists("Module Def", new):
			continue
		for dt in ("DocType", "Report", "Print Format", "Page", "Number Card", "Dashboard Chart", "Workspace", "Notification"):
			if frappe.db.exists("DocType", dt) and frappe.get_meta(dt).has_field("module"):
				frappe.db.set_value(dt, {"module": old}, "module", new, update_modified=False)
		frappe.delete_doc("Module Def", old, ignore_permissions=True, force=True)


def fix_office_number():
	"""Brave's office line is +256(0)200 930115; correct the earlier number wherever it was saved."""
	meta = frappe.get_meta("Chemical ERP Settings")
	for field in ("coa_header_lines", "sales_company_lines"):
		if meta.has_field(field):
			value = frappe.db.get_single_value("Chemical ERP Settings", field) or ""
			if "966446" in value:
				frappe.db.set_single_value("Chemical ERP Settings", field,
				                           value.replace("+256 (0) 200 966446", "+256(0)200 930115").replace("200 966446", "200 930115"))


def ensure_access_profiles():
	if frappe.db.count("Access Profile"):
		return
	for name, roles, desc in ACCESS_PROFILES:
		roles = [r for r in roles if frappe.db.exists("Role", r)]
		if roles:
			frappe.get_doc({"doctype": "Access Profile", "profile_name": name, "description": desc,
			                "roles": [{"role": r} for r in roles]}).insert(ignore_permissions=True)


# Connections: each record shows everything related to it (Connections panel on the form).
CONNECTIONS = {
	"Batch": [("Quality", "Retained Sample", "batch"), ("Quality", "Stability Study", "batch"), ("Quality", "Deviation", "batch"),
	          ("Quality", "Batch Status Override", "batch"), ("Quality", "OOS Investigation", "batch"),
	          ("Customers", "Customer Complaint", "batch"), ("Waste", "Disposal Order", "waste_batch"), ("Traceability", "Batch Link", "to_batch")],
	"Item": [("Costing and Compliance", "Document Exception", "item_code"), ("Costing and Compliance", "Product Cost Sheet", "item_code"), ("Costing and Compliance", "Product Certification", "item_code"),
	         ("Costing and Compliance", "SDS File", "item_code"), ("Quality", "Stability Study", "item_code"),
	         ("Quality", "Customer Complaint", "item_code")],
	"Customer": [("Field Laboratory", "Client Water System", "customer"), ("Field Laboratory", "Water Sample", "customer"),
	             ("Field Laboratory", "Water Analysis", "customer"),
	             ("Service", "Customer Complaint", "customer"), ("Service", "Estimate Request", "customer"),
	             ("Accounts", "WHT Certificate", "customer"), ("Containers", "Container Movement", "customer"),
	             ("Orders", "Quick Order", "customer")],
	"Sales Order": [("Orders", "Quick Order", "sales_order"), ("Costs", "Expense Claim", "for_sales_order")],
	"Supplier": [("Evaluation", "Supplier Evaluation", "supplier"), ("Imports", "Import Shipment", "supplier"),
	             ("Waste", "Disposal Order", "vendor"), ("Waste", "Disposal Vendor Price", "supplier")],
	"Employee": [("Commission", "Commission Agreement", "employee"), ("Commission", "Commission Entry", "employee"),
	             ("Access", "Access Grant", "employee"), ("Learning", "Training Need", "employee"),
	             ("Contract and Pay", "Employment Contract", "employee"), ("Contract and Pay", "Staff Payslip", "employee")],
	"BOM": [("Costing", "Product Cost Sheet", "bom")],
	"Delivery Note": [("Dispatch", "Dispatch Safety Check", "delivery_note"), ("Dispatch", "Container Movement", "delivery_note"),
	                  ("Service", "Customer Complaint", "delivery_note")],
	"Sales Invoice": [("Service", "Customer Complaint", "sales_invoice"), ("Commission", "Commission Entry", "sales_invoice"),
	                  ("Costs", "Expense Claim", "for_sales_invoice")],
	"Quality Inspection": [("Investigation", "OOS Investigation", "quality_inspection")],
	"Purchase Order": [("Imports", "Import Shipment", "purchase_order")],
	"Purchase Receipt": [("Imports", "Import Shipment", "purchase_receipt")],
	"Work Order": [("Waste", "Batch", "source_work_order")],
	"Payment Entry": [("Accounts", "WHT Certificate", "payment_entry")],
	"Stock Entry": [("Waste", "Disposal Order", "issue_entry")],
	"Equipment": [("Calibration", "Calibration Record", "equipment"), ("Maintenance", "Maintenance Job", "equipment"),
	              ("Maintenance", "PM Schedule", "equipment"), ("Maintenance", "Return to Service", "equipment")],
	"Substance Register": [("Products", "Item", "substance")],
	"Training Program": [("Learning", "Training Need", "training_program")],
	"Legal Requirement": [],
	"Client Water System": [("Field Laboratory", "Water Sample", "water_system"), ("Field Laboratory", "Water Analysis", "water_system")],
	"Water Sample": [("Field Laboratory", "Water Analysis", "water_sample")],
	"Tender Category": [("Tenders", "Tender", "category"), ("Tenders", "Tender Lead", "category")],
	"Item Group": [("Tenders", "Tender Category", "item_group")],
}


def ensure_connections():
	for parent, rows in CONNECTIONS.items():
		if not frappe.db.exists("DocType", parent):
			continue
		for group, link_doctype, fieldname in rows:
			if not frappe.db.exists("DocType", link_doctype) or not frappe.get_meta(link_doctype).has_field(fieldname):
				continue
			if frappe.db.exists("DocType Link", {"parent": parent, "link_doctype": link_doctype, "link_fieldname": fieldname}):
				continue
			frappe.get_doc({"doctype": "DocType Link", "parent": parent, "parenttype": "DocType", "parentfield": "links",
			                "link_doctype": link_doctype, "link_fieldname": fieldname, "group": group, "custom": 1}).insert(ignore_permissions=True)


def ensure_manufacturing_links():
	"""Put Product Costing on ERPNext's own Manufacturing workspace."""
	if not frappe.db.exists("Workspace", "Manufacturing"):
		return
	ws = frappe.get_doc("Workspace", "Manufacturing")
	if any(l.link_to == "Product Cost Sheet" for l in ws.links):
		return
	ws.append("links", {"type": "Card Break", "label": "Product Costing", "link_count": 3})
	for label, kind, ref in (("Product Cost Sheet", "DocType", None), ("Cost Element", "DocType", None),
	                         ("Product Cost Summary", "Report", "Product Cost Sheet")):
		ws.append("links", {"type": "Link", "label": label, "link_to": label, "link_type": kind,
		                    "is_query_report": 1 if kind == "Report" else 0, "report_ref_doctype": ref})
	import json

	content = json.loads(ws.content or "[]")
	content.append({"id": "chemcosting", "type": "card", "data": {"card_name": "Product Costing", "col": 4}})
	ws.content = json.dumps(content)
	ws.flags.ignore_permissions = True
	ws.save()


def ensure_cost_elements():
	"""Starting cost elements with zero rates; the MD and Accounts set the rates and can add, change or retire any."""
	if frappe.db.count("Cost Element"):
		return
	for name, category, basis, qty, absorb in COST_ELEMENTS:
		frappe.get_doc({"doctype": "Cost Element", "element_name": name, "category": category, "basis": basis,
		                "default_rate": 0, "default_quantity": qty, "absorb_into_stock": 0, "active": 1,
		                "description": "Set the rate, and an absorbed cost account if it should be added to stock value."
		                if absorb else "Set the rate."}).insert(ignore_permissions=True)


def ensure_lab_permissions():
	"""QC Analyst and Laboratory Technician: create and fill in Quality Inspections; read what an inspection refers to."""
	from frappe.permissions import add_permission, update_permission_property

	for role in LAB_ROLES:
		if not frappe.db.exists("Role", role):
			continue
		for dt, rights in [("Quality Inspection", ("read", "write", "create", "report", "print", "email"))] + [(d, ("read", "report")) for d in LAB_READ]:
			if not frappe.db.exists("DocType", dt):
				continue
			if not frappe.db.exists("Custom DocPerm", {"parent": dt, "role": role, "permlevel": 0}):
				add_permission(dt, role, 0)
			for ptype in rights:
				update_permission_property(dt, role, 0, ptype, 1, validate=False)


def ensure_approver_permissions():
	from frappe.permissions import add_permission, update_permission_property

	for role, doctypes in APPROVER_PERMS.items():
		if not frappe.db.exists("Role", role):
			continue
		for dt in doctypes:
			if not frappe.db.exists("DocType", dt):
				continue
			if not frappe.db.exists("Custom DocPerm", {"parent": dt, "role": role, "permlevel": 0}):
				add_permission(dt, role, 0)
			for ptype in ("read", "write", "submit", "report", "print", "email"):
				update_permission_property(dt, role, 0, ptype, 1, validate=False)
			if role == "Managing Director":
				for ptype in ("cancel", "amend"):
					update_permission_property(dt, role, 0, ptype, 1, validate=False)
LOG = {"fieldtype": "Table", "options": "Approval Log", "read_only": 1, "allow_on_submit": 1, "no_copy": 1}
LEVEL = {"fieldtype": "Select", "options": "\nNone\nManager\nMD", "read_only": 1, "no_copy": 1}


MD_FLAG = {"fieldname": "raised_by_md", "label": "Raised by the Managing Director", "fieldtype": "Check", "read_only": 1, "no_copy": 1}


AOS = {"allow_on_submit": 1}


def RECEIPT_CLOCK(after):
	return [{"fieldname": "receipt_requested_on", "label": "Receipt Requested On", "fieldtype": "Datetime", "read_only": 1, "allow_on_submit": 1, "insert_after": after, "description": "The 72-hour clock for attaching the receipt starts here"}, {"fieldname": "receipt_due_by", "label": "Receipt Due By", "fieldtype": "Datetime", "read_only": 1, "allow_on_submit": 1, "insert_after": "receipt_requested_on"}, {"fieldname": "receipt_warning_sent", "fieldtype": "Check", "hidden": 1, "allow_on_submit": 1, "insert_after": "receipt_due_by", "label": "Warning Sent"}, {"fieldname": "receipt_breach_sent", "fieldtype": "Check", "hidden": 1, "allow_on_submit": 1, "insert_after": "receipt_warning_sent", "label": "Breach Notice Sent"}]

RO = {"read_only": 1, "allow_on_submit": 1}
BOM_COSTING_FIELDS = [
	{"fieldname": "costing_tab", "label": "Product Costing", "fieldtype": "Tab Break", "insert_after": "amended_from"},
	{"fieldname": "cost_pack_size", "label": "Pack Size (kg per pack)", "fieldtype": "Float", "insert_after": "costing_tab", **AOS},
	{"fieldname": "cost_monthly_volume", "label": "Expected Monthly Output (kg)", "fieldtype": "Float", "insert_after": "cost_pack_size", **AOS},
	{"fieldname": "cost_cb1", "fieldtype": "Column Break", "insert_after": "cost_monthly_volume"},
	{"fieldname": "cost_target_margin", "label": "Target Gross Margin %", "fieldtype": "Percent", "default": "30", "insert_after": "cost_cb1", **AOS},
	{"fieldname": "cost_standard_sheet", "label": "Standard Cost Sheet", "fieldtype": "Link", "options": "Product Cost Sheet",
	 "insert_after": "cost_target_margin", **RO},
	{"fieldname": "cost_lines_section", "label": "Labour, Electricity, Packaging and Other Costs", "fieldtype": "Section Break",
	 "insert_after": "cost_standard_sheet",
	 "description": "Every active cost item is added for a new formula. Change rates here, or add rows for further cost items (create them under Cost Element). Materials come from the formula above."},
	{"fieldname": "costing_lines", "label": "Cost Items", "fieldtype": "Table", "options": "Cost Sheet Line", "insert_after": "cost_lines_section", **AOS},
	{"fieldname": "cost_summary_section", "label": "Cost per Batch", "fieldtype": "Section Break", "insert_after": "costing_lines"},
	{"fieldname": "cost_materials", "label": "Raw Materials", "fieldtype": "Currency", "insert_after": "cost_summary_section", **RO},
	{"fieldname": "cost_packaging", "label": "Packaging", "fieldtype": "Currency", "insert_after": "cost_materials", **RO},
	{"fieldname": "cost_labour", "label": "Labour", "fieldtype": "Currency", "insert_after": "cost_packaging", **RO},
	{"fieldname": "cost_utilities", "label": "Electricity, Water and Overheads", "fieldtype": "Currency", "insert_after": "cost_labour", **RO},
	{"fieldname": "cost_cb2", "fieldtype": "Column Break", "insert_after": "cost_utilities"},
	{"fieldname": "cost_other", "label": "Other Cost Items", "fieldtype": "Currency", "insert_after": "cost_cb2", **RO},
	{"fieldname": "cost_disposal", "label": "Waste Disposal", "fieldtype": "Currency", "insert_after": "cost_other", **RO},
	{"fieldname": "cost_coproduct_credit", "label": "Less Co-product Credit", "fieldtype": "Currency", "insert_after": "cost_disposal", **RO},
	{"fieldname": "cost_total_batch", "label": "Total Cost per Batch", "fieldtype": "Currency", "insert_after": "cost_coproduct_credit", **RO},
	{"fieldname": "cost_cb3", "fieldtype": "Column Break", "insert_after": "cost_total_batch"},
	{"fieldname": "cost_per_kg", "label": "Cost per kg", "fieldtype": "Currency", "insert_after": "cost_cb3", **RO},
	{"fieldname": "cost_per_pack", "label": "Cost per Pack", "fieldtype": "Currency", "insert_after": "cost_per_kg", **RO},
	{"fieldname": "cost_suggested_price_kg", "label": "Suggested Price per kg", "fieldtype": "Currency", "insert_after": "cost_per_pack", **RO},
	{"fieldname": "cost_suggested_price_pack", "label": "Suggested Price per Pack", "fieldtype": "Currency", "insert_after": "cost_suggested_price_kg", **RO},
]


def _log_fields(after):
	return [{"fieldname": "approval_level", "label": "Approval Level", "insert_after": after, **LEVEL},
	        {**MD_FLAG, "insert_after": "approval_level"},
	        {"fieldname": "sb_approval_log", "label": "Approval Log", "fieldtype": "Section Break", "collapsible": 1,
	         "insert_after": "approval_level"},
	        {"fieldname": "approval_log", "label": "Approval Log", "insert_after": "sb_approval_log", **LOG}]


def custom_fields():
	cf = {
		"Warehouse": [
			{"fieldname": "qc_zone", "label": "QC Zone", "fieldtype": "Select", "insert_after": "warehouse_name",
			 "options": "Neutral\nReceiving\nQuarantine\nReleased\nWIP\nTransit\nRejected\nWaste Hold", "default": "Neutral",
			 "in_list_view": 1, "in_standard_filter": 1},
			{"fieldname": "capacity_kg", "label": "Capacity (kg)", "fieldtype": "Float", "insert_after": "qc_zone"},
			{"fieldname": "max_storage_kg", "label": "Permitted Maximum (kg)", "fieldtype": "Float", "insert_after": "capacity_kg",
			 "description": "From the storage permit or fire certificate: stock may not exceed it"},
			{"fieldname": "segregated_bays", "label": "Has Segregated Bays", "fieldtype": "Check", "insert_after": "max_storage_kg",
			 "description": "Separate bunded bays for incompatible chemicals: mixing classes then warns instead of stopping"},
		],
		"Quality Inspection Template": [
			{"fieldname": "coa_section", "label": "Certificate of Analysis", "fieldtype": "Section Break", "insert_after": "item_quality_inspection_parameter"},
			{"fieldname": "coa_comment", "label": "COA Comment", "fieldtype": "Small Text", "insert_after": "coa_section",
			 "description": "Leave blank to use the default comment in Chemical ERP Settings"},
			{"fieldname": "coa_product_notes", "label": "Product Technical Notes", "fieldtype": "Small Text", "insert_after": "coa_comment",
			 "description": "One note per line: storage, stability and handling notes specific to this product"},
		],
		"Item Quality Inspection Parameter": [
			{"fieldname": "test_method", "label": "QATM No.", "fieldtype": "Data", "insert_after": "specification", "in_list_view": 1, "columns": 1},
			{"fieldname": "specification_text", "label": "Specification as Printed", "fieldtype": "Data", "insert_after": "test_method",
			 "description": "e.g. 8.0 – 10.0, or Clear, light green–yellow liquid. Leave blank to print the limits."},
		],
		"Quality Inspection Reading": [
			{"fieldname": "instrument", "label": "Instrument", "fieldtype": "Link", "options": "Equipment", "insert_after": "specification", "in_list_view": 1},
			{"fieldname": "reagent", "label": "Reagent Solution", "fieldtype": "Link", "options": "Reagent Solution", "insert_after": "instrument"},
			{"fieldname": "test_method", "label": "QATM No.", "fieldtype": "Data", "insert_after": "reagent"},
			{"fieldname": "specification_text", "label": "Specification as Printed", "fieldtype": "Data", "insert_after": "test_method"},
		],
		"User": [
			{"fieldname": "signature_image", "label": "Signature", "fieldtype": "Attach Image", "insert_after": "user_image",
			 "description": "Printed on certificates this user countersigns"},
		],
		"Item": [
			{"fieldname": "chem_section", "label": "Chemical Data", "fieldtype": "Section Break", "insert_after": "description"},
			{"fieldname": "substance", "label": "Substance", "fieldtype": "Link", "options": "Substance Register", "insert_after": "chem_section"},
			{"fieldname": "is_hazardous", "label": "Hazardous", "fieldtype": "Check", "insert_after": "substance"},
			{"fieldname": "requires_current_sds", "label": "Requires Current SDS to Deliver", "fieldtype": "Check", "default": "1", "insert_after": "is_hazardous"},
			{"fieldname": "density_kg_per_l", "label": "Density (kg/L)", "fieldtype": "Float", "insert_after": "requires_current_sds",
			 "fetch_from": "substance.density_kg_per_l", "fetch_if_empty": 1},
			{"fieldname": "chem_cb1", "fieldtype": "Column Break", "insert_after": "density_kg_per_l"},
			{"fieldname": "is_potency_managed", "label": "Potency Managed", "fieldtype": "Check", "insert_after": "chem_cb1"},
			{"fieldname": "target_assay", "label": "Target Assay %", "fieldtype": "Percent", "insert_after": "is_potency_managed", "depends_on": "is_potency_managed"},
			{"fieldname": "price_floor", "label": "Price Floor (per stock unit)", "fieldtype": "Currency", "insert_after": "target_assay"},
			{"fieldname": "chem_cb2", "fieldtype": "Column Break", "insert_after": "price_floor"},
			{"fieldname": "is_waste_item", "label": "Waste Item", "fieldtype": "Check", "insert_after": "chem_cb2"},
			{"fieldname": "waste_physical_form", "label": "Waste Form", "fieldtype": "Select", "options": "\nSolid\nLiquid\nSludge\nGas",
			 "insert_after": "is_waste_item", "depends_on": "is_waste_item"},
			{"fieldname": "allowed_disposal_methods", "label": "Allowed Disposal Methods", "fieldtype": "Table",
			 "options": "Allowed Disposal Method", "insert_after": "waste_physical_form", "depends_on": "is_waste_item"},
			{"fieldname": "efris_commodity_code", "label": "EFRIS Commodity Code", "fieldtype": "Data", "insert_after": "allowed_disposal_methods"},
			{"fieldname": "efris_unit", "label": "EFRIS Unit Code", "fieldtype": "Data", "insert_after": "efris_commodity_code"},
			{"fieldname": "is_returnable_container", "label": "Returnable Container", "fieldtype": "Check", "insert_after": "efris_unit"},
			{"fieldname": "container_deposit", "label": "Deposit per Container", "fieldtype": "Currency", "insert_after": "is_returnable_container",
			 "depends_on": "is_returnable_container"},
			{"fieldname": "coa_description", "label": "Description on COA", "fieldtype": "Data", "insert_after": "efris_unit",
			 "description": "e.g. Sodium Hypochlorite Solution (8.0 – 10.0% w/v)"},
		],
		"Batch": [
			{"fieldname": "qc_status", "label": "QC Status", "fieldtype": "Select", "insert_after": "batch_id", "default": "Quarantine",
			 "options": "Quarantine\nReleased\nRetest Due\nRejected\nExpired", "read_only": 1, "in_list_view": 1, "in_standard_filter": 1},
			{"fieldname": "retest_date", "label": "Retest Date", "fieldtype": "Date", "insert_after": "expiry_date"},
			{"fieldname": "assay", "label": "Assay %", "fieldtype": "Percent", "insert_after": "retest_date", "read_only": 1},
			{"fieldname": "grade", "label": "Grade", "fieldtype": "Data", "insert_after": "assay"},
			{"fieldname": "supplier_batch", "label": "Supplier Batch No.", "fieldtype": "Data", "insert_after": "grade"},
			{"fieldname": "accepted_inspection", "label": "Accepted Inspection (COA)", "fieldtype": "Link", "options": "Quality Inspection",
			 "insert_after": "supplier_batch", "read_only": 1},
			{"fieldname": "source_work_order", "label": "Source Work Order", "fieldtype": "Link", "options": "Work Order", "insert_after": "accepted_inspection", "read_only": 1},
			{"fieldname": "is_waste_batch", "label": "Waste Batch", "fieldtype": "Check", "insert_after": "source_work_order", "read_only": 1},
			{"fieldname": "waste_from_batch", "label": "Waste From Batch", "fieldtype": "Link", "options": "Batch", "insert_after": "is_waste_batch", "read_only": 1},
			{"fieldname": "supplier_coa", "label": "Supplier COA", "fieldtype": "Attach", "insert_after": "waste_from_batch", "read_only": 1},
			{"fieldname": "supplier_sds", "label": "Supplier SDS", "fieldtype": "Attach", "insert_after": "supplier_coa", "read_only": 1},
		],
		"BOM": [
			{"fieldname": "formula_status", "label": "Formula Status", "fieldtype": "Select", "options": "Draft\nApproved\nObsolete",
			 "default": "Draft", "read_only": 1, "insert_after": "item", "in_list_view": 1, "allow_on_submit": 1},
			{"fieldname": "formula_level", "label": "Formula Level", "fieldtype": "Select", "options": "Production recipe\nMaster premix",
			 "default": "Production recipe", "insert_after": "formula_status"},
			{"fieldname": "is_confidential", "label": "Confidential", "fieldtype": "Check", "read_only": 1, "insert_after": "formula_level"},
			{"fieldname": "expected_disposal_cost", "label": "Expected Disposal Cost", "fieldtype": "Currency", "read_only": 1, "insert_after": "total_cost"},
			{"fieldname": "yield_section", "label": "Yield and Waste", "fieldtype": "Section Break", "insert_after": "expected_disposal_cost"},
			{"fieldname": "expected_yield_percent", "label": "Expected Yield (%)", "fieldtype": "Percent", "insert_after": "yield_section",
			 "description": "Product out ÷ total batch. Blank: worked out from the formula. Waste = (1 − Yield %) × Total Batch Size"},
			{"fieldname": "yield_cb", "fieldtype": "Column Break", "insert_after": "expected_yield_percent"},
			{"fieldname": "total_batch_kg", "label": "Total Batch Size (kg)", "fieldtype": "Float", "read_only": 1, "insert_after": "yield_cb",
			 "description": "Everything charged into the batch"},
			{"fieldname": "expected_waste_kg", "label": "Expected Waste (kg)", "fieldtype": "Float", "read_only": 1, "insert_after": "total_batch_kg"},
			{"fieldname": "substitutes_section", "label": "Substitutes", "fieldtype": "Section Break", "insert_after": "items", "collapsible": 1},
			{"fieldname": "substitutes", "label": "Substitutes", "fieldtype": "Table", "options": "BOM Substitute", "insert_after": "substitutes_section"},
		] + _log_fields("is_confidential")[1:] + BOM_COSTING_FIELDS,
		"BOM Scrap Item": [
			{"fieldname": "is_co_product", "label": "Co-product", "fieldtype": "Check", "insert_after": "item_code", "in_list_view": 1},
			{"fieldname": "allocation_percent", "label": "Cost Allocation %", "fieldtype": "Percent", "insert_after": "is_co_product",
			 "depends_on": "is_co_product", "in_list_view": 1},
		],
		"Work Order": [
			{"fieldname": "is_confidential", "label": "Confidential", "fieldtype": "Check", "read_only": 1, "insert_after": "bom_no"},
			{"fieldname": "differs_from_sales_order", "label": "Differs From Sales Order", "fieldtype": "Check", "read_only": 1, "insert_after": "is_confidential"},
		] + _log_fields("differs_from_sales_order"),
		"Stock Entry": [
			{"fieldname": "is_confidential", "label": "Confidential", "fieldtype": "Check", "read_only": 1, "insert_after": "stock_entry_type"},
			{"fieldname": "is_release_transfer", "label": "System Release Transfer", "fieldtype": "Check", "read_only": 1, "insert_after": "is_confidential"},
			{"fieldname": "release_reference", "label": "Release Reference", "fieldtype": "Data", "read_only": 1, "insert_after": "is_release_transfer"},
			{"fieldname": "disposal_order", "label": "Disposal Order", "fieldtype": "Link", "options": "Disposal Order", "read_only": 1, "insert_after": "release_reference"},
			{"fieldname": "waste_reason", "label": "Reason for Low or Zero Waste", "fieldtype": "Small Text", "insert_after": "disposal_order",
			 "depends_on": "eval:doc.purpose=='Manufacture'"},
			{"fieldname": "excess_waste_approved_by", "label": "Excess Waste Approved By", "fieldtype": "Link", "options": "User",
			 "read_only": 1, "insert_after": "waste_reason"},
			{"fieldname": "excess_waste_approved_qty", "label": "Approved Waste Quantities", "fieldtype": "Small Text", "read_only": 1,
			 "hidden": 1, "no_copy": 1, "insert_after": "excess_waste_approved_by"},
			{"fieldname": "waste_weighed", "label": "Waste Weighed", "fieldtype": "Check", "insert_after": "excess_waste_approved_qty",
			 "no_copy": 1, "description": "Tick once the waste has been weighed and the quantities entered (not the formula's figure)"},
			{"fieldname": "waste_expected_kg", "label": "Waste Expected by Formula (kg)", "fieldtype": "Float", "read_only": 1,
			 "insert_after": "waste_weighed", "no_copy": 1},
			{"fieldname": "waste_recorded_kg", "label": "Waste Recorded (kg)", "fieldtype": "Float", "read_only": 1,
			 "insert_after": "waste_expected_kg", "no_copy": 1},
			{"fieldname": "total_batch_kg", "label": "Total Batch Size (kg)", "fieldtype": "Float", "read_only": 1,
			 "insert_after": "waste_recorded_kg", "no_copy": 1},
			{"fieldname": "expected_yield_percent", "label": "Formula Yield (%)", "fieldtype": "Percent", "read_only": 1,
			 "insert_after": "total_batch_kg", "no_copy": 1},
			{"fieldname": "actual_yield_percent", "label": "Actual Yield (%)", "fieldtype": "Percent", "read_only": 1,
			 "insert_after": "expected_yield_percent", "no_copy": 1},
			{"fieldname": "waste_unaccounted_kg", "label": "Loss Not Recorded as Waste (kg)", "fieldtype": "Float", "read_only": 1,
			 "insert_after": "actual_yield_percent", "no_copy": 1,
			 "description": "Batch in − product out − waste recorded: evaporation, spills or unweighed waste"},
		],
		"Stock Entry Detail": [
			{"fieldname": "potency_factor", "label": "Potency Factor", "fieldtype": "Float", "read_only": 1, "insert_after": "qty", "precision": "4"},
		],
		"Purchase Receipt Item": [
			{"fieldname": "supplier_batch_no", "label": "Supplier Batch No.", "fieldtype": "Data", "insert_after": "batch_no"},
			{"fieldname": "supplier_coa", "label": "Supplier COA", "fieldtype": "Attach", "insert_after": "supplier_batch_no",
			 "description": "Required for chemicals before the receipt goes to the MD"},
			{"fieldname": "supplier_sds", "label": "Supplier SDS", "fieldtype": "Attach", "insert_after": "supplier_coa",
			 "description": "Required for chemicals before the receipt goes to the MD"},
		],
		"Purchase Receipt": [
			{"fieldname": "supplier_delivery_note_file", "label": "Supplier's Delivery Note (optional)", "fieldtype": "Attach",
			 "insert_after": "supplier", "allow_on_submit": 1},
		],
		"Purchase Order": [
			{"fieldname": "supplier_receipt", "label": "Supplier's Receipt", "fieldtype": "Attach", "insert_after": "supplier",
			 "allow_on_submit": 1,
			 "description": "Attached after the purchase by the person who raised it; the supplier's invoice is fine where it serves as the receipt. The order cannot close until it is attached"},
			{"fieldname": "supplier_receipt_status", "label": "Supplier's Receipt", "fieldtype": "Select", "read_only": 1, "allow_on_submit": 1,
			 "options": "\nAwaiting Supplier Receipt\nAttached", "insert_after": "supplier_receipt", "in_standard_filter": 1},
			{"fieldname": "purchase_originator", "label": "Raised By", "fieldtype": "Link", "options": "User", "read_only": 1,
			 "allow_on_submit": 1, "insert_after": "supplier_receipt_status"},
			{"fieldname": "signed_lpo", "label": "Signed and Stamped LPO", "fieldtype": "Attach", "insert_after": "purchase_originator",
			 "allow_on_submit": 1, "description": "Optional: the supplier's signed acknowledgement of this order"},
		],
		"Quotation": [
			{"fieldname": "sale_originator", "label": "Sale Originator", "fieldtype": "Link", "options": "User", "insert_after": "order_type",
			 "in_standard_filter": 1, "no_copy": 1, "description": "Earns commission on the profit if they have a commission agreement"},
		],
		"Expense Claim": [
			{"fieldname": "for_sales_order", "label": "For Sale (Sales Order)", "fieldtype": "Link", "options": "Sales Order",
			 "insert_after": "employee", "description": "Spent to win or deliver this sale: it reduces the sale's profit (and commission)"},
			{"fieldname": "for_sales_invoice", "label": "For Sale (Sales Invoice)", "fieldtype": "Link", "options": "Sales Invoice",
			 "insert_after": "for_sales_order"},
		],
		"Expense Claim Detail": [
			{"fieldname": "receipt", "label": "Receipt", "fieldtype": "Attach", "insert_after": "description", "in_list_view": 1, "columns": 2,
			 "allow_on_submit": 1, "description": "Attached after approval, once the money has been spent"},
		],
		"Sales Order": [
			{"fieldname": "customer_po_file", "label": "Customer's Purchase Order (copy)", "fieldtype": "Attach", "insert_after": "po_date",
			 "allow_on_submit": 1, "description": "The customer's signed LPO: the basis for the invoice"},
		],
		"Delivery Note Item": [
			{"fieldname": "sds_file", "label": "SDS File Sent", "fieldtype": "Link", "options": "SDS File", "read_only": 1, "insert_after": "batch_no"},
		],
		"Delivery Note": [
			{"fieldname": "customer_po_file", "label": "Customer's Purchase Order (copy)", "fieldtype": "Attach", "insert_after": "po_date",
			 "read_only": 1, "allow_on_submit": 1},
			{"fieldname": "containers_returnable", "label": "Containers to Be Returned", "fieldtype": "Check", "insert_after": "customer",
			 "description": "Optional: tick when this customer will send the containers back"},
		],
		"Sales Invoice": [
			{"fieldname": "customer_po_file", "label": "Customer's Purchase Order (copy)", "fieldtype": "Attach", "insert_after": "po_date",
			 "allow_on_submit": 1, "description": "Copied from the sales order; attach here for invoices without one"},
			{"fieldname": "efris_section", "label": "EFRIS", "fieldtype": "Section Break", "insert_after": "remarks", "collapsible": 1},
			{"fieldname": "efris_status", "label": "EFRIS Status", "fieldtype": "Select", "options": "\nPending\nFiscalised\nFailed",
			 "read_only": 1, "allow_on_submit": 1, "insert_after": "efris_section", "in_standard_filter": 1},
			{"fieldname": "efris_fdn", "label": "Fiscal Document Number", "fieldtype": "Data", "allow_on_submit": 1, "insert_after": "efris_status",
			 "description": "Manual mode: key in the number from the URA Desktop App"},
			{"fieldname": "efris_verification_code", "label": "Verification Code", "fieldtype": "Data", "allow_on_submit": 1, "insert_after": "efris_fdn"},
			{"fieldname": "efris_qr_code", "label": "EFRIS QR Code", "fieldtype": "Small Text", "allow_on_submit": 1, "insert_after": "efris_verification_code"},
			{"fieldname": "efris_fiscalised_on", "label": "Fiscalised On", "fieldtype": "Datetime", "read_only": 1, "allow_on_submit": 1, "insert_after": "efris_qr_code"},
			{"fieldname": "wht_section", "label": "Withholding Tax", "fieldtype": "Section Break", "insert_after": "efris_fiscalised_on", "collapsible": 1,
			 "collapsible_depends_on": "wht_applicable"},
			{"fieldname": "wht_applicable", "label": "Customer Deducts WHT", "fieldtype": "Check", "allow_on_submit": 1, "insert_after": "wht_section",
			 "fetch_from": "customer.deducts_wht", "fetch_if_empty": 1},
			{"fieldname": "wht_amount", "label": "WHT Expected", "fieldtype": "Currency", "options": "Company:company:default_currency",
			 "allow_on_submit": 1, "insert_after": "wht_applicable", "depends_on": "wht_applicable",
			 "description": "Calculated at the WHT rate on the value excluding VAT; change it if the customer withheld a different amount"},
			{"fieldname": "wht_status", "label": "WHT Certificate Status", "fieldtype": "Select", "read_only": 1, "allow_on_submit": 1,
			 "options": "\nAwaiting Certificate\nCertificate Received\nClaimed", "insert_after": "wht_amount", "depends_on": "wht_applicable",
			 "in_standard_filter": 1},
			{"fieldname": "wht_cb", "fieldtype": "Column Break", "insert_after": "wht_status"},
			{"fieldname": "wht_certificate_no", "label": "WHT Certificate No.", "fieldtype": "Data", "allow_on_submit": 1, "insert_after": "wht_cb",
			 "depends_on": "wht_applicable"},
			{"fieldname": "wht_certificate_file", "label": "Attach WHT Certificate", "fieldtype": "Attach", "allow_on_submit": 1,
			 "insert_after": "wht_certificate_no", "depends_on": "wht_applicable",
			 "description": "Attach whenever it arrives, even months later. Nothing waits on it"},
			{"fieldname": "wht_certificate", "label": "WHT Certificate Record", "fieldtype": "Link", "options": "WHT Certificate", "read_only": 1,
			 "allow_on_submit": 1, "insert_after": "wht_certificate_file", "depends_on": "wht_applicable"},
		],
		"Customer": [
			{"fieldname": "efris_buyer_type", "label": "EFRIS Buyer Type", "fieldtype": "Select", "options": "Business\nIndividual\nGovernment\nForeigner",
			 "default": "Business", "insert_after": "tax_id"},
			{"fieldname": "spec_section", "label": "Customer Specifications", "fieldtype": "Section Break", "insert_after": "efris_buyer_type", "collapsible": 1},
			{"fieldname": "customer_spec", "label": "Specifications", "fieldtype": "Table", "options": "Customer Spec Line", "insert_after": "spec_section"},
			{"fieldname": "po_required", "label": "Sends a Purchase Order", "fieldtype": "Check", "default": "1", "insert_after": "tax_id",
			 "description": "Untick for cash or walk-in customers who do not issue purchase orders"},
			{"fieldname": "deducts_wht", "label": "Deducts Withholding Tax", "fieldtype": "Check", "insert_after": "tax_id",
			 "description": "Government bodies and designated withholding agents. Their invoices then expect a WHT certificate"},
			{"fieldname": "returns_containers", "label": "Returns Containers", "fieldtype": "Check", "insert_after": "efris_buyer_type",
			 "description": "Optional. Tick if this customer sends drums, IBCs or jerrycans back; deliveries then record containers owed"},
		],
		"Supplier": [
			{"fieldname": "chem_supplier_section", "label": "Chemical Supply", "fieldtype": "Section Break", "insert_after": "supplier_group"},
			{"fieldname": "is_approved_vendor", "label": "Approved Vendor", "fieldtype": "Check", "insert_after": "chem_supplier_section"},
			{"fieldname": "lead_time_days", "label": "Lead Time (days)", "fieldtype": "Int", "insert_after": "is_approved_vendor"},
			{"fieldname": "is_disposal_vendor", "label": "Disposal Vendor", "fieldtype": "Check", "insert_after": "lead_time_days"},
			{"fieldname": "disposal_licence_no", "label": "Disposal Licence No.", "fieldtype": "Data", "insert_after": "is_disposal_vendor", "depends_on": "is_disposal_vendor"},
			{"fieldname": "disposal_licence_expiry", "label": "Licence Expiry", "fieldtype": "Date", "insert_after": "disposal_licence_no", "depends_on": "is_disposal_vendor"},
			{"fieldname": "supplier_rating", "label": "Supplier Rating", "fieldtype": "Data", "read_only": 1, "insert_after": "disposal_licence_expiry"},
			{"fieldname": "last_evaluated_on", "label": "Last Evaluated", "fieldtype": "Date", "read_only": 1, "insert_after": "supplier_rating"},
		],
		"Quality Inspection": [
			{"fieldname": "analyst_signed_by", "label": "Analyst Signed By", "fieldtype": "Link", "options": "User", "read_only": 1, "insert_after": "inspected_by"},
			{"fieldname": "analyst_signed_on", "label": "Analyst Signed On", "fieldtype": "Datetime", "read_only": 1, "insert_after": "analyst_signed_by"},
			{"fieldname": "sb_approval_log", "label": "Approval Log", "fieldtype": "Section Break", "collapsible": 1, "insert_after": "remarks"},
			{"fieldname": "approval_log", "label": "Approval Log", "insert_after": "sb_approval_log", **LOG},
		],

		"Employee": [
			{"fieldname": "certifications_section", "label": "Training, Certifications, Medicals and PPE", "fieldtype": "Section Break",
			 "insert_after": "staff_qualifications", "collapsible": 1},
			{"fieldname": "staff_certifications", "label": "Records", "fieldtype": "Table", "options": "Staff Certification",
			 "insert_after": "certifications_section"},
		],
		"Training Program": [
			{"fieldname": "learning_section", "label": "Learning", "fieldtype": "Section Break", "insert_after": "description"},
			{"fieldname": "certification_title", "label": "Certificate Issued", "fieldtype": "Data", "insert_after": "learning_section",
			 "description": "Exactly as it should appear on the employee's record, e.g. Forklift Operation"},
			{"fieldname": "validity_months", "label": "Valid For (months)", "fieldtype": "Int", "insert_after": "certification_title",
			 "description": "0 = does not expire"},
			{"fieldname": "is_induction", "label": "Induction Program for New Joiners", "fieldtype": "Check", "insert_after": "validity_months"},
			{"fieldname": "materials", "label": "Learning Material", "fieldtype": "Table", "options": "Course Material", "insert_after": "is_induction"},
		],
		"Training Event": [
			{"fieldname": "delivery_mode", "label": "Delivery", "fieldtype": "Select", "options": "In Person\nOnline\nHybrid",
			 "default": "In Person", "insert_after": "event_name"},
			{"fieldname": "meeting_room", "label": "Training Room", "fieldtype": "Data", "read_only": 1, "insert_after": "delivery_mode",
			 "depends_on": "eval:['Online','Hybrid'].includes(doc.delivery_mode)"},
			{"fieldname": "meeting_url", "label": "External Meeting Link", "fieldtype": "Data", "options": "URL", "insert_after": "meeting_room",
			 "depends_on": "eval:['Online','Hybrid'].includes(doc.delivery_mode)",
			 "description": "Only when Learning Settings uses an external platform (Zoom, Google Meet, Teams)"},
		],
		"Training Result Employee": [
			{"fieldname": "outcome", "label": "Outcome", "fieldtype": "Select", "options": "Passed\nFailed\nDid Not Attend",
			 "default": "Passed", "in_list_view": 1, "insert_after": "employee_name"},
			{"fieldname": "online_minutes", "label": "Minutes in Training Room", "fieldtype": "Float", "read_only": 1, "insert_after": "outcome"},
			{"fieldname": "certificate", "label": "Certificate", "fieldtype": "Attach", "insert_after": "online_minutes"},
		],
		"Event": [
			{"fieldname": "event_kind", "label": "Kind", "fieldtype": "Select", "insert_after": "subject",
			 "options": "Meeting\nAppointment\nField Visit\nTraining\nOther", "default": "Meeting", "in_list_view": 1, "in_standard_filter": 1},
			{"fieldname": "party_type", "label": "With (type)", "fieldtype": "Select", "options": "\nCustomer\nSupplier\nLead\nEmployee",
			 "insert_after": "event_kind"},
			{"fieldname": "party", "label": "With", "fieldtype": "Dynamic Link", "options": "party_type", "insert_after": "party_type"},
			{"fieldname": "attendees_section", "label": "Attendees", "fieldtype": "Section Break", "insert_after": "party"},
			{"fieldname": "attendees", "label": "Attendees", "fieldtype": "Table", "options": "Calendar Attendee", "insert_after": "attendees_section"},
			{"fieldname": "visit_section", "label": "Visit Report", "fieldtype": "Section Break", "insert_after": "attendees",
			 "depends_on": "eval:doc.event_kind=='Field Visit'"},
			{"fieldname": "visit_report", "label": "What Happened", "fieldtype": "Text", "insert_after": "visit_section"},
			{"fieldname": "visit_outcome", "label": "Outcome", "fieldtype": "Select", "insert_after": "visit_report",
			 "options": "\nOrder Expected\nQuotation Requested\nComplaint Raised\nFollow-up Needed\nNo Further Action"},
			{"fieldname": "follow_up_date", "label": "Follow-up Date", "fieldtype": "Date", "insert_after": "visit_outcome"},
		],
		"Journal Entry": [
			{"fieldname": "disposal_order", "label": "Disposal Order", "fieldtype": "Link", "options": "Disposal Order", "read_only": 1, "insert_after": "user_remark"},
			{"fieldname": "waste_batch", "label": "Waste Batch", "fieldtype": "Link", "options": "Batch", "read_only": 1, "insert_after": "disposal_order"},
		],
		"Purchase Invoice": [
			{"fieldname": "supplier_invoice_file", "label": "Supplier's Invoice (copy)", "fieldtype": "Attach", "insert_after": "bill_date",
			 "allow_on_submit": 1},
			{"fieldname": "invoice_is_receipt", "label": "This Invoice Is Also the Receipt", "fieldtype": "Check", "insert_after": "supplier_invoice_file",
			 "description": "Tick when the supplier's invoice doubles as the receipt: it is then filed as the receipt on the purchase order"},
		],
		"Purchase Invoice Item": [
			{"fieldname": "disposal_order", "label": "Disposal Order", "fieldtype": "Link", "options": "Disposal Order", "insert_after": "item_code"},
			{"fieldname": "waste_batch", "label": "Waste Batch", "fieldtype": "Link", "options": "Batch", "insert_after": "disposal_order"},
		],
	}
	cf.setdefault("Work Order", []).extend([
		{"fieldname": "material_section", "label": "Material Availability", "fieldtype": "Section Break", "insert_after": "required_items",
		 "collapsible": 1, "description": "Released stock only counts as available; quarantined stock and open purchases are shown separately"},
		{"fieldname": "material_status", "label": "Materials", "fieldtype": "Select", "read_only": 1, "allow_on_submit": 1,
		 "options": "\nAll Available\nShortages Covered\nLate Supplies\nOrder Needed", "insert_after": "material_section",
		 "in_list_view": 1, "in_standard_filter": 1},
		{"fieldname": "material_checked_on", "label": "Checked On", "fieldtype": "Datetime", "read_only": 1, "allow_on_submit": 1,
		 "insert_after": "material_status"},
		{"fieldname": "material_check", "label": "Material Check", "fieldtype": "Table", "options": "Work Order Material Check",
		 "read_only": 1, "allow_on_submit": 1, "insert_after": "material_checked_on"},
	])
	cf.setdefault("Purchase Order", []).append(
		{"fieldname": "for_work_order", "label": "For Manufacturing Order", "fieldtype": "Link", "options": "Work Order",
		 "read_only": 1, "insert_after": "signed_lpo"})
	cf.setdefault("Expense Claim", []).extend(RECEIPT_CLOCK("receipts_status"))
	cf.setdefault("Expense Claim", []).extend([
		{"fieldname": "pattern_section", "label": "Expense Pattern", "fieldtype": "Section Break", "insert_after": "receipt_breach_sent",
		 "collapsible": 1, "collapsible_depends_on": "pattern_flag", "depends_on": "pattern_flag"},
		{"fieldname": "pattern_flag", "label": "Pattern Flagged", "fieldtype": "Check", "read_only": 1, "allow_on_submit": 1,
		 "insert_after": "pattern_section", "in_standard_filter": 1},
		{"fieldname": "pattern_reason", "label": "Why", "fieldtype": "Small Text", "read_only": 1, "allow_on_submit": 1, "insert_after": "pattern_flag"},
		{"fieldname": "pattern_related", "label": "Related Claims", "fieldtype": "Small Text", "read_only": 1, "allow_on_submit": 1,
		 "insert_after": "pattern_reason"},
		{"fieldname": "pattern_cb", "fieldtype": "Column Break", "insert_after": "pattern_related"},
		{"fieldname": "pattern_reviewed", "label": "Pattern Reviewed", "fieldtype": "Check", "insert_after": "pattern_cb",
		 "description": "Approver: confirm the claims are genuine and not split to avoid approval"},
		{"fieldname": "pattern_review_note", "label": "Review Note", "fieldtype": "Small Text", "insert_after": "pattern_reviewed",
		 "depends_on": "pattern_reviewed"},
		{"fieldname": "pattern_reviewed_by", "label": "Reviewed By", "fieldtype": "Link", "options": "User", "read_only": 1,
		 "insert_after": "pattern_review_note"},
	])
	cf.setdefault("Purchase Order", []).extend(RECEIPT_CLOCK("purchase_originator"))
	cf.setdefault("Item", []).extend([
		{"fieldname": "doc_section", "label": "Product Documents", "fieldtype": "Section Break", "insert_after": "coa_description", "collapsible": 1},
		{"fieldname": "doc_profile", "label": "Document Profile", "fieldtype": "Select", "insert_after": "doc_section", "in_standard_filter": 1,
		 "options": "\nHazardous - Made by Us\nHazardous - Bought In\nNon-hazardous Industrial\nConsumer (Brave Home)\nService / Equipment / PPE",
		 "description": "Decides what this product needs: hazardous products cannot be delivered without a current SDS"},
		{"fieldname": "coa_basis", "label": "Certificate Issued", "fieldtype": "Select", "insert_after": "doc_profile",
		 "options": "\nCertificate of Analysis\nCertificate of Testing\nCertificate of Conformity\nNot Applicable",
		 "description": "Analysis: full test by us. Testing: some parameters tested by us. Conformity: to the manufacturer's certificate"},
		{"fieldname": "doc_cb", "fieldtype": "Column Break", "insert_after": "coa_basis"},
		{"fieldname": "needs_conformity_document", "label": "Needs Manufacturer's Certificate or Datasheet", "fieldtype": "Check",
		 "insert_after": "doc_cb", "description": "PPE and equipment"},
	])
	cf.setdefault("Customer", []).extend([
		{"fieldname": "credit_section", "label": "Credit Control", "fieldtype": "Section Break", "insert_after": "requires_sds", "collapsible": 1},
		{"fieldname": "credit_hold", "label": "On Credit Hold", "fieldtype": "Check", "insert_after": "credit_section",
		 "description": "Set automatically (overdue or over the limit) and lifted when cleared; only the MD or Accounts Manager change it by hand"},
		{"fieldname": "credit_hold_reason", "label": "Hold Reason", "fieldtype": "Data", "read_only": 1, "insert_after": "credit_hold"},
		{"fieldname": "credit_hold_manual", "label": "Held by Hand", "fieldtype": "Check", "read_only": 1, "hidden": 1, "insert_after": "credit_hold_reason"},
		{"fieldname": "credit_cb", "fieldtype": "Column Break", "insert_after": "credit_hold_manual"},
		{"fieldname": "collector", "label": "Collector", "fieldtype": "Link", "options": "User", "insert_after": "credit_cb",
		 "description": "Who follows up payment; copied on reminders"},
	])
	for dt, fields in {
		"Vehicle": [
			{"fieldname": "dg_section", "label": "Dangerous Goods and Safety", "fieldtype": "Section Break", "insert_after": "last_odometer"},
			{"fieldname": "dg_permit_expiry", "label": "Dangerous-Goods Permit Expiry", "fieldtype": "Date", "insert_after": "dg_section"},
			{"fieldname": "inspection_expiry", "label": "Inspection Expiry", "fieldtype": "Date", "insert_after": "dg_permit_expiry"},
			{"fieldname": "fire_extinguisher_expiry", "label": "Fire Extinguisher Service Due", "fieldtype": "Date", "insert_after": "inspection_expiry"},
			{"fieldname": "dg_cb", "fieldtype": "Column Break", "insert_after": "fire_extinguisher_expiry"},
			{"fieldname": "max_load_kg", "label": "Maximum Load (kg)", "fieldtype": "Float", "insert_after": "dg_cb"},
			{"fieldname": "spill_kit", "label": "Spill Kit on Board", "fieldtype": "Check", "insert_after": "max_load_kg"},
			{"fieldname": "placards", "label": "Hazard Placards Fitted", "fieldtype": "Check", "insert_after": "spill_kit"},
		],
		"Driver": [
			{"fieldname": "dg_training_expiry", "label": "Dangerous-Goods Training Valid Until", "fieldtype": "Date", "insert_after": "employee",
			 "description": "Needed to carry hazardous loads"},
		],
		"Delivery Trip": [
			{"fieldname": "dg_load_section", "label": "Load and Cost", "fieldtype": "Section Break", "insert_after": "delivery_stops"},
			{"fieldname": "load_kg", "label": "Load (kg)", "fieldtype": "Float", "read_only": 1, "insert_after": "dg_load_section"},
			{"fieldname": "dangerous_goods", "label": "Carries Dangerous Goods", "fieldtype": "Check", "read_only": 1, "insert_after": "load_kg"},
			{"fieldname": "trip_cb", "fieldtype": "Column Break", "insert_after": "dangerous_goods"},
			{"fieldname": "fuel_cost", "label": "Fuel", "fieldtype": "Currency", "insert_after": "trip_cb"},
			{"fieldname": "driver_allowance", "label": "Driver Allowances", "fieldtype": "Currency", "insert_after": "fuel_cost"},
			{"fieldname": "other_cost", "label": "Other Costs (tolls, loading)", "fieldtype": "Currency", "insert_after": "driver_allowance"},
			{"fieldname": "total_cost", "label": "Trip Cost", "fieldtype": "Currency", "read_only": 1, "insert_after": "other_cost"},
			{"fieldname": "cost_per_kg", "label": "Cost per kg", "fieldtype": "Currency", "read_only": 1, "insert_after": "total_cost"},
		],
		"Delivery Note": [
			{"fieldname": "pod_section", "label": "Proof of Delivery", "fieldtype": "Section Break", "insert_after": "containers_returnable", "collapsible": 1},
			{"fieldname": "pod_received_by", "label": "Received By", "fieldtype": "Data", "insert_after": "pod_section", "allow_on_submit": 1},
			{"fieldname": "pod_time", "label": "Delivered At", "fieldtype": "Datetime", "insert_after": "pod_received_by", "allow_on_submit": 1, "read_only": 1},
			{"fieldname": "pod_gps", "label": "GPS", "fieldtype": "Data", "insert_after": "pod_time", "allow_on_submit": 1, "read_only": 1},
			{"fieldname": "pod_cb", "fieldtype": "Column Break", "insert_after": "pod_gps"},
			{"fieldname": "pod_photo", "label": "Photo", "fieldtype": "Attach Image", "insert_after": "pod_cb", "allow_on_submit": 1, "read_only": 1},
			{"fieldname": "pod_notes", "label": "Driver's Notes", "fieldtype": "Small Text", "insert_after": "pod_photo", "allow_on_submit": 1, "read_only": 1},
		],
	}.items():
		cf.setdefault(dt, []).extend(fields)
	cf.setdefault("Sales Invoice", []).append(
		{"fieldname": "reminder_stage", "label": "Reminders Sent", "fieldtype": "Int", "read_only": 1, "no_copy": 1, "allow_on_submit": 1,
		 "insert_after": "due_date"})
	cf.setdefault("Customer", []).extend([
		{"fieldname": "requires_coa", "label": "Requires a Certificate With Every Delivery", "fieldtype": "Check", "insert_after": "po_required",
		 "description": "Deliveries to this customer stop if a batch has no certificate"},
		{"fieldname": "requires_sds", "label": "Requires an SDS for Every Product", "fieldtype": "Check", "insert_after": "requires_coa",
		 "description": "Institutions, hospitals, government: SDS needed even for non-hazardous and consumer products"},
	])
	cf.setdefault("Batch", []).append(
		{"fieldname": "certificate_basis", "label": "Certificate Issued", "fieldtype": "Select", "insert_after": "supplier_sds", "read_only": 1,
		 "options": "\nCertificate of Analysis\nCertificate of Testing\nCertificate of Conformity"})
	cf.setdefault("Purchase Order", []).append(
		{"fieldname": "documents_requested", "label": "Documents to Be Supplied With the Goods", "fieldtype": "Small Text", "read_only": 1,
		 "insert_after": "terms", "description": "Filled from the products' Document Profiles; printed on the order"})
	cf.setdefault("Sales Invoice", []).append(
		{"fieldname": "sale_originator", "label": "Sale Originator", "fieldtype": "Link", "options": "User", "insert_after": "customer",
		 "in_standard_filter": 1, "description": "Carried from the sales order. Earns commission on this sale's profit"})
	cf.setdefault("Sales Order", []).append(
		{"fieldname": "sale_originator", "label": "Sale Originator", "fieldtype": "Link", "options": "User", "insert_after": "customer",
		 "in_standard_filter": 1, "no_copy": 1, "description": "Carried from the quotation. Earns commission on the profit of this sale"})
	cf.setdefault("Payment Entry", []).append(
		{"fieldname": "commission_payout", "label": "Commission Payout", "fieldtype": "Check", "insert_after": "party_name",
		 "depends_on": "eval:doc.party_type=='Employee' && doc.payment_type=='Pay'",
		 "description": "Pays this employee's commission: taken off what they are owed"})
	cf.setdefault("Expense Claim", []).extend([
		{"fieldname": "receipts_status", "label": "Receipts", "fieldtype": "Select", "read_only": 1, "allow_on_submit": 1,
		 "options": "\nAwaiting Receipts\nReceipts Attached", "insert_after": "approval_status", "in_standard_filter": 1},
		{"fieldname": "first_approver", "label": "Signs First", "fieldtype": "Link", "options": "User", "read_only": 1,
		 "insert_after": "expense_approver"},
		{"fieldname": "claimant_is_md", "label": "Claimant Is the Managing Director", "fieldtype": "Check", "read_only": 1,
		 "insert_after": "first_approver"},
	])
	for dt, after in (("Purchase Order", "set_warehouse"), ("Purchase Receipt", "set_warehouse"), ("Quotation", "order_type"),
	                  ("Sales Order", "order_type"), ("Payment Entry", "mode_of_payment"), ("Expense Claim", "approval_status"),
	                  ("Stock Reconciliation", "purpose")):
		cf.setdefault(dt, []).extend(_log_fields(after))
	return cf


BRAVE_PRINT_CSS = """
/* House style: Arial everywhere; lengthy running text at 11pt with 1.15 line spacing. */
.print-format, .print-format table, .print-format td, .print-format th { font-family: Arial, 'Liberation Sans', Helvetica, sans-serif; }
.print-format .ql-editor, .print-format .text-editor-content,
.print-format [data-fieldtype="Text Editor"], .print-format [data-fieldtype="Text"],
.print-format [data-fieldtype="Long Text"], .print-format .terms, .print-format .lengthy {
	font-size: 11pt !important; line-height: 1.15 !important;
}
.print-format .ql-editor p, .print-format .lengthy p { margin: 0 0 8pt; }
"""


def ensure_print_style():
	if not frappe.db.exists("DocType", "Print Style"):
		return
	if frappe.db.exists("Print Style", "House Style"):
		frappe.db.set_value("Print Style", "House Style", "css", BRAVE_PRINT_CSS)
	else:
		frappe.get_doc({"doctype": "Print Style", "print_style_name": "House Style", "css": BRAVE_PRINT_CSS}).insert(ignore_permissions=True)
	current = frappe.db.get_single_value("Print Settings", "print_style")
	if current in (None, "", "Redesign", "Modern", "Classic", "Monochrome", "Brave"):
		frappe.db.set_single_value("Print Settings", "print_style", "House Style")


def after_install():
	ensure_setup(first_install=True)


def after_migrate():
	ensure_setup()


def ensure_setup(first_install=False):
	"""Run every setup step on its own. A step that fails is logged and reported, and the rest carry on,
	so one problem never stops the whole app from installing."""
	from chemical_erp.management_systems import install as ims
	from chemical_erp.people_management import install as hr
	from chemical_erp.tenders_desk import install as tenders

	brave = is_brave()
	steps = [
		("Roles", ensure_roles),
		("Custom fields", ensure_custom_fields),
		("Stock settings", ensure_stock_settings),
		("MD Delegate role", lambda: _call("chemical_erp.controls.delegation.ensure_role_and_permissions")),
		("Approval workflows", lambda: _call("chemical_erp.setup.workflows.ensure_workflows")),
		("Approver permissions", ensure_approver_permissions),
		("Laboratory permissions", ensure_lab_permissions),
		("Cost elements", ensure_cost_elements),
		("Formula seed (Brave)", lambda: brave and _call("chemical_erp.setup.coa_seed.ensure_coa_seed")),
		("Print style and default formats", ensure_print_defaults),
		("House-style PDFs", lambda: _call("chemical_erp.print_pdf.ensure_print_settings")),
		("Tenders Desk", lambda: tenders.ensure_setup(first_install=first_install)),
		("HR and payroll", lambda: hr.ensure_setup(first_install=first_install)),
		("Management Systems register (Brave)", lambda: brave and ims.ensure_setup(first_install=first_install)),
		("Company positions", ensure_positions),  # after Tenders/HR/Learning: every role now exists
		("Access profiles", ensure_access_profiles),
		("Office number", fix_office_number),
		("Company Profile", migrate_company_profile),
		("Renamed modules", tidy_renamed_modules),
		("Water sample statuses", fix_water_sample_statuses),
		("QR address (Brave)", lambda: brave and set_qr_base_url()),
		("Numbering", ensure_numbering_rows),
		("Field Laboratory standards", lambda: _call("chemical_erp.field_laboratory.seed.ensure_seed", brave=brave)),
		("Help topics (user manual)", lambda: _call("chemical_erp.help.search.ensure_topics")),
		("Tender scan", lambda: _call("chemical_erp.tenders_desk.scan_seed.ensure_tender_scan")),
		("Brave defaults", lambda: brave and _call("chemical_erp.setup.brave_defaults.apply")),
		("Document connections", ensure_connections),
		("Manufacturing links", ensure_manufacturing_links),
		("Security settings", lambda: _call("chemical_erp.controls.security.ensure_security")),
		("Product document profiles", lambda: _call("chemical_erp.regulatory_compliance.documents.classify", overwrite=0)),
		("Hide standard modules we replace", lambda: _call("chemical_erp.setup.replaced_modules.ensure")),
		("Delete rights (MD only)", lambda: _call("chemical_erp.controls.deletion.ensure_md_only_delete")),  # last
	]
	problems = []
	for label, fn in steps:
		try:
			fn()
			frappe.db.commit()
		except Exception as e:
			frappe.db.rollback()
			problems.append((label, str(e)[:300]))
			frappe.log_error(title=f"Chemical ERP setup: {label}", message=frappe.get_traceback())
			frappe.db.commit()
	report_setup(problems, len(steps))


def _call(path, *args, **kwargs):
	return frappe.get_attr(path)(*args, **kwargs)


def report_setup(problems, total):
	"""Print the outcome where the person running bench sees it, and keep it for the MD."""
	frappe.cache().set_value("chem_setup_problems", problems)
	if not problems:
		print(f"Chemical ERP: all {total} setup steps completed.")
		return
	print(f"\nChemical ERP: {total - len(problems)} of {total} setup steps completed. These need attention:")
	for label, msg in problems:
		print(f"  - {label}: {msg}")
	print("Full details: Error Log (search 'Chemical ERP setup'). Fix, then run: bench --site <site> migrate\n")


def ensure_roles():
	for role in ROLES:
		if not frappe.db.exists("Role", role):
			frappe.get_doc({"doctype": "Role", "role_name": role, "desk_access": 1}).insert(ignore_permissions=True)


def ensure_custom_fields():
	"""Doctype by doctype, so one bad field only holds back its own document type; the culprit is named."""
	fields = {dt: fl for dt, fl in custom_fields().items() if frappe.db.exists("DocType", dt)}
	if "Employee" in fields and not frappe.get_meta("Employee").has_field("staff_qualifications"):
		for f in fields["Employee"]:
			if f["fieldname"] == "certifications_section":
				f.pop("insert_after")
	failed = []
	for dt, fl in fields.items():
		try:
			create_custom_fields({dt: fl}, update=True)
			frappe.db.commit()
		except Exception:
			frappe.db.rollback()
			for f in fl:  # find the field(s) at fault, keep the rest
				try:
					create_custom_fields({dt: [f]}, update=True)
					frappe.db.commit()
				except Exception as e:
					frappe.db.rollback()
					failed.append(f"{dt}.{f.get('fieldname')} ({str(e)[:120]})")
	if failed:
		raise Exception("Custom fields not added: " + "; ".join(failed))


def ensure_stock_settings():
	if not frappe.db.exists("Stock Entry Type", "QC Sample"):
		frappe.get_doc({"doctype": "Stock Entry Type", "name": "QC Sample", "purpose": "Material Issue"}).insert(ignore_permissions=True)
	# v15: let batch numbers sit on rows so the zone rules can read them directly
	frappe.db.set_single_value("Stock Settings", "use_serial_batch_fields", 1)


def ensure_print_defaults():
	from frappe.custom.doctype.property_setter.property_setter import make_property_setter

	# Company font: Arial on every printed document, including ERPNext's standard formats
	if not frappe.db.get_single_value("Print Settings", "font") or frappe.db.get_single_value("Print Settings", "font") == "Default":
		frappe.db.set_single_value("Print Settings", "font", "Arial")
	ensure_print_style()
	for old in ("Brave Quotation", "Brave Local Purchase Order"):  # renamed to neutral names
		if frappe.db.exists("Print Format", old) and frappe.db.get_value("Print Format", old, "module") == "Chemical Core":
			frappe.delete_doc("Print Format", old, ignore_permissions=True, force=True)
	# sales and purchasing documents: chemical_erp.print_pdf.ensure_print_settings
	for dt, fmt in (("Quality Inspection", "Certificate of Analysis"), ("Water Analysis", "Water Analysis Report"),
	                ("Water Sample", "Field Sampling Sheet")):
		if frappe.db.exists("Print Format", fmt) and frappe.db.exists("DocType", dt):
			make_property_setter(dt, None, "default_print_format", fmt, "Data", for_doctype=True, validate_fields_for_doctype=False)


def fix_water_sample_statuses():
	for old, new in (("Sampled", "Open"), ("In Transit", "Open"), ("Received in Lab", "Open"), ("Testing", "Analysed"), ("Rejected", "Cancelled")):
		frappe.db.sql("update `tabWater Sample` set status = %s where status = %s", (new, old))


def set_qr_base_url():
	if not frappe.db.get_single_value("Chemical ERP Settings", "qr_base_url"):
		frappe.db.set_single_value("Chemical ERP Settings", "qr_base_url", "https://bravechemicals.com/system")


def ensure_numbering_rows():
	from chemical_erp.numbering import add_missing_rows

	for profile in frappe.get_all("Company Profile", pluck="name"):
		add_missing_rows(profile)
