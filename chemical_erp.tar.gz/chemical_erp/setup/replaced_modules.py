"""Standard ERPNext / HRMS workspaces whose job a Chemical ERP module already does. They are hidden from staff, not
deleted: the MD can show them again by unticking 'Hide Standard Modules We Replace' in Chemical ERP Settings, and a
System Manager still sees them (greyed) in the sidebar."""
import frappe

REPLACED = {
	"Payroll": "People Management: Payroll Run (Uganda PAYE, NSSF, LST)",
	"Salary Payout": "People Management: Payroll Run and Staff Payslip",
	"Tax & Benefits": "People Management: PAYE Band Set, statutory returns",
	"Quality": "Management Systems and Regulatory Compliance",
}


def apply(hide=None):
	if hide is None:
		hide = frappe.db.get_single_value("Chemical ERP Settings", "hide_replaced_modules")
	for name in REPLACED:
		if frappe.db.exists("Workspace", name):
			frappe.db.set_value("Workspace", name, "is_hidden", 1 if hide else 0, update_modified=False)
	frappe.clear_cache()


def ensure():
	"""Setup step: hide once on first run; afterwards follow the setting (so migrate never overrides the MD)."""
	if not frappe.db.get_default("chem_replaced_modules_applied"):
		frappe.db.set_single_value("Chemical ERP Settings", "hide_replaced_modules", 1)
		frappe.db.set_default("chem_replaced_modules_applied", "1")
	apply()
