"""Workflow definitions. Where two people sign, the Managing Director's state is reachable only
from the first approver's state, so the MD always signs last. Existing workflows are never
overwritten, so changes made on site survive upgrades."""

import frappe

MD = "Managing Director"
PM = "Plant Manager"   # production and quality approvals; quality may be moved to "QC Manager" in settings
PRODUCTION_WORKFLOWS = {"Chem Work Order", "Chem Stock Reconciliation", "Chem Calibration", "Chem Return to Service"}
QUALITY_WORKFLOWS = {"Chem Batch Release", "Chem Status Override", "Chem Water Analysis"}
# Actions the document's own creator performs; every other action is an approval and may not be done by the creator.
MD_DIRECT = "Approve as MD"
# The MD is the final authority: documents the MD raises go straight to their approved state.
# Not for batch release (needs the analyst's results) or formulas (already the MD's alone) or calibration.
NO_MD_DIRECT = {"Chem Batch Release", "Chem Formula", "Chem Calibration"}
CREATOR_ACTIONS = {"Submit Report", "Submit", "Send for Approval", "Send for Review", "Send to MD", "Submit for Approval", "Sign Results",
                   "Sign", "Revise", "Confirm"}
STYLE = {"Draft": "", "Rejected": "Danger", "Cancelled": "Inverse"}
LVL_NONE = 'doc.approval_level == "None"'
LVL_ANY = 'doc.approval_level in ("Manager", "MD")'
LVL_MGR = 'doc.approval_level == "Manager"'
LVL_MD = 'doc.approval_level == "MD"'

# name: (doctype, [(state, docstatus, editor, update_field, update_value)], [(from, action, to, role, condition)])
WORKFLOWS = {
	"Chem PO Approval": ("Purchase Order",
		[("Draft", 0, "Purchase User", None, None), ("Pending Review", 0, "Accounts User", None, None),
		 ("Pending MD", 0, MD, None, None), ("Approved", 1, "Purchase Manager", None, None),
		 ("Rejected", 0, "Purchase User", None, None), ("Cancelled", 2, MD, None, None)],
		[("Draft", "Submit", "Approved", "Purchase User", LVL_NONE),
		 ("Draft", "Send for Approval", "Pending Review", "Purchase User", LVL_ANY),
		 ("Pending Review", "Approve", "Approved", "Accounts User", LVL_MGR),
		 ("Pending Review", "Approve", "Pending MD", "Accounts User", LVL_MD),
		 ("Pending MD", "Approve", "Approved", MD, None),
		 ("Pending Review", "Reject", "Rejected", "Accounts User", None), ("Pending MD", "Reject", "Rejected", MD, None),
		 ("Rejected", "Revise", "Draft", "Purchase User", None), ("Approved", "Cancel", "Cancelled", MD, None)]),
	"Chem Receipt Approval": ("Purchase Receipt",
		[("Draft", 0, "Stock User", None, None), ("Pending MD", 0, MD, None, None),
		 ("Received into Quarantine", 1, "Stock Manager", None, None), ("Rejected", 0, "Stock User", None, None)],
		[("Draft", "Send to MD", "Pending MD", "Stock User", None),
		 ("Pending MD", "Approve", "Received into Quarantine", MD, None),
		 ("Pending MD", "Reject", "Rejected", MD, None), ("Rejected", "Revise", "Draft", "Stock User", None)]),
	"Chem Batch Release": ("Quality Inspection",
		# readings are entered by a Laboratory Technician (QC Analysts hold that role too); only a QC Analyst signs them
		[("Draft", 0, "Laboratory Technician", None, None), ("Analyst Signed", 0, PM, None, None),
		 ("Released", 1, PM, None, None), ("Batch Rejected", 1, PM, None, None)],
		[("Draft", "Sign Results", "Analyst Signed", "QC Analyst", None),
		 ("Analyst Signed", "Approve Release", "Released", PM, 'doc.status == "Accepted"'),
		 ("Analyst Signed", "Approve Rejection", "Batch Rejected", PM, 'doc.status == "Rejected"'),
		 ("Analyst Signed", "Return to Analyst", "Draft", PM, None)]),
	"Chem Formula": ("BOM",
		[("Draft", 0, "Formula Owner", None, None), ("Approved", 1, MD, "formula_status", "Approved"),
		 ("Obsolete", 1, MD, "is_active", "0")],
		[("Draft", "Approve", "Approved", MD, None), ("Approved", "Make Obsolete", "Obsolete", MD, None)]),
	"Chem Work Order": ("Work Order",
		[("Draft", 0, "Manufacturing User", None, None), ("Pending Plant Manager", 0, PM, None, None),
		 ("Approved", 1, "Manufacturing Manager", None, None), ("Rejected", 0, "Manufacturing User", None, None)],
		[("Draft", "Submit", "Approved", "Manufacturing User", LVL_NONE),
		 ("Draft", "Send for Approval", "Pending Plant Manager", "Manufacturing User", 'doc.approval_level == "MD"'),
		 ("Pending Plant Manager", "Approve", "Approved", PM, None), ("Pending Plant Manager", "Reject", "Rejected", PM, None),
		 ("Rejected", "Revise", "Draft", "Manufacturing User", None)]),
	"Chem Expense Claim v2": ("Expense Claim",
		[("Draft", 0, "Employee", None, None), ("Manager Review", 0, "Expense Approver", None, None),
		 ("MD Review", 0, MD, None, None), ("Approved", 1, "HR Manager", "approval_status", "Approved"),
		 ("Rejected", 0, "Employee", None, None)],
		[("Draft", "Submit for Approval", "Manager Review", "Employee", None),
		 ("Manager Review", "Approve", "Approved", "Expense Approver", 'doc.approval_level == "Manager" and not doc.claimant_is_md'),
		 ("Manager Review", "Review", "MD Review", "Expense Approver", 'doc.approval_level == "MD" or doc.claimant_is_md'),
		 ("MD Review", "Approve", "Approved", MD, None),
		 ("Manager Review", "Reject", "Rejected", "Expense Approver", None),
		 ("MD Review", "Reject", "Rejected", MD, None),
		 ("Rejected", "Revise", "Draft", "Employee", None)]),
	"Chem Payment": ("Payment Entry",
		[("Draft", 0, "Accounts User", None, None), ("Pending MD", 0, MD, None, None),
		 ("Submitted", 1, "Accounts Manager", None, None), ("Rejected", 0, "Accounts User", None, None)],
		[("Draft", "Submit", "Submitted", "Accounts User", LVL_NONE),
		 ("Draft", "Send for Approval", "Pending MD", "Accounts User", LVL_MD),
		 ("Pending MD", "Approve", "Submitted", MD, None), ("Pending MD", "Reject", "Rejected", MD, None),
		 ("Rejected", "Revise", "Draft", "Accounts User", None)]),
	"Chem Quotation": ("Quotation",
		[("Draft", 0, "Sales User", None, None), ("Pending Approval", 0, "Sales Manager", None, None),
		 ("Approved", 1, "Sales Manager", None, None), ("Rejected", 0, "Sales User", None, None)],
		[("Draft", "Submit", "Approved", "Sales User", LVL_NONE),
		 ("Draft", "Send for Approval", "Pending Approval", "Sales User", LVL_ANY),
		 ("Pending Approval", "Approve", "Approved", "Sales Manager", None),
		 ("Pending Approval", "Reject", "Rejected", "Sales Manager", None), ("Rejected", "Revise", "Draft", "Sales User", None)]),
	"Chem Sales Order": ("Sales Order",
		[("Draft", 0, "Sales User", None, None), ("Pending Approval", 0, "Sales Manager", None, None),
		 ("Approved", 1, "Sales Manager", None, None), ("Rejected", 0, "Sales User", None, None)],
		[("Draft", "Submit", "Approved", "Sales User", LVL_NONE),
		 ("Draft", "Send for Approval", "Pending Approval", "Sales User", LVL_ANY),
		 ("Pending Approval", "Approve", "Approved", "Sales Manager", None),
		 ("Pending Approval", "Reject", "Rejected", "Sales Manager", None), ("Rejected", "Revise", "Draft", "Sales User", None)]),
	"Chem Stock Reconciliation": ("Stock Reconciliation",
		[("Draft", 0, "Stock User", None, None), ("HSE Review", 0, "HSE Officer", None, None),
		 ("Plant Manager Review", 0, PM, None, None), ("Applied", 1, PM, None, None), ("Rejected", 0, "Stock User", None, None)],
		[("Draft", "Send for Review", "HSE Review", "Stock User", None), ("HSE Review", "Review", "Plant Manager Review", "HSE Officer", None),
		 ("Plant Manager Review", "Approve", "Applied", PM, None), ("HSE Review", "Reject", "Rejected", "HSE Officer", None),
		 ("Plant Manager Review", "Reject", "Rejected", PM, None), ("Rejected", "Revise", "Draft", "Stock User", None)]),
	"Chem Estimate Request": ("Estimate Request",
		[("Draft", 0, "Sales User", None, None), ("Pending Approval", 0, "Sales Manager", None, None),
		 ("Approved", 0, "Sales Manager", None, None), ("Rejected", 0, "Sales User", None, None)],
		[("Draft", "Confirm", "Approved", "Sales User", LVL_NONE),
		 ("Draft", "Send for Approval", "Pending Approval", "Sales User", LVL_MGR),
		 ("Pending Approval", "Approve", "Approved", "Sales Manager", None),
		 ("Pending Approval", "Reject", "Rejected", "Sales Manager", None), ("Rejected", "Revise", "Draft", "Sales User", None)]),
	"Chem Credit Limit": ("Credit Limit Request",
		[("Draft", 0, "Sales User", None, None), ("Pending MD", 0, MD, None, None), ("Applied", 1, MD, None, None),
		 ("Rejected", 0, "Sales User", None, None)],
		[("Draft", "Send to MD", "Pending MD", "Sales User", None), ("Pending MD", "Approve", "Applied", MD, None),
		 ("Pending MD", "Reject", "Rejected", MD, None), ("Rejected", "Revise", "Draft", "Sales User", None)]),
	"Chem Disposal": ("Disposal Order",
		[("Draft", 0, "Waste Officer", None, None), ("Compliance Review", 0, "HSE Officer", None, None),
		 ("MD Review", 0, MD, None, None), ("Approved", 1, MD, None, None), ("Rejected", 0, "Waste Officer", None, None)],
		[("Draft", "Send for Review", "Compliance Review", "Waste Officer", None),
		 ("Compliance Review", "Approve", "Approved", "HSE Officer", LVL_MGR),
		 ("Compliance Review", "Review", "MD Review", "HSE Officer", LVL_MD),
		 ("MD Review", "Approve", "Approved", MD, None),
		 ("Compliance Review", "Reject", "Rejected", "HSE Officer", None), ("MD Review", "Reject", "Rejected", MD, None),
		 ("Rejected", "Revise", "Draft", "Waste Officer", None)]),
	"Chem Status Override": ("Batch Status Override",
		[("Draft", 0, "QC Analyst", None, None), ("HSE Review", 0, "HSE Officer", None, None),
		 ("Plant Manager Review", 0, PM, None, None), ("Applied", 1, PM, None, None), ("Rejected", 0, "QC Analyst", None, None)],
		[("Draft", "Send for Review", "HSE Review", "QC Analyst", None), ("HSE Review", "Review", "Plant Manager Review", "HSE Officer", None),
		 ("Plant Manager Review", "Approve", "Applied", PM, None), ("HSE Review", "Reject", "Rejected", "HSE Officer", None),
		 ("Plant Manager Review", "Reject", "Rejected", PM, None), ("Rejected", "Revise", "Draft", "QC Analyst", None)]),
	"Chem SDS": ("SDS File",
		[("Draft", 0, "HSE Officer", None, None), ("Pending MD", 0, MD, None, None), ("Current", 1, MD, None, None),
		 ("Rejected", 0, "HSE Officer", None, None)],
		[("Draft", "Send to MD", "Pending MD", "HSE Officer", None), ("Pending MD", "Approve", "Current", MD, None),
		 ("Pending MD", "Reject", "Rejected", MD, None), ("Rejected", "Revise", "Draft", "HSE Officer", None)]),
	"Chem Calibration": ("Calibration Record",
		[("Draft", 0, "Maintenance Technician", None, None), ("Under Review", 0, "QC Analyst", None, None),
		 ("Completed", 1, PM, None, None)],
		[("Draft", "Send for Review", "Under Review", "Maintenance Technician", None),
		 ("Under Review", "Approve", "Completed", "QC Analyst", 'doc.equipment_category == "Laboratory Instrument"'),
		 ("Under Review", "Approve", "Completed", PM, None),
		 ("Under Review", "Return", "Draft", "QC Analyst", 'doc.equipment_category == "Laboratory Instrument"'),
		 ("Under Review", "Return", "Draft", PM, None)]),
	"Chem Internal Audit": ("Internal Audit",
		[("Draft", 0, "HSE Officer", None, None), ("MD Review", 0, MD, None, None), ("Report Issued", 1, MD, None, None)],
		[("Draft", "Submit Report", "MD Review", "HSE Officer", None),
		 ("MD Review", "Approve", "Report Issued", MD, None),
		 ("MD Review", "Return to Auditor", "Draft", MD, None)]),
	"Chem Supplier Evaluation": ("Supplier Evaluation",
		[("Draft", 0, "Purchase User", None, None), ("MD Review", 0, MD, None, None), ("Approved", 1, MD, None, None)],
		[("Draft", "Send for Approval", "MD Review", "Purchase User", None), ("MD Review", "Approve", "Approved", MD, None),
		 ("MD Review", "Return", "Draft", MD, None)]),
	"Chem Management Review": ("Management Review",
		[("Draft", 0, "HSE Officer", None, None), ("MD Review", 0, MD, None, None), ("Approved", 1, MD, None, None)],
		[("Draft", "Send for Approval", "MD Review", "HSE Officer", None), ("MD Review", "Approve", "Approved", MD, None),
		 ("MD Review", "Return", "Draft", MD, None)]),
	"Chem Water Analysis": ("Water Analysis",
		[("Draft", 0, "QC Analyst", None, None), ("Analyst Signed", 0, PM, None, None), ("Report Issued", 1, PM, None, None)],
		[("Draft", "Sign Results", "Analyst Signed", "QC Analyst", None),
		 ("Draft", "Sign Results", "Analyst Signed", "Field Technician", None),
		 ("Analyst Signed", "Approve Report", "Report Issued", PM, None),
		 ("Analyst Signed", "Return to Analyst", "Draft", PM, None)]),
	"Chem Return to Service": ("Return to Service",
		[("Draft", 0, "Manufacturing Manager", None, None), ("Plant Manager Review", 0, PM, None, None),
		 ("In Service", 1, PM, None, None), ("Rejected", 0, "Manufacturing Manager", None, None)],
		[("Draft", "Sign", "Plant Manager Review", "Manufacturing Manager", None), ("Draft", "Sign", "Plant Manager Review", "QC Analyst", None),
		 ("Plant Manager Review", "Approve", "In Service", PM, None), ("Plant Manager Review", "Reject", "Rejected", PM, None),
		 ("Rejected", "Revise", "Draft", "Manufacturing Manager", None)]),
}


RETIRED = {"Chem Expense Claim": "Chem Expense Claim v2"}  # earlier versions this app shipped


def md_direct_transition(states):
	final = next((s[0] for s in states if s[1] == 1), None) or "Approved"
	return ("Draft", MD_DIRECT, final, MD, "doc.raised_by_md")


def with_md_direct():
	"""Shipped workflows plus the MD's direct approval and, for every step the MD signs, the delegate's twin step."""
	from chemical_erp.controls.delegation import delegate_transitions

	out = {}
	for name, (doctype, states, transitions) in WORKFLOWS.items():
		transitions = list(transitions) + delegate_transitions(name, transitions)
		if name not in NO_MD_DIRECT:
			transitions = transitions + [md_direct_transition(states)]
		out[name] = (doctype, states, transitions)
	return out


def add_delegate_steps(wf):
	"""Existing workflows on site: give each step the MD signs a twin for the MD's delegate (once)."""
	from chemical_erp.controls.delegation import DELEGATE_ROLE, NO_DELEGATION_WORKFLOWS, NOT_DELEGATED_ACTIONS

	if wf.name in NO_DELEGATION_WORKFLOWS or not frappe.db.exists("Role", DELEGATE_ROLE):
		return False
	have = {(t.state, t.action, t.next_state) for t in wf.transitions if t.allowed == DELEGATE_ROLE}
	changed = False
	for t in list(wf.transitions):
		if t.allowed == MD and t.action not in NOT_DELEGATED_ACTIONS and (t.state, t.action, t.next_state) not in have:
			wf.append("transitions", {"state": t.state, "action": t.action, "next_state": t.next_state, "allowed": DELEGATE_ROLE,
			                          "condition": t.condition, "allow_self_approval": 0})
			have.add((t.state, t.action, t.next_state))
			changed = True
	return changed


def upgrade_existing():
	"""Bring workflows already on a site up to date: add the MD's direct approval, drop the retired Director route."""
	for name, (doctype, states, transitions) in with_md_direct().items():
		if not frappe.db.exists("Workflow", name):
			continue
		wf = frappe.get_doc("Workflow", name)
		changed = False
		for t in list(wf.transitions):
			if t.allowed == "Director":
				wf.remove(t)
				changed = True
		if name not in NO_MD_DIRECT and not any(t.action == MD_DIRECT for t in wf.transitions):
			f, a, n, r, c = md_direct_transition(states)
			if not frappe.db.exists("Workflow Action Master", a):
				frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": a}).insert(ignore_permissions=True)
			wf.append("transitions", {"state": f, "action": a, "next_state": n, "allowed": r, "condition": c, "allow_self_approval": 1})
			changed = True
		if name == "Chem Calibration":
			changed = _calibration_to_plant_manager(wf) or changed
		if name in PRODUCTION_WORKFLOWS | QUALITY_WORKFLOWS:
			for t in wf.transitions:
				if t.allowed == MD and t.action != MD_DIRECT:
					t.allowed, changed = PM, True
			for st in wf.states:
				if st.allow_edit == MD:
					st.allow_edit, changed = PM, True
		changed = add_delegate_steps(wf) or changed
		if changed:
			wf.flags.ignore_permissions = True
			wf.save()


def _calibration_to_plant_manager(wf):
	"""Plant equipment calibrations are accepted by the MD as Plant Manager, not the Production Supervisor."""
	changed = False
	for t in wf.transitions:
		if t.allowed == "Manufacturing Manager" and t.state == "Under Review":
			t.allowed = PM
			changed = True
		elif t.allowed == "QC Analyst" and t.state == "Under Review" and not t.condition:
			t.condition = 'doc.equipment_category == "Laboratory Instrument"'
			changed = True
	for st in wf.states:
		if st.state == "Completed" and st.allow_edit == "Manufacturing Manager":
			st.allow_edit = PM
			changed = True
	if changed and not any(t.action == "Return" and t.allowed == PM for t in wf.transitions):
		wf.append("transitions", {"state": "Under Review", "action": "Return", "next_state": "Draft", "allowed": PM, "allow_self_approval": 0})
	return changed


def ensure_workflows():
	for old, new in RETIRED.items():
		if frappe.db.exists("Workflow", old) and not frappe.db.exists("Workflow", new):
			frappe.db.set_value("Workflow", old, "is_active", 0)
	upgrade_existing()
	for name, (doctype, states, transitions) in with_md_direct().items():
		if not frappe.db.exists("DocType", doctype) or frappe.db.exists("Workflow", name):
			continue
		if frappe.db.exists("Workflow", {"document_type": doctype, "is_active": 1}):
			continue  # respect a workflow already active on site
		roles = {s[2] for s in states} | {t[3] for t in transitions}
		if any(not frappe.db.exists("Role", r) for r in roles):
			continue  # e.g. Expense Claim workflow when Frappe HR is not installed
		for s in states:
			if not frappe.db.exists("Workflow State", s[0]):
				frappe.get_doc({"doctype": "Workflow State", "workflow_state_name": s[0], "style": STYLE.get(s[0], "Primary")}).insert(ignore_permissions=True)
		for t in transitions:
			if not frappe.db.exists("Workflow Action Master", t[1]):
				frappe.get_doc({"doctype": "Workflow Action Master", "workflow_action_name": t[1]}).insert(ignore_permissions=True)
		frappe.get_doc({
			"doctype": "Workflow", "workflow_name": name, "document_type": doctype, "is_active": 1,
			"workflow_state_field": "workflow_state", "send_email_alert": 0,
			"states": [{"state": s, "doc_status": str(ds), "allow_edit": ed, "update_field": uf, "update_value": uv}
			           for s, ds, ed, uf, uv in states],
			"transitions": [{"state": f, "action": a, "next_state": n, "allowed": r, "condition": c,
			                 "allow_self_approval": 1 if (doctype == "BOM" or a in CREATOR_ACTIONS or a == MD_DIRECT) else 0} for f, a, n, r, c in transitions],
		}).insert(ignore_permissions=True)


def sync_quality_approver(role):
	"""Point quality workflows at the current quality approver (Plant Manager or QC Manager). Called when settings change."""
	for name in QUALITY_WORKFLOWS:
		if not frappe.db.exists("Workflow", name):
			continue
		wf = frappe.get_doc("Workflow", name)
		changed = False
		for t in wf.transitions:
			if t.allowed in ("Plant Manager", "QC Manager") and t.allowed != role:
				t.allowed, changed = role, True
		for st in wf.states:
			if st.allow_edit in ("Plant Manager", "QC Manager") and st.allow_edit != role:
				st.allow_edit, changed = role, True
		if changed:
			wf.flags.ignore_permissions = True
			wf.save()
