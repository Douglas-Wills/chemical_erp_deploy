"""Remove Demo Content: Cleanup script to delete all seeded demo data from Chemical ERP.

This script removes specific demo records created by seed_real_content.py, including:
- Demo customers, suppliers, items, employees
- Demo batches, work orders, invoices
- Demo HSE incidents, maintenance jobs, events, documents
"""

import frappe
from frappe import _


def remove_all_demo_data(dry_run=False):
	"""
	Remove all demo data seeded by seed_real_content.py
	
	Args:
		dry_run (bool): If True, only report what would be deleted without actually deleting
	"""
	frappe.set_user("Administrator")
	
	if not dry_run:
		print("\n" + "="*80)
		print("WARNING: This will DELETE demo data from the database!")
		print("="*80)
		print("\nDemo data to be removed:")
	else:
		print("\n" + "="*80)
		print("DRY RUN MODE - No data will be deleted")
		print("="*80)
		print("\nDemo data that would be removed:")
	
	stats = {
		"deleted": 0,
		"skipped": 0,
		"errors": 0
	}
	
	# 1. Remove Demo Customers
	demo_customers = [
		"Mukwano Industries Uganda",
		"Kakira Sugar Limited",
		"National Water & Sewerage Corp",
		"Tororo Cement Works",
		"Nile Breweries Jinja"
	]
	removed = _remove_records("Customer", {"name": ["in", demo_customers]}, dry_run, stats)
	print(f"\n✓ Customers: {removed} demo records")
	
	# 2. Remove Demo Suppliers
	demo_suppliers = [
		"Brenntag East Africa Ltd",
		"Desbro Uganda Limited",
		"Crown Packaging Industries"
	]
	removed = _remove_records("Supplier", {"name": ["in", demo_suppliers]}, dry_run, stats)
	print(f"✓ Suppliers: {removed} demo records")
	
	# 3. Remove Demo Items
	demo_items = [
		"CHEM-CS-50", "CHEM-HCL-33", "CHEM-NAOCL-15", "CHEM-ALUM-SOL",
		"CHEM-PAC-18", "RAW-SALT-IND", "RAW-BAUXITE", "PKG-IBC-1000L"
	]
	removed = _remove_records("Item", {"item_code": ["in", demo_items]}, dry_run, stats)
	print(f"✓ Items: {removed} demo records")
	
	# 4. Remove Demo Employees (by name matching)
	demo_employee_names = [
		{"first_name": "David", "last_name": "Kato"},
		{"first_name": "Sarah", "last_name": "Namubiru"},
		{"first_name": "Geoffrey", "last_name": "Okello"},
		{"first_name": "Grace", "last_name": "Atuhaire"},
		{"first_name": "Brian", "last_name": "Mugisha"}
	]
	emp_count = 0
	for emp in demo_employee_names:
		removed = _remove_records("Employee", emp, dry_run, stats)
		emp_count += removed
	print(f"✓ Employees: {emp_count} demo records")
	
	# 5. Remove Demo Batches (by batch ID pattern)
	demo_batch_patterns = [
		"BATCH-CS-2026-%", "BATCH-HCL-2026-%", "BATCH-NAOCL-2026%",
		"BATCH-ALUM-2026%", "BATCH-PAC-2026-%"
	]
	batch_count = 0
	for pattern in demo_batch_patterns:
		removed = _remove_records("Batch", {"batch_id": ["like", pattern]}, dry_run, stats)
		batch_count += removed
	print(f"✓ Batches: {batch_count} demo records")
	
	# 6. Remove Demo Work Orders (by production item)
	removed = _remove_records("Work Order", {"production_item": ["in", demo_items]}, dry_run, stats)
	print(f"✓ Work Orders: {removed} demo records")
	
	# 7. Remove Demo Sales Invoices (by customer)
	removed = _remove_records("Sales Invoice", {"customer": ["in", demo_customers]}, dry_run, stats)
	print(f"✓ Sales Invoices: {removed} demo records")
	
	# 8. Remove Demo Purchase Invoices (by supplier)
	removed = _remove_records("Purchase Invoice", {"supplier": ["in", demo_suppliers]}, dry_run, stats)
	print(f"✓ Purchase Invoices: {removed} demo records")
	
	# 9. Remove Demo HSE Incidents (if exists)
	if frappe.db.exists("DocType", "HSE Incident"):
		# Remove by description pattern matching
		incidents = frappe.get_all("HSE Incident", 
			filters=[
				["description", "like", "%Chemical splash goggles%"],
				["description", "like", "%sodium hypochlorite pipe flange%"]
			],
			or_filters=True,
			pluck="name"
		)
		if incidents:
			removed = _remove_records("HSE Incident", {"name": ["in", incidents]}, dry_run, stats)
			print(f"✓ HSE Incidents: {removed} demo records")
	
	# 10. Remove Demo Maintenance Jobs (if exists)
	if frappe.db.exists("DocType", "Maintenance Job"):
		demo_maint_tasks = [
			"Chlorine Neutralization Scrubber Pump Overhaul",
			"pH & Conductivity Analyzer Probe Recalibration",
			"Reactor Vessel R-101 Pressure Relief Valve Testing",
			"Bulk Chemical Storage Tank T-204 Wall Ultrasonic Thickness Scan"
		]
		removed = _remove_records("Maintenance Job", {"pm_task": ["in", demo_maint_tasks]}, dry_run, stats)
		print(f"✓ Maintenance Jobs: {removed} demo records")
	
	# 11. Remove Demo Events
	demo_event_subjects = [
		"Technical Site Water Sampling & Analysis Audit",
		"UNBS Annual Chemical Quality Surveillance Inspection",
		"Plant Safety & Hazardous Spill Response Emergency Drill",
		"Executive Management Review & IMS Quality Performance"
	]
	removed = _remove_records("Event", {"subject": ["in", demo_event_subjects]}, dry_run, stats)
	print(f"✓ Events: {removed} demo records")
	
	# 12. Remove Demo Chemical Documents (if exists)
	if frappe.db.exists("DocType", "Chemical Document"):
		demo_doc_titles = [
			"Material Safety Data Sheet (MSDS) - Caustic Soda Lye 50%",
			"Technical Data Sheet (TDS) - Industrial Hydrochloric Acid 33%",
			"Certificate of Analysis (COA) - Master Blend Batch 2026-001",
			"Confidential Formulation Specification - Poly Aluminium Chloride PAC-18",
			"NEMA Statutory Operating License & Environmental Approval"
		]
		removed = _remove_records("Chemical Document", {"title": ["in", demo_doc_titles]}, dry_run, stats)
		print(f"✓ Chemical Documents: {removed} demo records")
	
	# 13. Remove Demo Legal Requirements (if exists)
	if frappe.db.exists("DocType", "Legal Requirement"):
		demo_permits = [
			"NEMA Chemical Effluent Discharge Permit",
			"NDA Precursor & Controlled Chemical License",
			"UNBS Quality Certification Mark (Q-Mark)",
			"Factory Workplace Registration & Fire Certificate"
		]
		removed = _remove_records("Legal Requirement", {"licence_permit_filing": ["in", demo_permits]}, dry_run, stats)
		print(f"✓ Legal Requirements: {removed} demo records")
	
	# 14. Remove Demo Bank Account and GL Entries
	demo_bank = frappe.get_all("Account", 
		filters={"account_name": "Stanbic Bank Operating"},
		pluck="name"
	)
	if demo_bank:
		# Remove GL Entries for demo bank account
		removed = _remove_records("GL Entry", {"account": ["in", demo_bank]}, dry_run, stats)
		print(f"✓ GL Entries (Demo Bank): {removed} demo records")
		
		# Remove the demo bank account itself
		removed = _remove_records("Account", {"name": ["in", demo_bank]}, dry_run, stats)
		print(f"✓ Bank Accounts: {removed} demo records")
	
	# Summary
	print("\n" + "="*80)
	if dry_run:
		print("DRY RUN COMPLETE - No data was actually deleted")
	else:
		print("CLEANUP COMPLETE!")
		frappe.db.commit()
	print("="*80)
	print(f"\nStatistics:")
	print(f"  - Records deleted: {stats['deleted']}")
	print(f"  - Records skipped: {stats['skipped']}")
	print(f"  - Errors: {stats['errors']}")
	print("\nThe dashboard will now show only real operational data.")
	print("Empty metrics are expected if no real data exists yet.\n")
	
	return stats


def _remove_records(doctype, filters, dry_run, stats):
	"""
	Helper function to remove records matching filters.
	
	Args:
		doctype (str): The DocType to delete from
		filters (dict): Frappe filters to match records
		dry_run (bool): If True, only count without deleting
		stats (dict): Statistics dictionary to update
	
	Returns:
		int: Number of records removed (or would be removed in dry_run)
	"""
	try:
		if not frappe.db.exists("DocType", doctype):
			return 0
		
		records = frappe.get_all(doctype, filters=filters, pluck="name")
		
		if not records:
			return 0
		
		if dry_run:
			return len(records)
		
		# Delete records
		for name in records:
			try:
				# Use frappe.delete_doc for proper cascade deletion
				frappe.delete_doc(doctype, name, force=True, ignore_permissions=True)
				stats["deleted"] += 1
			except Exception as e:
				print(f"  Warning: Could not delete {doctype} '{name}': {str(e)}")
				stats["errors"] += 1
		
		return len(records)
	
	except Exception as e:
		print(f"  Error processing {doctype}: {str(e)}")
		stats["errors"] += 1
		return 0


def preview_demo_data():
	"""
	Preview what demo data would be removed without actually deleting.
	Safe to run anytime.
	"""
	print("\n" + "="*80)
	print("PREVIEW: Demo Data Detection")
	print("="*80)
	print("\nThis will show what demo records exist in your system.\n")
	
	return remove_all_demo_data(dry_run=True)


# Convenience functions for bench console
def dry_run():
	"""Run in dry-run mode to see what would be deleted"""
	return preview_demo_data()


def execute():
	"""Execute the cleanup (actually delete demo data)"""
	return remove_all_demo_data(dry_run=False)
