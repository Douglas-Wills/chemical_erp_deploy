"""Formatting helpers for Brave's sales and purchasing documents (Jinja methods), matching the current
quotation and invoice style: UGX750,000 amounts, '40 bags' quantities, amount in words ending in the currency."""

import re

import frappe
from frappe.utils import flt, in_words

NO_UNIT = {"nos", "no", "unit", "units", "each", "ea", "pcs", "pc", "piece", "pieces"}
NO_PLURAL = {"kg", "g", "mg", "l", "ltr", "litre", "liter", "ml", "m", "mm", "cm", "km", "ton", "tonne", "mt", "lb"}


def brave_money(amount, currency=None):
	currency = currency or "UGX"
	precision = 0 if currency in ("UGX", "KES", "TZS", "RWF") else 2
	text = f"{flt(amount, precision):,.{precision}f}"
	return f"{currency}{text}"


def brave_qty(qty, uom=None):
	q = flt(qty)
	shown = f"{q:,.0f}" if q == int(q) else f"{q:,.2f}".rstrip("0").rstrip(".")
	unit = (uom or "").strip()
	low = unit.lower()
	if not unit or low in NO_UNIT:
		return shown
	if q != 1 and low not in NO_PLURAL and not low.endswith("s"):
		low += "s"
	return f"{shown} {low}"


def brave_words(amount, currency=None):
	words = in_words(int(round(abs(flt(amount)))))  # credit notes: the title says credit, the words stay positive
	words = re.sub(r"[,\-]", " ", words).title()
	words = re.sub(r"\s+", " ", words).strip()
	return f"{words} {currency or 'UGX'}"


def brave_tax_label(t):
	desc = (t.get("description") or t.get("account_head") or "").split(" - ")[0].strip()
	if t.get("rate") and "vat" in desc.lower():
		return f"VAT ({flt(t.rate):g}%)"
	return desc


def brave_status(doc):
	"""Status shown under the document number: (text, colour)."""
	if doc.docstatus == 0:
		return "DRAFT", "#6b7280"
	if doc.docstatus == 2:
		return "CANCELLED", "#dc2626"
	status = (doc.get("status") or "").upper()
	colour = {"PAID": "#16a34a", "UNPAID": "#ef4444", "OVERDUE": "#ef4444", "PARTLY PAID": "#d97706",
	          "OPEN": "#2563eb", "ORDERED": "#16a34a", "LOST": "#6b7280", "EXPIRED": "#6b7280",
	          "TO RECEIVE AND BILL": "#2563eb", "TO BILL": "#2563eb", "TO RECEIVE": "#2563eb", "COMPLETED": "#16a34a",
	          "CLOSED": "#6b7280"}.get(status, "#6b7280")
	return status or "ISSUED", colour


def brave_agent(doc):
	team = doc.get("sales_team") or []
	if team and team[0].get("sales_person"):
		return team[0].sales_person
	return frappe.utils.get_fullname(doc.owner)


def brave_logo():
	"""Kept for older print formats: the logo now comes from the Company Profile."""
	from chemical_erp.company import company_logo

	return company_logo(None, wide=True)
